# Installing MaiaOS v1 on Akai MPC Sample

MaiaOS v1 is based on r109 and targets the Akai MPC Sample running stock firmware **1.3.0.12**. The public source preview contains source code and SD preparation tools. The `autorun` directory used by the MPC is generated locally.

> **Current installation requirement:** You need a locally held copy of `MaiaOS-r109-SD-completa-privata.zip` to prepare a bootable card. If you only have the public repository and stock firmware, you can build the MaiaOS host, but a full stock-only installation is not available yet.

## 1. Gather the files

- The extracted **MaiaOS v1 public source package**, which contains `prepare_sd.py` and `SRC/`.
- A local copy of **`MaiaOS-r109-SD-completa-privata.zip`**. Keep it zipped. The public repository does not provide this file.
- Python **3.9 or later** on your computer.
- A separate microSD card named **MPCSSH**. Back up any files before reformatting or replacing an existing launcher.

The MPC must be running the supported stock application when the SD launcher starts. You do not need SSH for the SD boot procedure.

## 2. Generate the SD files

Open a terminal in the extracted public source folder. The following example assumes that the local runtime ZIP is in Downloads. Adjust the paths if yours are different.

```sh
python3 prepare_sd.py \
  --runtime-locale "$HOME/Downloads/MaiaOS-r109-SD-completa-privata.zip" \
  --output "$HOME/Downloads/MaiaOS-v1-SD"
```

The tool verifies the runtime files and creates `MaiaOS-v1-SD/autorun`. Use a new output directory for each run. The tool refuses to overwrite an existing directory.

**Already running an internal r109 installation?** Add `--test-con-mod-interna` to the preparation command. This enables the SD test while preserving the internal installation. The launcher still checks that the stock app is running before switching to MaiaOS. Omit this option on a clean stock unit.

## 3. Boot the MPC

1. Copy the **generated `autorun` directory** to the root of the microSD card. For example, the launcher config should be at `MPCSSH/autorun/autorun.json`.
2. Eject the card from your computer. Power off the MPC, insert the card, then power it on.
3. The stock screen may appear first. The launcher checks the stock executable, reconstructs the MaiaOS application in RAM and starts it. Keep the card inserted during startup.

The candidate behind this procedure was tested on a unit with r109 installed internally while the stock app was running. A first boot on a unit with no internal MaiaOS installation still needs hardware verification.

## 4. Return to the previous boot setup

Power off the MPC, remove the test card and power it back on. The SD launcher uses a temporary mount and leaves the installed firmware intact. If you normally use another MaiaOS card, reinsert that card while the MPC is off.

## 5. Troubleshoot startup

With the MPC powered off, move the test card to your computer and open `autorun/maia-boot.log`.

| Symptom or log message | What to check |
| --- | --- |
| Stock boots and no log appears | Check the volume name and confirm that `autorun/autorun.json` is at the card root. |
| `Internal MaiaOS installed` | Regenerate the test card with `--test-con-mod-interna` if it is your existing r109 unit. |
| `Unsupported Akai application` | Check the exact stock firmware version. The installer checks the executable checksum as well as its size. |
| `Damaged SD package` | Copy a fresh, complete generated `autorun` folder to the card. |
| `maia.failed` exists | Save the log and resolve the reported issue. Delete `maia.failed` from the test card before retrying. |

## Building the host from public source

On Linux with Zig 0.14.1 and GNU C++ 14 headers, run the following from the public source directory:

```sh
cd SRC/host
MPC_ZIG=/absolute/path/to/zig python3 build_host.py
sh tests/run_linux.sh
```

The build outputs `bin/libpc-host.aarch64.so`. This builds the r109 host library. The SD preparation step still requires the local runtime.

## What belongs in the public repository

This preview includes source, preparation scripts and this guide. Keep stock firmware, the private runtime ZIP, native reference executables and the generated `autorun` directory out of the public repository and release downloads. The launcher templates in `SRC/sd/` are source files. The generated folder contains the local runtime and reconstruction data.
