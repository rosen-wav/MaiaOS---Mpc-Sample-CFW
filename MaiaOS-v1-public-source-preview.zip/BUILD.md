# Building and testing the r109 source preview

## Host

On Linux, install Python 3, Zig 0.14.1, GNU C++ 14 headers and a C/C++ compiler for the native tests. From the archive root, run:

```sh
cd SRC/host
MPC_ZIG=/absolute/path/to/zig python3 build_host.py
sh tests/run_linux.sh
```

The cross-build writes `bin/libpc-host.aarch64.so`. The Linux tests use synthetic data and do not require an Akai executable.

## Runtime modules

See [runtime build instructions](SRC/runtime/README.md) for AutoTune, the War Bells send and the CPU-affinity helper. These rebuilds need hardware integration testing. The private SD preparer verifies the hashes of the original r109 modules.

The SD launcher and startup logo source are in `SRC/sd/`. The ARM64 state-pointer slot for a future preload module is in `SRC/preload/shared_state.S`. Its publish/load path was tested separately at a relocatable address. The production native entry hooks are still separate.

## Stock-only release checklist

| Area | Current evidence and remaining work |
| --- | --- |
| Startup | A diagnostic preload on stock 1.3.0.12 reached audio and pad callbacks and displayed the logo. |
| Native integration | The stock process already maps the address used by the legacy shared state. Wire the production ARM64 hooks to the relocatable bridge and rebuild the remaining native fragments from reviewed source. |
| Runtime | Finish source builds and provenance review for WT Lite and the remaining DSP modules. Integrate all rebuilt modules with the SD launcher. |
| Hardware | Boot with only the public package and stock firmware on a unit with no internal MaiaOS install. Exercise the r109 feature set, including recording, MIDI, projects, synths, DJ audio, SD access and return to stock. |

Keep firmware, generated boot files, local references and private runtimes out of the public archive.
