#!/usr/bin/env python3
"""Prepare a local MaiaOS SD using stock and a verified local runtime."""
import argparse
import gzip
import hashlib
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
from zipfile import BadZipFile, ZipFile

from prepare_sd import APP_SIZE, SOURCES, STOCK_SHA, STOCK_SIZE, read_member

STOCK_FONTS_SHA = "431e5992652e98fc58cc322ab2eb7d10e23c976562fa5273d31f19dc2649eb14"
BLOCK_SIZE = 64
ZERO = bytes(BLOCK_SIZE)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_verified(path, size, expected):
    with path.open("rb") as stream:
        data = stream.read(size + 1)
    if len(data) != size or digest(data) != expected:
        raise ValueError(f"File non riconosciuto: {path}")
    return data

def make_recipe(stock, app, destination):
    with destination.open("wb") as file, gzip.GzipFile(filename="", mode="wb", fileobj=file, mtime=0) as stream:
        stream.write(b"MAIASD1\0")

        def emit(tag, start, end):
            stream.write(struct.pack("<cI", tag, end-start))
            if tag == b"C":
                stream.write(struct.pack("<I", start))
            elif tag == b"W":
                stream.write(app[start:end])

        start, previous = 0, None
        for position in range(0, len(app), BLOCK_SIZE):
            piece = app[position:position+BLOCK_SIZE]
            if piece == stock[position:position+len(piece)]:
                tag = b"C"
            elif piece == ZERO[:len(piece)]:
                tag = b"Z"
            else:
                tag = b"W"
            if tag != previous:
                if previous is not None:
                    emit(previous, start, position)
                start, previous = position, tag
        if previous is not None:
            emit(previous, start, len(app))

def prepare(args):
    out = args.output.expanduser()
    if out.exists() or out.is_symlink():
        raise ValueError(f"La destinazione esiste già: {out}")
    stock = read_verified(args.stock.expanduser(), STOCK_SIZE, STOCK_SHA)
    app = read_verified(args.native.expanduser(), APP_SIZE, STOCK_FONTS_SHA)
    inputs = {}
    for line in (SOURCES / "runtime-r109.sha256").read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        if name not in ("apply-delta", "app.delta.gz"):
            inputs[name] = expected
    with ZipFile(args.runtime_locale.expanduser()) as bundle:
        runtime = {name: read_member(bundle, name, expected) for name, expected in inputs.items()}

    with tempfile.TemporaryDirectory(prefix=".maia-stock-", dir=out.parent) as directory:
        stage = Path(directory) / "sd"
        autorun = stage / "autorun"
        autorun.mkdir(parents=True)
        for name, data in runtime.items():
            target = autorun / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        for name in ("autorun.sh", "autorun.json"):
            shutil.copyfile(SOURCES / name, autorun / name)
        worker = (SOURCES / "maia-start.sh").read_text()
        for previous, replacement in (("app.delta.gz", "app.recipe.gz"), ("apply-delta", "apply-recipe")):
            if previous not in worker:
                raise ValueError("Launcher di origine inatteso")
            worker = worker.replace(previous, replacement)
        (autorun / "maia-start.sh").write_text(worker)
        (autorun / "release.txt").write_text(f"{STOCK_SHA} {STOCK_SIZE} {STOCK_FONTS_SHA} {APP_SIZE}\n")
        make_recipe(stock, app, autorun / "app.recipe.gz")
        subprocess.run([args.zig, "cc", "-target", "aarch64-linux-musl", "-static", "-O2",
                        str(SOURCES / "apply_recipe.c"), "-o", str(autorun / "apply-recipe")], check=True)
        if args.test_con_mod_interna:
            (autorun / "test-with-internal").touch()
        controls = {"autorun.sh", "autorun.json", "autorun.check", "test-with-internal"}
        files = sorted(p for p in autorun.rglob("*") if p.is_file() and p.name not in controls)
        (autorun / "SHA256SUMS").write_text("".join(
            f"{digest(p.read_bytes())}  {p.relative_to(autorun).as_posix()}\n" for p in files))
        out.mkdir()
        try:
            autorun.rename(out / "autorun")
        except OSError:
            out.rmdir()
            raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stock", type=Path, required=True)
    parser.add_argument("--native", type=Path, required=True,
                        help="Riferimento locale r109 rigenerato con i font stock")
    parser.add_argument("--runtime-locale", type=Path, required=True,
                        help="ZIP privato della candidata r109 verificata")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--zig", default="zig")
    parser.add_argument("--test-con-mod-interna", action="store_true")
    args = parser.parse_args()
    try:
        prepare(args)
    except (OSError, ValueError, BadZipFile, subprocess.CalledProcessError) as error:
        parser.exit(1, f"Preparazione interrotta: {error}\n")
    print(f"Pronto per il test: {args.output.expanduser() / 'autorun'}")

if __name__ == "__main__":
    main()
