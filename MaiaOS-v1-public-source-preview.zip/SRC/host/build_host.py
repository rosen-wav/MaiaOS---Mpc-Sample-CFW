from pathlib import Path
import subprocess,os,time,tempfile,hashlib,json
r=Path(__file__).resolve().parent;zig=Path(__import__('os').environ['MPC_ZIG']).resolve();(r/'build').mkdir(exist_ok=True);obj=Path(tempfile.mkdtemp(prefix='host-r39-',dir=r/'build'))
(r/'bin').mkdir(exist_ok=True)
files=['build_features','fx_worker','performance','cpu_pressure','quantize_poly','fm6','stock_filter','synth_filter','tempo_font','padfx_record','import_view','diagnostics','host','ui','persistence','presets','sidechain','project_state','platform','preview','mix','mix_state','ms_context','audio_features','tune_follow','click_wav','bounce_job','bounce_sequence','bounce_history','bounce_ui','native_audio','input_config_view','new_engines','user_presets','editorial_sequencer','groove','groove_patterns','harmony_groove','groove_store','drumkit','drumkit_files','sd_path','sd_access','usb_cue','chord_browser','chord_files','roll_view','syx_parse','syx_backend','syx_browser','editorial_native_fx','flex_clock','sample_playback','sequence_take','rs_import','limiter','dj_mode','dj_analysis','dj_prepare','dj_playback','mastering2','airwindows','pressure6','pressure6_native','dj_qm','mixxx_beatutils','multisamples']
qmroot=r/'vendor/qm-dsp'
qm_sources=['dsp/onsets/DetectionFunction.cpp','dsp/phasevocoder/PhaseVocoder.cpp','dsp/transforms/FFT.cpp','dsp/tempotracking/TempoTrackV2.cpp','maths/MathUtilities.cpp','ext/kissfft/kiss_fft.c','ext/kissfft/tools/kiss_fftr.c']
# Use target glibc headers and the GNU C++ ABI already supplied by stock.
gnu_cpp=Path(os.environ.get('MPC_GNU_CPP','/usr/include/c++/14'))
gnu_config=Path(os.environ.get('MPC_GNU_CONFIG','/usr/include/x86_64-linux-gnu/c++/14'))
cpp_includes=['-fgnuc-version=4.2.1','-std=c++17','-fcxx-exceptions','-fexceptions','-isystem',str(gnu_cpp),'-isystem',str(gnu_config)]
for folder in ['aarch64-linux-gnu','generic-glibc','aarch64-linux-any','any-linux-any']:
 cpp_includes+=['-isystem',str(zig.parent/'lib/libc/include'/folder)]
for name in files:
 source=r/'src'/(name+('.cpp' if name in ('mastering2','airwindows','pressure6','dj_qm','mixxx_beatutils') else '.c'))
 options=['-x','c++','-fno-rtti'] if name in ('mastering2','airwindows','pressure6','dj_qm','mixxx_beatutils') else []
 if name in ('dj_qm','mixxx_beatutils'): options+=cpp_includes+['-I'+str(qmroot)]
 subprocess.run([str(zig),'clang','-cc1','-triple','aarch64-unknown-linux-gnu','-emit-obj',*([] if name in ('dj_qm','mixxx_beatutils') else ['-ffreestanding']),'-fno-builtin','-fwrapv','-mno-outline-atomics','-pic-level','2','-fvisibility=hidden','-O2','-internal-isystem',str(zig.parent/'lib/include'),'-I'+str(r/'src'),'-I'+str(r/'dsp/source/adapter'),*options,str(source),'-o',str(obj/f'{name}.o')],check=True)
qmobjects=[]
for index,rel in enumerate(qm_sources):
 source=qmroot/rel;out=obj/f'qm-{index}.o';qmobjects.append(str(out))
 opts=cpp_includes+['-x','c++','-fno-rtti'] if source.suffix=='.cpp' else cpp_includes[cpp_includes.index('-isystem'):] # C libc headers only
 if source.suffix=='.c':
  opts=[]
  for folder in ['aarch64-linux-gnu','generic-glibc','aarch64-linux-any','any-linux-any']:opts+=['-isystem',str(zig.parent/'lib/libc/include'/folder)]
 subprocess.run([str(zig),'clang','-cc1','-triple','aarch64-unknown-linux-gnu','-emit-obj','-O2','-pic-level','2','-fvisibility=hidden','-mno-outline-atomics','-internal-isystem',str(zig.parent/'lib/include'),'-I'+str(qmroot),'-Dkiss_fft_scalar=double',*opts,str(source),'-o',str(out)],check=True)
subprocess.run([str(zig),'ld.lld','-shared','-Bsymbolic','-o',str(obj/'libpc-host.aarch64.so')]+[str(obj/f'{n}.o') for n in files]+qmobjects,check=True)
target=r/'bin/libpc-host.aarch64.so'
compiled=obj/'libpc-host.aarch64.so'
stamp=max(time.time(),target.stat().st_mtime+1 if target.exists() else 0,3000005200)
os.utime(compiled,(stamp,stamp));os.replace(compiled,target)
record={'binary_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'objects':{},'sources':{}}
for name in files:
 record['objects'][name]=hashlib.sha256((obj/f'{name}.o').read_bytes()).hexdigest()
 record['sources'][name]=hashlib.sha256((r/'src'/(name+('.cpp' if name in ('mastering2','airwindows','pressure6','dj_qm','mixxx_beatutils') else '.c'))).read_bytes()).hexdigest()
record['qm_sources']={rel:hashlib.sha256((qmroot/rel).read_bytes()).hexdigest() for rel in qm_sources}
p=r/'build/build-host-r39.json';p.write_text(json.dumps(record,indent=2));os.utime(p,(stamp,stamp))
print('Built fresh ARM64 host',record['binary_sha256'])
