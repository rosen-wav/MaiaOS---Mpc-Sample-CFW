/* SPDX-License-Identifier: AGPL-3.0-only */
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Create/destroy off the audio thread. Instance exclusively owned by audio
 * except atomic set_control/enable. No Akai hooks are installed by this module. */
void *mpc_autotune_create(double sample_rate);
void mpc_autotune_destroy(void *);
void mpc_autotune_enable(void *,unsigned enabled);
void mpc_autotune_set_control(void *,unsigned control,unsigned position);
unsigned mpc_autotune_get_control(void *,unsigned control);
void mpc_autotune_process(void *,float *left,float *right,unsigned frames);
unsigned mpc_autotune_latency_floor(void *);
#ifdef __cplusplus
}
#endif
