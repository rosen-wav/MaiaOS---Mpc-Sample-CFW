/* SPDX-License-Identifier: AGPL-3.0-only */
#include "mpc_autotune.h"
#include "../vendor/TuneEngine.h"
#include <new>
#include "octave_shifter.h"
#define API __attribute__((visibility("default")))
namespace {
constexpr unsigned block=128,maximum=16383;
struct State {
 tune::Engine base;
 OctaveShifter octave;
 std::atomic<unsigned> controls[6],enabled{0},harmony{0};
 float gain=0;
 bool wasEnabled=false,wasDoubled=false;
 State(double sr) {
  const unsigned defaults[6]={0,0,819,0,0,8192};
  for(unsigned i=0;i<6;i++)controls[i].store(defaults[i]);
  tune::Params p;p.liveMode=true;p.formantPreserve=false;p.throat=1;p.mix=1;p.scale=1;
  base.setParams(p);base.prepare(sr,2);octave.prepare(sr);
 }
};
}
extern "C" API void *mpc_autotune_create(double sr){if(!tune::Engine::isSupportedRate(sr))return nullptr;try{return new State(sr);}catch(...){return nullptr;}}
extern "C" API void mpc_autotune_destroy(void*v){delete static_cast<State*>(v);}
extern "C" API void mpc_autotune_enable(void*v,unsigned x){if(v)static_cast<State*>(v)->enabled.store(!!x,std::memory_order_release);}
extern "C" API void mpc_autotune_set_control(void*v,unsigned k,unsigned x){if(v&&k<6)static_cast<State*>(v)->controls[k].store(std::min(x,maximum),std::memory_order_relaxed);}
extern "C" API unsigned mpc_autotune_get_control(void*v,unsigned k){return v&&k<6?static_cast<State*>(v)->controls[k].load(std::memory_order_relaxed):0;}
extern "C" API unsigned mpc_autotune_latency_floor(void*v){return v?static_cast<State*>(v)->base.getLatencySamples(true):0;}
/* Atomic packed control: no MIDI collections or inference in the DSP. */
extern "C" API unsigned mpc_autotune_harmony_version(){return 1;}
extern "C" API void mpc_autotune_set_harmony(void*v,unsigned packed){if(v)static_cast<State*>(v)->harmony.store(packed,std::memory_order_release);}
extern "C" API void mpc_autotune_process(void*v,float*l,float*r,unsigned n){
 if(!v||!l||!r)return;auto&s=*static_cast<State*>(v);
 if(!s.enabled.load(std::memory_order_acquire)){s.wasEnabled=false;s.wasDoubled=false;s.gain=0;return;}
 if(!s.wasEnabled){s.base.reset();s.octave.reset();s.wasEnabled=true;}
 unsigned c[6];for(unsigned k=0;k<6;k++)c[k]=s.controls[k].load(std::memory_order_relaxed);
 tune::Params p;p.liveMode=true;p.formantPreserve=false;p.throat=1;p.mix=1;
 p.key=std::min(11u,c[0]*12/(maximum+1));static constexpr int scales[]={1,2,0,10};p.scale=scales[std::min(3u,c[1]*4/(maximum+1))];
 const unsigned harmony=s.harmony.load(std::memory_order_acquire);
 if(harmony&0x100u){p.key=std::min(11u,harmony&15u);p.scale=(harmony&16u)?2:1;}else if(harmony&512u)p.scale=0;
 p.retuneMs=c[2]*400.f/maximum;p.transitionMs=c[3]*400.f/maximum;
 s.base.setParams(p);
 const bool doubled=c[4]>=8192;
 if(doubled&&!s.wasDoubled&&s.gain==0)s.octave.reset();
 s.wasDoubled=doubled;
 const float blend=c[5]/float(maximum);
 const float ramp=1.f/float(s.base.getSampleRate()*.01);
 for(unsigned at=0;at<n;at+=block){unsigned count=std::min(block,n-at);
  float*base[]={l+at,r+at};s.base.process(base,2,count);
  for(unsigned i=0;i<count;i++){
   float highL=0,highR=0;
   if(doubled||s.gain>0)s.octave.process(l[at+i],r[at+i],highL,highR);
   const float target=doubled&&s.octave.ready()?blend:0.f;
   s.gain+=std::clamp(target-s.gain,-ramp,ramp);
   l[at+i]=l[at+i]*(1-s.gain)+highL*s.gain;
   r[at+i]=r[at+i]*(1-s.gain)+highR*s.gain;
  }
 }
}
