/* SPDX-License-Identifier: AGPL-3.0-only */
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
// Two crossfaded fractional-delay taps, fixed ratio 2. No detector, FFT,
// heap allocation or formant stage; a shared phase keeps stereo coherent.
struct OctaveShifter {
 static constexpr unsigned capacity=16384;
 std::array<std::array<float,capacity>,2> ring{};
 unsigned write=0,filled=0,window=4096;
 float phase=0;
 void prepare(double rate){window=std::clamp(unsigned(rate*(4096./44100.)+.5),512u,12000u);reset();}
 void reset(){for(auto&c:ring)c.fill(0);write=filled=0;phase=0;}
 bool ready()const{return filled>=window+34;}
 float read(unsigned channel,float ph)const{
  float at=float(write+capacity)-(32.f+(1.f-ph)*float(window));
  unsigned whole=unsigned(at);float frac=at-float(whole);
  const auto&b=ring[channel];float a=b[whole&(capacity-1)],v=b[(whole+1)&(capacity-1)];return a+(v-a)*frac;
 }
 void process(float l,float r,float&ol,float&orr){
  ring[0][write]=l;ring[1][write]=r;
  float other=phase+.5f;if(other>=1)other-=1;
  float weight=1.f-std::abs(2.f*phase-1.f);
  ol=read(0,phase)*weight+read(0,other)*(1.f-weight);
  orr=read(1,phase)*weight+read(1,other)*(1.f-weight);
  write=(write+1)&(capacity-1);filled=std::min(capacity,filled+1);
  phase+=1.f/float(window);if(phase>=1)phase-=1;
 }
};
