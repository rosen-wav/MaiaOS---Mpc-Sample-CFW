#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
CXX=${CXX:-aarch64-linux-gnu-g++}
"$CXX" -std=c++17 -O3 -fPIC -shared -static-libstdc++ -static-libgcc -ffunction-sections -fdata-sections -Wl,--gc-sections -Wl,--exclude-libs,ALL -mno-outline-atomics -fvisibility=hidden "$HERE/src/mpc_autotune.cpp" -o "$HERE/libmpc-autotune.aarch64.so"
# Release used GCC 9.3 with an ARM64 glibc 2.31 sysroot. Recheck versioned
# dependencies before distributing a rebuild made with a newer toolchain.
