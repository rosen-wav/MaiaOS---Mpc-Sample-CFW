#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>
#include "internal.h"
#include "groove_store.h"
static char root[128];
static const char*translate(long raw,char*p){const char*s=(const char*)raw;const char*prefix="/media/MPCSSH/grooves";assert(!strncmp(s,prefix,strlen(prefix)));snprintf(p,256,"%s%s",root,s+strlen(prefix));return p;}
long pc_sys(long n,long a,long b,long c,long d,long e,long f){
 (void)f;long result;char p[256],q[256];
 switch(n){
 case 56:{int flags=c;flags&=~(0x8000|0x4000|0x20000);if(c&0x8000)flags|=O_NOFOLLOW;if(c&0x4000)flags|=O_DIRECTORY;result=openat(a,translate(b,p),flags,d);break;}
 case 57:result=close(a);break;
 case 63:result=read(a,(void*)b,c);break;
 case 64:result=write(a,(void*)b,c);break;
 case 82:result=fsync(a);break;
 case 34:result=mkdirat(a,translate(b,p),c);break;
 case 35:result=unlinkat(a,translate(b,p),c);break;
 case 276:result=syscall(SYS_renameat2,a,translate(b,p),c,translate(d,q),e);break;
 default:assert(0);
 }return result<0?-errno:result;
}
static PcStoredGroove a,b;
int main(void){
 char temp[]="/tmp/maia-grooves-XXXXXX";assert(mkdtemp(temp));snprintf(root,sizeof root,"%s/patterns",temp);
 strcpy(a.name,"Test hats");a.span=3840;a.count=3;a.hits[0]=(PcStoredHit){0,1,0};a.hits[1]=(PcStoredHit){490,.3f,0};a.hits[2]=(PcStoredHit){3100,.8f,0};
 assert(pc_groove_read(2,0,0,0)==0);assert(pc_groove_write(2,0,&a));assert(!pc_groove_write(2,0,&a));
 char name[25];assert(pc_groove_read(2,0,&b,name)==1);assert(!strcmp(name,a.name)&&b.span==a.span&&b.count==3&&!memcmp(b.hits,a.hits,3*sizeof(PcStoredHit)));
 char file[256];snprintf(file,sizeof file,"%s/Hi-hat/000.pcg",root);int fd=open(file,O_RDWR);assert(fd>=0);char bad=1;assert(pwrite(fd,&bad,1,70)==1);close(fd);assert(pc_groove_read(2,0,&b,0)==-1);
 assert(!pc_groove_write(4,0,&a));assert(pc_groove_read(2,128,0,0)==-1);
 puts("groove save, read, no-overwrite and corruption checks passed");
}
