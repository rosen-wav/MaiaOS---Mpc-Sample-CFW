"""Check all live-input vtable relays against the installed ARM64 executable."""
import argparse,struct
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
p=argparse.ArgumentParser();p.add_argument('--native',required=True);p.add_argument('--host',required=True);args=p.parse_args()
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x7800000);u.mem_map(0x10000000,0x1000000);u.mem_map(0x20000000,0x100000)
symbols={}
for path,base in [(args.native,0),(args.host,0x10000000)]:
 e=ELFFile(open(path,'rb'))
 for s in e.iter_segments():
  if s['p_type']=='PT_LOAD':u.mem_write(base+s['p_vaddr'],s.data())
 if base:
  for r in e.get_section_by_name('.rela.dyn').iter_relocations():
   if r['r_info_type']==1027:u.mem_write(base+r['r_offset'],struct.pack('<Q',base+r['r_addend']))
  symbols={s.name:base+s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols() if s['st_value']}
sites=[0x6e3b0b8,0x6ec6d48,0x6ec7460,0x6eca1e8]
before={a:bytes(u.mem_read(a-8,24)) for a in sites}
for a in sites:assert struct.unpack('<Q',u.mem_read(a,8))[0]==0x286fcf0
calls=[]
def hook(uc,pc,size,data):
 if pc==0x20000000:uc.emu_stop()
 if pc==symbols['pc_sys']:
  calls.append([uc.reg_read(UC_ARM64_REG_X0+i) for i in range(4)])
  uc.reg_write(UC_ARM64_REG_X0,0);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))
u.hook_add(UC_HOOK_CODE,hook)
u.reg_write(UC_ARM64_REG_SP,0x200ff000);u.reg_write(UC_ARM64_REG_LR,0x20000000);u.reg_write(UC_ARM64_REG_X0,4096)
u.emu_start(symbols['install_live_input'],0x20000004,count=100000)
for a in sites:
 assert struct.unpack('<Q',u.mem_read(a,8))[0]==symbols['pc_synth_live_input']
 assert bytes(u.mem_read(a-8,8))==before[a][:8] and bytes(u.mem_read(a+8,8))==before[a][16:]
assert len(calls)==8 and all(c[0]==226 for c in calls)
print('All four ARM64 live-input relays match the installed executable and preserve adjacent vtable entries')
