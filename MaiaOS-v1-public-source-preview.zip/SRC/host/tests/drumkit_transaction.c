#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include "../src/drumkit.c"
int pc_sd_folder(char*out,unsigned cap,const char*suffix){assert(!strcmp(suffix,"MPC-Sample/Samples/"));snprintf(out,cap,"/media/az01-internal-sd/%s",suffix);return 1;}
Host host;static uintptr_t project,program,behaviour,instruments[128],factory,loader,group,pad_controller,surface,raw;
static uintptr_t saved[128];static int volumes[128];static unsigned roles[128],assigned,committed,undone,fail_at,decoded,bank_switches;
static unsigned ordinal(uintptr_t i){for(unsigned n=0;n<128;n++)if(instruments[n]==i)return n;assert(0);return 0;}
int pc_valid(uintptr_t p,uintptr_t i){return p==program&&i&&Q(i,0x2310)==program;}
int pc_find(uintptr_t i){(void)i;return -1;}
uint64_t pc_mix_default(void){return (uint64_t)601<<42;}
uint64_t pc_mix_controls(uintptr_t i){return (uint64_t)(volumes[ordinal(i)]+601)<<42;}
int pc_mix_set_volume(uintptr_t p,uintptr_t i,int db){assert(p==program);volumes[ordinal(i)]=db;return 1;}
int pc_mix_set_controls(uintptr_t p,uintptr_t i,uint64_t c){assert(p==program);volumes[ordinal(i)]=(int)(c>>42)-601;return 1;}
unsigned pc_sc_role(uintptr_t i){return roles[ordinal(i)];}
int pc_sc_set(uintptr_t p,uintptr_t i,unsigned role){assert(p==program);roles[ordinal(i)]=role;return 1;}
void pc_sc_forget(uintptr_t i,uintptr_t p){(void)p;roles[ordinal(i)]=0;}
void pc_mix_route_program(uintptr_t p){assert(p==program);}
void pc_light_refresh(void){}
void pc_diag_value(unsigned key,unsigned value){(void)key;(void)value;}
void pc_diag_add(unsigned key){(void)key;}
unsigned pc_sample_default_mode(uintptr_t sample){(void)sample;return 0;}
uintptr_t pc_bounce_service(uintptr_t type){return type==host.base+0x6e08dd0?loader:factory;}
unsigned pc_kit_gain_group(unsigned n){return n<2?0:n<7?1:2;}
const uint8_t pc_kit_category[16]={0,0,1,1,1,2,2,3,3,3,3,4,4,4,5,5};
const char*const pc_kit_folders[6]={"Kick","Snare","Claps","Hats","Perc","Cymbals"};
int pc_kit_pick(const char*r,uint16_t locked,uint32_t seed,char paths[16][PC_KIT_PATH],unsigned*f){(void)seed;(void)f;assert(!strcmp(r,"/media/az01-internal-sd/MPC-Sample/Samples/"));for(unsigned n=0;n<16;n++)snprintf(paths[n],PC_KIT_PATH,"%u-%u.wav",locked,n);return 1;}
long pc_sys(long n,long a,long b,long c,long d,long e,long f){(void)a;(void)c;(void)d;(void)e;(void)f;assert(n==113);static unsigned tick;((long*)b)[0]=1;((long*)b)[1]=++tick;return 0;}
static void string_new(uintptr_t*out,const char*text){*out=(uintptr_t)text;}
static void string_empty(uintptr_t*out){*out=0;}
static void string_free(uintptr_t*out){*out=0;}
static PcNativeReturn load(uintptr_t l,uintptr_t*path,float rate){assert(l==loader&&*path&&rate==44100);PcNativeReturn sample={0};sample.object=(uintptr_t)calloc(1,32);sample.owner=sample.object;decoded++;return sample;}
static void release_owner(uintptr_t p){(void)p;}
static PcNativeTransaction begin(uintptr_t manager,uintptr_t*title,uintptr_t*merge){(void)title;(void)merge;assert(manager==factory+0x100);I(group,0x28)=1;assigned=0;for(unsigned n=0;n<128;n++)saved[n]=sample(instruments[n]);PcNativeTransaction t={.group=group,.processor=group+0x80};return t;}
static void add(uintptr_t f,PcNativeReturn*s){assert(f==factory&&s->object);I(group,0x28)=0;}
static void assign(uintptr_t f,uintptr_t p,PcNativeReturn*s,unsigned index,int layer){assert(f==factory&&p==program&&index>=32&&index<48&&layer==-1);assigned++;if(fail_at&&assigned==fail_at){I(group,0x28)=2;return;}Q(Q(instruments[index],0x22e8),0x4a8)=s->object;I(group,0x28)=0;}
static void poly(uintptr_t i,unsigned mode){assert(i&&mode==0);}
static int undo(uintptr_t g){assert(g==group);for(unsigned n=0;n<128;n++)Q(Q(instruments[n],0x22e8),0x4a8)=saved[n];undone++;return 0;}
static void discard(uintptr_t p,unsigned on){assert(p==group+0x80&&on==1);}
static void commit(PcNativeTransaction*t){assert(t->group==group);t->processor=0;committed++;}
static void select_bank(uintptr_t controller,unsigned source){
 assert(controller==pad_controller&&source==32);
 bank_switches++;
}
static void colour_set(uintptr_t property,const uint64_t*colour){(void)property;(void)colour;}
static void select_pad(uintptr_t prop,int index){assert(prop==project+0x4b0);I(project,0x500)=index;}
static void trampoline(uintptr_t offset,void*fn){uint8_t*p=(uint8_t*)(host.base+offset);p[0]=0x48;p[1]=0xb8;memcpy(p+2,&fn,8);p[10]=0xff;p[11]=0xe0;}
int main(void){host.base=(uintptr_t)mmap(0,0x7300000,7,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(host.base!=(uintptr_t)MAP_FAILED);static PcDebug debug;host.debug=&debug;program=(uintptr_t)calloc(1,0x3000);project=(uintptr_t)calloc(1,0x800);behaviour=(uintptr_t)calloc(1,0x280);pad_controller=(uintptr_t)calloc(1,0x200);
 surface=(uintptr_t)calloc(1,0x3000);raw=(uintptr_t)calloc(16,0x128);Q(behaviour,0x78)=surface;I(surface,0x29d0)=16;Q(surface,0x29d8)=raw;
 Q(behaviour,0)=host.base+0x6d8bee8;Q(behaviour,0x270)=pad_controller,surface,raw;Q(pad_controller,0)=host.base+0x6d98388;I(pad_controller,0x1c0)=128;factory=(uintptr_t)calloc(1,0x200);loader=(uintptr_t)calloc(1,16);group=(uintptr_t)calloc(1,0x200);
 Q(factory,0x28)=project;Q(factory,0x60)=factory+0x100;Q(program,0)=host.base+0x6ec6860;Q(project,0)=host.base+0x6ecc648;Q(project,0xb8)=program;Q(host.base+G,0x1d08)=project;Q(host.base+G,0x20)=behaviour;Q(program,0x2808)=(uintptr_t)instruments;Q(program,0x2810)=(uintptr_t)(instruments+128);
 for(unsigned n=0;n<128;n++){I(program,0x12a8+4*n)=n;I(program,0x14a8+4*n)=n;instruments[n]=(uintptr_t)calloc(1,0x2400);Q(instruments[n],0x2310)=program;Q(instruments[n],0x22e8)=(uintptr_t)calloc(8,0xb30);}Q(Q(instruments[0],0x22e8),0x4a8)=1234;
 trampoline(0xf535c0,string_new);trampoline(0xf1c620,string_empty);trampoline(0xf0a290,string_free);trampoline(0x1df3db0,load);trampoline(0x123bca0,release_owner);trampoline(0x19d0520,begin);trampoline(0x195bbb0,add);trampoline(0x195e940,assign);trampoline(0x2806c90,poly);trampoline(0x19c9c40,undo);trampoline(0x19cea40,discard);trampoline(0x19cc6b0,commit);trampoline(0x13b3740,select_pad);trampoline(0x1a395e0,select_bank);trampoline(0x13be8b0,colour_set);
 Q(Q(instruments[16],0x22e8),0x4a8)=2345;
 assert(pc_drumkit_open(program,0)&&kit.page==2&&bank_switches==1&&host.ui.source==32);pc_drumkit_event(12,2);assert(assigned==16&&committed==1&&(kit.input&KIT_LOADED));assert(roles[32]==1&&roles[33]==1&&roles[34]==0&&sample(instruments[0])==1234);
 pc_drumkit_lock_edit();assert(pc_drumkit_pressure(raw,.5f)&&pc_drumkit_pressure(raw,.9f)&&pc_drumkit_pressure(raw,0.f));assert(!pc_drumkit_pad(16,0));assert(pc_drumkit_pressure(raw+7*0x128,.5f)&&pc_drumkit_pressure(raw+7*0x128,.9f)&&pc_drumkit_pressure(raw+7*0x128,0.f));assert((kit.input&KIT_LOCKED_MASK)==129);pc_drumkit_lock_edit();assert(!(kit.input&KIT_EDIT)&&(kit.input&KIT_LOCKED_MASK)==129);assert(pc_drumkit_hw_colour(raw+0x20,0)==0x3f80000000ffff00ull&&pc_drumkit_hw_colour(raw+7*0x128+0x20,0)==0x3f80000000ffff00ull);assert(pc_drumkit_hw_colour(raw+0x128+0x20,123)==123&&pc_drumkit_hw_colour(raw+8,123)==123);uintptr_t kick=sample(instruments[32]),hat=sample(instruments[39]);pc_drumkit_event(12,2);assert(pc_drumkit_hw_colour(raw+0x20,0)==0x3f80000000ffff00ull&&pc_drumkit_hw_colour(raw+7*0x128+0x20,0)==0x3f80000000ffff00ull);assert(assigned==14&&sample(instruments[32])==kick&&sample(instruments[39])==hat);
 pc_drumkit_event(13,10922);pc_drumkit_event(13,14000);assert(volumes[32]>0&&volumes[33]==volumes[32]);
 uintptr_t before[16];for(unsigned n=0;n<16;n++)before[n]=sample(instruments[32+n]);fail_at=5;pc_drumkit_event(12,2);assert(undone==1&&committed==2);for(unsigned n=0;n<16;n++)assert(sample(instruments[32+n])==before[n]);
 pc_drumkit_lock_edit();pc_drumkit_pad(32,0);assert((kit.input&KIT_LOCKED_MASK)==128&&pc_drumkit_hw_colour(raw+0x20,123)==123);pc_drumkit_pad(39,0);assert(!(kit.input&KIT_LOCKED_MASK)&&pc_drumkit_hw_colour(raw+7*0x128+0x20,123)==123);pc_drumkit_event(12,0);assert(!pc_drumkit_active()&&I(project,0x500)==39&&pc_drumkit_hw_colour(raw+7*0x128+0x20,123)==123);for(unsigned page=3;page<8;page++)Q(Q(instruments[page*16],0x22e8),0x4a8)=1234;
 assert(!pc_drumkit_open(program,32)&&!strcmp(host.ui.message,"No bank with 16 free pads")&&bank_switches==1);
 puts("DRUMKIT first-free-bank selection and all-banks-occupied alert, full-page import, locks, native gains, sidechain sends and failed-import rollback passed");
}
