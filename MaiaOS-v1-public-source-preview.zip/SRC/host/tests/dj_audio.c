#define _GNU_SOURCE
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include "../src/dj_playback.c"

static unsigned monitor_enabled;
static float monitor_left[4096],monitor_right[4096];
unsigned pc_usb_cue_enabled(void){return monitor_enabled;}
void pc_usb_cue_publish(const float*l,const float*r,unsigned n){
 memcpy(monitor_left,l,n*4);memcpy(monitor_right,r,n*4);
}
Host host;
void pc_mix_dj_fallback(float*l,float*r,unsigned o,unsigned n){(void)l;(void)r;(void)o;(void)n;}
unsigned pc_dj_space_active(void){return 0;}
void pc_dj_space_process(float *l,float *r,unsigned n,unsigned p,unsigned e){(void)l;(void)r;(void)n;(void)p;(void)e;}
static unsigned source_rate=44100,starvations;
static double frequency=.013;
void pc_diag_add(unsigned field){if(field==76)starvations++;}
void pc_diag_value(unsigned field,unsigned value){(void)field;(void)value;}
int pc_dj_reader_open(DjReader *reader,const char *path){
 (void)path;
 reader->format=(DjWav){.frames=30000,.rate=source_rate,.channels=2};
 return DJ_OK;
}
void pc_dj_reader_close(DjReader *reader){(void)reader;}
int pc_dj_reader_frame(DjReader *reader,uint64_t frame,float *left,float *right){
 if(frame>=reader->format.frames)return 0;
 *left=.3f*(float)sin(frame*frequency);*right=-*left;return 1;
}
static void notice(uint64_t event){(void)event;}
long pc_sys(long number,long a,long b,long c,long d,long e,long f){
 (void)a;(void)b;(void)c;(void)d;(void)e;(void)f;
 if(number==122)return 0;
 assert(number==101);
 decks[0].request=0;return 0;
}
static void trampoline(uintptr_t offset,void *function){
 uint8_t *p=(uint8_t*)(host.base+offset);
 p[0]=0x48;p[1]=0xb8;memcpy(p+2,&function,8);p[10]=0xff;p[11]=0xe0;
}
int main(void){
 host.base=(uintptr_t)mmap(0,0x7400000,7,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 assert(host.base!=(uintptr_t)MAP_FAILED);trampoline(0x6d43500,notice);
 Playback *d=&decks[0];
 /* Non-block-aligned loop length and non-integer source step must
  * preserve every output sample and the fractional overshoot. */
 for(unsigned rate=44100;rate<=48000;rate+=3900){
  memset(d,0,sizeof *d);d->ratio=1000000;d->gain=16383;d->filter=8192;d->request=1;
  d->cue=103;source_rate=rate;d->loop=(UINT64_C(1708)<<32)|103;
  render_worker(d);
  assert(d->write==DJ_RING-DJ_HISTORY&&!d->error);
  double phase=103,step=(double)rate/44100;
  float previous=0;
  for(unsigned i=0;i<DJ_RING-DJ_HISTORY;i++){
   if(phase>=1708)phase=103+fmod(phase-103,1605);
   DjFrame *sample=&d->ring[i];
   assert(sample->frame==(unsigned)phase);
   if(i&&sample->frame<d->ring[i-1].frame)assert(fabsf(sample->l-previous)<.02f);
   assert(fabsf(sample->l+sample->r)<1e-6f);
   previous=sample->l;phase+=step;
  }
 }
 /* Nudge changes the live consumer immediately, including short taps,
  * and backward history is bounded by the producer ring's retained data. */
 memset(d,0,sizeof*d);d->request=d->started=d->running=1;d->read=2000;d->write=8000;d->gain=16383;d->level=.5f;d->signal=1;
 for(unsigned n=0;n<8000;n++)d->ring[n]=(DjFrame){.2f,-.2f,n};
 float nl[256]={0},nr[256]={0};
 pc_dj_nudge_step(0,1);pc_dj_audio(nl,nr,256);assert(d->read==2000+441+256);
 pc_dj_nudge_step(0,-1);pc_dj_audio(nl,nr,256);assert(d->read==2000+512);
 assert(d->position==d->read-1);
 for(unsigned n=0;n<256;n++)assert(nl[n]>=-.5f&&nl[n]<=.5f&&nl[n]+nr[n]==0);
 /* A scheduled bar seek splits a producer block at the exact output
  * frame, preserving all preceding audio and the active worker/ring. */
 for(unsigned rate=44100;rate<=48000;rate+=3900){
  memset(d,0,sizeof *d);source_rate=rate;d->ratio=1000000;d->gain=16383;d->filter=8192;
  d->request=d->started=d->running=1;d->timeline=UINT64_C(3000)<<32;
  assert(pc_dj_seek(0,20000,4003));render_worker(d);
  assert(!d->error&&d->write>1003);
  assert(d->ring[1002].frame==(unsigned)(1002.*rate/44100));
  assert(d->ring[1003].frame==20000);
  assert(fabsf(d->ring[1003].l-d->ring[1002].l)<1e-6f);
 }
 memset(d,0,sizeof *d);d->ratio=1000000;d->gain=16383;d->request=d->started=1;
 d->level=.5f;d->signal=1;
 d->ring[0]=(DjFrame){.3f,-.3f,0};d->write=1;
 float l[256]={0},r[256]={0};
 pc_dj_audio(l,r,256);
 assert(starvations==1&&d->buffering&&d->signal==0);
 for(unsigned i=1;i<256;i++)assert(fabsf(l[i]-l[i-1])<.002f);
 for(unsigned i=1;i<=32;i++)d->ring[i]=(DjFrame){-.3f,.3f,i};
 d->write=33;memset(l,0,sizeof l);memset(r,0,sizeof r);
 pc_dj_audio(l,r,256);assert(d->read==1);
 for(unsigned i=0;i<256;i++)assert(l[i]==0&&r[i]==0);
 for(unsigned i=33;i<=DJ_PREFILL;i++)d->ring[i]=(DjFrame){-.3f,.3f,i};
 d->write=DJ_PREFILL+1;memset(l,0,sizeof l);memset(r,0,sizeof r);
 pc_dj_audio(l,r,256);
 assert(d->read==257&&fabsf(l[0])<.002f&&fabsf(l[255]+.15f)<1e-5f);
 for(unsigned i=1;i<256;i++)assert(fabsf(l[i]-l[i-1])<.002f);
 // A deck at zero master volume still feeds CUE at full pad gain.
 memset(decks,0,sizeof decks);
 for(unsigned index=0;index<2;index++){
  Playback *deck=&decks[index];
  deck->request=deck->started=deck->running=1;
  deck->write=16000;deck->gain=index?0:16383;
  deck->level=index?0:.5f;deck->signal=1;
  for(unsigned n=0;n<DJ_RING;n++)deck->ring[n]=(DjFrame){index?.6f:.2f,index?-.6f:-.2f,n};
 }
 monitor_enabled=1;pc_dj_monitor(1,16383);pc_dj_monitor_reset();
 memset(l,0,sizeof l);memset(r,0,sizeof r);pc_dj_audio(l,r,256);
 assert(fabsf(l[255]-.1f)<1e-6f&&fabsf(monitor_left[255]-.3f)<1e-6f);
 assert(fabsf(monitor_right[255]+.3f)<1e-6f);
 pc_dj_monitor(1,0);
 for(unsigned b=0;b<16;b++){memset(l,0,sizeof l);memset(r,0,sizeof r);pc_dj_audio(l,r,256);}
 assert(fabsf(l[255]-.1f)<1e-6f&&fabsf(monitor_left[255]-.1f)<.001f);
 pc_dj_monitor(1,8192);
 for(unsigned b=0;b<16;b++){memset(l,0,sizeof l);memset(r,0,sizeof r);pc_dj_audio(l,r,256);}
 assert(fabsf(l[255]-.1f)<1e-6f&&fabsf(monitor_left[255]-.2f)<.001f);
 pc_dj_monitor(0,16383);
 for(unsigned b=0;b<16;b++){memset(l,0,sizeof l);memset(r,0,sizeof r);pc_dj_audio(l,r,256);}
 assert(fabsf(l[255]-.1f)<1e-6f&&fabsf(monitor_left[255]-.1f)<.001f);
 for(unsigned index=0;index<2;index++)decks[index].write=26000;
 pc_dj_monitor_gain(8192);
 for(unsigned b=0;b<16;b++){memset(l,0,sizeof l);memset(r,0,sizeof r);pc_dj_audio(l,r,256);}
 assert(fabsf(l[255]-.1f)<1e-6f&&fabsf(monitor_left[255]-.05f)<.001f);
 pc_dj_monitor_gain(0);
 for(unsigned b=0;b<16;b++){memset(l,0,sizeof l);memset(r,0,sizeof r);pc_dj_audio(l,r,256);}
 assert(fabsf(l[255]-.1f)<1e-6f&&fabsf(monitor_left[255])<.001f&&fabsf(monitor_right[255])<.001f);
 puts("USB cue follows selected pre-fader deck, blends with post-mix master and keeps jack output isolated");
 puts("DJ loops keep fractional timing and continuous seams; starvation and recovery fade without clicks");
}
