#include <assert.h>
#include <stdio.h>
#include "synth_splice.h"
int main(void){
 PcSynthSplice a={0},b={0};
 float l[256],r[256],x[256],y[256];
 for(unsigned i=0;i<256;i++){l[i]=x[i]=.8f;r[i]=y[i]=-.6f;}
 a.transition=b.transition=1;
 pc_synth_splice(&a,l,r,256);
 pc_synth_splice(&b,x,y,32);
 pc_synth_splice(&b,x+32,y+32,224);
 assert(l[0]==0&&r[0]==0);
 for(unsigned i=0;i<256;i++)assert(l[i]==x[i]&&r[i]==y[i]);
 assert(l[132]==.8f&&r[132]==-.6f);
 a.transition=1;l[0]=.5f;r[0]=.5f;
 pc_synth_splice(&a,l,r,1);
 assert(l[0]==.8f&&r[0]==-.6f);
 puts("132-sample stereo synth transition is continuous and block-size independent");
}
