"""Exercise two stock AkaiLib processors with independent source and sink callbacks."""
import sys
from unicorn import *
from unicorn.arm64_const import *
from elftools.elf.elffile import ELFFile
from struct import pack,unpack
import math
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.ctl_set_cpu_model(UC_CPU_ARM64_MAX)
u.mem_map(0,0x7800000);u.mem_map(0x10000000,0x800000)
elf=ELFFile(open(sys.argv[1],'rb'))
for s in elf.iter_segments():
 if s['p_type']=='PT_LOAD':u.mem_write(s['p_vaddr'],s.data())
def q(a):return unpack('<Q',u.mem_read(a,8))[0]
def p(a,v):u.mem_write(a,pack('<Q',v))
def si(a):return unpack('<I',u.mem_read(a,4))[0]
def r(n):return u.reg_read(UC_ARM64_REG_X0+n)
def s(n):return unpack('<f',pack('<I',u.reg_read(UC_ARM64_REG_S0+n)))[0]
def d(n):return unpack('<d',pack('<Q',u.reg_read(UC_ARM64_REG_D0+n)))[0]
def sf(n,v):u.reg_write(UC_ARM64_REG_S0+n,unpack('<I',pack('<f',v))[0])
def df(n,v):u.reg_write(UC_ARM64_REG_D0+n,unpack('<Q',pack('<d',v))[0])
def ret(x=0):u.reg_write(UC_ARM64_REG_X0,x);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
data,stop,canary,buffer,config,src=0x10000000,0x10000010,0x10000100,0x10100000,0x10002000,0x10003000
srate=44100
ptr=0x10200000; offsets={}; outputs={}; freq={}
p(0x7164398,canary);p(canary,42);p(config+0xa8,64)
p(src+0x140,0x10000600);p(src+0x150,0x10000610)
def alloc(size):
 global ptr
 assert 0<=size<0x100000,hex(size)
 a=ptr;ptr=(ptr+max(size,1)+15)&~15
 return a
plts=elf.get_section_by_name('.plt')['sh_addr']+32
syms=elf.get_section_by_name('.dynsym')
plt={plts+16*i:syms.get_symbol(rel['r_info_sym']).name for i,rel in enumerate(elf.get_section_by_name('.rela.plt').iter_relocations())}
def hook(u,pc,sz,_):
 if pc==0x10000600:
  ctx,dst,n=r(0),r(1),r(2);planes=q(dst+0x10); start=offsets[ctx];hz=freq[ctx]
  values=pack(f'<{n}f',*(.2*math.sin(2*math.pi*hz*(start+j)/srate) for j in range(n)))
  u.mem_write(q(planes),values);u.mem_write(q(planes+8),values);offsets[ctx]+=n;ret();return
 if pc==0x10000610:
  outputs[r(2)-0x58]+=unpack(f'<{r(4)}f',u.mem_read(r(0),4*r(4)))
  ret();return
 name=plt.get(pc)
 if not name:return
 x,y,z=r(0),r(1),r(2)
 if name in ('_Znwm','_Znam','malloc'):ret(alloc(x))
 elif name in ('_ZdlPvm','_ZdlPv','_ZdaPv','_ZdaPvm','free'):ret()
 elif name=='snd_pcm_avail_update':ret(256)
 elif name=='calloc':ret(alloc(x*y))
 elif name in ('memcpy','memmove'):u.mem_write(x,bytes(u.mem_read(y,z)));ret(x)
 elif name=='memset':u.mem_write(x,bytes([y&255])*z);ret(x)
 elif name=='memcmp':
  first,second=bytes(u.mem_read(x,z)),bytes(u.mem_read(y,z));ret((first>second)-(first<second))
 elif name=='strlen':
  n=0
  while u.mem_read(x+n,1)!=b'\0':n+=1
  ret(n)
 elif name in ('powf','sqrtf','sinf','cosf','tanf','expf','logf','floorf','roundf','fmodf','fabsf'):
  fun={'fabsf':abs,'roundf':round}.get(name) or getattr(math,name[:-1])
  sf(0,fun(s(0),s(1)) if name in ('powf','fmodf') else fun(s(0)));ret()
 elif name in ('pow','sqrt','sin','cos','tan','exp','log','floor','round','fmod','fabs'):
  fun={'fabs':abs,'round':round}.get(name) or getattr(math,name)
  df(0,fun(d(0),d(1)) if name in ('pow','fmod') else fun(d(0)));ret()
 elif name in ('frexp','frexpf'):
  mantissa,exponent=math.frexp(s(0) if name=='frexpf' else d(0))
  u.mem_write(x,pack('<i',exponent))
  if name=='frexpf':sf(0,mantissa)
  else:df(0,mantissa)
  ret()
 elif name=='ldexpf':sf(0,math.ldexp(s(0),unpack('<i',pack('<I',x&0xffffffff))[0]));ret()
 elif name=='ldexp':df(0,math.ldexp(d(0),unpack('<i',pack('<I',x&0xffffffff))[0]));ret()
 elif name=='sincosf':
  u.mem_write(x,pack('<f',math.sin(s(0))));u.mem_write(y,pack('<f',math.cos(s(0))));ret()
 elif 'Rb_tree_insert_and_rebalance' in name:
  left,node,parent,head=x,y,z,r(3)
  p(node+8,parent);p(node+16,0);p(node+24,0)
  if parent==head:
   p(head+8,node);p(head+16,node);p(head+24,node);p(node,1)
  elif left:
   p(parent+16,node)
   if q(head+16)==parent:p(head+16,node)
  else:
   p(parent+24,node)
   if q(head+24)==parent:p(head+24,node)
  ret()
 elif 'Rb_tree_decrement' in name:
  if q(q(x+8)+8)==x and not si(x):ret(q(x+24));return
  if q(x+16):
   x=q(x+16)
   while q(x+24):x=q(x+24)
  else:
   y=q(x+8)
   while x==q(y+16):x,y=y,q(y+8)
   x=y
  ret(x)
 elif 'Rb_tree_increment' in name:
  if q(x+24):
   x=q(x+24)
   while q(x+16):x=q(x+16)
  else:
   y=q(x+8)
   while x==q(y+24):x,y=y,q(y+8)
   if q(x+24)!=y:x=y
  ret(x)
 elif 'Rb_tree_rebalance_for_erase' in name:
  node,head=x,y
  def replace(old,new):
   parent=q(old+8)
   if parent==head:p(head+8,new)
   elif q(parent+16)==old:p(parent+16,new)
   else:p(parent+24,new)
   if new:p(new+8,parent)
  left,right=q(node+16),q(node+24)
  if not left:replace(node,right)
  elif not right:replace(node,left)
  else:
   sub=right
   while q(sub+16):sub=q(sub+16)
   if sub!=right:
    replace(sub,q(sub+24));p(sub+24,right);p(right+8,sub)
   replace(node,sub);p(sub+16,left);p(left+8,sub)
  lo=hi=q(head+8)
  while lo and q(lo+16):lo=q(lo+16)
  while hi and q(hi+24):hi=q(hi+24)
  p(head+16,lo or head);p(head+24,hi or head);ret(node)
 elif name=='__cxa_guard_acquire':ret(not si(x))
 elif name=='__cxa_guard_release':u.mem_write(x,pack('<I',1));ret()
 elif name=='__cxa_atexit':ret()
 else:raise RuntimeError(name,hex(pc),hex(u.reg_read(UC_ARM64_REG_LR)),hex(x))
u.hook_add(UC_HOOK_CODE,hook)
def call(addr,*args,flt=()):
 for j,x in enumerate(args):u.reg_write(UC_ARM64_REG_X0+j,x)
 for j,x in enumerate(flt):sf(j,x)
 u.reg_write(UC_ARM64_REG_SP,0x100ff000);u.reg_write(UC_ARM64_REG_LR,stop)
 try:u.emu_start(addr,stop,count=10000000)
 except Exception: print('PC',hex(u.reg_read(UC_ARM64_REG_PC)));raise
 assert u.reg_read(UC_ARM64_REG_PC)==stop
for i in range(2):
 ctx=src+0x200*i; proc=buffer+i*0x1000
 p(ctx+0x140,0x10000600);p(ctx+0x150,0x10000610)
 freq[ctx]=220+110*i;offsets[ctx]=0;outputs[ctx]=[]
 call(0x22440d0,proc,0,config)
 print('native warp created',hex(q(proc)),hex(q(proc+0x308)),ptr)
 call(0x2243de0,proc,flt=(1.0,1.0))
 print('reset',offsets)
for n in range(100):
 for i in range(2):
  ctx=src+0x200*i;proc=buffer+i*0x1000
  call(0x2243e80,proc,0,256,ctx,flt=((.96 if i==0 else 1.04) if n>40 else 1.0,1.0,1.0))
for ctx in offsets:print('result',len(outputs[ctx]),max(outputs[ctx]),offsets[ctx])
first,second=sorted(outputs)
assert offsets[first]>offsets[second]+256
for ctx,samples in outputs.items():
    # Inspect a window after both processes have changed ratio.
    window=samples[15000:24000]
    crossings=sum(a<0<=b for a,b in zip(window,window[1:]))
    measured=crossings*44100/len(window)
    assert abs(measured-freq[ctx])<6,(measured,freq[ctx])
    assert len(samples)==25600 and max(samples)>.15
print('Two real AkaiLib contexts process distinct source rates while preserving their test tones.')

if len(sys.argv)>2:
    import io
    import wave

    host=ELFFile(open(sys.argv[2],'rb'))
    host_base=0x12000000
    u.mem_map(host_base,0x1800000)
    for seg in host.iter_segments():
        if seg['p_type']=='PT_LOAD':
            u.mem_write(host_base+seg['p_vaddr'],seg.data())
    host_syms={s.name:host_base+s['st_value'] for s in host.get_section_by_name('.symtab').iter_symbols() if s['st_value']}
    u.reg_write(UC_ARM64_REG_TPIDR_EL0,0x10008000)
    for rel in host.get_section_by_name('.rela.dyn').iter_relocations():
        if rel['r_info_type']==1027:
            p(host_base+rel['r_offset'],host_base+rel['r_addend'])
        elif rel['r_info_type']==1031:
            p(host_base+rel['r_offset'],0x10000670)
            p(host_base+rel['r_offset']+8,rel['r_addend'])
    for rel in host.get_section_by_name('.rela.plt').iter_relocations():
        name=host.get_section_by_name('.dynsym').get_symbol(rel['r_info_sym']).name
        match=next((a for a,symbol in plt.items() if name==symbol),0)
        if not match and name in ('frexp','frexpf'):
            match=0x10000700+16*len([a for a in plt if 0x10000700<=a<0x10000800])
            plt[match]=name
        if match:p(host_base+rel['r_offset'],match)

    def cstr(address):
        return bytes(u.mem_read(address,64)).split(b'\0')[0]

    wavs={}
    for track,hz in enumerate((220,330)):
        out=io.BytesIO()
        with wave.open(out,'wb') as writer:
            rate=48000 if track else 44100
            writer.setparams((2,2,rate,0,'NONE',''))
            for frame in range(8192):
                value=int(9000*math.sin(2*math.pi*hz*frame/rate))
                writer.writeframesraw(pack('<hh',value,-value))
        wavs[10+track]=out.getvalue()

    pending=[]
    def integration_hook(uc,pc,_size,_data):
        if pc==host_syms['pc_sys']:
            number=r(0)
            if number==56:ret(10 if cstr(r(2))==b'/test1.wav' else 11)
            elif number==62:ret(len(wavs[r(1)]))
            elif number==67:
                chunk=wavs[r(1)][r(4):r(4)+r(3)]
                u.mem_write(r(2),chunk);ret(len(chunk))
            elif number in (57,122,226):ret()
            else:raise AssertionError(number)
        elif pc==0x10000640:
            p(r(0),1);pending.append((r(2),r(3)));ret()
        elif pc in (0x10000650,0x6d43500,0x10000680,host_syms['pc_trigger_block'],
                     host_syms['pc_flex_clock_external']):ret()
        elif pc==0x10000670:ret(q(r(0)+8))
        elif pc==host_syms['pc_diag_add'] or pc==host_syms['pc_diag_value']:ret()
        elif pc==0x18dbcc0:
            # Reproduce a silent native engine, as when the sequencer is idle.
            assert si(r(1)+8)==256 and si(r(2))==4
            u.mem_write(r(2)+0x128,b'\x01')
            ret()
    u.hook_add(UC_HOOK_CODE,integration_hook)
    # dlsym was not needed for the native processor tests. Replace its
    # test runtime entry with a tiny resolver for the host worker hooks.
    del plt[0xb51898]
    def resolver(uc,pc,_size,_data):
        ret({b'pthread_create':0x10000640,b'pthread_detach':0x10000650}.get(cstr(r(1)),0))
    resolver_handle=u.hook_add(UC_HOOK_CODE,resolver,begin=0xb51898,end=0xb51898)
    for track,ratio in enumerate((1000000,1050000)):
        path=0x10000500
        u.mem_write(path,f'/test{track+1}.wav\0'.encode())
        call(host_syms['pc_dj_rate'],track,ratio)
        call(host_syms['pc_dj_play'],track,path,0,0)
        assert r(0)==1
    warp_destructor=q(0x6da6750)
    p(0x6da6750,0) # Native Warp is optional at unity speed.
    call(*pending[0])
    p(0x6da6750,warp_destructor)
    call(*pending[1])
    left,right=0x10010000,0x10020000
    callback,table,outputs=0x10004000,0x10004100,0x10004200
    p(callback,table);p(table+0x10,0x10000680)
    logical_l,logical_r=0x10014000,0x10024000
    p(outputs,logical_l);p(outputs+8,logical_r)
    thread,device,physical=0x10005000,0x10005800,0x10005900
    p(thread+0x248,device);p(thread+0x3d0,physical);p(thread+0x1a0,256);p(device+0x14,2)
    p(physical,left);p(physical+8,right)
    p(host_syms['dj_engine_output'],1)
    live_buffer,live_planes,live_context=0x10006000,0x10006200,0x10006300
    p(live_buffer,4|(256<<32));p(live_buffer+0x10,live_planes)
    p(live_planes,left);p(live_planes+8,right);p(live_planes+16,logical_l);p(live_planes+24,logical_r)
    p(live_context+8,256)
    p(0x6e3b238,host_syms['dj_engine_audio'])
    for output in (left,right,logical_l,logical_r):
        u.mem_write(output,pack('<256f',*([.9]*256)))
    call(q(0x6e3b238),thread,live_context,live_buffer)
    assert not any(u.mem_read(logical_l,1024)) and not any(u.mem_read(logical_r,1024))
    assert u.mem_read(live_buffer+0x128,1)==b'\x00'
    samples=unpack('<256f',u.mem_read(left,1024))
    assert max(map(abs,samples))>.02
    stereo=unpack('<256f',u.mem_read(right,1024))
    assert all(abs(l+r)<1e-5 for l,r in zip(samples,stereo))
    for track in range(2):
        call(host_syms['pc_dj_position'],track)
        assert r(0)>=250
    print('MpcAudioThread live vtable produces DJ audio while stock is silent and clears all four output planes.')
    buses=0x10030000
    call(host_syms['pc_dj_send'],0,0,16383)
    call(host_syms['pc_dj_space_position'],0)
    for block in range(4):
        u.mem_write(left,bytes(1024));u.mem_write(right,bytes(1024))
        u.mem_write(buses,bytes(3*2*4096*4))
        call(host_syms['pc_dj_device_begin'],256)
        call(host_syms['pc_dj_graph_audio'],256,buses,1)
        call(host_syms['pc_dj_clock'])
        assert r(0)==256*(block+2)
        call(host_syms['pc_dj_device_end'],left,right,256)
        call(host_syms['pc_dj_clock'])
        assert r(0)==256*(block+2)
        wet=unpack('<256f',u.mem_read(buses,1024))
        dry=unpack('<256f',u.mem_read(left,1024))
        assert max(map(abs,wet))>.02 and max(map(abs,dry))>.02
    print('DJ graph consumes once, sends only the selected deck and keeps the DJ combination bypassed at zero.')


    call(host_syms['pc_dj_clock'])
    before_clock=r(0)
    call(host_syms['output_callback'],callback,0,0,outputs,2,256)
    call(host_syms['pc_dj_clock'])
    assert r(0)==before_clock
    print('The legacy callback leaves DJ transport on the active MpcAudioThread path.')
    # Isolate the stretched stereo deck after the unity-speed deck fades out.
    call(host_syms['pc_dj_space_position'],0)
    call(host_syms['pc_dj_gain'],0,0)
    isolated=[]
    for block in range(9):
        u.mem_write(left,bytes(1024));u.mem_write(right,bytes(1024))
        call(host_syms['pc_dj_audio'],left,right,256)
        if block>=2:isolated+=unpack('<256f',u.mem_read(left,1024))
        a,b=unpack('<256f',u.mem_read(left,1024)),unpack('<256f',u.mem_read(right,1024))
        assert all(abs(x+y)<1e-5 for x,y in zip(a,b))
    assert max(map(abs,isolated))>.04
    crossings=sum(a<0<=b for a,b in zip(isolated,isolated[1:]))
    measured=crossings*44100/len(isolated)
    assert abs(measured-330)<30,measured
    print('Full-rate stock KeyLock keeps the 330 Hz tone and independent stereo output:',measured)


    # Execute the new compiled ARM64 DSP, including active Galactic and Highpass.
    for block in range(12):
        u.mem_write(left,bytes(1024));u.mem_write(right,bytes(1024))
        call(host_syms['pc_dj_space_process'],left,right,256,16383,7)
    u.mem_write(left,pack('<f',1)+bytes(1020));u.mem_write(right,bytes(1024))
    call(host_syms['pc_dj_space_process'],left,right,256,16383,7)
    impulse=unpack('<256f',u.mem_read(left,1024))
    assert max(map(abs,impulse))<.01
    print('Compiled ARM64 Galactic/Highpass runs at full wet with no direct impulse leakage.')

if len(sys.argv)>2:
    owner,params,settings,processor,planes=0x10400000,0x10400400,0x10400500,0x10400800,0x10400b00
    p(owner,0x70784a8);p(owner+0x18,params);p(owner+0x28,6);p(owner+0x70,processor)
    p(processor+0xb8,settings);p(planes,left);p(planes+8,right)
    u.mem_write(params,pack('<6f',.2,.3,.85,0,0,0));u.mem_write(settings,pack('<2f',4,700))
    u.mem_write(processor+0x7c,pack('<f',1))
    p(0x7078500,host_syms['pc_pressure6_native'])
    for block in range(200):
        u.mem_write(left,pack('<256f',*([1.]*256)));u.mem_write(right,pack('<256f',*([-1.]*256)))
        call(q(0x7078500),owner,planes,planes,256,0,0)
    gain=unpack('<f',u.mem_read(processor+0xc0,4))[0]
    assert .1<gain<.9,gain
    call(0x3c591f0,owner,0x726d6574,0x10400c00)
    meter=unpack('<f',u.mem_read(r(0),4))[0]
    assert meter<-.05,meter
    u.mem_write(owner+0x69,b'\x01')
    u.mem_write(left,pack('<256f',*([.25]*256)));u.mem_write(right,pack('<256f',*([-.25]*256)))
    call(q(0x7078500),owner,planes,planes,256,0,0)
    assert unpack('<f',u.mem_read(left,4))[0]==.25 and unpack('<f',u.mem_read(processor+0xc0,4))[0]==1
    print('Compiled Pressure6 replaces the stock master kernel; native reduction meter and exact bypass passed.')

if len(sys.argv)>2:
    import binascii
    import re
    from pathlib import Path
    source=(Path(__file__).resolve().parent.parent/'vendor/more-chords-fm6/felucca_fm6.h').read_text()
    voice=bytes(map(int,re.findall(r'\d+',source.split('FM6_INIT[128] = {',1)[1].split('};',1)[0])))
    assert len(voice)==128
    patch=bytearray(512)
    patch[:8]=b'MPCEXT01';patch[8]=4;patch[20:28]=b'DX7RAW01';patch[64:192]=voice
    patch[508:512]=pack('<I',binascii.crc32(patch[:508]))
    u.mem_write(params,bytes(patch))
    call(host_syms['pc_fm6_load'],0,params,0);assert r(0)==1
    for note in range(48,60):
        call(host_syms['pc_fm6_on'],0,note,100);assert r(0)==1
    energy=0
    for _ in range(12):
        call(host_syms['pc_fm6_render'],0,left,right,256)
        samples=unpack('<256f',u.mem_read(left,1024))
        assert all(math.isfinite(v) for v in samples)
        assert u.mem_read(left,1024)==u.mem_read(right,1024)
        energy+=sum(v*v for v in samples)
    assert energy>1
    call(host_syms['pc_fm6_off'],0,48)
    call(host_syms['pc_fm6_voices'],0);assert r(0)==12
    print('Compiled ARM64 FM6 renders 12 simultaneous DX7 notes and preserves releases.')

if len(sys.argv)>2:
    storage_screen=0x10402000
    def storage_visibility(uc,pc,_size,_data):
        u.mem_write(storage_screen+0xa8,bytes([2 if r(1)&1 else 0]))
        ret()
    u.hook_add(UC_HOOK_CODE,storage_visibility,begin=0x1172670,end=0x1172670)
    # Four output planes cover both the physical master and the logical bus.
    audio_planes=[left,right,logical_l,logical_r]
    for plane in audio_planes:
        u.mem_write(plane,pack('<256f',*([.35]*256)))
    call(host_syms['pc_sd_access_silence'],live_planes,4,256)
    assert unpack('<f',u.mem_read(left,4))[0]>.3
    call(host_syms['pc_sd_access_visibility'],storage_screen,1)
    call(host_syms['pc_sd_access_silence'],live_planes,4,256)
    assert all(not any(u.mem_read(plane,1024)) for plane in audio_planes)
    for plane in audio_planes:
        u.mem_write(plane,pack('<256f',*([.35]*256)))
    call(host_syms['dj_engine_audio'],thread,live_context,live_buffer)
    assert all(not any(u.mem_read(plane,1024)) for plane in audio_planes)
    for plane in (left,right):
        u.mem_write(plane,pack('<256f',*([.35]*256)))
    call(host_syms['pc_dj_alsa_available'],0,thread)
    assert r(0)==256 and not any(u.mem_read(left,1024)) and not any(u.mem_read(right,1024))
    call(host_syms['pc_sd_access_visibility'],storage_screen,0)
    for plane in audio_planes:
        u.mem_write(plane,pack('<256f',*([.35]*256)))
    call(host_syms['pc_sd_access_silence'],live_planes,4,256)
    assert all(unpack('<f',u.mem_read(plane,4))[0]>.3 for plane in audio_planes)
    print('SD Card Access zeros all four output planes after the native graph and before ALSA conversion; exit restores normal output.')

if len(sys.argv)>2:
    pcm_calls=[]
    pcm_symbols={
        b'snd_pcm_writei':0x10000800,b'snd_pcm_close':0x10000880,
        b'snd_pcm_info_sizeof':0x10000810,b'snd_pcm_hw_params_sizeof':0x10000810,
        b'snd_pcm_info':0x10000820,b'snd_pcm_info_get_id':0x10000830,
        b'snd_pcm_hw_params_current':0x10000840,b'snd_pcm_hw_params_get_format':0x10000850,
        b'snd_pcm_hw_params_get_channels':0x10000860,b'snd_pcm_hw_params_get_rate':0x10000870,
    }
    def cue_native(uc,pc,_size,_data):
        if pc==0x10000800:
            pcm_calls.append(bytes(u.mem_read(r(1),r(2)*8)));ret(r(2))
        elif pc==0x10000810:ret(256)
        elif pc==0x10000820:
            u.mem_write(r(1),b'UAC2 PCM\0' if r(0)==2 else b'I2S\0');ret()
        elif pc==0x10000830:ret(r(0))
        elif pc in (0x10000840,0x10000880):ret()
        elif pc in (0x10000850,0x10000860,0x10000870):
            u.mem_write(r(1),pack('<I',{0x10000850:10,0x10000860:2,0x10000870:44100}[pc]))
            ret()
    u.hook_add(UC_HOOK_CODE,cue_native,begin=0x10000800,end=0x10000880)
    pcm_resolver=lambda uc,pc,size,data:ret(pcm_symbols.get(cstr(r(1)),0))
    # The resolver installed above handles only the playback-worker setup.
    # Supply ALSA's stock symbols for the additional initialization.
    u.hook_del(resolver_handle)
    u.hook_add(UC_HOOK_CODE,pcm_resolver,begin=0xb51898,end=0xb51898)
    p(0x716e298,pcm_symbols[b'snd_pcm_writei']);p(0x716e1e8,pcm_symbols[b'snd_pcm_close'])
    call(host_syms['pc_usb_cue_init'],4096)
    assert q(0x716e298)==host_syms['pc_usb_cue_write']
    call(host_syms['pc_usb_cue_enable'],1)
    u.mem_write(logical_l,pack('<512i',*([123456]*512)))
    call(q(0x716e298),2,logical_l,256)
    assert not any(pcm_calls[-1])
    u.mem_write(left,pack('<1024f',*([.25]*1024)))
    u.mem_write(right,pack('<1024f',*([-.5]*1024)))
    call(host_syms['pc_usb_cue_publish'],left,right,1024)
    call(q(0x716e298),2,logical_l,256)
    assert unpack('<2i',pcm_calls[-1][-8:])==(536870912,-1073741824)
    call(q(0x716e298),1,logical_l,256)
    assert unpack('<2i',pcm_calls[-1][-8:])==(123456,123456)
    call(host_syms['pc_usb_cue_enable'],0)
    call(q(0x716e298),2,logical_l,256)
    assert unpack('<2i',pcm_calls[-1][-8:])==(123456,123456)
    print('Compiled ARM64 USB cue replaces only the UAC2 stereo S32 stream and restores stock output on exit.')
