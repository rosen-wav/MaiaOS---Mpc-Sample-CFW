#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "../src/mix.c"
static unsigned prepared,galactic_calls;
void pc_galactic_prepare(unsigned slot){assert(slot<3);prepared++;}
void pc_galactic_process(unsigned slot,float *l,float *r,unsigned n,const float *p,unsigned generation){
 assert(slot==1&&n==8&&p[0]==.5f&&generation==9);galactic_calls++;l[0]=.25f;r[0]=-.25f;
}
int pc_project_new_pending(void){return 0;}
Host host;void pc_error(unsigned n){(void)n;}
int main(void){host.base=(uintptr_t)calloc(1,G+0x2000);uintptr_t c=(uintptr_t)calloc(1,0x200),rows=(uintptr_t)calloc(28,0x158);assert(host.base&&c&&rows);Q(host.base+G,0x1eb0)=c;Q(c,0)=host.base+FX_CONTROLLER;Q(c,0x180)=rows;Q(c,0x188)=rows+28*0x158;
 for(unsigned n=0;n<28;n++)Q(rows,n*0x158+8)=(uintptr_t)(n==13?"Guitar Amp":"Native Effect");
 assert(pc_fx_count()==29);unsigned cloud=0,galactic=0;for(unsigned choice=0;choice<=pc_fx_count();choice++){int type=pc_fx_catalog_type(choice);assert(type!=13&&type!=28&&type!=30);assert(pc_fx_catalog_index(type)==choice);if(type==29)cloud++;if(type==31)galactic++;}assert(galactic==1&&cloud==1&&!pc_fx_select(0,30)&&!pc_fx_select(0,13));
 PcFxProject state={.version=1};for(unsigned n=0;n<3;n++)state.slots[n].type=-1;state.slots[0].type=30;state.slots[0].count=6;state.slots[1].type=13;assert(pc_fx_restore(&state));assert(mix.initial.slots[0].type==-1&&mix.initial.slots[1].type==-1);
 assert(!strcmp(pc_fx_name(31),"Galactic Reverb"));
 assert(extra_prepare(1,3)&&prepared==1);
 FxTask task={.slot=1,.n=8,.type=31,.custom=1,.active=1,.generation=9,.params={.5f}};
 fx_task_run(&task);assert(galactic_calls==1&&mix.pcm[1][0][0]==.25f&&mix.pcm[1][1][0]==-.25f);
 PcFxProject gal={.version=1};for(unsigned n=0;n<3;n++)gal.slots[n].type=-1;
 gal.slots[1].type=31;gal.slots[1].count=6;for(unsigned k=0;k<6;k++)gal.slots[1].params[k]=k/6.f;
 assert(pc_fx_restore(&gal)&&mix.initial.slots[1].type==31);
 mix.ready=1;for(unsigned n=0;n<3;n++)mix.types[n]=-1;mix.types[1]=31;
 for(unsigned k=0;k<6;k++)assert(pc_fx_knob(1,k,1000+k));
 PcFxProject saved;assert(pc_fx_snapshot(&saved)&&saved.slots[1].type==31&&saved.slots[1].count==6);
 for(unsigned k=0;k<6;k++)assert(fabsf(saved.slots[1].params[k]-(1000+k)/16383.f)<1e-6f);
 puts("Galactic catalog, independent send routing, six parameters and project snapshot/restore passed");
 puts("Guitar Amp removed from catalog, selection and legacy project restore without renumbering FX IDs");
}
