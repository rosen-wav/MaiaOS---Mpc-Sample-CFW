#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
build_dir=$(mktemp -d /tmp/maia-r69-checks.XXXXXX)
trap 'rm -rf "$build_dir"' EXIT HUP INT TERM
for test_name in trigger_budget cpu_pressure groove_store chord_files harmony_groove drumkit_files;do
 case "$test_name" in
 trigger_budget) source_name=performance; extra_flags='-pthread';;
 *) source_name=$test_name; extra_flags='';;
 esac
 cc -O2 -ffunction-sections -fdata-sections -Isrc -Idsp/source/adapter "tests/$test_name.c" "src/$source_name.c" -Wl,--gc-sections $extra_flags -lm -o "$build_dir/$test_name"
 "$build_dir/$test_name"
done
cc -O2 -ffunction-sections -fdata-sections -Isrc -Idsp/source/adapter tests/chord_browser.c src/chord_files.c src/sd_path.c -Wl,--gc-sections -o "$build_dir/chord_browser"
"$build_dir/chord_browser"

cc -O2 -ffunction-sections -fdata-sections -Isrc -Idsp/source/adapter tests/synth_live.c src/ms_context.c src/fm6.c src/syx_parse.c -Wl,--gc-sections -o "$build_dir/synth_live"
"$build_dir/synth_live"
sh tests/build_qm_linux.sh "$build_dir/qm"
for test_name in sequence_sample_protection drumkit_transaction fx_catalog sample_gain synth_splice multisamples dj_analysis dj_prepare dj_controls dj_audio dj_repeat dj_sends synth_filter;do
 extra='';case "$test_name" in dj_analysis|dj_prepare) extra="$build_dir/qm/libdj-qm.a -lstdc++";; esac
 cc -O2 -ffunction-sections -fdata-sections -Isrc -Idsp/source/adapter "tests/$test_name.c" -Wl,--gc-sections $extra -lm -o "$build_dir/$test_name"
 "$build_dir/$test_name"
done
cc -O2 -ffunction-sections -fdata-sections -Isrc -Idsp/source/adapter tests/preset_delete.c src/presets.c -Wl,--gc-sections -o "$build_dir/preset_delete"
"$build_dir/preset_delete"
for test_name in synth_sequence_protection tune_default;do
 case "$test_name" in synth_sequence_protection) source_name=performance;; tune_default) source_name=tune_follow;; esac
 cc -O2 -ffunction-sections -fdata-sections -Isrc -Idsp/source/adapter "tests/$test_name.c" "src/$source_name.c" -Wl,--gc-sections -o "$build_dir/$test_name"
 "$build_dir/$test_name"
done
cc -O2 -ffunction-sections -fdata-sections -Isrc -Idsp/source/adapter -c src/limiter.c -o "$build_dir/limiter.o"
c++ -O2 tests/mastering2.cpp src/mastering2.cpp "$build_dir/limiter.o" -Wl,--gc-sections -o "$build_dir/mastering2"
"$build_dir/mastering2"

c++ -O2 tests/airwindows.cpp src/airwindows.cpp -lm -o "$build_dir/airwindows"
"$build_dir/airwindows"

c++ -O2 tests/pressure6.cpp src/pressure6.cpp -lm -o "$build_dir/pressure6"
"$build_dir/pressure6"

cc -O2 -fwrapv -ffunction-sections -fdata-sections -Isrc tests/fm6.c src/fm6.c src/syx_parse.c src/syx_backend.c src/rs_import.c -Wl,--gc-sections -Idsp/source/adapter -lm -o "$build_dir/fm6"
"$build_dir/fm6"

cc -O2 -ffunction-sections -fdata-sections -Isrc -Idsp/source/adapter tests/usb_cue.c -Wl,--gc-sections -lm -o "$build_dir/usb_cue"
"$build_dir/usb_cue"
