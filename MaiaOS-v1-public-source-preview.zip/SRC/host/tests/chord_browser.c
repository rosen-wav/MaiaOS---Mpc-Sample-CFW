#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>
#include "../src/chord_browser.c"
Host host;static char directory[128];static ChordProject imported;static unsigned imports,unlocks;
static const char*translate(long raw,char*p){const char*s=(const char*)raw;snprintf(p,1400,"%s%s",directory,s);return p;}
long pc_sys(long n,long a,long b,long c,long d,long e,long f){(void)e;(void)f;long result;char p[1400];
 switch(n){
 case 56:{int flags=c;flags&=~(0x8000|0x4000|0x20000);if(c&0x8000)flags|=O_NOFOLLOW;if(c&0x4000)flags|=O_DIRECTORY;result=openat(a,translate(b,p),flags,d);break;}
 case 113:{static unsigned tick;((long*)b)[0]=1;((long*)b)[1]=++tick;return 0;}
 case 57:result=close(a);break;case 63:result=read(a,(void*)b,c>17?17:c);break;case 61:result=syscall(SYS_getdents64,a,(void*)b,c);break;default:assert(0);
 }return result<0?-errno:result;
}
static void dir(const char*s){char p[1400];assert(!mkdir(translate((long)s,p),0700));}
static void write_file(const char*s,const char*text){char p[1400];int fd=open(translate((long)s,p),O_WRONLY|O_CREAT|O_TRUNC,0600);assert(fd>=0);assert(write(fd,text,strlen(text))==(long)strlen(text));close(fd);}
static void bank(const char*s){ChordBank b={0};memcpy(b.magic,"MPCCHD1",8);b.version=1;b.reference=60;b.count=16;b.pads[0].count=3;b.pads[0].notes[0]=60;b.pads[0].notes[1]=64;b.pads[0].notes[2]=67;char p[1400];int fd=open(translate((long)s,p),O_WRONLY|O_CREAT,0600);assert(fd>=0);assert(write(fd,&b,sizeof b)==sizeof b);close(fd);}
static int guard(void){return 1;}static void unguard(void){unlocks++;}
static unsigned export_bank(uintptr_t p,void*out,unsigned n){(void)p;assert(n==sizeof(ChordProject));ChordProject data={0};data.version=1;data.page=2;data.fixed=1;data.transpose[1]=5;data.banks[2].pads[7].count=3;data.banks[2].pads[7].notes[0]=48;memcpy(data.banks[0].name,"KEEP",5);memcpy(out,&data,n);return n;}
static int import_bank(uintptr_t p,const void*in,unsigned n){(void)p;assert(n==sizeof imported);memcpy(&imported,in,n);assert(imported.page==2&&imported.fixed==1&&imported.transpose[1]==5&&!strcmp(imported.banks[0].name,"KEEP"));imports++;return 1;}
static void trampoline(uintptr_t offset,void*fn){uint8_t*p=(uint8_t*)(host.base+offset);p[0]=0x48;p[1]=0xb8;memcpy(p+2,&fn,8);p[10]=0xff;p[11]=0xe0;}
static unsigned entry(const char*name){for(unsigned n=0;n<browser.count;n++)if(!strcmp(browser.names[n],name))return n+1;assert(0);return 0;}
int main(void){char temp[]="/tmp/maia-chords-XXXXXX";assert(mkdtemp(temp));strcpy(directory,temp);
 dir("/proc");dir("/proc/self");dir("/sys");dir("/sys/dev");dir("/sys/dev/block");dir("/sys/devices");
 for(unsigned n=0;n<2;n++){char path[128];snprintf(path,sizeof path,"/sys/devices/mmcblk%u",n);dir(path);snprintf(path,sizeof path,"/sys/devices/mmcblk%u/mmcblk%up1",n,n);dir(path);snprintf(path,sizeof path,"/sys/devices/mmcblk%u/device",n);dir(path);snprintf(path,sizeof path,"/sys/devices/mmcblk%u/device/type",n);write_file(path,n?"SD\n":"MMC\n");}
 char alias[1400];assert(!symlink("../../devices/mmcblk0/mmcblk0p1",translate((long)"/sys/dev/block/179:1",alias)));assert(!symlink("../../devices/mmcblk1/mmcblk1p1",translate((long)"/sys/dev/block/179:9",alias)));
 dir("/media");dir("/media/az01-internal-sd");dir("/media/az01-internal-sd/progressions");bank("/media/az01-internal-sd/progressions/Wrong.chb");
 dir("/media/My Card");dir("/media/My Card/progressions");dir("/media/My Card/MPC-Sample");dir("/media/My Card/MPC-Sample/Samples");dir("/media/My Card/progressions/Sub");bank("/media/My Card/progressions/Bank.chb");bank("/media/My Card/progressions/Sub/Other.chb");
 write_file("/proc/self/mountinfo","25 1 179:1 / /media/az01-internal-sd rw - ext4 /dev/mmcblk0p1 rw\n26 1 179:9 /MPCSSH /media/FakeAlias rw - vfat /dev/mmcblk1p1 rw\n27 1 179:9 / /media/My\\040Card rw - vfat /dev/mmcblk1p1 rw\n");
 host.base=(uintptr_t)mmap(0,0x7500000,7,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(host.base!=(uintptr_t)MAP_FAILED);trampoline(0x7410018,guard);trampoline(0x7410098,unguard);trampoline(PC_CH_EXPORT,export_bank);trampoline(PC_CH_IMPORT,import_bank);uintptr_t p=(uintptr_t)calloc(1,0x100),b=(uintptr_t)calloc(1,0x100);assert(host.base&&p&&b);Q(p,0)=host.base+0x6ecc648;Q(host.base+G,0x1d08)=p;Q(host.base+G,0x20)=b;
 char samples[512];assert(pc_sd_folder(samples,sizeof samples,"MPC-Sample/Samples/")&&!strcmp(samples,"/media/My Card/MPC-Sample/Samples/"));
 assert(pc_chord_browser_open(b));assert(browser.count==2&&!strcmp(browser.root,"/media/My Card/progressions/")&&browser.index==0);assert(browser.directories[0]);
 browser.index=1;pc_chord_browser_event(12,3);assert(!strcmp(browser.relative,"Sub/")&&browser.count==1);
 pc_chord_browser_event(12,0);assert(!browser.relative[0]&&browser.count==2&&pc_chord_browser_active());pc_chord_browser_event(12,0);assert(!pc_chord_browser_active());
 /* Scan and import a synthetic JSON .progression alongside a binary bank; a bad file stays visible and random skips it. */
 char original[8192];FILE*fixture=fopen("tests/fixtures/Bank3.progression","rb");assert(fixture);size_t bytes=fread(original,1,sizeof original-1,fixture);fclose(fixture);original[bytes]=0;
 write_file("/media/My Card/progressions/Synthetic.progression",original);write_file("/media/My Card/progressions/Broken.PROGRESSION","{bad");
 assert(pc_chord_browser_open(b)&&browser.count==4);browser.index=entry("Synthetic.progression");pc_chord_browser_event(12,3);assert(!pc_chord_browser_active()&&imports==1&&unlocks==1);assert(imported.banks[2].pads[0].notes[0]==51&&imported.banks[2].pads[0].count==5&&imported.banks[2].pads[7].count==3&&imported.banks[2].pads[7].notes[0]==48);
 assert(pc_chord_browser_open(b));browser.index=entry("Broken.PROGRESSION");pc_chord_browser_event(12,3);assert(pc_chord_browser_active()&&imports==1&&browser.message);
 for(unsigned i=0;i<16;i++){assert(pc_chord_browser_open(b));pc_chord_browser_event(12,3);assert(!pc_chord_browser_active()&&imports==i+2);assert(imported.banks[2].pads[0].count>=3&&imported.banks[2].pads[7].notes[0]==48);}
 char deleted[1400];assert(!unlink(translate((long)"/media/My Card/progressions/Synthetic.progression",deleted)));assert(!unlink(translate((long)"/media/My Card/progressions/Broken.PROGRESSION",deleted)));
 /* A mounted SD with an empty progression folder stays on that folder. */
 char path[1400];assert(!unlink(translate((long)"/media/My Card/progressions/Bank.chb",path)));assert(!unlink(translate((long)"/media/My Card/progressions/Sub/Other.chb",path)));assert(!rmdir(translate((long)"/media/My Card/progressions/Sub",path)));
 assert(pc_chord_browser_open(b)&&browser.count==0&&!strcmp(browser.root,"/media/My Card/progressions/"));
 write_file("/sys/devices/mmcblk1/device/type","MMC\n");char missing[512];assert(!pc_sd_folder(missing,sizeof missing,"progressions/")&&!missing[0]);
 assert(pc_chord_browser_open(b)&&!browser.root[0]);
 puts("SD-root discovery, eMMC exclusion, mounted card identity, escaped mount names, missing SD, empty folders, exact MPC-Sample folder JSON listing/import, invalid files, random filtering and folder/back navigation passed");
}
