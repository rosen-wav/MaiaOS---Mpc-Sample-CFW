#include <assert.h>
#include <stdio.h>
#include "../src/dj_controls.h"

int main(void){
 assert(dj_filter_position(0)==0&&dj_filter_position(16383)==16383);
 for(unsigned position=7373;position<=9010;position++)assert(dj_filter_position(position)==8192);
 assert(dj_filter_position(7372)<8192&&dj_filter_position(9011)>8192);

 assert(dj_sync_target(170,87)==85&&dj_sync_target(170,150)==170);
 assert(dj_sync_target(87,170)==174&&dj_sync_target(120,90)==120&&dj_sync_target(120,180)==120);
 DjControls c=DJ_CONTROLS_DEFAULT;
 assert(dj_page_button(&c,2)&&c.page==DJ_SENDS);
 assert(dj_page_button(&c,2)&&c.page==DJ_VOLUME);
 assert(!dj_pickup(&c,0,3000));
 assert(dj_pickup(&c,0,16300)&&c.volume[0]==16300);
 assert(dj_pickup(&c,0,11000)&&c.volume[0]==11000);
 assert(dj_pickup(&c,1,8200)&&dj_pickup(&c,1,12000));
 assert(dj_page_button(&c,1)&&c.filter_deck==1&&c.filter==8192);
 assert(!dj_pickup(&c,1,12000));
 assert(dj_pickup(&c,1,5000)&&c.filter==5000);
 assert(dj_page_button(&c,0)&&c.page==DJ_EQ);
 assert(!dj_pickup(&c,0,12000));
 assert(dj_pickup(&c,0,8100)&&dj_pickup(&c,0,0)&&dj_low_db(c.low[0])==-24);
 assert(dj_low_db(8192)==0&&dj_low_db(16383)==6&&c.low[1]==8192);
 assert(dj_page_button(&c,2)&&c.page==DJ_SENDS);
 assert(dj_pickup(&c,0,1)&&dj_pickup(&c,0,5000)&&c.send[0][0]==5000);
 assert(dj_page_button(&c,1)&&c.send_deck==1&&!dj_pickup(&c,0,5000));
 assert(dj_pickup(&c,0,30)&&dj_pickup(&c,0,14000)&&c.send[0][0]==5000&&c.send[1][0]==14000);
 assert(dj_page_button(&c,2)&&c.page==DJ_VOLUME&&c.volume[0]==11000);
 puts("DJ page mapping, separate sends, filter assignment, EQ and pickup passed");
}
