#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <sys/mman.h>
#include "internal.h"
Host host;
void pc_diag_value(unsigned field,unsigned value){(void)field;(void)value;}
int main(void){
 host.base=(uintptr_t)mmap(0,0x6d44000,7,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 assert(host.base!=(uintptr_t)MAP_FAILED);
 *(uint8_t*)(host.base+0x6d43500)=0xc3; /* Mock UI queue on x86_64. */
 assert(pc_tune_follow_mode()==1);
 assert(pc_tune_sample_key("Track [Cmin].wav")==272);
 assert(pc_tune_sample_key("Beat_F#maj_90.wav")==262);
 assert(pc_tune_sample_key("Loop (Dbmin).flac")==273);
 assert(pc_tune_sample_key("/Folder_Cmaj/Track.wav")==0);
 assert(pc_tune_sample_key("Track Cmaj.wav")==256);
 assert(pc_tune_sample_key("Sample admin.wav")==0);
 assert(pc_tune_sample_key("Sample Cmaj-Dmin.wav")==0);
 pc_tune_follow_sample(273);
 assert(pc_tune_follow_render(256)==273&&(pc_tune_follow_result()&1024));
 pc_tune_follow_note(48,127);pc_tune_follow_note(52,105);pc_tune_follow_note(55,100);
 pc_tune_follow_midi_held(1);
 for(unsigned n=0;n<20;n++)pc_tune_follow_render(256);
 assert(pc_tune_follow_render(256)==256&&!(pc_tune_follow_result()&1024));
 for(unsigned n=0;n<220;n++)pc_tune_follow_render(256);
 assert(pc_tune_follow_render(256)==256);
 pc_tune_follow_midi_held(0);
 for(unsigned n=0;n<220;n++)pc_tune_follow_render(256);
 assert(pc_tune_follow_render(256)==273);
 pc_tune_follow_sample(0);
 assert(pc_tune_follow_render(256)==0);
 pc_tune_follow_set(0);assert(!pc_tune_follow_mode()&&!pc_tune_follow_render(256));
 pc_tune_follow_set(1);assert(pc_tune_follow_mode());
 puts("Auto MIDI default, filename sharps/flats, MIDI precedence and expiry, sample fallback and WAIT MIDI passed");
}
