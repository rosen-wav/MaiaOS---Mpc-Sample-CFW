# Host regression checks

The C tests run on Linux with a C compiler. Compile using `-Isrc -Idsp/source/adapter` from the host root. Link `tests/trigger_budget.c` with `src/performance.c`, `-ffunction-sections -fdata-sections -Wl,--gc-sections -pthread`. Link `tests/groove_store.c` with `src/groove_store.c`, and `tests/cpu_pressure.c` with `src/cpu_pressure.c`.

`quantize_native.py` requires Python, pyelftools and Unicorn. Pass `--stock` with the unmodified MPC Sample 1.3.0 executable and `--host` with the built host library. It runs the actual native collision pass and the host wrapper in ARM64 emulation. Libstdc++ tree helpers, memory allocation, selection and grid rounding are simulated. The native executable is not redistributed here.

These are software regression checks. They do not replace on-device audio and control testing.

For r69, `sh tests/run_linux.sh` runs all native Linux fixtures. The additional tests cover standard MIDI files with multiple tracks and running status, SD-root discovery and folders, highest-note lead, 14 arpeggio patterns and 128-bar limits, and continuous Dexed filter coefficients with finite-state recovery.

`shift_native.py --host PATH` exercises the compiled ARM64 physical callback with a browser active. 

For r70, the Linux suite also covers DRUMKIT file categories, empty-page admission, preload and transaction rollback, locks, gains and kick sidechain; direct synth packets in 16 Levels and after a new generation; protection of sequenced gates and tails; native sample trim gain; removal of Guitar Amp with stable effect IDs; and the Auto MIDI default.

`quantize_command_native.py --stock PATH --host PATH` exercises the native command constructor, publication, undo and subsequent duplicate cleanup. It reproduces the original loss of two triads (six notes become two) and verifies the replacement retains all six. The command tests also cover intentional unison layering and another pad. Native tree and allocator helpers are simulated; LDAPR is replaced by equivalent LDR for this single-threaded fixture because Unicorn lacks that instruction.

For r71, the onset fixture admits 1024 synth and sample attacks at one offset (no global count ceiling) and checks sustained-load rejection separately. CPU fixtures test >=98 percent for five continuous seconds, recovery, short spikes, and both cores. The SD fixture uses the native card alias as a symlink and checks `MPC Sample/Samples/` with its exact space. The live fixture now exercises deferred callbacks with no physical TLS, generic sources and their Note Off, duplicate suppression, and audio event consumption through the DSP attack boundary.

`live_hook_native.py --native PATH --host PATH` verifies the four runtime live-input vtable relays against the installed executable, including page protection calls and adjacent entry preservation.

For r72, the path integration fixture supplies realistic mountinfo and sysfs partition aliases with their parent SD/MMC type files. It verifies that internal eMMC is rejected even if it contains a progressions folder, the SD mount name is decoded correctly, bind mounts below the card root are excluded, short reads preserve parsing, and missing SD media never falls back to internal storage. DRUMKIT uses the exact card-relative folder `MPC-Sample/Samples/`.

For r73, five synthetic `.progression` JSON files are included as parser fixtures. Tests preserve their chord names, note ordering and absolute MIDI pitches. Additional cases cover explicit velocities, Unicode, UTF-8 BOM, unknown metadata, malformed/truncated JSON, browser listing, native-bank publication, unchanged other pages, and Random skipping invalid files. The DRUMKIT fixture checks persistent yellow lock colour across pad selection/randomization, and restoration after unlock/exit. `kit_lights_native.py` verifies the compiled ARM64 LED relay installation and colour forwarding at the final native LED setter.
