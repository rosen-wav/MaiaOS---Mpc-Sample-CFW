#define _GNU_SOURCE
#include "host.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>

static uintptr_t base;
static _Alignas(16) unsigned char state[PC_SHARED_STATE_SIZE], other[PC_SHARED_STATE_SIZE];
static unsigned controls, audio, loads;
uintptr_t pc_imagebase(void){return base;}
uintptr_t pc_loader_statebase(void);
int pc_loader_init_with_state(void*,size_t);
int pc_loader_physical(uintptr_t,unsigned);
void pc_bridge_input(uintptr_t,uintptr_t,unsigned,unsigned);
void pc_loader_fx_release(uintptr_t);

static int physical(uintptr_t object,unsigned down)
{
    assert(object==22&&down==1);
    controls++;
    return 1;
}
static void input(uintptr_t owner,uintptr_t buffer,unsigned frames,unsigned offset)
{
    assert(owner==7&&buffer==8&&frames==128&&offset==0);
    audio++;
}
static const PcApi api={.magic=PC_MAGIC,.version=6,.physical=physical,.audio_input=input,
 .audio_extension_magic=0x303730415544494fULL,.audio_extension_size=sizeof(PcApi)};
static const PcApi *init(uintptr_t image,void *storage,size_t size)
{
    assert(image==base&&storage==state&&size==sizeof state);
    assert(pc_loader_statebase()==(uintptr_t)state);
    loads++;
    return &api;
}
static void *open_mock(const char *name,int mode)
{
    assert(!strcmp(name,"/run/mpc-pc-integrated-v040/libpc-host.aarch64.so")&&mode==2);
    return (void*)1;
}
static void *symbol_mock(void *handle,const char *name)
{
    assert(handle==(void*)1&&!strcmp(name,"pc_init_with_state"));
    return (void*)init;
}
static void stub(unsigned offset,void *address)
{
    unsigned char code[]={0x48,0xb8,0,0,0,0,0,0,0,0,0xff,0xe0};
    memcpy(code+2,&address,sizeof address);
    memcpy((void*)(base+offset),code,sizeof code);
}
int main(void)
{
    base=(uintptr_t)mmap(NULL,0xc00000,PROT_READ|PROT_WRITE|PROT_EXEC,
                        MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
    assert(base!=(uintptr_t)MAP_FAILED);
    stub(0xb51898,symbol_mock);
    stub(0xb518a8,open_mock);
    assert(!pc_loader_init_with_state(state+1,sizeof state-1));
    assert(!pc_loader_init_with_state(state,sizeof state-1));
    assert(pc_loader_init_with_state(state,sizeof state));
    assert(pc_loader_init_with_state(state,sizeof state)&&loads==1);
    assert(!pc_loader_init_with_state(other,sizeof other));
    assert(pc_loader_physical(22,1)&&controls==1);
    pc_bridge_input(7,8,128,0);
    assert(audio==1);
    *(uintptr_t*)(state+0x1eb0)=55;
    pc_loader_fx_release(55);
    assert(!*(uintptr_t*)(state+0x1eb0)&&*(unsigned*)(state+0x1ef4)==1);
    puts("Relocated bridge forwards controls and audio, and updates the shared state");
}
