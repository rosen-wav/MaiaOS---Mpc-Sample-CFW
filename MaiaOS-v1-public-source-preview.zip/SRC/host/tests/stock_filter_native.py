"""Exercise the host bridge using the original ARM64 FilterS80 kernel."""
import argparse
import math
import struct
from collections import deque

from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM64, UC_HOOK_CODE, UC_MODE_ARM
from unicorn.arm64_const import (
    UC_ARM64_REG_D0, UC_ARM64_REG_D1, UC_ARM64_REG_LR, UC_ARM64_REG_PC,
    UC_ARM64_REG_S0, UC_ARM64_REG_S1, UC_ARM64_REG_SP, UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2,
)

parser = argparse.ArgumentParser()
parser.add_argument("--native", required=True)
parser.add_argument("--host", required=True)
args = parser.parse_args()

uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
host_base = 0x10000000
memory = 0x20000000
uc.mem_map(0, 0x7400000)
uc.mem_map(host_base, 0x1800000)
uc.mem_map(memory, 0x100000)

for filename, base in ((args.native, 0), (args.host, host_base)):
    with open(filename, "rb") as file:
        elf = ELFFile(file)
        for segment in elf.iter_segments():
            if segment["p_type"] == "PT_LOAD":
                uc.mem_write(base + segment["p_vaddr"], segment.data())
        if base:
            for relocation in elf.get_section_by_name(".rela.dyn").iter_relocations():
                if relocation["r_info_type"] == 1027:
                    uc.mem_write(base + relocation["r_offset"],
                                 struct.pack("<Q", base + relocation["r_addend"]))
            dynamic = elf.get_section_by_name(".dynsym")
            for relocation in elf.get_section_by_name(".rela.plt").iter_relocations():
                name = dynamic.get_symbol(relocation["r_info_sym"]).name
                target = {"memcpy": memory+0x80, "memset": memory+0x90}.get(name)
                if target:
                    uc.mem_write(base+relocation["r_offset"], struct.pack("<Q", target))
            symbols = {
                symbol.name: base + symbol["st_value"]
                for symbol in elf.get_section_by_name(".symtab").iter_symbols()
                if symbol["st_value"]
            }


def libc(emu, pc, _size, _data):
    dest=emu.reg_read(UC_ARM64_REG_X0)
    arg=emu.reg_read(UC_ARM64_REG_X1)
    size=emu.reg_read(UC_ARM64_REG_X2)
    data=bytes(emu.mem_read(arg,size)) if pc==memory+0x80 else bytes([arg&255])*size
    emu.mem_write(dest,data)
    emu.reg_write(UC_ARM64_REG_PC,emu.reg_read(UC_ARM64_REG_LR))

for address in (memory+0x80,memory+0x90):
    uc.hook_add(UC_HOOK_CODE,libc,begin=address,end=address)

def put(address, fmt, *values):
    uc.mem_write(address, struct.pack("<" + fmt, *values))


last_native_call = deque(maxlen=12)
uc.hook_add(UC_HOOK_CODE, lambda _u, pc, _s, _d: last_native_call.append(pc), begin=0xB513A8, end=0xB55B00)

def call(address, *values, s0=None):
    uc.reg_write(UC_ARM64_REG_SP, memory + 0xFF000)
    uc.reg_write(UC_ARM64_REG_LR, memory)
    for index, value in enumerate(values):
        uc.reg_write(UC_ARM64_REG_X0 + index, value)
    if s0 is not None:
        uc.reg_write(UC_ARM64_REG_S0, struct.unpack("<I", struct.pack("<f", s0))[0])
    try:
        uc.emu_start(address, memory, count=2_000_000)
    except Exception as error:
        raise RuntimeError(f"Failed at {uc.reg_read(UC_ARM64_REG_PC):#x}, last native {[hex(x) for x in last_native_call]}") from error
    assert uc.reg_read(UC_ARM64_REG_PC) == memory
    return uc.reg_read(UC_ARM64_REG_X0)


def f64(reg):
    return struct.unpack("<d", struct.pack("<Q", uc.reg_read(reg)))[0]


def math_call(emu, pc, _size, _data):
    x = f64(UC_ARM64_REG_D0)
    if pc == 0xB516E8:
        base = struct.unpack("<f", struct.pack("<I", emu.reg_read(UC_ARM64_REG_S0)))[0]
        exponent = struct.unpack("<f", struct.pack("<I", emu.reg_read(UC_ARM64_REG_S1)))[0]
        emu.reg_write(UC_ARM64_REG_S0, struct.unpack("<I", struct.pack("<f", base ** exponent))[0])
    elif pc == 0xB51BF8:
        put(emu.reg_read(UC_ARM64_REG_X0), "d", math.sin(x))
        put(emu.reg_read(UC_ARM64_REG_X1), "d", math.cos(x))
    else:
        if pc == 0xB51C08:
            result = x ** f64(UC_ARM64_REG_D1)
        else:
            result = {0xB51A68: math.exp, 0xB51AB8: math.cos, 0xB51C18: math.tan}[pc](x)
        emu.reg_write(UC_ARM64_REG_D0, struct.unpack("<Q", struct.pack("<d", result))[0])
    emu.reg_write(UC_ARM64_REG_PC, emu.reg_read(UC_ARM64_REG_LR))


for address in (0xB516E8, 0xB51A68, 0xB51AB8, 0xB51BF8, 0xB51C08, 0xB51C18):
    uc.hook_add(UC_HOOK_CODE, math_call, begin=address, end=address)

# Use the original stock initializer to build cutoff and interpolation tables.
call(0x22329B0, s0=44100.0)
call(symbols["pc_stock_filter_init"])
instrument, section, state = (memory + x for x in (0x1000, 0x5000, 0x6000))
left, right, program, packet = (memory + x for x in (0x7000, 0x8000, 0x9000, 0xC000))
put(instrument + 0x2340, "Q", section)
frames = 256
dry = [0.2 * math.sin(index * 2.0) for index in range(frames)]


def block(cutoff, note_filter=0):
    put(section + 0x498, "f", cutoff)
    put(left, "256f", *dry)
    put(right, "256f", *[0.0] * frames)
    call(symbols["pc_stock_filter_render"], state, instrument, note_filter, left, right, frames)
    samples = struct.unpack("<256f", uc.mem_read(left, frames * 4))
    silent = struct.unpack("<256f", uc.mem_read(right, frames * 4))
    assert all(math.isfinite(x) and abs(x) < 16.0 for x in samples)
    assert max(map(abs, silent)) < 1e-5
    return sum(x * x for x in samples)


put(section + 0x420, "I", 0)
dry_energy = block(1.0)
assert dry_energy > 4.0
# Movement of the audio-side pad parameter changes an already-running filter.
put(section + 0x420, "I", 3)
open_energy = block(1.0)
for _ in range(8):
    closed_energy = block(0.15)
assert closed_energy < open_energy * 0.01
for _ in range(8):
    reopened_energy = block(1.0)
assert reopened_energy > closed_energy * 100.0

# Verify the same packed cutoff payload used by the stock sample-note path.
put(packet + 12, "H", 4)
put(packet + 16, "B", 51)
note_filter = call(symbols["pc_stock_filter_note"], program, packet)
assert note_filter == 0x100 | 51
for _ in range(8):
    absolute_energy = block(1.0, note_filter)
assert absolute_energy < reopened_energy * 0.01
engine, locks = memory + 0xD000, memory + 0xE000
put(program + 0x1FB8, "Q", engine)
put(engine + 0xF0, "Q", locks)
put(locks + 0x9C, "I", 1)
assert call(symbols["pc_stock_filter_note"], program, packet) == 0x200 | 51

for mode in range(1, 30):
    put(section + 0x420, "I", mode)
    block(0.3)
    block(0.8)

# Switch to bypass while a low-pass filter is attenuating a sustained
# signal. The first sample must still be the old kernel's output.
put(section+0x420,"I",2)
for _ in range(8):
    block(.15)
reference=memory+0x6400
uc.mem_write(reference,bytes(uc.mem_read(state,416)))
block(.15)
expected=struct.unpack("<256f",uc.mem_read(left,1024))
uc.mem_write(state,bytes(uc.mem_read(reference,416)))
put(section+0x420,"I",0)
block(.15)
mixed=struct.unpack("<256f",uc.mem_read(left,1024))
assert abs(mixed[0]-expected[0])<1e-6
assert sum(abs(a-b) for a,b in zip(mixed,dry))>.05
block(.15)
assert struct.unpack("<256f",uc.mem_read(left,1024))[-1]==struct.unpack("<f",struct.pack("<f",dry[-1]))[0]

print("Stock ARM64 FilterS80 modes, stereo isolation, live pad cutoff and 16 Levels locks passed")


# Live Input FX uses the same stock kernel with a separate stereo state.
input_state = memory + 0x6500
vocal_mode = 26
for _ in range(8):
    put(left, "256f", *dry)
    put(right, "256f", *[0.0] * frames)
    uc.reg_write(UC_ARM64_REG_S1, 0)
    call(symbols["pc_stock_filter_process"], input_state, vocal_mode, left, right, frames, s0=1.0)
vocal = struct.unpack("<256f", uc.mem_read(left, 1024))
assert all(math.isfinite(x) for x in vocal)
assert sum(abs(a-b) for a,b in zip(vocal,dry)) > .05
assert max(map(abs, struct.unpack("<256f", uc.mem_read(right,1024)))) < 1e-5
assert call(symbols["pc_synth_filter_type"], call(symbols["pc_synth_filter_type_position"], vocal_mode)) == vocal_mode
print("Live Input FX uses stock VOCAL1 with stereo isolation")

# The live input callback applies VOCAL1 even when all three sends are zero.
def bypass_dependency(emu, _pc, _size, _data):
    emu.reg_write(UC_ARM64_REG_X0, 0)
    emu.reg_write(UC_ARM64_REG_PC, emu.reg_read(UC_ARM64_REG_LR))

for name in ("pc_bounce_input", "pc_ms_input", "pc_padfx_record_input"):
    dependency = symbols[name]
    uc.hook_add(UC_HOOK_CODE, bypass_dependency, begin=dependency, end=dependency)

input_object, channels = memory + 0xF000, memory + 0xF100
put(channels, "QQ", left, right)
for _ in range(8):
    put(left, "256f", *dry)
    put(right, "256f", *[0.0] * frames)
    call(symbols["pc_audio_input"], input_object, channels, frames, 0)
live_vocal = struct.unpack("<256f", uc.mem_read(left, 1024))
assert max(abs(a-b) for a,b in zip(live_vocal,vocal)) < 1e-6
print("Input FX default Vocal1 processes the live input with sends off")
