#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "chord_files.h"
static const uint8_t midi[]={
 'M','T','h','d',0,0,0,6,0,1,0,2,1,0xe0,
 'M','T','r','k',0,0,0,16,0,0xff,0x51,3,7,0xa1,0x20,0,0xf0,2,0x7d,0xf7,0,0xff,0x2f,0,
 'M','T','r','k',0,0,0,29,
 0,0x90,60,100,0,64,80,0,67,90,0x83,0x60,0x90,62,110,0,65,70,0,69,100,0,0x90,69,0,0,0xff,0x2f,0};
int main(void){ChordBank bank;
 assert(pc_chord_file_parse(midi,sizeof midi,&bank));assert(bank.count==16&&bank.reference==60&&bank.pads[0].count==3&&bank.pads[1].count==3);
 assert(bank.pads[0].notes[0]==60&&bank.pads[0].notes[2]==67&&bank.pads[0].velocities[1]==80&&bank.pads[1].notes[0]==62&&bank.pads[2].count==0);
 ChordBank restored;assert(pc_chord_file_parse((const uint8_t*)&bank,sizeof bank,&restored));assert(!memcmp(&bank,&restored,sizeof bank));
 for(unsigned n=0;n<sizeof midi;n++)assert(!pc_chord_file_parse(midi,n,&bank));
 uint8_t bad[sizeof midi];memcpy(bad,midi,sizeof midi);bad[8]=2;assert(!pc_chord_file_parse(bad,sizeof bad,&bank));memcpy(bad,midi,sizeof midi);bad[14+8]=0x80;bad[14+9]=0x80;bad[14+10]=0x80;bad[14+11]=0x80;assert(!pc_chord_file_parse(bad,sizeof bad,&bank));
 const char*files[]={"Bank1","Bank2","Bank3","Bank4","Bank5"};unsigned counts[]={3,6,8,11,16},first[]={47,49,51,53,55};
 for(unsigned i=0;i<5;i++){char path[128],bytes[8192];snprintf(path,sizeof path,"tests/fixtures/%s.progression",files[i]);FILE*f=fopen(path,"rb");assert(f);size_t size=fread(bytes,1,sizeof bytes,f);fclose(f);assert(pc_chord_file_parse((const uint8_t*)bytes,size,&bank));assert(bank.pads[0].notes[0]==first[i]);for(unsigned n=0;n<counts[i];n++){assert(bank.pads[n].count);for(unsigned k=0;k<bank.pads[n].count;k++)assert(bank.pads[n].velocities[k]==100);}for(unsigned n=counts[i];n<16;n++)assert(!bank.pads[n].count);for(unsigned n=0;n<size-1;n++)assert(!pc_chord_file_parse((const uint8_t*)bytes,n,&restored));}
 const char*json="\xef\xbb\xbf{\"progression\":{\"metadata\":{\"x\":[true,false,null,-1.5e2]},\"chords\":[{\"velocities\":[30,90,127],\"notes\":[60,64,67],\"name\":\"C\\u266f\"}],\"name\":\"Test\"}}";
 assert(pc_chord_file_parse((const uint8_t*)json,strlen(json),&bank)&&bank.pads[0].velocities[0]==30&&!strcmp(bank.pads[0].name,"C♯"));
 const char*invalid[]={"{\"chords\":[{\"notes\":[128]}]}","{\"chords\":[{\"notes\":[-1]}]}","{\"chords\":[{\"notes\":[60],\"velocities\":[1,2]}]}","{\"chords\":[{\"notes\":[60],}]}","{\"chords\":[{\"notes\":[60]}]} garbage","{\"chords\":[{\"notes\":[01]}]}","{\"chords\":[{\"notes\":[60.5]}]}"};
 for(unsigned n=0;n<sizeof invalid/sizeof *invalid;n++)assert(!pc_chord_file_parse((const uint8_t*)invalid[n],strlen(invalid[n]),&bank));
 puts("MIDI plus five synthetic .progression banks, velocities, Unicode, metadata, malformed and truncated JSON passed");
}
