#include <cassert>
#include <cmath>
#include <cstdio>
extern "C" void pc_mastering2_process(float*,float*,unsigned,const unsigned*,unsigned);
extern "C" {
#include "../src/limiter.h"
}
int main(){
    constexpr unsigned n=4096;
    float l[n],r[n],a[n],b[n];
    unsigned values[7]={0,0,8192,8192,8192,8192,16383};
    for(unsigned mode=0;mode<6;mode++){
        values[6]=(mode*16384+5)/6;
        for(unsigned i=0;i<n;i++){l[i]=a[i]=4*std::sin(i*.17);r[i]=b[i]=-4*std::sin(i*.11);}
        pc_mastering2_process(l,r,n,values,1);
        pc_mastering2_process(a,b,256,values,1);
        for(unsigned i=256;i<n;i+=256)pc_mastering2_process(a+i,b+i,256,values,0);
        for(unsigned i=0;i<n;i++){
            assert(std::isfinite(l[i])&&std::isfinite(r[i]));
            assert(std::abs(l[i])<1&&std::abs(r[i])<1);
            assert(l[i]==a[i]&&r[i]==b[i]);
        }
    }
    for(unsigned i=0;i<n;i++){l[i]=a[i]=.7f*std::sin(i*.17);r[i]=b[i]=.8f*std::cos(i*.11);}
    pc_limiter_process(l,r,a,b,n,1);
    for(unsigned i=0;i<n;i++){
        assert(std::abs(l[i]-a[i])<1.e-6f&&std::abs(r[i]-b[i])<1.e-6f);
        l[i]+=4*std::sin(i*.3);r[i]+=4*std::cos(i*.23);
    }
    pc_limiter_process(l,r,a,b,n,1);
    for(unsigned i=0;i<n;i++)assert(std::abs(l[i])<=.999f&&std::abs(r[i])<=.999f);
    puts("Mastering2 clipping, continuous block state, all dither modes and dry sidechain exemption passed");
}
