"""Run compiled ARM64 chord import against original MPC progression JSON."""
import argparse,json,struct
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
p=argparse.ArgumentParser();p.add_argument('--host',required=True);args=p.parse_args()
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0x10000000,0x1000000);u.mem_map(0x20000000,0x200000)
e=ELFFile(open(args.host,'rb'));base=0x10000000
for s in e.iter_segments():
 if s['p_type']=='PT_LOAD':u.mem_write(base+s['p_vaddr'],s.data())
for r in e.get_section_by_name('.rela.dyn').iter_relocations():
 if r['r_info_type']==1027:u.mem_write(base+r['r_offset'],struct.pack('<Q',base+r['r_addend']))
symbols={s.name:base+s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols() if s['st_value']};stubs={}
for i,r in enumerate(e.get_section_by_name('.rela.plt').iter_relocations()):
 name=e.get_section_by_name('.dynsym').get_symbol(r['r_info_sym']).name;address=0x20001000+4*i;stubs[address]=name;u.mem_write(base+r['r_offset'],struct.pack('<Q',address))
def reg(n):return u.reg_read(UC_ARM64_REG_X0+n)
def hook(uc,pc,size,data):
 if pc==0x20000000:uc.emu_stop();return
 if pc not in stubs:return
 name=stubs[pc];a,b,n=reg(0),reg(1),reg(2)
 if name in ('memcpy','memmove'):u.mem_write(a,bytes(u.mem_read(b,n)));value=a
 elif name=='memset':u.mem_write(a,bytes([b&255])*n);value=a
 elif name=='memcmp':
  x,y=bytes(u.mem_read(a,n)),bytes(u.mem_read(b,n));value=(x>y)-(x<y)
 else:raise AssertionError(name)
 u.reg_write(UC_ARM64_REG_X0,value&0xffffffffffffffff);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
u.hook_add(UC_HOOK_CODE,hook)
for path in sorted((Path(__file__).parent/'fixtures').glob('*.progression')):
 raw=path.read_bytes();u.mem_write(0x20010000,raw);u.mem_write(0x20020000,bytes(1088));u.reg_write(UC_ARM64_REG_SP,0x201ff000);u.reg_write(UC_ARM64_REG_LR,0x20000000)
 for n,v in enumerate([0x20010000,len(raw),0x20020000]):u.reg_write(UC_ARM64_REG_X0+n,v)
 u.emu_start(symbols['pc_chord_file_parse'],0x20000004,count=10000000);assert reg(0)==1,path
 bank=bytes(u.mem_read(0x20020000,1088));source=json.loads(raw)['progression'];assert bank[:8]==b'MPCCHD1\0'
 for i,chord in enumerate(source['chords'][:16]):
  pad=bank[64+64*i:128+64*i];count=struct.unpack('<I',pad[32:36])[0];assert count==len(chord['notes']) and list(pad[36:36+count])==chord['notes'];assert pad[:32].split(b'\0')[0].decode()==chord['name'][:31];assert list(pad[44:44+count])==[100]*count
print('Compiled ARM64 importer preserves all five original .progression banks, chord names, ordered pitches and velocities')
