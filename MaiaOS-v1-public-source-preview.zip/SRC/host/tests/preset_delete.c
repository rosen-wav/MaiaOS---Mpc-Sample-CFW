#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include "../src/user_presets.c"

Host host;
static char temp_root[]="/tmp/maia-preset-delete-XXXXXX";
static const char *local(long input,char output[160]){
 const char *path=(const char*)input;
 assert(!strncmp(path,"/media/MPCSSH",13));
 snprintf(output,160,"%s%s",temp_root,path+13);
 return output;
}
static long result(long status){return status<0?-errno:status;}
long pc_sys(long number,long a,long b,long c,long d,long e,long f){
 char first[160],second[160];
 switch(number){
 case 34:return result(mkdir(local(b,first),c));
 case 35:return result(unlink(local(b,first)));
 case 38:return result(rename(local(b,first),local(d,second)));
 case 56:return result(open(local(b,first),(c&~0x4000)|((c&0x4000)?O_DIRECTORY:0),d));
 case 57:return result(close(a));
 case 63:return result(read(a,(void*)b,c));
 case 64:return result(write(a,(const void*)b,c));
 case 82:return result(fsync(a));
 default:assert(0);return -1;
 }
}
unsigned pc_engine_count(unsigned engine){return engine<10?12:0;}
int pc_find(uintptr_t instrument){return instrument==2?0:-1;}
int pc_assign(uintptr_t p,uintptr_t i,unsigned engine,unsigned preset,const uint8_t *patch){
 assert(0&&"Erase must never load a preset");return 0;
}
int main(void){
 assert(mkdtemp(temp_root));
 uint8_t patch[512]={42},out[512];
 assert(pc_preset_write(4,2,patch));
 assert(!pc_preset_hidden(4,2)&&pc_preset_read(4,2,out)==1);
 assert(pc_preset_delete(4,2));
 assert(pc_preset_hidden(4,2)&&!pc_preset_hidden(4,3));
 assert(pc_preset_read(4,2,out)==0);
 assert(!pc_preset_hidden(7,2)&&pc_preset_hidden(4,2));

 uintptr_t globals=(uintptr_t)calloc(1,0x2000),behaviour=(uintptr_t)calloc(1,0x100),manager=(uintptr_t)calloc(1,0x100);
 assert(globals&&behaviour&&manager);
 host.base=globals-G;
 Q(globals,0x20)=behaviour;Q(behaviour,0x30)=manager;I(manager,0xd8)=0x20a7;
 host.slots[0].engine=4;
 user.active=2;user.mode=0x20a7;user.engine=4;user.program=1;user.instrument=2;
 assert(pc_user_write(4,0,2,"First",patch)&&pc_user_write(4,1,3,"Second",patch));
 scan();assert(user.count==2);
 pc_user_event(12,PC_PRESET_ERASE,1,2);assert(user.active==6&&user.delete_choice==PC_KEEP);
 pc_user_event(12,3,1,2);assert(user.count==2&&pc_user_read(4,0,out,0,0)==1);
 pc_user_event(12,PC_PRESET_ERASE,1,2);
 pc_user_event(14,1,1,2);
 pc_user_event(12,3,1,2);assert(user.count==1&&user.ids[0]==1&&pc_user_read(4,0,out,0,0)==0);
 pc_user_event(12,PC_PRESET_ERASE,1,2);
 patch[0]=12;assert(pc_user_write(4,1,3,"Second",patch));
 pc_user_event(14,1,1,2);
 pc_user_event(12,3,1,2);
 assert(pc_user_read(4,1,out,0,0)==1&&out[0]==12);
 char name[80],file[160];
 assert(!unlink(local((long)"/media/MPCSSH/mpc-pc-presets/hidden-4",file)));
 path(name,4,1,0);assert(!unlink(local((long)name,file)));
 assert(!rmdir(local((long)"/media/MPCSSH/mpc-pc-presets",file))&&!rmdir(local((long)root,file))&&!rmdir(temp_root));
 free((void*)globals);free((void*)behaviour);free((void*)manager);
 puts("Factory preset visibility and named preset Keep, Delete and changed-file protection passed");
}
