#define _GNU_SOURCE
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include "../src/usb_cue.c"

Host host;
static unsigned sd_muted,info_calls,write_calls;
static long accept_frames=-1;
static unsigned usb_channels=2;
static int32_t received[CUE_MAX*2];
unsigned pc_sd_access_muted(void){return sd_muted;}
static long native_write(uintptr_t pcm,const void *data,unsigned long frames){
 (void)pcm;write_calls++;
 assert(frames<=CUE_MAX);
 memcpy(received,data,frames*2*sizeof(int32_t));
 return accept_frames< -1?accept_frames:accept_frames<0?(long)frames:accept_frames;
}
static int native_close(uintptr_t pcm){(void)pcm;return 0;}
static unsigned long metadata_size(void){return 256;}
static int get_info(uintptr_t pcm,void *data){
 info_calls++;
 strcpy(data,pcm==2?"UAC2 PCM":"Physical I2S");
 return 0;
}
static const char *get_id(const void *data){return data;}
static int get_params(uintptr_t pcm,void *data){(void)pcm;(void)data;return 0;}
static int get_format(const void *data,int *format){(void)data;*format=10;return 0;}
static int get_channels(const void *data,unsigned *channels){(void)data;*channels=usb_channels;return 0;}
static int get_rate(const void *data,unsigned *rate,int *direction){(void)data;*rate=44100;*direction=0;return 0;}
static void *resolve(void *scope,const char *name){
 (void)scope;
 if(!strcmp(name,"snd_pcm_writei"))return native_write;
 if(!strcmp(name,"snd_pcm_close"))return native_close;
 if(!strcmp(name,"snd_pcm_info"))return get_info;
 if(!strcmp(name,"snd_pcm_info_get_id"))return get_id;
 if(!strcmp(name,"snd_pcm_hw_params_current"))return get_params;
 if(!strcmp(name,"snd_pcm_hw_params_get_format"))return get_format;
 if(!strcmp(name,"snd_pcm_hw_params_get_channels"))return get_channels;
 if(!strcmp(name,"snd_pcm_hw_params_get_rate"))return get_rate;
 if(!strcmp(name,"snd_pcm_info_sizeof")||!strcmp(name,"snd_pcm_hw_params_sizeof"))return metadata_size;
 return 0;
}
long pc_sys(long n,long a,long b,long c,long d,long e,long f){
 (void)a;(void)b;(void)c;(void)d;(void)e;(void)f;assert(n==226);return 0;
}
int main(void){
 host.base=(uintptr_t)mmap(0,0x7400000,7,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 assert(host.base!=(uintptr_t)MAP_FAILED);
 unsigned char *code=(unsigned char*)(host.base+0xb51898);void *fn=resolve;
 code[0]=0x48;code[1]=0xb8;memcpy(code+2,&fn,8);code[10]=0xff;code[11]=0xe0;
 Q(host.base,0x716e298)=(uintptr_t)native_write;
 Q(host.base,0x716e1e8)=(uintptr_t)native_close;
 pc_usb_cue_init(4096);
 assert(Q(host.base,0x716e298)==(uintptr_t)pc_usb_cue_write);
 assert(Q(host.base,0x716e1e8)==(uintptr_t)usb_close);
 int32_t source[512];for(unsigned i=0;i<512;i++)source[i]=123456;
 assert(pc_usb_cue_write(2,source,256)==256&&received[0]==123456&&!info_calls);
 pc_usb_cue_enable(1);
 assert(pc_usb_cue_write(1,source,256)==256&&received[0]==123456);
 assert(pc_usb_cue_write(2,source,256)==256&&received[0]==0);
 float left[1024],right[1024];
 for(unsigned i=0;i<1024;i++){left[i]=.25;right[i]=-.5;}
 pc_usb_cue_publish(left,right,1024);
 assert(pc_usb_cue_write(2,source,256)==256);
 assert(received[510]==536870912&&received[511]==-1073741824);
 unsigned calls=info_calls,before=read_index;
 accept_frames=-11;
 assert(pc_usb_cue_write(2,source,256)==-11&&read_index==before);
 accept_frames=100;
 assert(pc_usb_cue_write(2,source,256)==100&&read_index-before>=99&&read_index-before<=101);
 assert(info_calls==calls);
 accept_frames=-1;
 sd_muted=1;
 assert(pc_usb_cue_write(2,source,256)==256);
 for(unsigned i=0;i<512;i++)assert(received[i]==0);
 sd_muted=0;
 pc_usb_cue_enable(0);
 assert(pc_usb_cue_write(2,source,256)==256&&received[0]==123456);
 usb_close(2);usb_channels=4;
 pc_usb_cue_enable(1);
 assert(pc_usb_cue_write(2,source,256)==256&&received[0]==123456);
 assert(info_calls==calls+1);
 printf("USB cue: native GOT hook, physical output isolation, exact S32 stereo, partial writes, EAGAIN, SD silence, exit and PCM reopen passed (%u writes)\n",write_calls);
}
