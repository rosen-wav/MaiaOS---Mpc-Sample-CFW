#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "internal.h"
void pc_diag_value(unsigned field,unsigned value){(void)field;(void)value;}
Host host;static long tick;static unsigned user0,idle0,user1,idle1;
long pc_sys(long n,long a,long b,long c,long d,long e,long f){(void)a;(void)c;(void)d;(void)e;(void)f;
 if(n==113){((long*)b)[0]=tick/1000;((long*)b)[1]=tick%1000*1000000;return 0;}
 if(n==56)return 10;if(n==57)return 0;
 if(n==63)return sprintf((char*)b,"cpu  0 0 0 0 0 0 0 0\ncpu0 %u 0 0 %u 0 0 0 0\ncpu1 %u 0 0 %u 0 0 0 0\n",user0,idle0,user1,idle1);
 assert(0);return -1;
}
int main(void){host.base=(uintptr_t)calloc(1,G+0x100);assert(host.base);pc_cpu_poll();assert(!pc_cpu_overloaded());
 for(unsigned i=1;i<=10;i++){tick=i*500;user0+=98;idle0+=2;idle1+=100;pc_cpu_poll();assert(!pc_cpu_overloaded());}
 tick=5500;user0+=98;idle0+=2;idle1+=100;pc_cpu_poll();assert(pc_cpu_overloaded()&&pc_cpu_warning());
 for(unsigned i=0;i<4;i++){tick+=500;user0+=100;idle1+=100;pc_cpu_poll();assert(pc_cpu_overloaded());}assert(!pc_cpu_warning());
 tick+=500;user0+=97;idle0+=3;idle1+=100;pc_cpu_poll();assert(!pc_cpu_overloaded());
 for(unsigned i=0;i<9;i++){tick+=500;idle0+=100;user1+=99;idle1++;pc_cpu_poll();assert(!pc_cpu_overloaded());}
 tick+=500;idle0+=100;user1+=97;idle1+=3;pc_cpu_poll();assert(!pc_cpu_overloaded());
 for(unsigned i=0;i<10;i++){tick+=500;idle0+=100;user1+=100;pc_cpu_poll();assert(!pc_cpu_overloaded());}
 tick+=500;idle0+=100;user1+=100;pc_cpu_poll();assert(pc_cpu_overloaded());
 puts("98 percent per-core CPU threshold, continuous five-second qualification, reset and temporary popup passed");
}
