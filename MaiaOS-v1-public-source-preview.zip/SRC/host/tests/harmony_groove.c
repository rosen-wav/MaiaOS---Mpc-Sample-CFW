#include <assert.h>
#include <stdio.h>
#include "harmony_groove.h"
static struct {int64_t tick,duration;unsigned pitch;float velocity;} out[65536];static unsigned count;
static int emit(void*context,int64_t tick,int64_t duration,unsigned pitch,float velocity){(void)context;assert(count<65536);out[count].tick=tick;out[count].duration=duration;out[count].pitch=pitch;out[count++].velocity=velocity;return 1;}
int main(void){
 PcHarmonyNote notes[]={{0,3840,.8f,120},{0,3840,.7f,124},{0,3840,.9f,127},{3840,3840,.6f,122},{3840,3840,.8f,125},{3840,3840,1,129}};
 count=0;assert(pc_harmony_generate(notes,6,7680,0,0,1,emit,0)==2);assert(out[0].pitch==120&&out[1].pitch==122&&out[0].duration==3840);
 count=0;assert(pc_harmony_generate(notes,6,7680,1,0,1,emit,0)==2);assert(out[0].pitch==127&&out[1].pitch==129&&out[1].tick==3840);
 count=0;assert(pc_harmony_generate(notes,6,7680,2,0,1,emit,0)==16);assert(out[0].pitch==120&&out[1].pitch==124&&out[2].pitch==127&&out[8].pitch==122);
 count=0;assert(pc_harmony_generate(notes,6,7680,2,1,1,emit,0)==16);assert(out[0].pitch==127&&out[1].pitch==124&&out[2].pitch==120);
 count=0;assert(pc_harmony_generate(notes,6,7680,2,2,1,emit,0));assert(out[0].pitch==120&&out[1].pitch==124&&out[2].pitch==127&&out[3].pitch==124&&out[4].pitch==120);
 for(unsigned pattern=0;pattern<pc_arp_count();pattern++){
  count=0;assert(pc_harmony_generate(notes,6,7680,2,pattern,123,emit,0)>0);assert(count>4);
  for(unsigned n=0;n<count;n++){assert(out[n].tick>=0&&out[n].tick+out[n].duration<=7680&&out[n].duration>0&&out[n].velocity>0&&out[n].velocity<=1);if(out[n].tick<3840)assert(out[n].tick+out[n].duration<=3840);}
 }
 PcHarmonyNote longnotes[]={{0,491520,.8f,120},{0,491520,.7f,124},{0,491520,.9f,127}};
 count=0;assert(pc_harmony_generate(longnotes,3,491520,2,12,1,emit,0)==2048);assert(out[count-1].tick+out[count-1].duration<=491520);
 assert(!pc_harmony_generate(notes,6,7680,2,pc_arp_count(),1,emit,0));
 puts("bass, highest-note lead, all arp patterns, velocities and 128-bar bounds passed");
}
