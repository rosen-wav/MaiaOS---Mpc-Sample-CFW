#define _GNU_SOURCE
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <string.h>
#include "../src/mix.c"
Host host;
static unsigned routed,processed,native_calls;
static void native_effect(uintptr_t fx,uintptr_t buffer,unsigned n){
 assert(I(fx,0x2f8)==1&&n==8);native_calls++;
 float*l=(float*)Q(Q(buffer,0x10),0),*r=(float*)Q(Q(buffer,0x10),8);
 for(unsigned j=0;j<n;j++){assert(l[j]==.25f&&r[j]==-.5f);l[j]*=2;r[j]*=2;}
 *(uint8_t*)(buffer+0x128)=0;
}

int pc_project_new_pending(void){return 0;}
void pc_native_input_process(uintptr_t i,uintptr_t b,unsigned n){assert(0);}
void pc_padfx_record_audio(uintptr_t p){(void)p;}
int pc_bounce_ensure_synth(uintptr_t b,unsigned n){return 0;}
void pc_bounce_synth_route(uintptr_t b,unsigned n){}
void pc_bounce_fx(uintptr_t b,unsigned n){}
unsigned pc_limiter_enabled(void){return 0;}
void pc_limiter_process(float*l,float*r,const float*a,const float*b,unsigned n,unsigned epoch){assert(0);}
int pc_fx_workers_run(const PcFxWork *w,unsigned n){return 0;}
void pc_galactic_process(unsigned slot,float*l,float*r,unsigned n,const float*p,unsigned gen){
 assert(slot==0&&n==8);processed++;for(unsigned i=0;i<n;i++){assert(l[i]==.25f&&r[i]==-.5f);l[i]*=2;r[i]*=2;}
}
void pc_dj_graph_audio(unsigned n,float (*buses)[2][4096],unsigned active){
 assert(n==8&&active==1);routed++;
 for(unsigned i=0;i<n;i++){buses[0][0][i]+=.25f;buses[0][1][i]-=.5f;}
}
int main(){
 host.base=(uintptr_t)mmap(0,G+0x2000,7,MAP_ANONYMOUS|MAP_PRIVATE,-1,0);assert(host.base!=(uintptr_t)MAP_FAILED);
 uint8_t*stub=(void*)(host.base+0x27599e0);void*fn=native_effect;stub[0]=0x48;stub[1]=0xb8;memcpy(stub+2,&fn,8);stub[10]=0xff;stub[11]=0xe0;
 Q(host.base+G,0x1eb0)=1;
 uintptr_t owner=(uintptr_t)calloc(1,0x1000),ins=(uintptr_t)calloc(1,0x200);assert(owner&&ins);
 mix.owner=owner;mix.inserts=ins;mix.ready=1;
 for(unsigned k=0;k<3;k++)mix.types[k]=-1;
 mix.types[0]=31;extra.ctx[0][3]=(void*)1;
 // No native voices, no native effect-vector entries: custom send must run.
 float l[20]={0},r[20]={0};pc_mix_dj_fallback(l,r,4,8);
 assert(routed==1&&processed==1);
 for(unsigned i=0;i<20;i++){assert(l[i]==(i>=4&&i<12?.5f:0));assert(r[i]==(i>=4&&i<12?-1.f:0));}
 uintptr_t vec=(uintptr_t)calloc(3,8),fx=(uintptr_t)calloc(1,0x400);assert(vec&&fx);
 Q(ins,0x108)=vec;Q(ins,0x110)=vec+24;Q(vec,0)=fx;mix.types[0]=0;
 memset(l,0,sizeof l);memset(r,0,sizeof r);pc_mix_dj_fallback(l,r,4,8);
 assert(native_calls==1&&routed==2&&I(fx,0x2f8)==1);
 for(unsigned i=0;i<20;i++){assert(l[i]==(i>=4&&i<12?.5f:0));assert(r[i]==(i>=4&&i<12?-1.f:0));}
 puts("Native selected send DSP is enabled on its audio owner, receives both deck planes and returns to output");
 puts("DJ sends drain into output with an idle native graph and preserve block offset");
}

unsigned pc_usb_cue_enabled(void){return 0;}
void pc_usb_cue_publish(const float*l,const float*r,unsigned n){(void)l;(void)r;(void)n;}
