#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include "../src/dj_mode.c"
Host host;
static unsigned ticks,sleeps;
static void tick(uint64_t event){assert(event==((10ull<<32)|(59u<<1)|1u));ticks++;}
long pc_sys(long call,long a,long b,long c,long d,long e,long f){
 (void)b;(void)c;(void)d;(void)e;(void)f;
 assert(call==101);long *delay=(long*)a;
 assert(delay[0]==0&&delay[1]==100000000);
 if(++sleeps==3)__atomic_store_n(&bpm_timer_mask,0,RL);
 return 0;
}
int main(void){
 host.base=(uintptr_t)mmap(0,0x7400000,7,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 assert(host.base!=(uintptr_t)MAP_FAILED);
 unsigned char *code=(unsigned char*)(host.base+0x6d43500);void *function=tick;
 code[0]=0x48;code[1]=0xb8;memcpy(code+2,&function,8);code[10]=0xff;code[11]=0xe0;
 bpm_timer_mask=1;bpm_timer_running=1;bpm_timer_worker(0);
 assert(sleeps==3&&ticks==2&&!bpm_timer_running&&!bpm_timer_mask);
 sleeps=ticks=0;bpm_timer_running=1;bpm_timer_worker(0);
 assert(!sleeps&&!ticks&&!bpm_timer_running);
 puts("Held-pad timer posts UI ticks without active audio and stops when all pads release");
}
