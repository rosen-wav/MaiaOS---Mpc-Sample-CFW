#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <chrono>
#include "../src/airwindows.h"
#include <initializer_list>
static float l[256],r[256],before_l[256],before_r[256];
static void clear(){memset(l,0,sizeof l);memset(r,0,sizeof r);}
int main(){
 for(unsigned i=0;i<256;i++){l[i]=.2f*std::sin(i*.173);r[i]=-.7f*l[i];}
 memcpy(before_l,l,sizeof l);memcpy(before_r,r,sizeof r);
 pc_dj_space_process(l,r,256,0,1);
 assert(!memcmp(l,before_l,sizeof l)&&!memcmp(r,before_r,sizeof r));
 // Rise to 100% wet on silence, then inject an impulse. There is no direct copy.
 for(unsigned b=0;b<12;b++){clear();pc_dj_space_process(l,r,256,16383,1);}
 clear();l[0]=1;pc_dj_space_process(l,r,256,16383,1);
 double immediate=0;for(float v:l)immediate+=v*v;
 assert(immediate<.0001);
 double tail=0;for(unsigned b=0;b<1200;b++){
  clear();pc_dj_space_process(l,r,256,16383,1);
  for(unsigned n=0;n<256;n++){assert(std::isfinite(l[n])&&std::isfinite(r[n]));if(b>900)tail+=l[n]*l[n]+r[n]*r[n];}
 }
 printf("DJ full wet: direct impulse energy %.9g; late high-passed reverb energy %.9g\n",immediate,tail);
 assert(tail>1e-10);
 // Returning to zero settles into an exact dry bypass; no frozen old tails.
 for(unsigned b=0;b<12;b++){clear();pc_dj_space_process(l,r,256,0,1);}
 memcpy(l,before_l,sizeof l);memcpy(r,before_r,sizeof r);pc_dj_space_process(l,r,256,0,1);
 assert(!memcmp(l,before_l,sizeof l)&&!memcmp(r,before_r,sizeof r));
 const float params[6]={.9f,.85f,.2f,1.f,1.f,1.f};
 pc_galactic_prepare(0);pc_galactic_prepare(1);
 double wet_energy=0,late=0,other=0,stereo=0;
 auto start=std::chrono::steady_clock::now();
 for(unsigned b=0;b<1800;b++){
  clear();if(!b)l[0]=1;
  pc_galactic_process(0,l,r,256,params,1);
  for(unsigned n=0;n<256;n++){
   assert(std::isfinite(l[n])&&std::isfinite(r[n]));assert(fabs(l[n])<2&&fabs(r[n])<2);
   wet_energy+=l[n]*l[n]+r[n]*r[n];stereo+=r[n]*r[n];
   if(b>1400)late+=l[n]*l[n]+r[n]*r[n];
  }
  clear();pc_galactic_process(1,l,r,256,params,1);
  for(unsigned n=0;n<256;n++)other+=l[n]*l[n]+r[n]*r[n];
 }
 double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
 printf("Galactic sends: energy %.9g, late %.9g, other slot %.9g, stereo %.9g; two 10.4 s renders in %.3f s on test host\n",wet_energy,late,other,stereo,elapsed);
 assert(wet_energy>1e-5&&late>1e-10&&stereo>1e-6&&other<wet_energy*.00001);
 // Generation reset clears a previous project's tail.
 clear();pc_galactic_process(0,l,r,256,params,2);double reset=0;
 for(unsigned i=0;i<256;i++)reset+=l[i]*l[i]+r[i]*r[i];assert(reset<1e-10);
 // Compare the combination against the same reverb without Highpass2.
 double response[2]={0};
 for(unsigned band=0;band<2;band++){
  double input_hz=band?8000:100;double filtered=0,unfiltered=0;
  const float matched[6]={.9473684211f,.85f,.2f,1.f,1.f,1.f};
  for(unsigned b=0;b<700;b++){
   for(unsigned i=0;i<256;i++){
    l[i]=.1*std::sin(6.283185307179586*input_hz*(b*256+i)/44100.);r[i]=l[i];
    before_l[i]=l[i];before_r[i]=r[i];
   }
   pc_dj_space_process(l,r,256,16383,20+band);
   pc_galactic_process(2,before_l,before_r,256,matched,20+band);
   if(b>350)for(unsigned i=0;i<256;i++){
    filtered+=l[i]*l[i]+r[i]*r[i];unfiltered+=before_l[i]*before_l[i]+before_r[i]*before_r[i];
   }
  }
  response[band]=filtered/unfiltered;
 }
 printf("Highpass2 top-fader energy ratios: 100 Hz %.8g; 8 kHz %.8g\n",response[0],response[1]);
 assert(response[1]>response[0]*100&&response[0]<.01);
 // A steady musical signal should not sag through the fader crossfade.
 for(unsigned p: {4096u,8192u,12288u,16383u}){
  double output=0,input=0;
  for(unsigned block=0;block<1600;block++){
   for(unsigned i=0;i<256;i++){
    double t=(block*256+i)/44100.;l[i]=.06*(std::sin(6.283185307*220*t)+std::sin(6.283185307*1800*t)+std::sin(6.283185307*7000*t));r[i]=l[i];
    if(block>1000)input+=l[i]*l[i]+r[i]*r[i];
   }
   pc_dj_space_process(l,r,256,p,100+p);
   if(block>1000)for(unsigned i=0;i<256;i++)output+=l[i]*l[i]+r[i]*r[i];
  }
  printf("DJ fader %u: steady RMS ratio %.3f\n",p,std::sqrt(output/input));
  assert(output/input>.35&&output/input<4);
 }
 puts("Galactic/Highpass DSP: exact dry zero, full wet endpoint, long stereo tails, independent send slots and reset passed");
}
