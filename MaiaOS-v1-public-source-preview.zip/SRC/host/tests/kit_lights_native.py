"""Verify final pad-LED relays and lock colours in the compiled ARM64 host."""
import argparse,struct
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
p=argparse.ArgumentParser();p.add_argument('--native',required=True);p.add_argument('--host',required=True);p.add_argument('--ready-offset',type=int,required=True)
p.add_argument('--shared-state-offset',type=int)
args=p.parse_args()
state_base=0x30000000 if args.shared_state_offset is not None else 0x72a4cb0
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x7800000);u.mem_map(0x10000000,0x1800000);u.mem_map(0x20000000,0x100000)
symbols={}
for path,base in [(args.native,0),(args.host,0x10000000)]:
 e=ELFFile(open(path,'rb'))
 for s in e.iter_segments():
  if s['p_type']=='PT_LOAD':u.mem_write(base+s['p_vaddr'],s.data())
 if base:
  for r in e.get_section_by_name('.rela.dyn').iter_relocations():
   if r['r_info_type']==1027:u.mem_write(base+r['r_offset'],struct.pack('<Q',base+r['r_addend']))
   if r['r_info_type']==1031:u.mem_write(base+r['r_offset'],struct.pack('<QQ',0x20000120,r['r_addend']))
  dynamic=e.get_section_by_name('.dynsym')
  for r in e.get_section_by_name('.rela.plt').iter_relocations():
   stubs={'memcpy':0x20000124,'memset':0x20000130,'memcmp':0x20000138}
   address=stubs.get(dynamic.get_symbol(r['r_info_sym']).name)
   if address:u.mem_write(base+r['r_offset'],struct.pack('<Q',address))
  symbols={s.name:base+s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols() if s['st_value']}
q=lambda a:struct.unpack('<Q',u.mem_read(a,8))[0]
def put(a,v):u.mem_write(a,struct.pack('<Q',v))
if args.shared_state_offset is not None:
 u.mem_map(state_base,0xf0000)
 put(symbols['host']+args.shared_state_offset,state_base)

forwarded=[]
audition=[]
physical_led=[]
queued=[]
attack_voice=0
panel_notices=[]
caption_titles={}
painted_rects=[]
coloured_rects=[]
paint_colour=0
view_height=240
caption_pass=[]
pad_select=0
dj_fixture=0x200b8000
dj_selected_path=0x200bb000
dj_parent_available=False
dj_folder=False
dj_parent_steps=[]
dj_folders=[]
dj_requests=[]
dj_paths=[]
dj_transport_test=False
dj_loop_test=False
dj_rate_updates=[]
dj_start_calls=[]
dj_seek_calls=[]
dj_nudge_steps=[]
dj_live_sync=False
dj_master_frame=0
dj_follower_frame=0
dj_queue_view=False
sidechain_role=0
assignment=None
assigned_modes=[]
mapped=set()
shutdown_calls=[]
dj_fx_test=False
dj_alias_outside=False
dj_exit_test=False
dj_exit_modes=[]
sequence_stop_calls=[]
deck_pause_calls=[]
dj_now_ms=0
dj_fx_selections=[]
dj_fx_parameters=[]
synth_filter_test=False
clear_calls=[]
def reg(n):return u.reg_read(UC_ARM64_REG_X0+n)
def ret(v=0):u.reg_write(UC_ARM64_REG_X0,v);u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
def hook(uc,pc,size,data):
 global paint_colour
 if pc==0x20000000:uc.emu_stop();return
 if pc==symbols['start_bpm_timer']:ret();return
 if pc==0x21390f0:
  assert reg(1)==0;sequence_stop_calls.append(reg(0));ret();return
 if pc==symbols['pc_dj_pause']:deck_pause_calls.append(reg(0))
 if dj_alias_outside and pc==0x741583c:ret(0);return
 if pc in (0x1c0e5c0,0x1c0d690) and (dj_queue_view or dj_exit_test):
  if dj_exit_test:dj_exit_modes.append(reg(1))
  put(reg(0)+0xd8,reg(1));ret();return
 if pc==0x15b7090 and dj_queue_view:
  assert reg(0)==dj_fixture+0xff0
  target=reg(8);put(target,dj_selected_path);put(target+8,1);ret();return
 if pc==0x14fa0a0 and dj_queue_view:ret(int(dj_parent_available));return
 if pc==0x1605e90 and dj_queue_view:dj_parent_steps.append(reg(0));ret();return
 if pc==0x1608bb0 and dj_queue_view:
  for offset in (0x1f8,0x418,0x638,0x858,0xa78,0xc98):
   put(reg(0)+offset+0x28,38<<32|104)
  ret();return
 if pc==0x1605a60 and dj_queue_view:raise AssertionError("Stock memory popup opened")
 if pc==0x14fa400 and dj_queue_view:ret(1);return
 if pc==0x1604a40 and dj_queue_view:
  assert reg(0)==dj_fixture
  put(q(dj_fixture+0x1390)+0xb0,int(not reg(1)));ret();return
 if pc==0xf41a00 and dj_queue_view:ret(int(dj_folder));return
 if pc==0x3b71c30 and dj_queue_view:dj_folders.append(reg(0));ret();return
 if pc==0xb51898 and dj_queue_view:
  name=bytes(uc.mem_read(reg(1),16)).split(b'\0')[0]
  ret({b'pthread_create':0x20000240,b'pthread_detach':0x20000250}.get(name,0));return
 if pc==0x20000240 and dj_queue_view:
  put(reg(0),1);dj_requests.append((reg(2),reg(3)));ret();return
 if pc==0x20000250 and dj_queue_view:ret();return
 if pc==symbols['pc_dj_prepare_track'] and dj_queue_view:
  value=bytes(uc.mem_read(reg(0),1024)).split(b'\0')[0]+b'\0'
  uc.mem_write(reg(1),value);ret();return
 if pc==symbols['pc_dj_analyse_progress'] and dj_queue_view:
  dj_paths.append(bytes(uc.mem_read(reg(0),64)).split(b'\0')[0])
  master=len(dj_paths)==1
  bpm,origin=(170,13759.) if master else (87,18447.)
  period=44100*60/bpm
  result=reg(2)
  late_downbeat=origin+8*period
  uc.mem_write(result,struct.pack('<QIfddi',48*44100,44100,bpm,period,late_downbeat,0)+bytes([120])*32768)
  uc.mem_write(result+32824,struct.pack('<dI',late_downbeat,1))
  ret();return
 if dj_loop_test:
  if pc==symbols['pc_dj_playing']:ret(1);return
 if dj_transport_test:
  if pc==symbols['pc_dj_nudge_step']:dj_nudge_steps.append((reg(0),reg(1)&0xffffffff));ret();return
  if pc==symbols['pc_dj_started']:ret(int(dj_live_sync or reg(0)==0));return
  if pc==symbols['pc_dj_playing'] and dj_live_sync:ret(1);return
  if pc==symbols['pc_dj_seek']:
   dj_seek_calls.append((reg(0),reg(1),reg(2)));ret(1);return
  if pc==symbols['pc_dj_position']:ret(dj_master_frame if reg(0)==0 else dj_follower_frame);return
  if pc==symbols['pc_dj_rate']:dj_rate_updates.append((reg(0),reg(1)))
  if pc==symbols['pc_dj_play']:
   dj_start_calls.append((reg(0),reg(2),reg(3)));ret(1);return
 if dj_fx_test:
  if pc==symbols['pc_meta']:ret(1);return
  if pc==symbols['pc_unmeta']:ret();return
  if pc==symbols['pc_mix_ensure']:ret(1);return
  if pc==symbols['pc_fx_type']:ret(3+reg(0));return
  if pc==symbols['pc_fx_count']:ret(12);return
  if pc==symbols['pc_fx_select']:dj_fx_selections.append((reg(0),reg(1)));ret(1);return
  if pc==symbols['pc_fx_position']:ret(5000+reg(1)*1000);return
  if pc==symbols['pc_fx_knob']:dj_fx_parameters.append((reg(0),reg(1),reg(2)));ret(1);return
 if synth_filter_test:
  if pc==0x13bb930:
   uc.mem_write(reg(0)+0x50,struct.pack('<I',uc.reg_read(UC_ARM64_REG_S0)));ret();return
  if pc==0x282a4a0:uc.mem_write(reg(0)+0x50,struct.pack('<I',reg(1)));ret();return
 if pc==symbols['pc_ms_clear_native_pad']:
  clear_calls.append(('multisample',reg(0)));ret();return
 if pc==0x195a044:
  clear_calls.append(('stock',reg(0),reg(1),reg(2)));ret();return
 if pc==0x14eb914:
  assert q(symbols['kit'])&0xffffffff==0
  shutdown_calls.append(reg(0));ret();return
 if pc in (0x1a2fcf0,0x1a30b50):panel_notices.append(pc);ret();return
 if pc==0x199a3b0 and assignment:
  put(assignment[0],assignment[1]);ret();return
 if pc==0x2806c90:assigned_modes.append(reg(1));ret();return
 if pc==0xf535c0:put(reg(0),reg(1));ret();return
 if pc==0xf0a290:ret();return
 if pc==0x116e8b0:put(reg(0)+8,q(reg(1)));ret();return
 if pc==0x3b7e940:
  title=bytes(uc.mem_read(q(reg(1)),24)).split(b'\0')[0]
  caption_titles[reg(0)]=title
  assert q(reg(2))&0xffffffff==1
  put(reg(0),0x706e940);ret();return
 if pc==0x1160fc0:
  put(reg(0)+0x20,reg(1));put(reg(0)+0x28,reg(2));ret();return
 if pc==0x1178f00:
  assert reg(1) in caption_titles
  put(reg(1)+0x18,reg(0));ret();return
 if pc in (0x102d360,0x102d470,0x1135cf0,0x102d3b0):
  caption_pass.append((pc,tuple(reg(n) for n in range(3))))
  ret();return
 if pc==0x11790b0:
  assert reg(1) in caption_titles
  put(reg(1)+0x18,reg(0));put(reg(1)+0xa8,2);ret();return
 if pc==0x1172670 and (reg(0) in caption_titles or reg(0)==0x20021118 or q(reg(0)) in (0x6e1cab8,0x6e17688) or (dj_queue_view and dj_fixture<=reg(0)<dj_fixture+0x1388)):
  put(reg(0)+0xa8,2 if reg(1) else 0);ret();return
 if pc==symbols['pc_sc_role']:ret(sidechain_role);return
 if pc==0x222a3a0:ret(attack_voice);return
 if pc in (0x20000128,0x2000012c,0xb51808,0xb51818):ret();return
 if pc in tuple(symbols[n] for n in ('pc_bounce_busy','pc_bounce_time_ns','pc_record_voice_started','pc_trigger_block')):ret();return
 if pc==symbols['pc_trigger_admit']:ret(1);return
 if pc==0x20000120:ret(q(reg(0)+8));return
 if pc==0x20000138:
  a=bytes(u.mem_read(reg(0),reg(2)));b=bytes(u.mem_read(reg(1),reg(2)))
  ret(((a>b)-(a<b))&0xffffffff);return
 if pc==0x20000130:
  u.mem_write(reg(0),bytes([reg(1)&255])*reg(2));ret(reg(0));return
 if pc==0x20000124:
  u.mem_write(reg(0),bytes(u.mem_read(reg(1),reg(2))));ret(reg(0));return
 if pc==symbols['pc_sys']:
  if reg(0)==140:ret();return
  if reg(0)==113:
   put(reg(2),dj_now_ms//1000);put(reg(2)+8,(dj_now_ms%1000)*1000000);ret();return
  if reg(0)==222:
   if reg(1) in mapped:ret((1<<64)-17);return
   mapped.add(reg(1));u.mem_map(reg(1),reg(2));ret(reg(1));return
  assert reg(0)==226;ret();return
 if pc==0x6d43500:
  if reg(0)!=99:queued.append(reg(0))
  ret();return
 if pc in (0x1a3ed50,0x1a3e040):
  source=struct.unpack('<I',u.mem_read(reg(3),4))[0]
  audition.append((reg(0),reg(1),source));ret();return
 if pc in (0x1a3eb70,0x1a3e7b0):ret();return
 if pc==0x1a3c520:physical_led.append((reg(0),reg(1),reg(2)));ret();return
 if pc==0x102d5e0:paint_colour=reg(1)
 if pc==0x102e000:
  bounds=tuple(reg(n) for n in range(5))
  painted_rects.append(bounds)
  coloured_rects.append((paint_colour,bounds))
 if pc in (0x236b2c0,0x10e2e10,0x15f4a70,0x102d5e0,0x102e000,0x1149d70,0x2114c00):ret();return
 if pc==0x10f8ec0:uc.reg_write(UC_ARM64_REG_X1,view_height<<32|320);ret();return
 if pc==0x1a3ffb0:forwarded.append((reg(0),reg(1),reg(2)));ret()
u.hook_add(UC_HOOK_CODE,hook)
u.reg_write(UC_ARM64_REG_TPIDR_EL0,0x20090000)
def call(pc,*values):
 u.reg_write(UC_ARM64_REG_SP,0x200ff000);u.reg_write(UC_ARM64_REG_LR,0x20000000)
 for n,v in enumerate(values):u.reg_write(UC_ARM64_REG_X0+n,v)
 try:u.emu_start(pc,0x20000004,count=1000000)
 except Exception:print("PC",hex(u.reg_read(UC_ARM64_REG_PC)));raise
# Install the actual property-entry detours and execute their native replays.
for site,wrapper,original in ((0x14a7580,'kit_raw_pressure','raw_pressure_original'),
                              (0x13be8b0,'kit_raw_colour','raw_colour_original'),
                              (0x1a30300,'kit_panel_pad','panel_pad_original'),
                              (0x195a040,'clear_pad','clear_pad_original'),
                              (0x1564ae0,'synth_mapping','synth_mapping_original')):
 call(symbols['install_property_detour'],site,symbols[wrapper],symbols[original],4096)
 assert reg(0)==1 and q(symbols[original])
kit=symbols['kit'];project=0x20010000;program=0x20011000;behaviour=0x20012000
surface=0x20014000;raw=0x20060000;canary=0x2001a000
put(0x7164398,canary)
u.mem_write(kit,struct.pack('<4I4Q',1,2,3,0,1<<37,project,program,behaviour))
put(project,0x6ecc648);put(project+0xb8,program)
put(state_base+0x1d08,project);put(state_base+0x20,behaviour)
u.mem_write(state_base+0x1ef4,struct.pack('<I',3))
put(behaviour+0x78,surface)
put(surface+0x29d0,16);put(surface+0x29d8,raw)
clear_program,clear_pads,clear_instrument=0x200d0000,0x200d4000,0x200d5000
put(clear_program,0x6ec6860)
put(clear_program+0x2808,clear_pads)
put(clear_program+0x2810,clear_pads+16)
put(clear_pads+8,clear_instrument)
call(0x195a040,0x200d7000,clear_program,1)
assert clear_calls==[('multisample',clear_instrument),('stock',0x200d7000,clear_program,1)]
print('Native Clear Pad detour dispatches a sampleless pad before stock guards')
b2=surface+0x1c20
def toggle():
 call(symbols['pc_ui_physical'],b2,1);call(symbols['pc_ui_physical'],b2,0)
def pressure(pad,value):
 u.reg_write(UC_ARM64_REG_S0,struct.unpack('<I',struct.pack('<f',value))[0])
 call(0x14a7580,raw+pad*0x128)
def tap(pad):
 pressure(pad,.5);pressure(pad,.9);pressure(pad,0)
for i in range(16):
 prop=raw+i*0x128
 put(prop+0x10,prop+8)
 put(prop+0x20+0x10,prop+0x20+8)
toggle();assert q(kit+16)&(1<<36)
tap(0);tap(7)
assert q(kit+16)&65535==129
assert q(raw+0x1c)==0
tap(0);assert q(kit+16)&65535==128
yellow=0x3f80000000ffff00;stock=0x3f80000000123456
put(0x20024000,stock)
call(0x13be8b0,raw+7*0x128+0x20,0x20024000)
assert q(raw+7*0x128+0x3c)==yellow
call(0x13be8b0,raw+0x20,0x20024000)
assert q(raw+0x3c)==stock
toggle();pressure(0,.5)
assert q(raw+0x1c)==0x3f000000 and q(kit+16)&65535==128
pressure(0,0);assert q(raw+0x1c)==0
toggle();tap(7);assert q(kit+16)&65535==0
call(symbols['pc_drumkit_refresh_lights'])
assert q(raw+7*0x128+0x3c)==stock
# This dispatcher notifies the native playing listener BEFORE setting the
# pressure property. The early hook must own the whole gesture.
panel=surface+0x2988
def panel_pressure(pad,value):
 u.reg_write(UC_ARM64_REG_S0,struct.unpack('<I',struct.pack('<f',value))[0])
 call(0x1a30300,panel,pad)
panel_pressure(7,.5);panel_pressure(7,0)
assert not panel_notices and q(kit+16)&65535==128
toggle()
panel_pressure(0,.5);panel_pressure(0,0)
assert panel_notices==[0x1a2fcf0,0x1a30b50] and q(kit+16)&65535==128
# An unrelated physical property reaches native dispatch, then the Power
# callback closes the kit before forwarding to the real confirmation.
call(symbols['pc_ui_physical'],surface+0x2b40,1)
assert reg(0)==0 and q(kit)&0xffffffff==1
call(symbols['install_property_detour'],0x14eb910,symbols['shutdown_prompt'],symbols['shutdown_prompt_original'],4096)
assert reg(0)==1
call(0x14ebd70,behaviour+0x300)
assert shutdown_calls==[behaviour] and q(kit)&0xffffffff==0

print('Native surface property detours consume Lock ON taps, restore stock colours and replay Lock OFF pressure')

# Exercise Compressor controls from the physical button/encoder/knob hooks.
manager=0x20020000
put(behaviour+0x30,manager);put(manager+0xd8,0x30f1)
screen=0x20021000;graphics=0x20022000
caption=symbols['mastering_caption']
put(screen,0x6e1bf30)
for offset,x in ((0x118,0),(0x338,213)):
 put(screen+offset,0x706e940)
 put(screen+offset+0x20,x);put(screen+offset+0x28,38<<32|106)
put(screen+0x118+0xa8,2)
put(screen+0x1eb8,0x706e5d0);put(screen+0x1eb8+8,0x20000180)
u.mem_write(0x20000180,b'Amount'+bytes(1))
u.mem_write(symbols["host"]+args.ready_offset,struct.pack("<I",1))
call(symbols['pc_limiter_visibility'],screen,1)
assert q(caption+0x18)==screen and q(caption+0xa8)==2 and caption_titles[caption]==b'Mastering'
assert not q(screen+0x118+0xa8)&2
assert bytes(u.mem_read(q(screen+0x1eb8+8),10))==b'Threshold'+bytes(1)
assert q(caption+0x20)==106 and q(caption+0x28)==38<<32|107
call(symbols['pc_limiter_paint'],screen,graphics)
before=len(queued)
call(symbols['pc_ui_physical'],surface+0x1bc8,1);assert reg(0)==1
call(symbols['pc_ui_physical'],surface+0x1bc8,0);assert reg(0)==1
assert len(queued)==before
def command(button):
 call(symbols['pc_ui_physical'],button,1)
 call(symbols['pc_ui_physical'],button,0)
 call(symbols['pc_ui_event'],queued.pop())
# Hardware Erase + Encoder is captured only in the managed preset browser.
ms_state=symbols['ms']
erase_key=surface+0x23b0
encoder_key=surface+0x2d50
put(ms_state,1)
call(symbols['pc_ui_physical'],erase_key,1);assert reg(0)==1
call(symbols['pc_ui_physical'],encoder_key,1);assert reg(0)==1
assert queued.pop()==(4<<32)|(12<<1)|1
call(symbols['pc_ui_physical'],encoder_key,0);assert reg(0)==1
call(symbols['pc_ui_physical'],erase_key,0);assert reg(0)==1
call(symbols['pc_ui_physical'],encoder_key,1);assert reg(0)==1
assert queued.pop()==(3<<32)|(12<<1)|1
call(symbols['pc_ui_physical'],encoder_key,0);assert reg(0)==1
put(ms_state,0)
print('Physical Erase + Encoder is distinct from a normal Encoder press in Multisamples')
command(b2)
assert not q(caption+0xa8)
call(symbols['pc_limiter_scope']);assert reg(0)==1
call(symbols['pc_limiter_enabled']);assert reg(0)==0
command(b2)
call(symbols['pc_limiter_enabled']);assert reg(0)==1
call(symbols['pc_ui_rotation'],surface+0x2da8,1)
call(symbols['pc_ui_event'],queued.pop())
knob=0x20023000;put(surface+0x3110,knob)
call(symbols['pc_ui_knob'],knob,0x3f400000)
call(symbols['pc_ui_event'],queued.pop())
assert struct.unpack('<I',u.mem_read(symbols['limiter']+16+4*2,4))[0]==12287
command(surface+0x1bc8)
assert q(caption+0xa8)==2
call(symbols['pc_limiter_scope']);assert reg(0)==0
command(b2);call(symbols['pc_limiter_visibility'],screen,0)
call(symbols['pc_limiter_scope']);assert reg(0)==0
call(symbols['pc_limiter_enabled']);assert reg(0)==1
print('Stock Compressor creates native Mastering caption in B2 column before opening, hides and restores it on navigation')

# Stock Fader overlay opens only from its B2 and closes on B1 or hide.
fader=0x200b0000
put(fader,0x6e1cab8);put(manager+0xd8,0x30f2)
for offset,x in ((0x1f8,7),(0x418,215)):
 put(fader+offset,0x706e940)
 put(fader+offset+0x20,x);put(fader+offset+0x28,38<<32|104)
call(symbols['pc_dj_visibility'],fader,1)
call(symbols['pc_dj_paint'],fader,graphics)
dj_caption=symbols['dj_caption']
assert caption_titles[dj_caption]==b'DJ Mode' and q(dj_caption+0x18)==fader
assert q(dj_caption+0x20)==111 and q(dj_caption+0x28)==38<<32|104
saved_stock_colours=[q(raw+i*0x128+0x3c) for i in range(16)]
put(symbols['fx_overlay'],1)
locator,service_node,native_transport=0x20038000,0x20038100,0x20038200
put(state_base+0x1e98,locator)
put(locator+0x10,service_node)
put(service_node+8,0x6e7faa8)
put(service_node+0x10,native_transport)
command(b2)
assert sequence_stop_calls==[native_transport]
put(state_base+0x1e98,0)
call(symbols['pc_dj_fx_shift'],1)
gain_symbol=symbols['monitor_gain_position']
call(symbols['pc_dj_knob'],2,8192)
assert q(gain_symbol)&0xffffffff==16383
call(symbols['pc_dj_knob'],2,16383)
call(symbols['pc_dj_knob'],2,8192)
assert q(gain_symbol)&0xffffffff==8192
call(symbols['pc_dj_fx_shift'],0)
assert not q(symbols['fx_overlay'])&0xffffffff
call(symbols['pc_dj_open']);assert reg(0)==1
painted_rects.clear()
call(symbols['pc_dj_paint'],fader,graphics)
assert (graphics,8,54,304,67) in painted_rects and (graphics,8,125,304,67) in painted_rects
# The four transport aliases queue DJ actions exactly once, consuming both edges.
for action,offset in enumerate((0x23b0,0x2460,0x2bf0,0x2ca0)):
 before=len(queued)
 call(symbols['pc_ui_physical'],surface+offset,1);assert reg(0)==1
 call(symbols['pc_ui_physical'],surface+offset,1);assert reg(0)==1
 call(symbols['pc_ui_physical'],surface+offset,0);assert reg(0)==1
 assert len(queued)==before+1 and queued.pop()==(action<<32)|(64<<1)|1
# Only the playhead subtree is hidden; exit restores its original visibility.
header,header_list,display=0x200bd000,0x200bd300,0x200be000
put(header,0x6e17688);put(header+0xa8,2)
put(display+0x40,header_list);put(display+0x4c,1);put(header_list,header)
call(symbols['dj_playhead_frame'],display);assert q(header+0xa8)==0
print('DJ-only Erase/Repeat/Stop/Play aliases consume both edges and hide sequence progress')
dj_fx_test=True
knob_fx=surface+0x21a0
command(knob_fx)
assert q(symbols.get('dj_fx',symbols.get('dj_fx.0')))&0xffffffff==1
call(symbols['pc_dj_paint'],fader,graphics)
assert b'Send' in caption_titles.values() and b'Load' in caption_titles.values()
assert (0xff000000,(graphics,0,0,320,240)) in coloured_rects
command(b2)
assert (q(symbols.get('dj_fx',symbols.get('dj_fx.0')))>>32)==1
call(symbols['pc_ui_rotation'],surface+0x2da8,1);assert reg(0)==1
call(symbols['pc_ui_event'],queued.pop())
command(surface+0x2d50)
assert len(dj_fx_selections)==1 and dj_fx_selections[0][0]==1
# The DJ selector edits the loaded send, with pickup and two momentary pages.
call(symbols['pc_dj_knob'],0,12000);assert not dj_fx_parameters
call(symbols['pc_dj_knob'],0,5000);assert dj_fx_parameters[-1]==(1,0,5000)
call(symbols['pc_ui_physical'],surface+0x2250,1)
shift_event=queued.pop();assert shift_event==(1<<32)|(65<<1)|1
call(symbols['pc_ui_event'],shift_event)
call(symbols['pc_dj_knob'],0,8000);assert dj_fx_parameters[-1]==(1,3,8000)
call(symbols['pc_ui_physical'],surface+0x2250,0)
shift_event=queued.pop();assert shift_event==(65<<1)|1
call(symbols['pc_ui_event'],shift_event)
call(symbols['pc_dj_knob'],0,9000);assert dj_fx_parameters[-1]==(1,3,8000)
call(symbols['pc_dj_knob'],0,5000);assert dj_fx_parameters[-1]==(1,0,5000)
command(knob_fx)
assert q(symbols.get('dj_fx',symbols.get('dj_fx.0')))&0xffffffff==0
call(symbols['pc_dj_open']);assert reg(0)==1
dj_fx_test=False
print('DJ Knob FX selects and edits the loaded send, pickup, Shift page 2 and release back to page 1 passed')
command(surface+0x2d50)
painted_rects.clear()
call(symbols['pc_dj_paint'],fader,graphics)
assert (graphics,8,125,2,67) in painted_rects and (graphics,8,54,2,67) not in painted_rects
command(surface+0x1bc8)
call(symbols['pc_dj_paint'],fader,graphics)
assert b'Volume' in caption_titles.values() and b'Sends' in caption_titles.values()
command(surface+0x1c78)
call(symbols['pc_dj_paint'],fader,graphics)
assert b'Select Deck' in caption_titles.values()
command(b2)
call(symbols['pc_dj_import']);assert reg(0)==0
command(surface+0x1c78)
put(surface+0x22a0,1)
command(surface+0x1bc8)
put(surface+0x22a0,0)
call(symbols['pc_dj_open']);assert reg(0)==1
# Sample opens a large modal. NO keeps DJ and its playback context active.
sample_button=surface+0x1f90
command(sample_button)
painted_rects.clear();coloured_rects.clear()
call(symbols['pc_dj_paint'],fader,graphics)
assert (graphics,8,54,304,67) not in painted_rects
assert any(colour==0xff36312b and rect[1:]==(176,120,128,48) for colour,rect in coloured_rects)
command(surface+0x2d50)
call(symbols['pc_dj_open']);assert reg(0)==1
# New DJ fader always starts dry and requires pickup at zero.
space_control=symbols['fader']
call(symbols['pc_dj_fader_position'],15000);assert q(space_control)&0xffffffff==0
call(symbols['pc_dj_fader_position'],0)
call(symbols['pc_dj_fader_position'],15000);assert q(space_control)&0xffffffff==15000
call(symbols['pc_dj_fader_position'],0)
# YES returns to the native pads screen. Modal input does not reach deck transport.
call(symbols['pc_ui_physical'],sample_button,1);assert reg(0)==1
call(symbols['pc_ui_event'],queued.pop())
call(symbols['pc_ui_rotation'],surface+0x2da8,-1);call(symbols['pc_ui_event'],queued.pop())
dj_exit_test=True
deck_pause_calls.clear()
command(surface+0x2d50)
assert deck_pause_calls==[0,1]
dj_exit_test=False
assert dj_exit_modes==[0x20a7]
assert [q(raw+i*0x128+0x3c) for i in range(16)]==saved_stock_colours
call(symbols['pc_ui_physical'],sample_button,0);assert reg(0)==1
call(symbols['pc_dj_open']);assert reg(0)==0
call(symbols['pc_ui_physical'],sample_button,1);assert reg(0)==0
call(symbols['pc_ui_physical'],sample_button,0);assert reg(0)==0
put(manager+0xd8,0x30f2)
call(symbols['pc_dj_paint'],fader,graphics)
assert q(dj_caption+0xa8)==2
command(b2)
print('Sample NO preserves DJ; YES returns to stock pads; large confirmation dialog verified')
call(symbols['pc_dj_visibility'],fader,0)
call(symbols['pc_dj_open']);assert reg(0)==0
assert q(dj_caption+0xa8)==0
call(symbols['pc_ui_physical'],knob_fx,1);assert reg(0)==1
call(symbols['pc_ui_physical'],knob_fx,0);assert reg(0)==1
assert queued.pop()==(26<<1)|1
call(symbols['dj_playhead_frame'],display);assert q(header+0xa8)==2
dj_alias_outside=True
for offset in (0x23b0,0x2460,0x2bf0,0x2ca0):
 before=len(queued)
 call(symbols['pc_ui_physical'],surface+offset,1);assert reg(0)==0
 call(symbols['pc_ui_physical'],surface+offset,0);assert reg(0)==0
 assert len(queued)==before
dj_alias_outside=False
print('Fader DJ entry and exit preserve the existing Knob FX event outside DJ Mode')

dj_queue_view=True
put(behaviour+0x58,dj_fixture)
put(dj_fixture,0x6e1cfb8);put(dj_fixture+0xa8,2)
put(dj_fixture+0x1390,0x200ba000)
put(dj_fixture+0x120,0x200b9000)
stock_browser_controls=(0x1f8,0x418,0x638,0x858,0xa78,0xc98)
for offset in stock_browser_controls:
 put(dj_fixture+offset+0x18,dj_fixture)
 put(dj_fixture+offset+0x28,38<<32|104)
 put(dj_fixture+offset+0xa8,2)
put(0x200ba000+0xb0,1)
u.mem_write(dj_selected_path,b'/media/MPCSSH/Track 170.wav\0')
put(manager+0xd8,0x30f2)
call(symbols['pc_dj_visibility'],fader,1)
call(symbols['pc_dj_paint'],fader,graphics)
command(b2)
command(surface+0x27d0)
call(symbols['pc_dj_import']);assert reg(0)==1
before=len(queued)
call(symbols['pc_ui_physical'],surface+0x21a0,1);assert reg(0)==1
call(symbols['pc_ui_physical'],surface+0x21a0,0);assert reg(0)==1
call(symbols['pc_ui_physical'],0xfffffffffffffffe,1);assert reg(0)==1
assert len(queued)==before
for offset in (0x23b0,0x2460,0x2bf0,0x2ca0):
 before=len(queued)
 call(symbols['pc_ui_physical'],surface+offset,1);assert reg(0)==1
 call(symbols['pc_ui_physical'],surface+offset,0);assert reg(0)==1
 assert len(queued)==before

call(symbols['pc_import_frame'],dj_fixture)
for offset in stock_browser_controls:
 assert not q(dj_fixture+offset+0x28) and q(dj_fixture+offset+0xa8)==2
for label in (b'Back',b'Load 1',b'Load 2'):
 assert any(value==label and q(caption+0x18)==dj_fixture and q(caption+0xa8)==2
            for caption,value in caption_titles.items())
call(symbols['pc_dj_browser_layout'],dj_fixture)
assert all(not q(dj_fixture+offset+0x28) for offset in stock_browser_controls)
call(symbols['pc_ui_event'],queued.pop())
assert q(0x200ba000+0xb0)==0
call(symbols['pc_dj_knob'],2,0)
assert q(0x200ba000+0xb0)==1
call(symbols['pc_dj_knob'],2,16383)
assert q(0x200ba000+0xb0)==0
assert {b'Song Import',b'Load 1',b'Load 2'}<=set(caption_titles.values())
assert not q(dj_fixture+0xa2c)&0xffffffff
call(symbols['pc_ui_rotation'],surface+0x2da8,1);assert reg(0)==0
dj_parent_available=True
command(surface+0x1bc8)
assert dj_parent_steps==[dj_fixture]
dj_folder=True
command(surface+0x2d50)
assert dj_folders==[dj_fixture+0xff0] and not dj_requests
dj_folder=False
command(b2)
assert all(q(dj_fixture+offset+0x28)==38<<32|104 for offset in stock_browser_controls)
assert len(dj_requests)==1 and dj_requests[0][0]==symbols['analyse_job']
call(*dj_requests[0])
call(symbols['pc_ui_event'],queued.pop())
call(symbols['pc_dj_paint'],fader,graphics)
call(symbols['pc_dj_open']);assert reg(0)==1
command(surface+0x27d0)
u.mem_write(dj_selected_path,b'/media/MPCSSH/Track 87.MP3\0')
command(surface+0x1c78)
assert len(dj_requests)==2 and dj_requests[1][1]!=dj_requests[0][1]
call(*dj_requests[1])
call(symbols['pc_ui_event'],queued.pop())
assert dj_paths==[b'/media/MPCSSH/Track 170.wav',b'/media/MPCSSH/Track 87.MP3']
call(symbols['pc_dj_paint'],fader,graphics)
call(symbols['pc_dj_open']);assert reg(0)==1
# Sync 87 BPM to half of the 170 BPM master and align the scaled grid.
# Monitor page is momentary and uses pickup at the default 100% CUE.
call(symbols['pc_dj_fx_shift'],1)
call(symbols['pc_dj_knob'],0,0)
assert q(symbols['cue_blend'])&0xffffffff==16383
call(symbols['pc_dj_knob'],0,16383)
call(symbols['pc_dj_knob'],0,8192)
assert q(symbols['cue_blend'])&0xffffffff==8192
call(symbols['pc_dj_paint'],fader,graphics)
assert q(symbols['monitor_settings'])&0xffffffff==(8192<<1)|1
command(surface+0x2d50)
assert q(symbols['monitor_settings'])&0xffffffff==(8192<<1)
command(surface+0x2d50)
call(symbols['pc_dj_knob'],0,16383)
call(symbols['pc_dj_fx_shift'],0)
assert q(symbols['cue_blend'])&0xffffffff==16383
print('Shift Volume USB CUE page, 100 percent default, pickup, blend and encoder deck selection passed')
dj_transport_test=True
def dj_pad(source):
 prop=raw+source*0x128
 for pressure in (1.,0.):
  u.reg_write(UC_ARM64_REG_S0,struct.unpack('<I',struct.pack('<f',pressure))[0])
  call(symbols['pc_dj_raw_pressure'],prop);assert reg(0)==1
  call(symbols['pc_ui_event'],queued.pop())
for pad,colour in enumerate((0x00bbff,0x00bbff,0x00bbff,0x00bbff,0xa000ff,0x00ff50,0xa000ff,0xff8200,
                            0x00bbff,0x00bbff,0x00bbff,0x00bbff,0xffff00,0xffff00,0xffff00,0xffff00)):
 call(symbols['pc_dj_colour'],raw+pad*0x128+0x20,0)
 assert reg(0)&0xffffff==colour
# BPM pads change tempo, never play or cue. Press/release applies one step.
dj_pad(0);assert not dj_start_calls and (0,994118) in dj_rate_updates
dj_pad(1);assert not dj_start_calls
# Repeat uses monotonic time, including while paused. It stops on release.
prop=raw+0x128
u.reg_write(UC_ARM64_REG_S0,0x3f800000);call(symbols['pc_dj_raw_pressure'],prop);call(symbols['pc_ui_event'],queued.pop())
call(symbols['pc_dj_colour'],prop+0x20,0);assert reg(0)&0xffffff==0x0040ff
assert dj_rate_updates[-2][1]==1005882
for dj_now_ms,expected in ((399,1005882),(400,1011765),(450,1011765),(500,1017647)):
 call(symbols['pc_dj_poll']);assert dj_rate_updates[-2]==(0,expected)
u.reg_write(UC_ARM64_REG_S0,0);call(symbols['pc_dj_raw_pressure'],prop);call(symbols['pc_ui_event'],queued.pop())
call(symbols['pc_dj_colour'],prop+0x20,0);assert reg(0)&0xffffff==0x00bbff
dj_now_ms=2000;call(symbols['pc_dj_poll']);assert dj_rate_updates[-2]==(0,1017647)
for _ in range(3):dj_pad(0)
dj_pad(2);assert dj_rate_updates[-1]==(1,988506)
dj_pad(3);assert dj_rate_updates[-1]==(1,1000000)
assert not dj_start_calls
command(surface+0x2460)
assert dj_start_calls==[(0,0,0)]
print('BPM pads are cyan/blue, step once, repeat after 400 ms, stop on release and keep deck transport separate')
dj_start_calls.clear()
dj_pad(5);dj_pad(6)
assert (1,977011) in dj_rate_updates
assert not dj_start_calls and not dj_seek_calls
# Choose a later bar and verify that Play alone schedules it.
call(symbols['pc_dj_rotate'],9)
command(surface+0x2ca0)
selected_bar=round(18447+8*(44100*60/87))
assert len(dj_start_calls)==1 and dj_start_calls[0][0:2]==(1,selected_bar),dj_start_calls
assert dj_start_calls[0][2]>100000 # next master downbeat
# Re-sync a running deck from its current bar; never start it again at zero.
dj_start_calls.clear();dj_live_sync=True
dj_master_frame=300000;dj_follower_frame=600000
dj_pad(6)
assert not dj_start_calls and len(dj_seek_calls)==1
assert dj_seek_calls[0][0]==1 and 550000<dj_seek_calls[0][1]<750000
period=44100*60/87
assert abs((dj_seek_calls[0][1]-18447)/period/4-round((dj_seek_calls[0][1]-18447)/period/4))<.0001
master_bars=(dj_master_frame+dj_seek_calls[0][2]-13759)/(44100*60/170*8)
assert abs(master_bars-round(master_bars))<.0001
dj_pad(6);assert len(dj_seek_calls)==2 and dj_seek_calls[-1]==dj_seek_calls[-2]
# A held nudge bends tempo and its phase change is not undone on release.
dj_pad(11);assert dj_nudge_steps[-1]==(1,1)
assert (1,1055172) in dj_rate_updates[-4:]
dj_pad(10);assert dj_nudge_steps[-1]==(1,0xffffffff)
# Both edges were released by dj_pad; base tempo is retained exactly.
assert dj_rate_updates[-1]==(1,977011)
dj_pad(6);assert len(dj_seek_calls)==3 and not dj_start_calls
# Playheads remain centred at the same x, including different song positions.
for dj_master_frame,dj_follower_frame in ((1000,47*44100),(300000,600000)):
 coloured_rects.clear();call(symbols['pc_dj_paint'],fader,graphics)
 assert any(r[1]==160 and r[2]==83 and r[3]==2 and r[4]==38 for colour,r in coloured_rects)
 assert any(r[1]==160 and r[2]==154 and r[3]==2 and r[4]==38 for colour,r in coloured_rects)
dj_live_sync=False;dj_master_frame=dj_follower_frame=0
call(symbols['pc_dj_colour'],raw+5*0x128+0x20,0)
assert reg(0)&0xffffff==0x00ff50
dj_transport_test=False
call(symbols['pc_ui_rotation'],surface+0x2da8,1);assert reg(0)==1
call(symbols['pc_ui_event'],queued.pop())
for view_height,top,height in ((240,83,38),(180,70,21)):
 painted_rects.clear()
 coloured_rects.clear()
 call(symbols['pc_dj_paint'],fader,graphics)
 grid_columns={r[1] for colour,r in coloured_rects
               if colour in (0xffe9e7df,0xffb8bcb4) and r[2]==top and r[4]==height and r[3] in (1,2)}
 assert len(grid_columns)==16,(view_height,len(grid_columns))
 assert any(colour==0xff48d982 for colour,_ in coloured_rects)
 assert any(colour==0xffb879f2 for colour,_ in coloured_rects)
 if view_height==240:
  assert any(colour==0xffff3030 and 83<=r[2]<121 for colour,r in coloured_rects)
  assert any(colour==0xffff3030 and 154<=r[2]<192 for colour,r in coloured_rects)
view_height=240
dj_loop_test=True
before_starts=len(dj_start_calls)
for pad,width in ((12,72),(13,145)):
 dj_pad(pad)
 coloured_rects.clear()
 call(symbols['pc_dj_paint'],fader,graphics)
 assert any(colour==0xff36312b and rect[2]==83 and rect[4]==38 and (abs(rect[3]-width)<=1 or (width==145 and rect[1]+rect[3]==305 and 0<rect[3]<width))
            for colour,rect in coloured_rects),(pad,width,[r for co,r in coloured_rects if co==0xff36312b])
 assert len(dj_start_calls)==before_starts
dj_pad(13)
coloured_rects.clear()
call(symbols['pc_dj_paint'],fader,graphics)
assert not any(colour==0xff36312b and rect[2]==83 and rect[4]==38 for colour,rect in coloured_rects)
dj_loop_test=False
print('DJ loops highlight two and four bars, toggle off and keep the playback worker running')
# Replacing the first-loaded track makes the older remaining deck Master.
command(surface+0x27d0)
u.mem_write(dj_selected_path,b'/media/MPCSSH/Replacement 120.wav\0')
command(b2)
request=dj_requests.pop(0);call(*request)
call(symbols['pc_ui_event'],queued.pop())
call(symbols['pc_dj_paint'],fader,graphics)
call(symbols['pc_dj_colour'],raw+5*0x128+0x20,0);assert reg(0)&0xffffff==0xff8200
call(symbols['pc_dj_colour'],raw+7*0x128+0x20,0);assert reg(0)&0xffffff==0x00ff50
# Pressing either Master pad cannot leave the loaded decks without a Master.
dj_pad(5);dj_pad(7)
call(symbols['pc_dj_colour'],raw+7*0x128+0x20,0);assert reg(0)&0xffffff==0x00ff50
print('Oldest-loaded deck is always Master; replacement reassigns it automatically; live SYNC schedules a current-bar seek')
command(surface+0x27d0)
dj_parent_available=False
command(surface+0x1bc8)
call(symbols['pc_dj_paint'],fader,graphics)
call(symbols['pc_dj_open']);assert reg(0)==1
call(symbols['pc_dj_visibility'],fader,0)
dj_queue_view=False
print('DJ Song Import keeps native navigation, loads the selected path into separate deck jobs and returns to DJ Mode')
# Exercise the stock tempo-map conversion using positions beyond the
# first two bars, where the old Step Edit cursor could wrap early.
engine=0x20030000;transport=0x20031000;shared=0x20032000
tempo_map=0x20033000;rate=0x20034000;bpm=0x20035000;position=0x20036000
put(engine+0x790,transport);put(transport+0x258,shared);put(shared+0x110,tempo_map)
put(tempo_map,rate);put(tempo_map+8,bpm)
u.mem_write(rate+0x50,struct.pack('<f',44100))
u.mem_write(bpm+0x50,struct.pack('<d',2))
for bar in (0,1,2,3,4,7):
 put(position+0x10,bar*88200);u.mem_write(position+0x3c,b'\x01')
 call(symbols['pc_record_first_pass'],engine,position)
 call(symbols['pc_sequence_play_tick']);assert reg(0)==bar*3840
u.mem_write(position+0x3c,b'\x00');call(symbols['pc_record_first_pass'],engine,position)
call(symbols['pc_sequence_play_tick']);assert reg(0)==(1<<64)-1
print('Native sequence transport publishes full 8-bar positions and clears on stop')

# Chord roll may have no chromatic event-list pointer. It must still
# normalize timeline units and accept the same four whole-bar zooms.
g=state_base;controller=0x20040000;track=0x20041000;sequence=0x20042000
roll=g+0x800;timeline=g+0x2000
put(behaviour+0x150,controller);put(controller+0x248,project)
put(project+0x140,track);put(project+0x1c8,sequence)
put(track,0x6ecf118);put(sequence,0x6ecdff0);put(sequence+0x348,3840*8)
put(roll,behaviour);put(roll+8,controller);put(roll+0x60,1);put(roll+0x480,1)
for wanted,supplied in ((1,0),(2,3),(4,7),(8,16)):
 put(timeline,7680);put(timeline+8,7680);put(timeline+0x10,3840*7+1)
 u.mem_write(timeline+0x3c,struct.pack('<I',supplied))
 call(symbols['pc_roll_prepare_locked'])
 assert reg(0)==1 and q(timeline)==3840
 assert struct.unpack('<I',u.mem_read(timeline+0x3c,4))[0]==wanted
 assert q(timeline+0x18)==7//wanted*wanted*3840
print('Chord-mode Piano Roll keeps 1, 2, 4 and 8 bar windows')

# Register real native sample attack calls and then update the fallback from
# the live voice list as the hardware output callback does each block.
pool=0x20070000;slots=0x20071000;voice1=0x20072000;voice2=0x20073000
instrument=0x20074000;layers=0x20077000;layer_sample=0x20078000
node1=0x20079000;node2=0x20079100;rate=0x20079200;mask=0x20079300
put(symbols['pool_trylock'],0x20000128)
put(program,0x6ec6860);put(instrument,0x6ec3ca0);put(instrument+0x2310,program)
put(instrument+0x638,rate);put(instrument+0x22e8,layers)
u.mem_write(rate+0x50,struct.pack('<f',44100))
put(layers+0x4a8,layer_sample);put(layer_sample+0xa8,0x2007a000);put(mask,1)
put(pool,0x6da6570);put(pool+0x80,slots);put(pool+0x8c,128)
put(slots,voice1);put(slots+8,voice2)
end=pool+0x128;put(end,end)
for voice,node in ((voice1,node1),(voice2,node2)):
 put(node, end);put(node+0x10,voice)
 put(voice+0x8f0,program);put(voice+0x8f8,instrument);put(voice+0x920,1)
callback=0x2007b000;callback_table=0x2007c000
put(callback,callback_table);put(callback_table+0x10,0x2000012c)
def sample_start(name,voice,node):
 global attack_voice
 u.mem_write(0x2007a000,name+b'\0')
 attack_voice=voice
 call(symbols['sample_attack'],pool,program,0,0,instrument,mask,0,0)
 assert reg(0)==voice
 put(end,node)
def tune(expected):
 call(symbols['output_callback'],callback,0,0,0,0,256)
 call(symbols['pc_tune_follow_render'],256)
 assert reg(0)==expected
sample_start(b'Live instrumental F#maj.wav',voice1,node1);tune(262)
sample_start(b'Live instrumental Dbmin.wav',voice2,node2);put(node2,node1);tune(273)
put(end,node1);tune(262)
put(end,end);tune(0)
print('Native sample attack and output callbacks track active tagged voices, newest key and stop')

# Play a keyed sample through the native render tap with the optional
# sample-pool and output relays unavailable.
put(symbols['pool_trylock'],0)
buf=0x2007d000;planes=0x2007e000;left=0x20080000;right=0x20081000
put(buf,2|(256<<32));put(buf+0x10,planes);put(planes,left);put(planes+8,right)
u.mem_write(left,struct.pack('<256f',*([.4]*256)))
u.mem_write(right,struct.pack('<256f',*([.3]*256)))
u.mem_write(0x2007a000,b'Backing track Cmin.wav\0')
call(symbols['pc_tune_audible_sample'],instrument,buf,256)
call(symbols['pc_tune_follow_render'],256)
assert reg(0)==272
for _ in range(34):call(symbols['pc_tune_follow_render'],256)
assert reg(0)==0
print('Rendered native sample provides filename fallback with the sample-pool relay unavailable')

# Native Sample header accessors supply source rate and full frame length.
metadata=0x20082000
put(layer_sample+0x130,metadata)
for rate_hz,frames,mode in ((44100,1322999,0),(44100,1323000,0),(44100,1323001,1),
                            (48000,1440000,0),(48000,1440001,1)):
 u.mem_write(metadata+4,struct.pack('<II',frames,rate_hz))
 call(symbols['pc_sample_default_mode'],layer_sample);assert reg(0)==mode
print('Native sample duration chooses Mono strictly after 30 seconds, at 44.1 and 48 kHz')

# Assigning a long sample to a secondary layer sets the pad Mono.
command_address=0x20083000;secondary=0x20084000;secondary_meta=0x20085000
put(command_address+0x80,program);put(command_address+0x98,instrument)
put(secondary+0x130,secondary_meta)
u.mem_write(metadata+4,struct.pack('<II',1323000,44100))
u.mem_write(secondary_meta+4,struct.pack('<II',1323001,44100))
assignment=(layers+0x4a8+0xb30,secondary)
call(symbols['assign_sample_poly'],command_address)
assert reg(0)==0 and assigned_modes==[1]
call(symbols['assign_sample_poly'],command_address)
assert reg(0)==0 and assigned_modes==[1]
print('Assign Sample applies Mono to a newly assigned long layer and preserves mode on unchanged assignment')

# Native caption widgets belong to the exact Sample and File Select screens.
sample_screen=0x20087000
put(sample_screen,0x6e212a0)
# Run the displaced Shift read on the stock instruction path in every tab.
call(symbols['install_sample_mix_shift'],4096)
assert q(0x1654b8c)&0xfc000000==0x14000000
shift_data=0x2008a000
for tab in range(3):
 for pressed in (0,1):
  u.mem_write(sample_screen+0x3a8,struct.pack('<I',tab))
  u.mem_write(shift_data+0x2a0,bytes([pressed]))
  u.reg_write(UC_ARM64_REG_X21,sample_screen)
  u.reg_write(UC_ARM64_REG_X1,shift_data)
  u.emu_start(0x1654b8c,0x1654b90,count=16)
  assert u.reg_read(UC_ARM64_REG_W20)==(pressed if tab!=1 else 0)
  assert bytes(u.mem_read(shift_data+0x2a0,1))==bytes([pressed])
print('Sample Mix stays on its primary parameter page without changing hardware Shift')
call(symbols['sample_mix_caption'],sample_screen,1,instrument)
title=next(k for k,v in caption_titles.items() if v==b'Sidechain')
side=next(k for k,v in caption_titles.items() if v==b'Off')
assert q(title+0x18)==q(side+0x18)==sample_screen
assert q(title+0x20)==198<<32|106 and q(side+0x20)==217<<32|106
assert q(title+0x28)==q(side+0x28)==19<<32|107
sidechain_role=2
call(symbols['sample_mix_caption'],sample_screen,1,instrument)
receive=next(k for k,v in caption_titles.items() if v==b'Receive')
assert q(receive+0xa8)==2 and q(side+0xa8)==0
call(symbols['sample_mix_caption'],sample_screen,0,instrument)
assert q(receive+0xa8)==q(title+0xa8)==0

step=0x200a0000;erase=step+0x760
put(step,0x6e24f38);put(erase,0x706e940)
put(erase+0x20,213);put(erase+0x28,38<<32|106)
put(manager+0xd8,0x20ad)
put(state_base+0x860,0)
painted_rects.clear();caption_pass.clear()
call(symbols['pc_step_roll_paint_caption'],step,graphics)
roll=symbols['piano_roll_caption']
assert caption_titles[roll]==b'Piano Roll' and q(roll+0x18)==step
assert q(roll+0x20)==106 and q(roll+0x28)==38<<32|107 and not q(roll+0xa8)
assert painted_rects==[(graphics,106,0,107,38)]
assert [v[0] for v in caption_pass]==[0x102d360,0x102d470,0x1135cf0,0x102d3b0]
assert caption_pass[1][1]==(graphics,106,0) and caption_pass[2][1][:2]==(roll,graphics)
put(state_base+0x860,1)
call(symbols['pc_step_roll_paint_caption'],step,graphics)
assert len(painted_rects)==1 and len(caption_pass)==4
put(state_base+0x860,0)
print('Step Edit clears the legacy cell then paints the native Piano Roll caption in the same pass')
file_screen=0x20090000
put(file_screen,0x6e1cfb8);put(file_screen+0xa8,2);put(manager+0xd8,0x20a9)
call(symbols['pc_import_frame'],file_screen)
for label in (b'Synths',b'K1 100% Metro',b'K3 Preview On'):
 widget=next(k for k,v in caption_titles.items() if v==label)
 assert q(widget+0x18)==file_screen and q(widget+0xa8)==2
put(manager+0xd8,0x20a7)
call(symbols['pc_import_frame'],file_screen)
assert not q(widget+0xa8)
print('Native Sample Sidechain and Sample Import captions attach to stock views and hide outside their scope')

# Actual physical fader dispatch for a sampleless synth pad. Native sample
# assignment fields must stay untouched; selecting a mapping opts out.
synth_filter_test=True;dj_fx_test=True
synth_track,synth_program,synth_instrument=0x200d0000,0x200d1000,0x200d5000
synth_rate,synth_section,synth_vector=0x200d8000,0x200d9000,0x200da000
synth_responder,synth_properties=0x200da100,0x200da400
put(project+0x140,synth_track);put(project+0x668,synth_instrument)
put(synth_track,0x6ecf118);put(synth_track+0xbb8,synth_program)
put(synth_program,0x6ec6860);put(synth_program+0x2808,synth_vector);put(synth_program+0x2810,synth_vector+8);put(synth_vector,synth_instrument)
put(synth_instrument,0x6ec3ca0);put(synth_instrument+0x2310,synth_program);put(synth_instrument+0x638,synth_rate);put(synth_instrument+0x2340,synth_section)
u.mem_write(synth_rate+0x50,struct.pack('<f',44100))
put(synth_responder+0xf8,synth_properties);u.mem_write(synth_properties+0x1b,b'\x01');u.mem_write(synth_properties+0x3c,struct.pack('<I',6))
slot=symbols['host']+32;put(slot+192,synth_instrument);put(slot+200,synth_program);u.mem_write(slot+40260,struct.pack('<I',7))
u.reg_write(UC_ARM64_REG_S0,0x3e800000)
call(symbols['pc_synth_fader_input'],synth_responder);assert reg(0)==1
call(symbols['pc_ui_event'],queued.pop())
assert struct.unpack('<f',u.mem_read(synth_section+0x498,4))[0]>.249
assert struct.unpack('<I',u.mem_read(synth_properties+0x3c,4))[0]==6
# Same-value native assignment still explicitly selects that mapping.
call(0x1564ae0,synth_properties+0x20,6)
u.reg_write(UC_ARM64_REG_S0,0x3f000000);call(symbols['pc_synth_fader_input'],synth_responder);assert reg(0)==0
# A native sample continues through the original fader callback.
put(slot+192,0);call(symbols['pc_synth_fader_input'],synth_responder);assert reg(0)==0
synth_filter_test=False;dj_fx_test=False
print('Synth fader defaults to stock cutoff, explicit native mappings are respected and sample mapping remains unchanged')
