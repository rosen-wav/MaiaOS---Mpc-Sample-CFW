#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>
#include <dirent.h>
#include <dlfcn.h>
static void *decoder;
#define DJ_RESOLVE(name) (decoder?dlsym(decoder,name):NULL)
#include "../src/dj_analysis.c"
#include "../src/dj_prepare.c"
static char card[256];
static unsigned writes,deny_writes,no_card;
static long result(long n){return n<0?-errno:n;}
int pc_sd_folder(char *out,unsigned cap,const char *suffix){
 assert(!*suffix);if(no_card)return 0;
 assert(strlen(card)+1<cap);strcpy(out,card);return 1;
}
long pc_sys(long n,long a,long b,long c,long d,long e,long f){
 switch(n){
 case 56:{int flags=(int)c;if(flags&0x4000)flags=(flags&~0x4000)|O_DIRECTORY;return result(openat(a,(const char*)b,flags,d));}
 case 57:return result(close(a));
 case 62:return result(lseek(a,b,c));
 case 67:return result(pread(a,(void*)b,c,d));
 case 64:writes++;if(deny_writes){errno=ENOSPC;return -errno;}return result(write(a,(void*)b,c));
 case 34:return result(mkdirat(a,(const char*)b,c));
 case 35:return result(unlinkat(a,(const char*)b,c));
 case 38:return result(renameat(a,(const char*)b,c,(const char*)d));
 case 80:{struct stat st;if(fstat(a,&st))return -errno;uint64_t *s=(uint64_t*)b;memset(s,0,128);s[0]=st.st_dev;s[1]=st.st_ino;s[6]=st.st_size;s[11]=st.st_mtim.tv_sec;s[12]=st.st_mtim.tv_nsec;s[13]=st.st_ctim.tv_sec;s[14]=st.st_ctim.tv_nsec;return 0;}
 case 82:return result(fsync(a));
 case 113:return result(clock_gettime(a,(struct timespec*)b));
 case 215:return result(munmap((void*)a,b));
 case 222:return result((long)mmap((void*)a,b,c,d,e,f));
 default:fprintf(stderr,"syscall %ld\n",n);assert(0);return -1;
 }
}
static void fixture(const char *path,unsigned rate){
 FILE *file=fopen(path,"wb");assert(file);
 unsigned frames=rate*3/5;uint8_t header[44]={0};
 memcpy(header,"RIFF",4);cache_u32(header+4,36+frames*8);memcpy(header+8,"WAVEfmt ",8);
 cache_u32(header+16,16);cache_u16(header+20,3);cache_u16(header+22,2);
 cache_u32(header+24,rate);cache_u32(header+28,rate*8);cache_u16(header+32,8);cache_u16(header+34,32);
 memcpy(header+36,"data",4);cache_u32(header+40,frames*8);assert(fwrite(header,1,44,file)==44);
 for(unsigned n=0;n<frames;n++){
  double t=(double)n/rate;
  float sample[2];sample[0]=.2*sin(2*M_PI*1000*t)+.2*sin(2*M_PI*19000*t)+.1*sin(2*M_PI*20000*t);sample[1]=-sample[0];
  assert(fwrite(sample,4,2,file)==2);
 }
 assert(!fclose(file));
}
static void check_audio(const char *path){
 DjReader r={0};assert(pc_dj_reader_open(&r,path)==DJ_OK);
 assert(r.format.rate==44100&&r.format.channels==2&&r.format.frames==26460&&r.format.bits==32);
 double error=0,signal=0,projection=0;
 unsigned count=0;
 for(unsigned n=128;n<r.format.frames-128;n++){
  float l,right;assert(pc_dj_reader_frame(&r,n,&l,&right));assert(fabsf(l+right)<1e-6f);
  double t=n/44100.,ideal=.2*sin(2*M_PI*1000*t)+.2*sin(2*M_PI*19000*t)+.1*sin(2*M_PI*20000*t);
  error+=(l-ideal)*(l-ideal);signal+=ideal*ideal;projection+=l*sin(2*M_PI*20000*t);count++;
 }
 double high=2*projection/count;
 printf("44.1 kHz cache: 20 kHz amplitude %.6f (source 0.100000), error %.2f dB\n",high,10*log10(error/signal));
 assert(high>.097&&high<.103);assert(error/signal<.0001);
 pc_dj_reader_close(&r);
}
int main(void){
 strcpy(card,"/tmp/maia-dj-card-XXXXXX");assert(mkdtemp(card));
 char source[512],normal[512],out[1024],cached[1024];
 snprintf(source,sizeof source,"%s/beat 170.wav",card);snprintf(normal,sizeof normal,"%s/normal.wav",card);
 fixture(source,48000);fixture(normal,44100);
 FILE *original=fopen(source,"rb");assert(original);fseek(original,0,SEEK_END);long bytes=ftell(original);rewind(original);
 char *before=malloc(bytes),*after=malloc(bytes);assert(before&&after);assert(fread(before,1,bytes,original)==(size_t)bytes);fclose(original);
 assert(pc_dj_prepare_track(source,out,sizeof out)==DJ_OK);assert(writes&&strcmp(out,source));strcpy(cached,out);check_audio(out);
 original=fopen(source,"rb");assert(fread(after,1,bytes,original)==(size_t)bytes);fclose(original);assert(!memcmp(before,after,bytes));free(before);free(after);
 writes=0;assert(pc_dj_prepare_track(source,out,sizeof out)==DJ_OK&&!strcmp(out,cached)&&!writes);
 DjAnalysis a;assert(pc_dj_analyse_named(cached,source,&a)==DJ_OK&&a.tagged_bpm==170&&a.rate==44100);
 struct timespec times[2]={{.tv_sec=1000000},{.tv_sec=1000000}};assert(!utimensat(AT_FDCWD,source,times,0));
 writes=0;assert(pc_dj_prepare_track(source,out,sizeof out)==DJ_OK&&writes&&strcmp(out,cached));
 times[1].tv_sec++;assert(!utimensat(AT_FDCWD,source,times,0));deny_writes=1;
 assert(pc_dj_prepare_track(source,out,sizeof out)==DJ_CACHE_ERROR&&!out[0]);deny_writes=0;
 char directory[512];snprintf(directory,sizeof directory,"%s/MaiaDJ-Cache",card);DIR *dir=opendir(directory);assert(dir);struct dirent *entry;
 while((entry=readdir(dir)))assert(!strstr(entry->d_name,".tmp"));closedir(dir);
 no_card=1;writes=0;assert(pc_dj_prepare_track(normal,out,sizeof out)==DJ_OK&&!strcmp(out,normal)&&!writes);
 assert(pc_dj_prepare_track(source,out,sizeof out)==DJ_CACHE_ERROR&&!out[0]);no_card=0;
 assert(pc_dj_prepare_track("/missing/track.wav",out,sizeof out)==DJ_READ_ERROR);
 decoder=dlopen("libmpg123.so.0",RTLD_NOW);
 if(decoder&&system("command -v ffmpeg >/dev/null")==0){
  char mp3[512],command[1400];snprintf(mp3,sizeof mp3,"%s/track.mp3",card);
  snprintf(command,sizeof command,"ffmpeg -hide_banner -loglevel error -i '%s' -codec:a libmp3lame '%s'",source,mp3);assert(system(command)==0);
  assert(pc_dj_prepare_track(mp3,out,sizeof out)==DJ_OK);DjReader r={0};assert(pc_dj_reader_open(&r,out)==DJ_OK&&r.format.rate==44100);pc_dj_reader_close(&r);dlclose(decoder);
 }
 dir=opendir(directory);assert(dir);while((entry=readdir(dir)))if(entry->d_name[0]!='.'){
  char path[1024];snprintf(path,sizeof path,"%s/%s",directory,entry->d_name);assert(!unlink(path));
 }closedir(dir);assert(!rmdir(directory));assert(!unlink(source));assert(!unlink(normal));
 char mp3[512];snprintf(mp3,sizeof mp3,"%s/track.mp3",card);unlink(mp3);assert(!rmdir(card));
 puts("Offline WAV/MP3 48->44.1 cache preserves stereo, timing, 20 kHz and original bytes; reuses cache, invalidates changes and cleans failed writes");
}
