#include <assert.h>
#include <math.h>
#include <stdio.h>
#include "../src/mix.c"
Host host;static int synth;
int pc_find(uintptr_t p){(void)p;return synth?0:-1;}
int main(void){float l[64],r[64];float*channels[2]={l,r};FxBuffer b={.channels=2,.capacity=64,.data=channels};uintptr_t instrument=123;
 mix.count=1;mix.pads[0].instrument=instrument;mix.pads[0].generation=1;mix.pads[0].controls=(uint64_t)661<<42;
 for(unsigned n=0;n<64;n++)l[n]=r[n]=1;pc_mix_native_gain(instrument,(uintptr_t)&b,64);assert(l[0]>1&&l[63]>1.99f&&l[63]<2.01f);
 for(unsigned n=0;n<64;n++)l[n]=r[n]=1;pc_mix_native_gain(instrument,(uintptr_t)&b,64);assert(fabsf(l[0]-l[63])<.0001f);
 synth=1;for(unsigned n=0;n<64;n++)l[n]=r[n]=1;pc_mix_native_gain(instrument,(uintptr_t)&b,64);assert(l[0]==1&&l[63]==1);
 puts("persisted native-sample trim gain is audible, smoothed and not doubled on synths");
}
