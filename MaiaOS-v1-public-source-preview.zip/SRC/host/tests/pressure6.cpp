#include "../src/pressure6.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <initializer_list>
static float l[256],r[256];
static void fill(float v){for(unsigned i=0;i<256;i++){l[i]=v;r[i]=-v;}}
static float run(unsigned owner,unsigned epoch,PcPressure6 p,unsigned blocks,float amplitude){
 float gain=1;
 for(unsigned n=0;n<blocks;n++){fill(amplitude);gain=pc_pressure6_process(owner,epoch,l,r,256,&p);
  for(unsigned i=0;i<256;i++)assert(std::isfinite(l[i])&&std::isfinite(r[i])&&std::abs(l[i]+r[i])<1e-5);
 }
 return gain;
}
int main(){
 PcPressure6 p={0,4,700,1,44100,0};
 assert(run(1,1,p,20,.2f)==1);
 for(unsigned i=0;i<256;i++)assert(l[i]==.2f&&r[i]==-.2f);
 p.amount=.85f;
 float gr=run(2,1,p,300,1.f);printf("Pressure6 steady compression gain %.6f, output %.6f\n",gr,l[255]);assert(gr<.9f&&gr>0);
 PcPressure6 fast=p,slow=p;fast.attack_ms=.5;slow.attack_ms=100;
 run(3,1,fast,200,.01f);run(4,1,slow,200,.01f);
 float gf=run(3,1,fast,1,.4f),gs=run(4,1,slow,1,.4f);assert(gf<gs);
 fast.attack_ms=slow.attack_ms=4;fast.release_ms=30;slow.release_ms=2000;
 run(5,1,fast,300,.4f);run(6,1,slow,300,.4f);
 gf=run(5,1,fast,10,.01f);gs=run(6,1,slow,10,.01f);printf("release gains fast %.9f slow %.9f\n",gf,gs);assert(gf>gs);
 PcPressure6 dry=p;dry.amount=0;
 assert(run(2,2,dry,1,.2f)==1&&l[0]==.2f); // New-project reset.
 // Shortest attack, maximum Amount: loud bass with both small and
 // over-full-scale input. Measure harmonic residual after settling.
 for(float amplitude : {.75f,1.6f}){
  PcPressure6 extreme={1,0,30,1,44100,1};
  constexpr double step=6.283185307179586*50/44100;
  double xy=0,x2=0,y2=0;
  for(unsigned b=0;b<344;b++){
   for(unsigned i=0;i<256;i++){l[i]=amplitude*sin(step*(256*b+i));r[i]=-.3f*l[i];}
   pc_pressure6_process(7,1,l,r,256,&extreme);
   if(b<172)continue;
   for(unsigned i=0;i<256;i++){
    assert(std::abs(l[i])<1&&std::abs(r[i]+.3f*l[i])<1e-6);
    double x=sin(step*(256*b+i));xy+=x*l[i];x2+=x*x;y2+=l[i]*l[i];
   }
  }
  double residual=sqrt(fmax(0,(y2-xy*xy/x2)/y2));
  printf("Pressure6 max Amount, attack 0, peak %.2f: residual %.6f\n",amplitude,residual);
  assert(residual<.012);
 }
 puts("Pressure6 neutral dry, stereo link, real reduction, attack/release controls, independent owners and project reset passed");
}
