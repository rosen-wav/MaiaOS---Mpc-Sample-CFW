#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>
#include "internal.h"
#include "drumkit_files.h"
long pc_sys(long n,long a,long b,long c,long d,long e,long f){(void)e;(void)f;long result;
 switch(n){case 56:{int flags=c;flags&=~(0x8000|0x4000|0x20000);if(c&0x8000)flags|=O_NOFOLLOW;if(c&0x4000)flags|=O_DIRECTORY;result=openat(a,(const char*)b,flags,d);break;}case 57:result=close(a);break;case 61:result=syscall(SYS_getdents64,a,(void*)b,c);break;default:assert(0);}return result<0?-errno:result;}
static char paths[16][PC_KIT_PATH];
int main(void){char root[]="/tmp/maia-kit-XXXXXX";assert(mkdtemp(root));char p[1024];
 for(unsigned c=0;c<6;c++){snprintf(p,sizeof p,"%s/%s",root,pc_kit_folders[c]);assert(!mkdir(p,0700));for(unsigned n=0;n<6;n++){snprintf(p,sizeof p,"%s/%s/%u.WAV",root,pc_kit_folders[c],n);int fd=open(p,O_WRONLY|O_CREAT,0600);assert(fd>=0);close(fd);}}
 unsigned failure;assert(pc_kit_pick(root,0,123,paths,&failure));unsigned counts[6]={0};for(unsigned n=0;n<16;n++){counts[pc_kit_category[n]]++;assert(strstr(paths[n],pc_kit_folders[pc_kit_category[n]]));assert(pc_kit_gain_group(n)==(n<2?0:n<7?1:2));for(unsigned j=0;j<n;j++)if(pc_kit_category[j]==pc_kit_category[n])assert(strcmp(paths[j],paths[n]));}
 assert(counts[0]==2&&counts[1]==3&&counts[2]==2&&counts[3]==4&&counts[4]==3&&counts[5]==2);
 assert(pc_kit_pick(root,(1u<<0)|(1u<<7)|(1u<<15),456,paths,&failure));assert(!paths[0][0]&&!paths[7][0]&&!paths[15][0]&&paths[1][0]);
 snprintf(p,sizeof p,"%s/Kick",root);char moved[1024];snprintf(moved,sizeof moved,"%s/Kick-off",root);assert(!rename(p,moved));assert(!pc_kit_pick(root,0,1,paths,&failure)&&failure==0);assert(pc_kit_pick(root,3,1,paths,&failure));assert(!paths[0][0]&&!paths[1][0]);
 assert(pc_kit_pick("/path-not-present",65535,1,paths,&failure));
 puts("16-pad distribution, unique category choices, gain groups, locks and missing-folder atomic planning passed");
}
