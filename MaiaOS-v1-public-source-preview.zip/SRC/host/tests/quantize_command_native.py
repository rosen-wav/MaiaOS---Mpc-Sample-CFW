import struct
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--stock',required=True,help='Unmodified MPC Sample 1.3.0 ARM64 executable')
parser.add_argument('--host',required=True,help='Built host library')
args=parser.parse_args()
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
u.mem_map(0,0x7300000);u.mem_map(0x10000000,0x1000000);u.mem_map(0x20000000,0x1000000);u.mem_map(0x30000000,0x100000);u.mem_map(0x40000000,4096)
syms={};dynamic_stubs={}
for name,base in [(args.stock,0),(args.host,0x10000000)]:
 e=ELFFile(open(name,'rb'))
 for s in e.iter_segments():
  if s['p_type']=='PT_LOAD':u.mem_write(base+s['p_vaddr'],s.data())
 for relsec in e.iter_sections():
  if relsec.name=='.rela.dyn':
   for r in relsec.iter_relocations():
    if r['r_info_type']==1027:u.mem_write(base+r['r_offset'],struct.pack('<Q',base+r['r_addend']))
 if base:
  for s in e.get_section_by_name('.symtab').iter_symbols():syms[s.name]=base+s['st_value']
  rel=e.get_section_by_name('.rela.plt');dyn=e.get_section_by_name('.dynsym')
  if rel:
   for r in rel.iter_relocations():
    name=dyn.get_symbol(r['r_info_sym']).name;address=0x40000100+16*len(dynamic_stubs);dynamic_stubs[address]=name
    u.mem_write(base+r['r_offset'],struct.pack('<Q',address))
def q(a):return struct.unpack('<Q',u.mem_read(a,8))[0]
def put(a,v):u.mem_write(a,struct.pack('<Q',v&((1<<64)-1)))
def reg(n):return u.reg_read(UC_ARM64_REG_X0+n)
def ret(v=None):
 if v is not None:u.reg_write(UC_ARM64_REG_X0,v)
 u.reg_write(UC_ARM64_REG_PC,u.reg_read(UC_ARM64_REG_LR))
heap=0x20000000;headers={}
def alloc(n):
 global heap
 a=heap;heap=(heap+n+15)&~15;u.mem_write(a,b'\0'*n);return a
def insert(left,node,parent,header):
 put(node+8,parent);put(node+16,0);put(node+24,0);headers[node]=header
 if parent==header:put(header+8,node);put(header+16,node);put(header+24,node)
 else:
  put(parent+(16 if left else 24),node)
  if left and q(header+16)==parent:put(header+16,node)
  if not left and q(header+24)==parent:put(header+24,node)
def successor(n):
 h=headers.get(n)
 if h is None:
  a=n
  for unused in range(1000):
   parent=q(a+8)
   if q(parent+8)==a:h=parent;break
   a=parent
  assert h is not None,hex(n)
  headers[n]=h
 if q(n+24):
  n=q(n+24)
  while q(n+16):n=q(n+16)
  return n
 p=q(n+8)
 while p!=h and n==q(p+24):n=p;p=q(p+8)
 return p
def erase(n,h):
 # Only simple temporary quantizer trees are expected here.
 l,r=q(n+16),q(n+24);p=q(n+8)
 if l and r:
  successor=r
  while q(successor+16):successor=q(successor+16)
  parent=q(successor+8);child=q(successor+24)
  if parent!=n:
   put(parent+16,child)
   if child:put(child+8,parent)
   put(successor+24,r);put(r+8,successor)
  put(successor+16,l);put(l+8,successor)
  if p==h:put(h+8,successor)
  else:put(p+(16 if q(p+16)==n else 24),successor)
  put(successor+8,p)
  l=r=0
  # Common header refresh below, without a second transplant.
  p=0
 child=l or r
 if p:
  if p==h:put(h+8,child)
  else:put(p+(16 if q(p+16)==n else 24),child)
  if child:put(child+8,p)
 root=q(h+8)
 if root:
  a=b=root
  while q(a+16):a=q(a+16)
  while q(b+24):b=q(b+24)
  put(h+16,a);put(h+24,b)
 else:put(h+16,h);put(h+24,h)
 return n
put(0x7164398,alloc(8))
# Unicorn lacks LDAPR; a plain load is equivalent in this single-thread fixture.
u.mem_write(0x214c634,struct.pack('<I',0xf9400022))
def hook(uc,pc,size,data):
 if pc==0x40000000:uc.emu_stop();return
 if pc in dynamic_stubs:
  name=dynamic_stubs[pc]
  if name=='memcpy':u.mem_write(reg(0),bytes(u.mem_read(reg(1),reg(2))));ret(reg(0));return
  if name=='memset':u.mem_write(reg(0),bytes([reg(1)&255])*reg(2));ret(reg(0));return
  if name=='memcmp':ret(0 if u.mem_read(reg(0),reg(2))==u.mem_read(reg(1),reg(2)) else 1);return
  raise RuntimeError('Unhandled host import '+name)
 if pc in (0xb51418,):ret(alloc(reg(0)));return
 if pc in (0xb51408,0x157df10,0xf0a290,0x27ee100,0xf1c620):ret();return
 if pc==0x19d0a00:
  pending_commands.append(q(reg(1)));owner=q(reg(1)+8)
  if owner:put(owner+8,0x100000002) # CommandManager retains its shared owner.
  ret(0);return
 if pc==0x19d1800:put(u.reg_read(UC_ARM64_REG_X8),empty_string);ret();return
 if pc==0x19c9850:u.mem_write(reg(0),b'\0'*256);ret();return
 if pc==0xf1c640:put(reg(0),q(reg(1)));ret();return
 if pc==0xb51668:insert(reg(0),reg(1),reg(2),reg(3));ret();return
 if pc==0xb51738:ret(successor(reg(0)));return
 if pc==0xb51718:
  n=reg(0)
  if n in known_headers:ret(q(n+24));return
  h=headers.get(n)
  if h is None:
   a=n
   while q(q(a+8)+8)!=a:a=q(a+8)
   h=q(a+8)
  if q(n+16):
   n=q(n+16)
   while q(n+24):n=q(n+24)
   ret(n);return
  p=q(n+8)
  while p!=h and n==q(p+16):n=p;p=q(p+8)
  ret(p);return
 if pc==0xb51768:ret(erase(reg(0),reg(1)));return
 if pc==0xb51688:u.mem_write(reg(0),bytes([reg(1)&255])*reg(2));ret(reg(0));return
 if pc==0xb51b58:u.reg_write(UC_ARM64_REG_X1,0);ret(0);return
 if pc==0xb51af8:raise AssertionError("native out of range")
 if pc==0x214bb40:ret(1);return
 if pc==0x214b610:ret((reg(1)+120)//240*240);return
 if 0xb50000<=pc<0xb60000:raise RuntimeError(f'unhandled PLT {pc:x}')
pending_commands=[];known_headers=set();empty_string=alloc(8)
u.mem_write(0x40000008,struct.pack('<I',0xd65f03c0))
u.hook_add(UC_HOOK_CODE,hook)
def call(pc,*args):
 u.reg_write(UC_ARM64_REG_SP,0x300ff000);u.reg_write(UC_ARM64_REG_LR,0x40000000)
 for n,v in enumerate(args):u.reg_write(UC_ARM64_REG_X0+n,v)
 try:u.emu_start(pc,0x40000004,count=10000000)
 except Exception as e:raise RuntimeError(f'{e} at {u.reg_read(UC_ARM64_REG_PC):x}') from e
 return reg(0)
def eventset():
 a=alloc(48);put(a+24,a+8);put(a+32,a+8);return a
def event(tick,key,pitch):
 a=alloc(56);u.mem_write(a,struct.pack('<qII f',tick,3,0,.8));u.mem_write(a+20,bytes([1,0,pitch]));put(a+40,120);u.mem_write(a+48,bytes([key]));return a
def values(s,pairs=False):
 vals=[];n=q(s+24);end=s+8
 while n!=end:
  e=n+32;vals.append((q(e),u.mem_read(e+48,1)[0],u.mem_read(e+22,1)[0],q(e+56) if pairs else None));n=successor(n)
 return vals

def initialize_set(a):
 put(a+24,a+8);put(a+32,a+8);known_headers.add(a+8)
def initialize_list():
 a=alloc(0x200)
 for offset in [0x60,0xc0,0xf0]:initialize_set(a+offset)
 put(a+0xa8,a+0xa8);put(a+0xb0,a+0xa8)
 table=alloc(32);put(table+0x10,0x40000008);put(a,table)
 return a
def make_command(list,removals,additions,pairs,flags):
 cmd=alloc(0x100);known_headers.update([cmd+0x88,cmd+0xb8])
 sp=0x300ff000
 for n in range(8):put(sp+8*n,0)
 put(sp,alloc(8));put(sp+8,alloc(8))
 call(0x19d79d0,cmd,list,removals,additions,pairs,flags[0],flags[1],1)
 return cmd
quantizer=alloc(1024)
for unison in [False,True]:
 flags=(1,0)
 list=initialize_list();changes=eventset();adds=eventset();empty=eventset()
 events=[(110,36,120),(110,36,124),(110,36,127),(350,36,120),(350,36,124),(350,36,127),(200,40,125)]
 if unison:events.append((110,36,120))
 for tick,key,pitch in events:call(0x1574460,list+0x60,event(tick,key,pitch))
 call(syms['pc_quantize_poly'],quantizer,0,list+0x60,changes,adds)
 cmd=make_command(list,adds,empty,changes,flags)
 print('constructor flags',flags,'remove',values(cmd+0x80),'add',values(cmd+0xb0))
 call(0x27f0ee0,list,cmd+0x80,cmd+0xb0)
 after=values(list+0x60);print('published',after)
 if True:
  assert len(after)==7+unison
  for tick in [0,240]:assert {p for t,k,p,new in after if t==tick and k==36}=={120,124,127}
  call(0x27f0ee0,list,cmd+0xb0,cmd+0x80)
  before=values(list+0x60);assert len(before)==7+unison
  for tick in [110,350]:assert {p for t,k,p,new in before if t==tick and k==36}=={120,124,127}
# The r69 regression is the post-command duplicate cleanup, not just the
# command constructor. Exercise that native pass and its published command.
for cleanup in [0x214be90,syms['pc_quantize_cleanup']]:
 list=initialize_list();pending_commands.clear()
 for tick,key,pitch in [(0,36,120),(0,36,124),(0,36,127),(240,36,120),(240,36,124),(240,36,127)]:call(0x1574460,list+0x60,event(tick,key,pitch))
 call(cleanup,list,alloc(256))
 for cmd in pending_commands:call(0x27f0ee0,list,cmd+0x80,cmd+0xb0)
 after=values(list+0x60);print('post-cleanup',hex(cleanup),after)
 if cleanup==0x214be90:assert len(after)==2
 else:assert len(after)==6
print('Full native publication, post-cleanup and undo retain all chord notes')
