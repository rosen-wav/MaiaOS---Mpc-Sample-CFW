#include <assert.h>
#include <pthread.h>
#include "internal.h"
Host host;static unsigned blocked,accepted;
int pc_cpu_overloaded(void){return blocked;}
uint64_t pc_bounce_time_ns(void){return 0;}
static void*onset(void*unused){(void)unused;if(pc_trigger_admit(0,64,1))__atomic_fetch_add(&accepted,1,__ATOMIC_RELAXED);return 0;}
int main(void){
 pc_trigger_block();for(unsigned i=0;i<1024;i++){assert(pc_trigger_admit(0,0,1));assert(pc_trigger_admit(1,0,8));}
 pthread_t threads[64];for(unsigned i=0;i<64;i++)assert(!pthread_create(&threads[i],0,onset,0));for(unsigned i=0;i<64;i++)pthread_join(threads[i],0);assert(accepted==64);
 blocked=1;assert(!pc_trigger_admit(0,0,1)&&!pc_trigger_admit(1,0,1));blocked=0;assert(pc_trigger_admit(0,0,1)&&pc_trigger_admit(1,0,1));
}
