#include <assert.h>
#include <stdio.h>
#include "internal.h"
Host host;static unsigned active,held;
static unsigned voices(void){return active;}static unsigned gates(void){return held;}
Dsp*pc_slot_dsp(Slot*s){return &s->dsp;}
unsigned pc_ms_voices(uintptr_t v){(void)v;return 0;}
unsigned pc_fm6_voices(unsigned k){(void)k;return active;}
void pc_diag_add(unsigned n){(void)n;}
void pc_diag_value(unsigned n,unsigned v){(void)n;(void)v;}
int main(void){Slot s={0};s.audio_engine=7;s.dsp.legacy_layout=1;s.dsp.voices=voices;s.dsp.held=gates;
 active=8;held=0;s.sequence_protected=1;assert(!pc_poly_reserve(&s)&&s.sequence_protected);
 s.sequence_protected=0;held=8;assert(!pc_poly_reserve(&s));s.sequence_protected=1;active=7;held=0;assert(pc_poly_reserve(&s)&&s.sequence_protected);active=0;pc_poly_sync(&s);assert(!s.sequence_protected&&pc_poly_reserve(&s));
 host.slots[0].audio_engine=4;active=16;assert(pc_poly_reserve(&host.slots[0]));
 puts("synth protects release tails and held voices at backend capacity");
}
