#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include "../src/host.c"
#include "../src/syx.h"
#include "../vendor/more-chords-fm6/felucca_fm6.h"
void pc_synth_fader_reset(uintptr_t i){(void)i;}
void pc_padfx_touch(unsigned a,unsigned b){(void)a;(void)b;}
unsigned pc_performance_gate(unsigned a,uintptr_t b,unsigned c){(void)a;(void)b;(void)c;return 0;}
void pc_sc_note(uintptr_t a,uintptr_t b,const uint8_t*c){(void)a;(void)b;(void)c;}
void pc_bounce_note_seen(uintptr_t a){(void)a;}
unsigned pc_bounce_busy(void){return 0;}
void pc_tune_follow_note(unsigned a,unsigned b){(void)a;(void)b;}
int pc_trigger_admit(unsigned a,unsigned b,unsigned c){(void)a;(void)b;(void)c;return 1;}
void pc_poly_reject(void){}
unsigned pc_stock_filter_note(uintptr_t p,const uint8_t*d){(void)p;return d[12]&4?256+d[16]:0;}
static unsigned native_live_calls,audio_attacks,duplicate_native;
int pc_cpu_overloaded(void){return 0;}
int pc_poly_reserve(Slot*s){(void)s;return 1;}
Dsp*pc_slot_dsp(Slot*s){return &s->dsp;}
void pc_poly_sync(Slot*s){(void)s;}
void pc_dsp_attack(Slot*s,unsigned n,unsigned v){(void)s;assert(n==60&&v>0);audio_attacks++;}
unsigned pc_ms_voices(uintptr_t v){(void)v;return 0;}
static unsigned ms_on[16],ms_off[16],ms_ons,ms_offs;
int pc_ms_on(uintptr_t v,unsigned n,unsigned vel,unsigned owner){
 (void)v;assert(n<128&&vel>0&&ms_ons<16);ms_on[ms_ons++]=owner;return 1;
}
void pc_ms_off(uintptr_t v,unsigned owner){(void)v;assert(ms_offs<16);ms_off[ms_offs++]=owner;}
static unsigned contexts,freed,stopped;
uintptr_t pc_ms_load(const uint8_t *patch){assert(!memcmp(patch,"MPCMUL01",8));return ++contexts;}
void pc_ms_free(uintptr_t context){if(context)freed++;}
void pc_ms_stop(uintptr_t context){if(context)stopped++;}
void pc_ms_set(uintptr_t context,unsigned index,unsigned value){(void)context;(void)index;(void)value;}
int pc_backend_load(Dsp *d,const uint8_t *patch){(void)d;(void)patch;return 1;}
void pc_poly_forget(Slot *s){s->voice_mask=0;}
float pc_mix_gain(uintptr_t instrument){(void)instrument;return 1.f;}
void pc_mix_route_program(uintptr_t program){(void)program;}
void pc_mix_forget(uintptr_t instrument,uintptr_t program){(void)instrument;(void)program;}
void pc_sc_forget(uintptr_t instrument,uintptr_t program){(void)instrument;(void)program;}
void pc_light_refresh(void){}
static unsigned gates(void){return host.slots[0].held_keys;}
static void gate_off(unsigned n){(void)n;}

static void native_live(uintptr_t iface,unsigned offset,unsigned tr,uintptr_t ctx,const uint8_t*d){(void)iface;(void)offset;(void)tr;(void)ctx;(void)d;native_live_calls++;if(duplicate_native)assert(note(host.slots[0].program,offset,ctx,host.slots[0].instrument,d,1));}
static void trampoline(uintptr_t offset,void*fn){uint8_t*p=(uint8_t*)(host.base+offset);p[0]=0x48;p[1]=0xb8;memcpy(p+2,&fn,8);p[10]=0xff;p[11]=0xe0;}
int main(void){
 host.base=(uintptr_t)mmap(0,0x7400000,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(host.base!=(uintptr_t)MAP_FAILED);
 *(uint8_t*)(host.base+0x286c860)=0xc3; /* native return-only notification fixture */
 static PcDebug debug;host.debug=&debug;host.ready=1;static uint8_t program[16],instrument[0x2400];Slot*s=&host.slots[0];s->instrument=(uintptr_t)instrument;s->program=(uintptr_t)program;s->generation=1;
 for(unsigned j=0;j<NOTE_QUEUE;j++)s->events[j].sequence=j;
 uint8_t packet[32]={0};float velocity=.8f;memcpy(packet+8,&velocity,4);packet[0]=255;packet[12]=1;packet[14]=120;
 I(host.base+G,0x18c0)=1; /* stale 16 Levels / pad-perform context */
 unsigned previous=pad_enter(7,0,0);assert(pad_owner==263);assert(note(s->program,0,0,s->instrument,packet,0));assert(s->event_write==1&&s->events[0].source==263&&s->events[0].pitch==60);pad_leave(previous);
 previous=pad_enter(7,0,1);pad_leave(previous);assert(s->event_write==2&&s->events[1].kind==4&&s->events[1].source==263);
 packet[0]=7;assert(note(s->program,0,0,s->instrument,packet,0));assert(s->events[2].source==7); /* Sequence ownership stays separate. */
 s->generation=2;packet[0]=255;previous=pad_enter(11,0,0);assert(note(s->program,0,0,s->instrument,packet,0));pad_leave(previous);assert(s->events[3].source==267&&s->events[3].generation==2);
 /* Native deferred direct packets have no physical TLS scope. */
 assert(!pad_owner);packet[0]=200;assert(note(s->program,0,0,s->instrument,packet,0));assert(s->events[4].source==200);
 off(s->program+0xdf0,0,0,0,200);assert(s->events[5].kind==2&&s->events[5].source==200);
 static uint8_t drum[0x3000];static uintptr_t instruments[256];instruments[0]=s->instrument;s->program=(uintptr_t)drum;Q(drum,0)=host.base+0x6ec6860;Q(drum,0x2808)=(uintptr_t)instruments;Q(drum,0x2810)=(uintptr_t)(instruments+256);I(drum,0x14a8+4*3)=0;
 trampoline(0x286fcf0,native_live);packet[0]=3;packet[12]|=4;packet[16]=64;pc_synth_live_input((uintptr_t)drum+0xdf0,0,0,0,packet);assert(native_live_calls==1&&s->events[6].source==3&&s->events[6].filter==320);
 packet[12]&=~4u;duplicate_native=1;instruments[200]=s->instrument;packet[0]=200;pc_synth_live_input((uintptr_t)drum+0xdf0,0,0,0,packet);assert(native_live_calls==2&&s->events[7].source==200);
 s->audio_generation=2;s->audio_engine=7;s->dsp.held=gates;s->dsp.off=gate_off;process_events(s);assert(audio_attacks==1&&s->refs[60]==3&&s->held_keys==1&&s->event_read==s->event_write);
 forget(s,&s->held[2]);assert(s->filter_lock==320);
 memset(s->held,0,sizeof s->held);memset(s->refs,0,sizeof s->refs);
 memset(s->native_sources,0,sizeof s->native_sources);s->held_keys=0;s->audio_engine=PC_MS_ENGINE;
 /* Both chords contain C4. Release of either source must only release
  * that chord, even when its numeric pad ID overlaps a deferred event. */
 const unsigned physical=256+72,deferred=200;
 for(unsigned k=0;k<3;k++){
  assert(event_push(s,1,physical,0,60+4*k,100,0));
  assert(event_push(s,1,deferred,0,60+3*k,100,0));
 }
 process_events(s);
 assert(ms_ons==6&&s->refs[60]==2);
 assert(event_push(s,4,physical,0,0,0,0));process_events(s);
 assert(ms_offs==3&&ms_off[0]==ms_on[0]&&ms_off[1]==ms_on[2]&&ms_off[2]==ms_on[4]);
 assert(s->refs[60]==1&&s->held_keys==3);
 off(s->program+0xdf0,0,0,0,deferred);process_events(s);
 assert(ms_offs==6&&ms_off[3]==ms_on[1]&&ms_off[4]==ms_on[3]&&ms_off[5]==ms_on[5]);
 assert(!s->held_keys);
 assert(event_push(s,1,deferred,0,60,100,0));process_events(s);
 stop(s->program+0xdf0,0,0,0);process_events(s);
 assert(!s->held_keys&&ms_offs==7&&ms_off[6]==ms_on[6]);
 /* Clear a sounding pad with queued work, then reload the same
  * preset on that pad. A fresh attack must be audible immediately. */
 static uint8_t router[0x60],other[0x2400],unrelated[0x2400];
 F(router,0x50)=44100;
 uint8_t *pads[]={instrument,other,unrelated};
 for(unsigned n=0;n<3;n++){
  Q(pads[n],0)=host.base+0x6ec3ca0;Q(pads[n],0x2310)=(uintptr_t)drum;Q(pads[n],0x638)=(uintptr_t)router;
  if(n)for(unsigned j=0;j<NOTE_QUEUE;j++)host.slots[n].events[j].sequence=j;
 }
 s->engine=PC_MS_ENGINE;s->multisample=1;contexts=1;host.debug->assigned=1;
 uint8_t patch[512]={0},another[512];
 memcpy(patch,"MPCMUL010123456789abcdefTest",28);memcpy(s->patch,patch,512);
 memcpy(another,patch,512);another[8]='f';
 assert(event_push(s,1,deferred,0,60,100,0));process_events(s);
 assert(event_push(s,1,physical,0,62,100,0));
 s->release_pending=1;s->late_off[16][0]=1;physical_slots[72]=1;
 unsigned old_generation=s->generation;
 pc_ms_clear_queued(old_generation<<8);
 assert(!s->instrument&&!s->multisample&&!s->held_keys&&!s->pending_on&&!s->release_pending);
 assert(!physical_slots[72]&&freed==1&&stopped==1&&debug.assigned==0);
 assert(pc_ms_assign((uintptr_t)drum,(uintptr_t)instrument,patch));
 pc_ms_clear_queued(old_generation<<8);assert(pc_find((uintptr_t)instrument)==0);
 assert(event_push(s,1,physical,0,60,100,0));drain(s);
 assert(ms_ons==9&&s->refs[60]==1&&s->multisample);
 assert(pc_ms_assign((uintptr_t)drum,(uintptr_t)other,patch));
 assert(pc_ms_assign((uintptr_t)drum,(uintptr_t)unrelated,another));
 pc_ms_unassign_preset((const char*)patch+8);
 assert(pc_find((uintptr_t)instrument)<0&&pc_find((uintptr_t)other)<0&&pc_find((uintptr_t)unrelated)==2);
 assert(debug.assigned==1&&freed==3);
 // Dispatch a real FM6 command and attacks through the host queue.
 s->instrument=(uintptr_t)instrument;s->program=(uintptr_t)drum;s->engine=4;
 Command fm={.kind=1,.index=4,.reserved=++s->generation};
 memcpy(fm.patch,"MPCEXT01",8);fm.patch[8]=4;memcpy(fm.patch+20,"DX7RAW01",8);memcpy(fm.patch+64,FM6_INIT,128);
 unsigned fm_crc=pc_syx_crc(fm.patch,508);memcpy(fm.patch+508,&fm_crc,4);
 pc_push(s,&fm);
 for(unsigned n=0;n<12;n++)assert(event_push(s,1,n,0,60+n,100,0));
 drain(s);
 assert(s->audio_engine==4&&pc_fm6_voices(0)==12&&s->held_keys==12&&audio_attacks==1);
 assert(event_push(s,2,0,0,0,0,0));drain(s);
 assert(s->held_keys==11&&pc_fm6_voices(0)==12); // release stays in FM6
 puts("Host pad and sequencer events reach FM6 without legacy DSP attacks");
 puts("Clear Pad releases Multisamples state, same-pad reload attacks, and Delete detaches matching pads only");
 puts("independent Multisamples chord ownership and note-off passed");
 puts("live and 16-Levels direct triggers, release ownership and new-generation admission passed");
}
