#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <dlfcn.h>
static void *decoder;
#define DJ_RESOLVE(name) (decoder ? dlsym(decoder,name) : NULL)
#include "../src/dj_analysis.c"

static unsigned reads;
static double fixture_offset=.18;
static long check(long result){return result<0?-errno:result;}
long pc_sys(long call,long a,long b,long c,long d,long e,long f){
 switch(call){
 case 56:return check(openat(a,(const char*)b,O_RDONLY));
 case 57:return check(close(a));
 case 62:return check(lseek(a,b,c));
 case 67:reads++;return check(pread(a,(void*)b,c,d));
 case 215:return check(munmap((void*)a,b));
 case 222:return check((long)mmap((void*)a,b,c,d,e,f));
 default:assert(0);return -1;
 }
}
static void put32(FILE*f,unsigned value){
 for(unsigned n=0;n<4;n++)fputc((value>>(8*n))&255,f);
}
static void fixture(const char *path,unsigned rate,double bpm,int accents,int drift){
 FILE *f=fopen(path,"wb");assert(f);
 unsigned frames=48*rate,bytes=4*frames;
 fwrite("RIFF",1,4,f);put32(f,36+bytes);fwrite("WAVEfmt ",1,8,f);
 put32(f,16);put32(f,0x20001);put32(f,rate);put32(f,4*rate);put32(f,0x100004);
 fwrite("data",1,4,f);put32(f,bytes);
 double first=(drift==2?12:0)+fixture_offset,beat_at=first,period=bpm?60/bpm:0;
 unsigned index=0;
 for(unsigned n=0;n<frames;n++){
  double time=(double)n/rate;
  while(period&&time>=beat_at+period){
   beat_at+=period;index++;
   if(drift==1&&index==40)period*=.8;
  }
  int16_t sample=0;
  if(period&&time>=first&&time-beat_at<.018)
   sample=(n&1?-1:1)*(accents&&index%4==0?25000:12000);
  fputc(sample&255,f);fputc((unsigned)(uint16_t)sample>>8,f);
  fputc(0,f);fputc(0,f);
 }
 assert(fclose(f)==0);
}
static void structured_fixture(const char *path,double bpm){
 FILE*f=fopen(path,"wb");assert(f);unsigned rate=44100,frames=96*rate;
 fwrite("RIFF",1,4,f);put32(f,36+4*frames);fwrite("WAVEfmt ",1,8,f);
 put32(f,16);put32(f,0x20001);put32(f,rate);put32(f,4*rate);put32(f,0x100004);fwrite("data",1,4,f);put32(f,4*frames);
 double period=60/bpm,origin=4.347;unsigned noise=1234;
 for(unsigned n=0;n<frames;n++){
  double t=(double)n/rate,relative=t-origin,phase=fmod(relative,period);if(phase<0)phase+=period;
  int beat=(int)floor(relative/period);double value=.035*sin(6.283185307*220*t);
  noise=noise*1664525+1013904223;double random=((noise>>8)/16777216.0-.5);
  if(relative>=0&&!(t>=32&&t<40)){
   if(phase<.10)value+=.42*sin(6.283185307*(62*phase-80*phase*phase))*exp(-phase*42);
   if((beat&1)&&phase<.065)value+=.17*random*exp(-phase*55);
   double hat=fmod(relative,period*.5);if(hat<.025)value+=.09*random*exp(-hat*150);
   if(beat%16==15){double fill=fmod(relative,period*.25);if(fill<.028)value+=.13*random*exp(-fill*80);}
  }
  int sample=(int)(value*32767);fputc(sample&255,f);fputc((sample>>8)&255,f);fputc(sample&255,f);fputc((sample>>8)&255,f);
 }
 assert(!fclose(f));
}
static unsigned progress_events,last_progress;
static DjProgress *checking_progress;
static void progress_notice(void){assert(checking_progress->value>=last_progress);last_progress=checking_progress->value;progress_events++;}
int main(void){
 char name[]="/tmp/maia-dj-wav-XXXXXX";
 int fd=mkstemp(name);assert(fd>=0);close(fd);
 DjAnalysis track;
 assert(pc_dj_analyse(name,&track)==DJ_FORMAT_ERROR);
 const unsigned rates[]={44100,48000,44100},bpm[]={120,125,141};
 for(unsigned i=0;i<3;i++){
  fixture(name,rates[i],bpm[i],i!=1,0);
  assert(pc_dj_analyse(name,&track)==DJ_OK);
  assert(track.frames==48u*rates[i]&&track.rate==rates[i]);
  assert(track.beat_frames>0);
  assert(fabs(track.rate*60/track.beat_frames-bpm[i])<.20);
  assert(fabs(track.first_beat/track.rate-.18)<.020);
  assert(track.downbeat==0);
  unsigned peak=0;for(unsigned n=0;n<DJ_PEAKS;n++)if(track.peak[n]>peak)peak=track.peak[n];
  assert(peak>=90);
 }
 assert(pc_dj_filename_bpm("/120/beat 170.wav")==170);
 assert(pc_dj_filename_bpm("/song name 90.mp3")==90);
 assert(pc_dj_filename_bpm("/2026_track_130_BPM_take_94.WAV")==130);
 assert(pc_dj_filename_bpm("/BPM127.5 edit.mp3")==127.5);
 assert(pc_dj_filename_bpm("/2026_take_v170_44.1.wav")==0);
 fixture(name,44100,193,1,2);
 assert(pc_dj_analyse(name,&track)==DJ_OK);
 printf("193 BPM fixture: %.5f BPM, first %.5f s\n",track.rate*60/track.beat_frames,track.first_beat/track.rate);fflush(stdout);
 assert(fmin(fabs(track.rate*60/track.beat_frames-193),fabs(track.rate*120/track.beat_frames-193))<.25);
 assert(fabs(track.first_beat/track.rate-12.18)<.020);
 fixture(name,44100,0,0,0);
 char titled[128];snprintf(titled,sizeof titled,"%s beat 170.wav",name);
 assert(!link(name,titled));
 assert(pc_dj_analyse(titled,&track)==DJ_OK&&track.tagged_bpm==170&&!track.beat_frames);
 fixture(name,44100,170,1,2);
 assert(pc_dj_analyse(titled,&track)==DJ_OK&&track.beat_frames==44100*60.0/170);
 assert(fabs(track.first_beat/track.rate-12.18)<.020&&track.downbeat==0);
 fixture_offset=.1837;
 fixture(name,48000,170,1,0);
 assert(pc_dj_analyse(titled,&track)==DJ_OK&&track.beat_frames==48000*60.0/170);
 printf("tagged exact phase: %.5f s\n",track.first_beat/track.rate);fflush(stdout);
 assert(fabs(track.first_beat/track.rate-.1837)<.020);
 fixture_offset=.18;
 assert(!unlink(titled));
 fixture(name,44100,0,0,0);
 assert(pc_dj_analyse(name,&track)==DJ_OK&&!track.beat_frames&&track.downbeat==-1);
 fixture(name,44100,125,1,1);
 assert(pc_dj_analyse(name,&track)==DJ_OK&&track.beat_frames>0);
 structured_fixture(name,127);
 DjProgress progress={.notify=progress_notice};checking_progress=&progress;
 assert(pc_dj_analyse_progress(name,name,&track,&progress)==DJ_OK);
 double detected=track.rate*60/track.beat_frames;
 printf("Structured fixture: %.5f BPM, phase %.5f, first bar %.5f, %u progress notifications\n",detected,track.first_beat/track.rate,track.first_downbeat/track.rate,progress_events);
 assert(track.downbeat_valid&&fabs(track.first_downbeat/track.rate-4.347)<.025);
 assert(fabs(detected-127)<.3&&progress.value==1000&&progress_events>50);
 double grid_error=fmod(fabs(track.first_beat/track.rate-4.347),60.0/127);
 assert(fmin(grid_error,60.0/127-grid_error)<.025);
 DjAnalysis first_pass=track;
 for(unsigned pass=0;pass<2;pass++){
  memset(&track,0x5a,sizeof track);
  assert(pc_dj_analyse(name,&track)==DJ_OK&&memcmp(&first_pass,&track,sizeof track)==0);
 }
 assert(pc_dj_analyse_named(name,"live_set_127_song.wav",&track)==DJ_OK&&track.tagged_bpm==127&&track.beat_frames==44100*60.0/127);
 assert(pc_dj_filename_bpm("song_170_extra.wav")==170&&pc_dj_filename_bpm("song170.wav")==0&&pc_dj_filename_bpm("song-170.wav")==0);
 puts("Full-song Mixxx/QM handles intro, break, fills, tonal backing, fixed filename BPM and monotonic progress");
 assert(!truncate(name,100));
 assert(pc_dj_analyse(name,&track)==DJ_FORMAT_ERROR);
 float onsets[16000]={0},offsets[16000]={0};
 for(unsigned n=13037,i=0;n<16000;n+=50,i++){
  onsets[n]=i%4==0?1.f:.4f;offsets[n]=.7f;
 }
 DjAnalysis late={.rate=44100,.tagged_bpm=120,.beat_frames=22050,.first_beat=37.7*441,.downbeat=-1};
 beatgrid(onsets,offsets,onsets,16000,441,&late);
 assert(late.beat_frames==22050&&fabs(late.first_beat-13037.7*441)<1&&late.downbeat==0);
 float pickup[4000]={0},pickup_offsets[4000]={0},low[4000]={0};
 for(unsigned i=0;i<6;i++)pickup[37+25*i]=.35f;
 for(unsigned i=0;237+50*i<4000;i++){
  unsigned at=237+50*i;pickup[at]=i%4==0?1.f:.45f;low[at]=i%4==0?1.f:.08f;
 }
 DjAnalysis fill={.rate=44100,.tagged_bpm=120,.beat_frames=22050,.first_beat=37*441,.downbeat=-1};
 beatgrid(pickup,pickup_offsets,low,4000,441,&fill);
 assert(fill.beat_frames==22050&&fill.transient_valid);
 assert(fabs(fill.first_transient-37*441)<1);
 assert(fabs(fill.first_beat-37*441)<1&&fill.downbeat==0);
 assert(fill.downbeat_valid&&fabs(fill.first_downbeat-237*441)<1);
 /* Shift the fill to off-beats: the first transient remains visible while
  * regular beats and the bar-one accent keep the later established phase. */
 memset(pickup,0,sizeof pickup);memset(low,0,sizeof low);
 for(unsigned i=0;i<5;i++)pickup[62+25*i]=.35f;
 for(unsigned i=0;237+50*i<4000;i++){
  unsigned at=237+50*i;pickup[at]=i%4==0?1.f:.45f;low[at]=i%4==0?1.f:.08f;
 }
 fill=(DjAnalysis){.rate=44100,.tagged_bpm=120,.beat_frames=22050,.first_beat=37*441,.downbeat=-1};
 beatgrid(pickup,pickup_offsets,low,4000,441,&fill);
 assert(fill.transient_valid&&fabs(fill.first_transient-62*441)<1);
 assert(fabs(fill.first_beat-87*441)<1&&fill.downbeat==3);
 assert(fill.downbeat_valid&&fabs(fill.first_downbeat-237*441)<1);
 /* The loudest initial hit is an isolated pickup, followed by silence.
  * Repeated kick accents, not the outlier, establish bar one. */
 memset(pickup,0,sizeof pickup);memset(low,0,sizeof low);
 pickup[37]=8;low[37]=5;
 for(unsigned i=0;237+50*i<4000;i++){
  unsigned at=237+50*i;pickup[at]=i%4==0?1.f:.55f;low[at]=i%4==0?1.f:.08f;
 }
 fill=(DjAnalysis){.rate=44100,.tagged_bpm=120,.beat_frames=22050,.first_beat=37*441,.downbeat=-1};
 beatgrid(pickup,pickup_offsets,low,4000,441,&fill);
 assert(fill.downbeat_valid&&fabs(fill.first_downbeat-237*441)<1);
 /* Snare peaks can exceed the kicks. Low-frequency attacks and repeated
  * bar accents still choose the kick on one. */
 memset(pickup,0,sizeof pickup);memset(low,0,sizeof low);
 for(unsigned i=0;237+50*i<4000;i++){
  unsigned at=237+50*i;pickup[at]=(i&1)?2.f:1.f;
  low[at]=i%4==0?1.f:(i%4==2?.35f:.02f);
 }
 fill=(DjAnalysis){.rate=44100,.tagged_bpm=120,.beat_frames=22050,.first_beat=37*441,.downbeat=-1};
 beatgrid(pickup,pickup_offsets,low,4000,441,&fill);
 assert(fill.downbeat_valid&&fabs(fill.first_downbeat-237*441)<1);
 /* Equal four-on-the-floor kicks use the first sustained kick run after
  * weak fill hits, without imposing an arbitrary phase from the seed. */
 memset(pickup,0,sizeof pickup);memset(low,0,sizeof low);
 for(unsigned i=0;i<5;i++)pickup[62+25*i]=.3f;
 for(unsigned i=0;237+50*i<4000;i++){pickup[237+50*i]=1;low[237+50*i]=1;}
 fill=(DjAnalysis){.rate=44100,.tagged_bpm=120,.beat_frames=22050,.first_beat=37*441,.downbeat=-1};
 beatgrid(pickup,pickup_offsets,low,4000,441,&fill);
 assert(fill.downbeat_valid&&fabs(fill.first_downbeat-237*441)<1);
 /* A normal opening kick is bar one even if later beat-three kicks
  * are louder: the complete track's accent vote must not rotate it. */
 memset(pickup,0,sizeof pickup);memset(low,0,sizeof low);
 for(unsigned i=0;37+50*i<4000;i++){unsigned at=37+50*i;pickup[at]=low[at]=i%4==2?1.f:.65f;}
 fill=(DjAnalysis){.rate=44100,.beat_frames=22050,.first_beat=38.2*441,.downbeat=-1};
 beatgrid(pickup,pickup_offsets,low,4000,441,&fill);
 assert(fill.downbeat_valid&&fill.downbeat==0&&fabs(fill.first_downbeat-37*441)<1);
 /* QM follows hats on the offbeat. A recurring kick lattice wins even
  * when the hats are louder; a lead-in snare remains a pickup. */
 memset(pickup,0,sizeof pickup);memset(low,0,sizeof low);
 pickup[12]=.8f;
 for(unsigned i=0;237+50*i+25<4000;i++){
  unsigned at=237+50*i;pickup[at]=.55f;low[at]=i%4==0?.85f:.5f;pickup[at+25]=1.f;
 }
 fill=(DjAnalysis){.rate=44100,.beat_frames=22050,.first_beat=12*441,.downbeat=-1};
 beatgrid(pickup,pickup_offsets,low,4000,441,&fill);
 assert(fill.downbeat_valid&&fabs(fill.first_downbeat-237*441)<1);
 puts("Downbeat tests: pickups, isolated loud hits, louder snares and sustained four-on-the-floor kicks passed");
 decoder=dlopen("libmpg123.so.0",RTLD_NOW);
 if(decoder&&system("command -v ffmpeg >/dev/null")==0){
  char mp3[128],command[512];
  snprintf(mp3,sizeof mp3,"%s.MP3",name);
  fixture(name,48000,125,1,0);
  snprintf(command,sizeof command,"ffmpeg -hide_banner -loglevel error -i %s -codec:a libmp3lame %s",name,mp3);
  assert(system(command)==0);
  assert(pc_dj_analyse(mp3,&track)==DJ_OK);
  assert(track.rate==48000&&track.frames==48u*48000);
  assert(fabs(track.rate*60/track.beat_frames-125)<.20);
  DjReader reader={0};
  assert(pc_dj_reader_open(&reader,mp3)==DJ_OK);
  float l,r;
  assert(pc_dj_reader_frame(&reader,72000,&l,&r));
  assert(pc_dj_reader_frame(&reader,8641,&l,&r));
  unsigned boundary=sizeof reader.bytes/reader.format.block;
  assert(pc_dj_reader_frame(&reader,0,&l,&r));
  assert(pc_dj_reader_frame(&reader,boundary-1,&l,&r));
  assert(pc_dj_reader_frame(&reader,boundary,&l,&r));
  unsigned before=reads;
  assert(pc_dj_reader_frame(&reader,boundary-1,&l,&r));
  assert(reads==before&&reader.base==boundary);
  pc_dj_reader_close(&reader);
  assert(!unlink(mp3));
  dlclose(decoder);
  puts("48 kHz MP3 duration, beatgrid and forward/backward seeks passed");
 }
 assert(!unlink(name));
 assert(pc_dj_analyse(name,&track)==DJ_READ_ERROR);
 assert(dj_mixxx_beat_at_or_after(124,100,20)==2);
 assert(dj_mixxx_beat_at_or_after(120,100,20)==1);
 assert(dj_mixxx_beat_at_or_after(79,100,20)==-1);
 puts("DJ filename BPM with measured phase, delayed first beats, 193 BPM, WAV peaks, silence, drift and corrupt input passed");
}
