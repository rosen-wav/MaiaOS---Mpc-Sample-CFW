#!/bin/sh
set -eu
out=$1
flags=${DJ_QM_FLAGS:--O2}
mkdir -p "$out"
for file in dsp/onsets/DetectionFunction.cpp dsp/phasevocoder/PhaseVocoder.cpp dsp/transforms/FFT.cpp dsp/tempotracking/TempoTrackV2.cpp maths/MathUtilities.cpp ext/kissfft/kiss_fft.c ext/kissfft/tools/kiss_fftr.c; do
 obj=$(basename "$file").o
 c++ -std=c++17 $flags -ffunction-sections -fdata-sections -Dkiss_fft_scalar=double -Ivendor/qm-dsp -c "vendor/qm-dsp/$file" -o "$out/$obj"
done
for file in dj_qm mixxx_beatutils; do
 c++ -std=c++17 $flags -ffunction-sections -fdata-sections -Ivendor/qm-dsp -Isrc -c "src/$file.cpp" -o "$out/$file.o"
done
ar rcs "$out/libdj-qm.a" "$out"/*.o
