#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include "../src/synth_filter.c"
Host host;
int pc_find(uintptr_t i){for(unsigned n=0;n<PC_SLOTS;n++)if(i&&host.slots[n].instrument==i)return n;return -1;}
static void type(uintptr_t p,unsigned n){I(p,0x50)=n;}
static void value(uintptr_t p,float f){F(p,0x50)=f;}
static void trampoline(unsigned offset,void*target){uint8_t*p=(void*)(host.base+offset);p[0]=0x48;p[1]=0xb8;memcpy(p+2,&target,8);p[10]=0xff;p[11]=0xe0;}
static unsigned native_page,browser;
static int native_view(MpcPanelView*v){
 memset(v,0,sizeof*v);v->page_count=3;v->page_index=native_page;v->browser=browser;
 for(unsigned k=0;k<3;k++)v->slots[k].index=native_page==2?-1:k;
 if(native_page==0){memcpy(v->slots[0].label,"Cutoff",7);memcpy(v->slots[1].label,"Resonance",10);memcpy(v->slots[2].label,"Type",5);}
 return 1;
}
static int native_encoder(int n){if(browser)return 1;int next=((int)native_page+n)%3;if(next<0)next+=3;native_page=next;return 1;}
int main(){
 host.base=(uintptr_t)mmap(0,0x3000000,7,MAP_ANONYMOUS|MAP_PRIVATE,-1,0);assert(host.base!=(uintptr_t)MAP_FAILED);
 trampoline(0x282a4a0,type);trampoline(0x13bb930,value);
 uintptr_t i=(uintptr_t)calloc(1,0x2400),s=(uintptr_t)calloc(1,0x600);Q(i,0x2340)=s;
 host.slots[0].instrument=i;host.slots[0].generation=1;
 I(s,0x420)=0;F(s,0x498)=1;
 pc_synth_filter_knob(i,1,8192);assert(I(s,0x420)==2&&F(s,0x498)>.499&&F(s,0x498)<.501);
 pc_synth_filter_knob(i,2,10000);assert(pc_synth_filter_position(i,2)==10000);
 pc_synth_filter_knob(i,0,10000);assert(I(s,0x420)==17);
 assert(pc_synth_fader_default(i));pc_synth_fader_custom(i);assert(!pc_synth_fader_default(i));pc_synth_fader_reset(i);assert(pc_synth_fader_default(i));assert(!pc_synth_fader_default(123));
 for(unsigned engine=0;engine<=9;engine++){
  if(engine==3||engine==5||engine==6)continue;
  host.slots[0].engine=engine;host.slots[0].generation++;native_page=0;
  host.mirror.view=native_view;host.mirror.encoder=native_encoder;pc_synth_filter_bind(0);
  MpcPanelView v;host.mirror.view(&v);assert(v.page_count==(engine==4?3:4));
  host.mirror.encoder((int)v.page_count-2);host.mirror.view(&v);
  assert(pc_synth_filter_page(&v)&&!strcmp(v.slots[0].label,"Type")&&!strcmp(v.slots[1].label,"Cutoff")&&!strcmp(v.slots[2].label,"Resonance"));
  host.mirror.encoder(1);host.mirror.view(&v);assert(v.page_index+1==v.page_count&&v.slots[0].index<0);
  host.mirror.encoder(-1);host.mirror.view(&v);assert(pc_synth_filter_page(&v));
  browser=1;host.mirror.encoder(1);host.mirror.view(&v);assert(v.browser);browser=0;
 }
 puts("All engine stock-filter pages precede output; Dexed legacy page removed; native model, preset browser and synth-only fader defaults passed");
}
