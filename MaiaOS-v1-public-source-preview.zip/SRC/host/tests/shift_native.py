"""Exercise the actual ARM64 physical callback with a modal browser open."""
import argparse,struct
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_CODE
from unicorn.arm64_const import *
p=argparse.ArgumentParser();p.add_argument('--host',required=True);p.add_argument('--expect',type=int,default=0);args=p.parse_args()
u=Uc(UC_ARCH_ARM64,UC_MODE_ARM);u.mem_map(0,0x7800000);u.mem_map(0x10000000,0x1000000);u.mem_map(0x20000000,0x100000)
e=ELFFile(open(args.host,'rb'));base=0x10000000
for s in e.iter_segments():
 if s['p_type']=='PT_LOAD':u.mem_write(base+s['p_vaddr'],s.data())
for s in e.get_section_by_name('.rela.dyn').iter_relocations():
 if s['r_info_type']==1027:u.mem_write(base+s['r_offset'],struct.pack('<Q',base+s['r_addend']))
symbols={s.name:base+s['st_value'] for s in e.get_section_by_name('.symtab').iter_symbols() if s['st_value']}
mock={symbols['pc_groove_active']:1}
for name in ['pc_bounce_modal','pc_audio_page','pc_audio_config_scope','pc_padfx_visible']:
 mock[symbols[name]]=0
u.mem_write(0x72a4cb0+0x20,struct.pack('<Q',0x20010000));u.mem_write(0x20010000+0x78,struct.pack('<Q',0x20020000))
def hook(uc,address,size,data):
 if address==0x20000000:uc.emu_stop();return
 if address in mock:
  uc.reg_write(UC_ARM64_REG_X0,mock[address]);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_LR))
u.hook_add(UC_HOOK_CODE,hook)
for offset in [0x2250,0x22a0]:
 for down in [1,0,1,0]:
  u.reg_write(UC_ARM64_REG_SP,0x200ff000);u.reg_write(UC_ARM64_REG_LR,0x20000000);u.reg_write(UC_ARM64_REG_X0,0x20020000+offset);u.reg_write(UC_ARM64_REG_X1,down)
  u.emu_start(symbols['pc_ui_physical'],0x20000004,count=100000)
  result=u.reg_read(UC_ARM64_REG_X0);assert result==args.expect,(hex(offset),down,result)
print('r68 modifier capture reproduced' if args.expect else 'Shift press/release reach native subscribers during browser, both physical properties passed')
