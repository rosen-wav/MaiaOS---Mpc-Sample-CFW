#define _GNU_SOURCE
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>
#include "../src/multisamples.c"

Host host;
static unsigned loaded_presets,deleted_presets;
void pc_ms_unassign_preset(const char *id){assert(!memcmp(id,ms.id,16));deleted_presets++;}
int pc_find(uintptr_t instrument){return instrument&&instrument==host.slots[0].instrument?0:-1;}
int pc_valid(uintptr_t program,uintptr_t instrument){return program&&instrument;}
void pc_synth_filter_knob(uintptr_t i,unsigned k,unsigned p){(void)i;(void)k;(void)p;}
void pc_synth_fader_reset(uintptr_t i){(void)i;}
int pc_mix_set_volume(uintptr_t p,uintptr_t i,int volume){(void)p;(void)i;(void)volume;return 1;}
int pc_sc_set(uintptr_t p,uintptr_t i,unsigned role){(void)p;(void)i;(void)role;return 1;}
unsigned pc_bounce_busy(void){return 0;}
int pc_ms_assign(uintptr_t program,uintptr_t instrument,const uint8_t*patch){
 assert(program==ms.program&&instrument==ms.instrument&&!memcmp(patch+8,ms.id,16));
 assert(!strcmp((const char*)patch+24,"First VST"));loaded_presets++;return 1;
}
static char directory[96];
static int64_t clock_ms;
static unsigned on_count,off_count,notice_count,down,silent;
static int64_t gate_start,gate_end;
static unsigned sequence[MS_COUNT*MS_LAYERS],velocities[MS_COUNT*MS_LAYERS],capture_velocity;
static void notified(uint64_t event){assert(event==117);notice_count++;}
static int sent(void*client,const MsMidiEvent*e){
 (void)client;assert(e->channel==4&&e->dest_client==20&&e->dest_port==1&&e->queue==253);
 if(e->type==6){assert(!down&&on_count<MS_COUNT*MS_LAYERS&&(!off_count||clock_ms-gate_end>=590));sequence[on_count]=e->note;velocities[on_count++]=capture_velocity=e->velocity;down=1;gate_start=clock_ms;}
 else{assert(e->type==7&&down&&clock_ms-gate_start==(int64_t)ms.seconds*1000);down=0;off_count++;gate_end=clock_ms;}
 return 0;
}
int pc_sd_folder(char*out,unsigned cap,const char*suffix){assert(!*suffix);snprintf(out,cap,"%s/",directory);return 1;}
static long sys_result(long n){return n<0?-errno:n;}
long pc_sys(long call,long a,long b,long c,long d,long e,long f){
 switch(call){
 case 17:assert(0);return -1;
 case 34:return sys_result(mkdir((const char*)b,c));
 case 35:return sys_result(unlink((const char*)b));
 case 56:
  if(c&0x4000){assert(!(c&0x10000));c=(c&~0x4000)|O_DIRECTORY;}
  return sys_result(openat(a,(const char*)b,c,d));
 case 57:return sys_result(close(a));
 case 61:return sys_result(syscall(SYS_getdents64,a,(void*)b,c));
 case 62:return sys_result(lseek(a,b,c));
 case 64:return sys_result(write(a,(const void*)b,c));
 case 67:return sys_result(pread(a,(void*)b,c,d));
 case 68:return sys_result(pwrite(a,(const void*)b,c,d));
 case 82:return sys_result(fsync(a));
 case 101:{
  static float l[177],r[177];uintptr_t channels[2]={(uintptr_t)l,(uintptr_t)r};
  clock_ms+=4;
  float level=silent?0:down?.2f*capture_velocity/127:clock_ms-gate_end<=240?.03f:0.f;
  for(unsigned n=0;n<176;n++){l[n]=level;r[n]=level*.5f;}
  pc_ms_input(1,(uintptr_t)channels,176,0);
  return 0;
 }
 case 113:((int64_t*)b)[0]=clock_ms/1000;((int64_t*)b)[1]=(clock_ms%1000)*1000000;return 0;
 case 215:return sys_result(munmap((void*)a,b));
 case 222:return sys_result((long)mmap((void*)a,b,c,d,e,f));
 case 233:return 0;
 case 276:assert(e==1&&access((const char*)d,F_OK));return sys_result(rename((const char*)b,(const char*)d));
 default:assert(0);return -1;
 }
}
static unsigned fake_client,fake_port,fake_gadget;
static int fake_alloc(void**out){*out=(void*)1;return 0;}
static void fake_free(void*p){(void)p;}
static void set_client(void*p,int value){(void)p;(void)value;fake_client=0;}
static void set_port_client(void*p,int value){(void)p;(void)value;}
static void set_port(void*p,int value){(void)p;(void)value;fake_port=0;}
static int next_client(void*s,void*p){(void)s;(void)p;return fake_client++<1+fake_gadget?0:-1;}
static int next_port(void*s,void*p){(void)s;(void)p;return fake_port++==0?0:-1;}
static int client_id(void*p){(void)p;return fake_client==1?20:21;}
static int port_id(void*p){(void)p;return 0;}
static unsigned caps(void*p){(void)p;return 2;}
static const char*client_name(void*p){(void)p;return fake_client==1?"External":"f_midi";}
static const char*port_name(void*p){(void)p;return fake_client==1?"DIN":"USB MIDI";}
static void trampoline(uintptr_t offset,void*fn){
 uint8_t*p=(uint8_t*)(host.base+offset);p[0]=0x48;p[1]=0xb8;memcpy(p+2,&fn,8);p[10]=0xff;p[11]=0xe0;
}
static unsigned font_pixels,font_partial;
static void font_rect(void *ignored,int x,int y,int w,int h,unsigned colour){
 (void)ignored;
 assert(x>=3&&x+w<=20&&y>=2&&y+h<=38&&h==1);
 font_pixels+=w; if((colour>>24)<255)font_partial+=w;
}
int main(void){
 EiCanvas font_canvas={0,font_rect,320,240};
 for(unsigned n=0;n<sizeof ms_fonts/sizeof *ms_fonts;n++){
  font_pixels=font_partial=0;
  ms_font_draw(&font_canvas,3,2,"Backspace",17,&ms_fonts[n],MPC_THEME_TEXT);
  assert(font_pixels>30&&font_partial>10);
 }
 for(unsigned note=0;note<128;note++)assert(pc_ms_zone(note)<9);
 assert(pc_ms_zone(36)==0&&pc_ms_zone(39)==0&&pc_ms_zone(40)==1&&pc_ms_zone(46)==1&&pc_ms_zone(47)==2);
 assert(pc_ms_zone(82)==7&&pc_ms_zone(83)==8&&pc_ms_zone(84)==8);
 strcpy(directory,"/tmp/maia-multisamples-XXXXXX");assert(mkdtemp(directory));
 char dir[MS_PATH];assert(root_path(dir)&&!mkdir(dir,0700));
 host.base=(uintptr_t)mmap(0,0x7400000,7,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(host.base!=(uintptr_t)MAP_FAILED);
 trampoline(0x6d43500,notified);
 midi.send=sent;ms.destination=(MsPort){20,1};ms.channel=4;
 strcpy(ms.id,"0000000000000123");
 assert(preset_path(ms.part,ms.id,1)&&preset_path(ms.final,ms.id,0));
 ms.pcm=mmap(0,MS_LIMIT*8,3,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(ms.pcm!=MAP_FAILED);
 record_worker(0);assert(ms.finished&&ms.success&&on_count==9&&off_count==9&&notice_count==10);
 for(unsigned n=0;n<9;n++)assert(sequence[n]==roots[n]&&velocities[n]==127);
 uint8_t patch[512]={0};memcpy(patch,"MPCMUL01",8);memcpy(patch+8,ms.id,16);
 uintptr_t ctx=pc_ms_load(patch);assert(ctx&1);
 MsPlayer*p=player(ctx);
 for(unsigned n=0;n<9;n++)assert(p->file->zone[n].frames>MS_HOLD+8000);
 pc_ms_on(ctx,36,127,36);pc_ms_on(ctx,40,127,40);
 assert(pc_ms_voices(ctx)==2&&p->voices[0].step==1.0&&p->voices[1].step<1.0&&p->voices[1].zone==1);
 float l[2048],r[2048];pc_ms_render(ctx,l,r,2048);assert(l[0]==0&&l[255]>.39f&&r[255]>.19f);
 assert(pc_ms_on(ctx,36,100,400));
 pc_ms_off(ctx,36);pc_ms_render(ctx,l,r,2048);assert(pc_ms_voices(ctx)==2);
 pc_ms_off(ctx,400);pc_ms_render(ctx,l,r,2048);assert(pc_ms_voices(ctx)==1);
 pc_ms_stop(ctx);pc_ms_render(ctx,l,r,2048);assert(pc_ms_voices(ctx)==0);
 /* A full pool keeps every held and released voice. */
 pc_ms_set(ctx,2,5000);
 for(unsigned n=0;n<PC_MS_VOICES;n++)pc_ms_on(ctx,n%128,127,n);
 pc_ms_render(ctx,l,r,2048);pc_ms_off(ctx,36);
 MsVoice tail=p->voices[36];assert(tail.release==220500);
 pc_ms_on(ctx,36,64,36);
 assert(pc_ms_voices(ctx)==PC_MS_VOICES&&!memcmp(&p->voices[36],&tail,sizeof tail));
 pc_ms_stop(ctx);pc_ms_render(ctx,l,r,2048);assert(!pc_ms_voices(ctx));
 /* Envelope changes apply on the audio owner, and r82 presets default safely. */
 assert(pc_ms_envelope(patch,0)==3&&pc_ms_envelope(patch,1)==100&&pc_ms_envelope(patch,2)==40);
 pc_ms_set(ctx,0,20);pc_ms_set(ctx,1,25);pc_ms_set(ctx,2,20);
 pc_ms_on(ctx,36,127,36);pc_ms_render(ctx,l,r,2048);
 assert(l[0]==0&&l[440]>.024f&&l[440]<.026f&&l[882]>.049f&&l[882]<.051f);
 pc_ms_off(ctx,36);pc_ms_render(ctx,l,r,2048);
 assert(l[0]>.049f&&l[440]>.024f&&l[440]<.026f&&l[882]==0);
 Slot*s=&host.slots[0];s->instrument=1;s->engine=PC_MS_ENGINE;s->generation=4;
 memcpy(s->patch,patch,sizeof s->patch);
 pc_ms_editor_event(1,14,2);
 pc_ms_editor_event(1,13,(1u<<16)|8192);
 assert(pc_ms_envelope(s->patch,0)==3&&pc_ms_envelope(s->patch,1)==50&&pc_ms_envelope(s->patch,2)==40);
 assert(s->pending[0]==2&&s->values[1]==(4ull<<32|50));
 uintptr_t restored=pc_ms_load(s->patch);assert(restored&&player(restored)->envelope[1]==50);
 pc_ms_free(restored);pc_ms_free(ctx);
 scan_presets();assert(ms.presets==1&&!strcmp(ms.preset[0].id,ms.id)&&!strcmp(ms.preset[0].name,"Multisample"));
 memset(ms.name,' ',sizeof ms.name-1);memcpy(ms.name,"First VST",9);
 assert(rename_capture());
 scan_presets();assert(ms.presets==1&&!strcmp(ms.preset[0].name,"First VST"));
 uintptr_t project=(uintptr_t)calloc(1,0xc0);assert(project);
 ms.project=project;ms.program=0x12345678;ms.instrument=0x87654321;ms.screen=MS_BROWSER;
 Q(project,0xb8)=ms.program;Q(host.base+G,0x1d08)=project;
 ms.screen=MS_RENAME;
 memset(ms.name,' ',sizeof ms.name-1);memcpy(ms.name,"First XVST",10);
 ms.cursor=7;
 pc_ms_event(12,1);
 assert(ms.cursor==6&&!memcmp(ms.name,"First VST ",10)&&!ms.name[31]);
 ms.cursor=0;
 pc_ms_event(12,1);
 assert(!ms.cursor&&!memcmp(ms.name,"First VST ",10));
 ms.screen=MS_BROWSER;
 midi.seq=(void*)1;
 midi.client_alloc=midi.port_alloc=fake_alloc;midi.client_free=midi.port_free=fake_free;
 midi.set_client=set_client;midi.set_port_client=set_port_client;midi.set_port=set_port;
 midi.next_client=next_client;midi.next_port=next_port;midi.get_client=client_id;midi.get_port=port_id;
 midi.capability=caps;midi.client_name=client_name;midi.port_name=port_name;
 midi_ports();assert(!ms.destination.client&&midi_out_notice());
 fake_gadget=1;midi_ports();
 assert(ms.destination.client==21&&ms.destination.port==0&&!midi_out_notice());
 ms.screen=MS_SETUP;
 pc_ms_event(13,16383);assert(ms.seconds==10);
 pc_ms_event(13,1u<<16|16383);assert(ms.channel==15);
 for(unsigned n=1;n<=4;n++){
  pc_ms_event(13,2u<<16|((n-1)*4096));assert(ms.layers==n&&ms.destination.client==21);
 }
 pc_ms_event(13,2u<<16|16383);assert(ms.layers==4&&ms.destination.client==21);
 pc_ms_event(13,2u<<16);assert(ms.layers==1);
 ms.screen=MS_BROWSER;
 pc_ms_event(12,3);assert(loaded_presets==1&&ms.screen==MS_CLOSED);
 ms.screen=MS_BROWSER;
 pc_ms_event(12,2);assert(loaded_presets==2&&ms.screen==MS_CLOSED);
 ms.screen=MS_BROWSER;
 pc_ms_event(12,PC_PRESET_ERASE);
 assert(ms.screen==MS_DELETE&&ms.delete_choice==PC_KEEP);
 pc_ms_event(12,3);
 assert(ms.screen==MS_BROWSER&&ms.presets==1&&loaded_presets==2);
 pc_ms_event(12,PC_PRESET_ERASE);
 pc_ms_event(14,1);
 pc_ms_event(12,3);
 assert(ms.screen==MS_BROWSER&&ms.presets==0&&access(ms.final,F_OK));
 assert(!pc_ms_load(patch)&&deleted_presets==1);
 char marker[MS_PATH];
 assert(preset_path(marker,ms.id,2)&&access(marker,F_OK));
 free((void*)project);
 ms.channel=4;ms.destination=(MsPort){20,1};
 on_count=off_count=0;ms.pcm=mmap(0,MS_LIMIT*8,3,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(ms.pcm!=MAP_FAILED);
 record_worker(0);assert(ms.success&&on_count==9&&off_count==9);
 int fd=open(ms.final,O_RDONLY);MsFile long_capture;
 assert(fd>=0&&read_header(fd,&long_capture)&&valid_file(&long_capture));close(fd);
 for(unsigned n=0;n<9;n++)assert(long_capture.zone[n].frames>=10u*MS_RATE);
 fd=open(marker,O_WRONLY|O_CREAT|O_EXCL,0600);assert(fd>=0);close(fd);
 scan_presets();
 assert(ms.presets==0&&access(ms.final,F_OK)&&access(marker,F_OK)&&deleted_presets==2);
 const unsigned bounds[4][4]={{127},{63,127},{42,84,127},{31,63,95,127}};
 for(unsigned count=1;count<=4;count++){
  unsigned first=1;
  for(unsigned layer=0;layer<count;layer++){
   unsigned last=bounds[count-1][layer];
   assert(layer_velocity(count,layer)==last);
   for(unsigned v=first;v<=last;v++)assert(playback_layer(count,v)==layer);
   first=last+1;
  }
 }
 ms.seconds=2;ms.layers=4;on_count=off_count=0;
 ms.pcm=mmap(0,MS_LIMIT*8,3,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(ms.pcm!=MAP_FAILED);
 record_worker(0);
 assert(ms.success&&on_count==36&&off_count==36);
 for(unsigned n=0;n<36;n++)assert(sequence[n]==roots[n/4]&&velocities[n]==bounds[3][n%4]);
 ctx=pc_ms_load(patch);assert(ctx&&file_layers(player(ctx)->file)==4);
 assert(pc_ms_on(ctx,60,63,900)&&player(ctx)->voices[0].zone==17);
 assert(pc_ms_on(ctx,60,64,901)&&player(ctx)->voices[1].zone==18);
 pc_ms_render(ctx,l,r,2048);
 assert(l[255]>.124f&&l[255]<.126f);
 pc_ms_free(ctx);
 resident_bytes=MS_PCM_BUDGET;
 ctx=pc_ms_load(patch);assert(ctx&&!player(ctx)->resident);pc_ms_free(ctx);
 assert(resident_bytes==MS_PCM_BUDGET);resident_bytes=0;
 assert(!unlink(ms.final));
 silent=1;on_count=off_count=0;ms.pcm=mmap(0,MS_LIMIT*8,3,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);
 assert(ms.pcm!=MAP_FAILED);record_worker(0);
 assert(!ms.success&&on_count==1&&off_count==1&&access(ms.final,F_OK)&&access(ms.part,F_OK));
 assert(!rmdir(dir)&&!rmdir(directory));
 puts("MULTISAMPLES C/G zones, 2- and 10-second MIDI gates, f_midi only, K3 layer selection, velocity boundaries and capture, legacy and layered loading, Capture controls, tail capture, save/load, stereo polyphony, first-preset discovery, rename, B2 Backspace, native-size anti-aliasing, B3 and encoder import, Keep, permanent Delete and legacy marker cleanup, envelope, saturation and no-input cleanup passed");
}
