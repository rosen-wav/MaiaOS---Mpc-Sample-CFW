#define _GNU_SOURCE
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include "../src/sample_playback.c"
Host host;static unsigned high,recycled;
int pc_cpu_overloaded(void){return high;}
void pc_diag_add(unsigned field){(void)field;}
static int mutex_stub(uintptr_t p){(void)p;return 0;}
static void native_retire(uintptr_t p,uintptr_t v){(void)p;(void)v;recycled++;}
static void trampoline(uintptr_t offset,void*function){uint8_t*p=(uint8_t*)(host.base+offset);p[0]=0x48;p[1]=0xb8;memcpy(p+2,&function,8);p[10]=0xff;p[11]=0xe0;}
int main(void){host.base=(uintptr_t)mmap(0,0x7300000,7,MAP_PRIVATE|MAP_ANONYMOUS,-1,0);assert(host.base!=(uintptr_t)MAP_FAILED);trampoline(0xb51818,mutex_stub);trampoline(0xb51808,mutex_stub);trampoline(0x2229830,native_retire);
 uintptr_t pool=(uintptr_t)calloc(1,0x200),program=(uintptr_t)calloc(1,0x1300),voice=(uintptr_t)calloc(1,0xa00),slots=(uintptr_t)calloc(128,8),node=(uintptr_t)calloc(1,0x20);Q(program,0)=host.base+DRUM_PROGRAM;Q(pool,0x80)=slots;I(pool,0x8c)=128;Q(slots,0)=voice;Q(voice,0x8f0)=program;I(voice,0x920)=1;Q(pool,0x128)=node;Q(node,0)=pool+0x128;Q(node,0x10)=voice;drum_pool=pool;
 for(high=0;high<2;high++)for(unsigned gate=0;gate<2;gate++){*(uint8_t*)(voice+0x92c)=gate;live[0]=0;PoolScan s={0};assert(scan(pool,&s)&&!s.released&&!s.held);assert(!retire(pool,voice));assert(!recycled);}
 high=0;live[0]=voice;*(uint8_t*)(voice+0x92c)=0;PoolScan s={0};assert(scan(pool,&s)&&s.released==1);assert(!retire(pool,voice)&&!recycled);
 live[0]=voice;*(uint8_t*)(voice+0x92c)=1;assert(!retire(pool,voice));high=1;assert(!retire(pool,voice)&&!recycled);
 bypass_legacy_budget=1;assert(sample_budget(pool,9999)==1);bypass_legacy_budget=0;native_pressure(pool,4,1);assert(!recycled);
 puts("sequence sample gates AND tails remain protected below and above CPU threshold");
}
