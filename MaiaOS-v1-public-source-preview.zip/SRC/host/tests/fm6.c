/* FM6 renders actual More Chords DX7 tones through the Maia SYX path. */
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "../src/fm6.h"
#include "../src/syx.h"
#include "../vendor/more-chords-fm6/felucca_fm6.h"
static float l[128],r[128];
static double play(unsigned owner,unsigned blocks){
 double energy=0;
 for(unsigned b=0;b<blocks;b++){
  pc_fm6_render(owner,l,r,128);
  for(unsigned j=0;j<128;j++){
   assert(isfinite(l[j])&&l[j]==r[j]);energy+=l[j]*l[j];
  }
 }
 return energy;
}
static void make(const uint8_t*vmem,uint8_t *patch){
 PcSyxVoice p={.engine=4,.size=128};memcpy(p.raw,vmem,128);
 assert(pc_syx_make_patch(&p,patch));
}
int main(void){
 unsigned imported=0;uint8_t patch[512];
 make(FM6_INIT,patch);
 assert(pc_fm6_load(0,patch,0)&&pc_fm6_load(1,patch,0));
 assert(!pc_fm6_on(1,60,0)&&!pc_fm6_on(1,128,127));
 for(unsigned i=0;i<18;i++)assert(pc_fm6_on(0,48+i,96));
 assert(pc_fm6_voices(0)==18&&pc_fm6_voices(1)==0&&play(1,2)==0);
 assert(play(0,20)>1);
 for(unsigned i=0;i<18;i++)pc_fm6_off(0,48+i);
 for(unsigned i=0;i<18;i++)assert(pc_fm6_on(0,48+i,96));
 assert(pc_fm6_voices(0)==36&&play(0,3)>1);
 for(unsigned i=0;i<18;i++)pc_fm6_off(0,48+i);
 play(0,1000);assert(pc_fm6_voices(0)==0);
 for(unsigned preset=0;preset<FM6_NFACTORY;preset++){
  uint8_t v[156],syx[163]={240,67,0,0,1,27};PcSyxVoice decoded;
  pc_dx7_unpack(FM6_FACTORY[preset],v);
  // Upstream sanitizes its raw factory slots before presenting a DX7 voice.
  for(unsigned op=0;op<6;op++)for(unsigned k=8;k<=10;k++)if(v[21*op+k]>99)v[21*op+k]=99;
  memcpy(syx+6,v,155);
  unsigned sum=0;for(unsigned i=0;i<155;i++)sum+=v[i];syx[161]=(0u-sum)&127;syx[162]=247;
  assert(pc_syx_parse(syx,sizeof syx,4,&decoded,1)==1);
  imported++;assert(pc_syx_make_patch(&decoded,patch)&&pc_fm6_load(1,patch,0));
  assert(pc_fm6_on(1,60,120));
  assert(play(1,180)>1e-10);
  pc_fm6_off(1,60);
 }
 printf("FM6: %u/%u supplied tones passed the SYX-to-audio path\n",imported,FM6_NFACTORY);
 assert(imported==FM6_NFACTORY);
 make(FM6_INIT,patch);assert(pc_fm6_load(0,patch,0)&&pc_fm6_on(0,60,127));
 play(0,20);patch[64+14+17*5]=0;
 unsigned crc=pc_syx_crc(patch,508);memcpy(patch+508,&crc,4);
 assert(pc_fm6_load(0,patch,1)&&pc_fm6_voices(0)==1);
 assert(play(0,60)<10);patch[64]^=1;assert(!pc_fm6_load(0,patch,1));
 puts("FM6 preserves release voices and active notes during edits; independent pads, checksum and DX7 import passed");
}
