/* SPDX-License-Identifier: GPL-3.0-only */
#include "../../../theme/text.h"
#include "../../../theme/minimal.h"
typedef struct {uint32_t *p;unsigned w,h;} PanelCanvas;
static void panel_rect(PanelCanvas *c,int x,int y,int w,int h,uint32_t color){
 color=pc_theme_colour(color);
 if(x<0||y<0||w<=0||h<=0||x>=(int)c->w||y>=(int)c->h)return;
 if(w>(int)c->w-x)w=(int)c->w-x;if(h>(int)c->h-y)h=(int)c->h-y;
 unsigned alpha=color>>24;
 for(int j=0;j<h;j++)for(int i=0;i<w;i++){
  unsigned *pixel=&c->p[(y+j)*c->w+x+i];
  if(alpha==255)*pixel=color;else if(alpha){unsigned old=*pixel,r=((color>>16&255)*alpha+(old>>16&255)*(255-alpha)+127)/255,g=((color>>8&255)*alpha+(old>>8&255)*(255-alpha)+127)/255,b=((color&255)*alpha+(old&255)*(255-alpha)+127)/255;*pixel=0xff000000u|r<<16|g<<8|b;}
 }
}
static void panel_glyph_rect(void *context,int x,int y,int w,int h,unsigned color){panel_rect((PanelCanvas *)context,x,y,w,h,color);}
static void panel_text(PanelCanvas *c,int x,int y,const char *s,unsigned max,uint32_t color){pc_theme_text(c,panel_glyph_rect,x,y,s,max,color);}
static void panel_line(PanelCanvas *c,int x0,int y0,int x1,int y1,uint32_t color){
 int dx=x1-x0;if(dx<0)dx=-dx;int dy=y1-y0;if(dy<0)dy=-dy;dy=-dy;
 int sx=x0<x1?1:-1,sy=y0<y1?1:-1,error=dx+dy;
 for(;;){panel_rect(c,x0,y0,1,1,color);if(x0==x1&&y0==y1)break;
  int e=2*error;if(e>=dy){error+=dy;x0+=sx;}if(e<=dx){error+=dx;y0+=sy;}}
}
API int mpc_panel_draw(uint32_t *pixels,unsigned width,unsigned height,unsigned pad){
 if(!pixels||width!=320||height!=160||pad>=128)return 0;
 MpcPanelView v;if(!mpc_panel_view(&v))return 0;PanelCanvas c={pixels,width,height};
 const uint32_t bg=0xff10151b,fg=0xfff0f2f4,muted=0xff9aa8b5,box=0xff1b2530;
 uint32_t accent=panel.engine==0?0xffe8b46b:panel.engine==2?0xffa6d98a:0xff77d8dc;
 panel_rect(&c,0,0,320,160,bg);panel_rect(&c,0,0,320,16,box);panel_rect(&c,0,15,320,1,MPC_THEME_LINE);
 panel_text(&c,4,2,v.browser?"B1 PREV":"B1 PAGE-",12,muted);
 panel_text(&c,110,2,v.browser?"B2 SAVE":"B2 PAGE+",12,muted);
 panel_text(&c,216,2,v.browser?"B3 CANCEL":"B3 PRESET",12,accent);
 panel_text(&c,4,20,v.engine,8,fg);
 char text[16];text[0]=(char)('A'+pad/16);fmt_int(text+1,(int32_t)(pad%16)+1);panel_text(&c,68,20,text,3,fg);
 panel_text(&c,102,20,v.preset,26,fg);
 if(v.dirty&&!v.browser)panel_text(&c,308,20,"*",1,accent);
 if(v.browser){
  panel_text(&c,4,38,"CHOOSE PRESET",24,accent);
  unsigned first=v.preset_index>2?v.preset_index-2:0;
  if(first+5>v.preset_count)first=v.preset_count>5?v.preset_count-5:0;
  for(unsigned n=0;n<5&&first+n<v.preset_count;n++){
   int y=53+(int)n*16;int selected=first+n==v.preset_index;
   if(selected)panel_rect(&c,2,y,316,15,0xff30414e);
   panel_text(&c,6,y+1,mpc_synth_preset_name(panel.engine,first+n),38,selected?fg:muted);
  }
  panel_text(&c,4,141,v.confirm_replace?"REPLACE PATCH? PRESS AGAIN":"PRESS ENCODER TO LOAD",38,accent);
  return 1;
 }
 panel_text(&c,4,38,v.page,29,fg);fmt_int(text,(int32_t)v.page_index+1);panel_text(&c,270,38,text,2,accent);
 panel_text(&c,286,38,"/",1,muted);fmt_int(text,(int32_t)v.page_count);panel_text(&c,296,38,text,2,muted);
 panel_rect(&c,106,109,1,39,MPC_THEME_GRID);panel_rect(&c,212,109,1,39,MPC_THEME_GRID);panel_rect(&c,4,54,312,50,bg);panel_rect(&c,4,54,312,1,MPC_THEME_LINE);panel_rect(&c,4,103,312,1,MPC_THEME_LINE);
 /* Parameter illustrations, deliberately not an analyser or measured response. */
 if(str_eq(v.page,"SIDECHAIN")){
  panel_line(&c,12,62,65,62,accent);panel_line(&c,65,62,82,98,accent);
  panel_line(&c,82,98,280,62,accent);panel_line(&c,280,62,307,62,accent);

 }else if(panel.engine>=4){
  for(unsigned k=0;k<3;k++){
   MpcPanelSlot *s=&v.slots[k];int range=s->maximum-s->minimum;
   int width=range>0?(int)((int64_t)(s->current-s->minimum)*284/range):0;
   panel_rect(&c,14,60+(int)k*14,284,7,0xff293444);
   if(s->index>=0&&width>0)panel_rect(&c,14,60+(int)k*14,width,7,accent);
  }
 }

 for(unsigned k=0;k<3;k++){
  MpcPanelSlot *s=&v.slots[k];int x=4+(int)k*106;if(s->index<0)continue;
  panel_text(&c,x,109,s->label,12,muted);panel_text(&c,x,125,s->value,8,fg);
  unsigned n=str_len(s->value);if(n<9)panel_text(&c,x+(int)n*8+4,125,s->unit,12-n-1,muted);
  panel_rect(&c,x,144,98,3,box);
  int range=s->maximum-s->minimum,fill=range?(s->current-s->minimum)*98/range:0;
  panel_rect(&c,x,144,fill,3,accent);
  if(s->takeover)panel_rect(&c,x,151,3,3,muted);
 }
 return 1;
}
