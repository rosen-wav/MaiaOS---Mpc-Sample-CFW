/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef MPC_PANEL_H
#define MPC_PANEL_H
#include "synth_api.h"
typedef struct {
 char label[24],value[32],unit[16];
 int32_t index,minimum,maximum,current;
 uint32_t boolean,takeover;
} MpcPanelSlot;
typedef struct {
 char engine[24],preset[40],page[24],message[64];
 uint32_t page_index,page_count,preset_index,preset_count,dirty,browser,confirm_replace;
 MpcPanelSlot slots[3];
} MpcPanelView;
int mpc_panel_init(unsigned engine,unsigned preset);
int mpc_panel_view(MpcPanelView *out);
/* B1 previous page, B2 next page, B3 preset chooser/cancel. */
int mpc_panel_button(unsigned button);
int mpc_panel_encoder(int delta);
int mpc_panel_confirm(void);
/* Absolute hardware position 0..16383. Crossing/tolerance soft takeover. */
int mpc_panel_knob(unsigned knob,unsigned position);
/* Relative turns / UI slider, native range; same DSP target as the knob. */
int mpc_panel_set(unsigned knob,int32_t value);
int mpc_panel_save(uint8_t out[512]);
int mpc_panel_load(unsigned engine,unsigned preset,const uint8_t in[512]);
/* 320x160 ARGB pixels, no native drawing ABI or framebuffer ownership assumed. */
int mpc_panel_draw(uint32_t *pixels,unsigned width,unsigned height,unsigned pad);
#endif
