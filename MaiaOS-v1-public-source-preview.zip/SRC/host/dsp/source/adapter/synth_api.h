/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef MPC_SYNTH_API_H
#define MPC_SYNTH_API_H
#include <stdint.h>
typedef struct {
 char page[24],label[24],value[32],unit[16];
 int32_t minimum,maximum,current;
 uint32_t kind;
} MpcSynthControl;
unsigned mpc_synth_api_version(void);
unsigned mpc_synth_engine_count(void);
const char *mpc_synth_engine_name(unsigned index);
unsigned mpc_synth_preset_count(unsigned index);
const char *mpc_synth_preset_name(unsigned index,unsigned preset);
int mpc_synth_select(unsigned index,unsigned preset);
unsigned mpc_synth_control_count(void);
int mpc_synth_control(unsigned control,MpcSynthControl *out);
int mpc_synth_set(unsigned control,int32_t value);
void mpc_synth_note_on(unsigned note,unsigned velocity);
void mpc_synth_note_off(unsigned note);
unsigned mpc_synth_voices(void);
unsigned mpc_synth_held(void);
void mpc_synth_render(float *left,float *right,unsigned frames);
int mpc_synth_save(uint8_t out[512]);
int mpc_synth_load(const uint8_t in[512]);
#endif
