/* SPDX-License-Identifier: GPL-3.0-only
 * Headless Linux backend for user-supplied Melodee CZ-1 and CS-1 sources.
 * Each loaded copy owns its voices, parameters, FX and panel. No audio-thread
 * allocation, file access, hardware code or locks.
 */
#include "../../new/backend.h"
#define API __attribute__((visibility("default")))
#define NELEM(a) (sizeof(a)/sizeof((a)[0]))
static unsigned engine=7,preset;
static int clamp(int x,int lo,int hi){return x<lo?lo:x>hi?hi:x;}
static void str_cpy(char*d,const char*s,unsigned n){nx_copy(d,s,n);}
static int str_eq(const char*a,const char*b){while(*a&&*a==*b){a++;b++;}return *a==*b;}
static unsigned str_len(const char*s){unsigned n=0;while(s[n])n++;return n;}
static void fmt_int(char*p,int32_t n){nx_int(p,n);}
static uint32_t get32(const uint8_t*p){return p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void put32(uint8_t*p,uint32_t v){for(unsigned k=0;k<4;k++)p[k]=v>>(8*k);}
static uint32_t crc(const uint8_t*p,unsigned n){uint32_t c=~0u;for(unsigned i=0;i<n;i++){c^=p[i];for(unsigned j=0;j<8;j++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
API unsigned mpc_synth_api_version(void){return 1;}
API int mpc_synth_prepare(unsigned e){return e==7||e==8||e==9;}
API unsigned mpc_synth_engine_count(void){return 10;}
API const char*mpc_synth_engine_name(unsigned e){return e==7?"CZ-1":e==8?"CS-1":e==9?"RS-01":0;}
API unsigned mpc_synth_preset_count(unsigned e){return e==7?cz_count():e==8?cs_count():e==9?rs_count():0;}
API const char*mpc_synth_preset_name(unsigned e,unsigned p){return e==7?cz_name(p):e==8?cs_name(p):e==9?rs_name(p):0;}
API int mpc_synth_select(unsigned e,unsigned p){if(!mpc_synth_prepare(e)||p>=mpc_synth_preset_count(e))return 0;int ok=e==7?cz_select(p):e==8?cs_select(p):rs_select(p);if(ok){engine=e;preset=p;}return ok;}
API unsigned mpc_synth_control_count(void){return engine==7?cz_controls():engine==8?cs_controls():rs_controls();}
API int mpc_synth_control(unsigned i,MpcSynthControl*c){return engine==7?cz_control(i,c):engine==8?cs_control(i,c):rs_control(i,c);}
API int mpc_synth_set(unsigned i,int32_t v){return engine==7?cz_set(i,v):engine==8?cs_set(i,v):rs_set(i,v);}
API void mpc_synth_note_on(unsigned n,unsigned v){if(engine==7)cz_on(n,v);else if(engine==8)cs_on(n,v);else rs_on(n,v);}
API void mpc_synth_note_off(unsigned n){if(engine==7)cz_off(n);else if(engine==8)cs_off(n);else rs_off(n);}
API unsigned mpc_synth_held(void){return engine==7?cz_held():engine==8?cs_held():rs_held();}
API unsigned mpc_synth_attack_cost(void){return engine==8?cs_attack_cost():1;}
API unsigned mpc_synth_voices(void){return engine==7?cz_voices():engine==8?cs_voices():rs_voices();}
API void mpc_synth_render(float*l,float*r,unsigned n){if(!l||!r)return;if(engine==7)cz_render(l,r,n);else if(engine==8)cs_render(l,r,n);else rs_render(l,r,n);}
API void mpc_synth_tempo(float bpm){cs_tempo(bpm);rs_tempo(bpm);}
API int mpc_synth_save(uint8_t*p){if(!p)return 0;memset(p,0,512);memcpy(p,"MPCNEW01",8);put32(p+8,engine);put32(p+12,preset);put32(p+16,44100);int n=engine==7?cz_save(p+32):engine==8?cs_save(p+32):rs_save(p+32);put32(p+20,n);put32(p+508,crc(p,508));return n>0;}
API int mpc_synth_load(const uint8_t*p){if(!p||memcmp(p,"MPCNEW01",8)||get32(p+16)!=44100||get32(p+508)!=crc(p,508))return 0;unsigned e=get32(p+8),pr=get32(p+12),n=get32(p+20);if(!mpc_synth_prepare(e)||pr>=mpc_synth_preset_count(e)||n!=(e==7?146:e==8?cs_save_size():102))return 0;int ok=e==7?cz_load(p+32):e==8?cs_load(p+32):rs_load(p+32);if(ok){engine=e;preset=pr;}return ok;}
#include "panel.c"
#include "panel_draw.c"
