/* SPDX-License-Identifier: GPL-3.0-only
 * One panel per independently loaded DSP instance. Call on the same owner
 * thread as DSP; native UI/audio transport must enqueue commands, not call
 * these functions concurrently. No allocations, I/O or locks in this module.
 */
#include "panel.h"
typedef struct {const char *page,*source,*label;unsigned boolean;} PanelBinding;
typedef struct {const char *name;PanelBinding slots[3];} PanelPage;
#define C(p,s,l) {p,s,l,0}
#define T(p,s,l) {p,s,l,1}
#define EMPTY {0,0,0,0}
static const PanelPage prophet_pages[]={
 {"FILTER",{C("FILTER","CUT","Cutoff"),C("FILTER","RESO","Resonance"),C("FILTER","ENV","Env amount")}},
 {"OSCILLATOR A",{C("OSC A","FREQ","A frequency"),C("OSC A","WIDTH","A width"),T("OSC A","SAW","A saw")}},
 {"OSCILLATOR B",{C("OSC B","FREQ","B frequency"),C("OSC B","FINE","B fine"),C("OSC B+","WIDTH","B width")}},
 {"WAVES A / SYNC",{T("OSC A","PULSE","A pulse"),T("OSC B+","SYNC","Osc sync"),T("OSC B+","KEY","B key track")}},
 {"WAVES B",{T("OSC B","SAW","B saw"),T("OSC B","TRI","B triangle"),T("OSC B+","PULSE","B pulse")}},
 {"OSC MIXER",{C("MIXER","OSC A","Osc A level"),C("MIXER","OSC B","Osc B level"),C("MIXER","NOISE","Noise")}},
 {"AMP ENVELOPE",{C("AMP ENV","ATK","Amp attack"),C("AMP ENV","DEC","Amp decay"),C("AMP ENV","SUS","Amp sustain")}},
 {"RELEASE / GLIDE",{C("AMP ENV","REL","Amp release"),C("FLT ENV","REL","Filter rel"),C("VOICE","GLD","Glide")}},
 {"FILTER ENVELOPE",{C("FLT ENV","ATK","Filter atk"),C("FLT ENV","DEC","Filter decay"),C("FLT ENV","SUS","Filter sus")}},
 {"KEY / LOW OSC",{C("FILTER","KEY","Key tracking"),T("MIXER","LOW B","B low range"),C("VOICE","VCE","Voice mode")}},
 {"LFO",{C("LFO","RATE","LFO rate"),C("LFO","AMOUNT","LFO amount"),C("LFO","NOISE","Wheel noise")}},
 {"POLY MOD",{T("LFO","TRI","LFO triangle"),C("POLYMOD","ENV","Poly env"),C("POLYMOD","OSC B","Poly osc B")}},
 {"MOD / OUTPUT",{T("POLYMOD","FREQ","Mod to pitch"),T("POLYMOD","FILTER","Mod filter"),C("VOICE","LVL","Level")}},
 {"TUNE / PAN",{C("FILTER/TUNE","TUNA","A transpose"),C("FILTER/TUNE","TUNB","B transpose"),C("VOICE","PAN","Pan")}},
 {"OUTPUT CONTROL",{EMPTY,EMPTY,EMPTY}},
};
static const PanelPage cloud_pages[]={
 {"GRAINS",{C("PERFORM","SIZE","Grain size"),C("PERFORM","DENS","Density"),C("GRAINS","SPRD","Spread")}},
 {"WAVETABLE",{C("WAVETABLE","Bank","Wave bank"),C("PERFORM","WAVE","Wave pos"),C("PERFORM","TONE","Tone")}},
 {"PITCH TEXTURE",{C("SPECTRUM","DTUN","Detune"),C("SPECTRUM","CHRP","Chirp"),C("SPECTRUM","STCK","Harmonics")}},
 {"WAVE SCAN",{C("WAVETABLE","Scan","Scan mode"),C("WAVETABLE","Rate","Scan rate"),C("WAVETABLE","Depth","Scan depth")}},
 {"AMP ENVELOPE",{C("ENVELOPE","ATK","Attack"),C("ENVELOPE","DEC","Decay"),C("ENVELOPE","SUS","Sustain")}},
 {"RELEASE / VOICE",{C("ENVELOPE","REL","Release"),C("VOICE","VCE","Voice mode"),C("VOICE","GLD","Glide")}},
 {"OUTPUT",{C("VOICE","LVL","Level"),C("VOICE","PAN","Pan"),EMPTY}},
 {"OUTPUT CONTROL",{EMPTY,EMPTY,EMPTY}},
};
static const PanelPage kr106_pages[]={
 {"FILTER",{C("VCF","CUTOFF","Cutoff"),C("VCF","RES","Resonance"),C("VCF","ENV MOD","Env amount")}},
 {"FILTER MOD",{C("VCF","KEY TRACK","Key tracking"),C("FILTER MOD","HPF","High pass"),C("FILTER MOD","LFO MOD","LFO filter")}},
 {"DCO WAVES",{T("DCO","SAW","Saw"),T("DCO","PULSE","Pulse"),T("PWM","SUB ON","Sub on")}},
 {"DCO MIXER",{C("DCO","SUB","Sub level"),C("DCO","NOISE","Noise"),C("PWM","RANGE","DCO range")}},
 {"PWM / VCA",{C("PWM","WIDTH","Pulse width"),C("PWM","PWM MODE","PWM mode"),C("FILTER MOD","VCA MODE","VCA mode")}},
 {"AMP ENVELOPE",{C("ENVELOPE","ATK","Attack"),C("ENVELOPE","DEC","Decay"),C("ENVELOPE","SUS","Sustain")}},
 {"RELEASE / VOICE",{C("ENVELOPE","REL","Release"),C("FILTER MOD","ENV POL","Env polarity"),C("VOICE","GLD","Glide")}},
 {"LFO",{C("LFO","RATE","LFO rate"),C("LFO","DELAY","LFO delay"),C("LFO","DCO MOD","LFO pitch")}},
 {"CHORUS",{T("CHORUS","CHORUS I","Chorus I"),T("CHORUS","CHORUS II","Chorus II"),C("CHORUS","LEVEL","VCA level")}},
 {"OUTPUT",{C("VOICE","VCE","Voice mode"),C("VOICE","LVL","Level"),C("VOICE","PAN","Pan")}},
 {"OUTPUT CONTROL",{EMPTY,EMPTY,EMPTY}},
};
#undef C
#undef T
#undef EMPTY
static struct {unsigned initialized,engine,preset,page,dirty,browser,candidate,replace;
 unsigned armed[3],known[3],last[3];int indices[64][3];} panel;
static PanelPage extra_pages[64];
static char extra_titles[64][24],extra_labels[192][24];
static unsigned extra_index[192];
static void extra_panel_pages(void){
 unsigned n=mpc_synth_control_count();memset(extra_pages,0,sizeof extra_pages);
 for(unsigned i=0;i<n;i++)extra_index[i]=i;
 if(panel.engine==5){unsigned j=0;for(unsigned i=20;i<23;i++)extra_index[j++]=i;for(unsigned i=0;i<n;i++)if(i<20||i>=23)extra_index[j++]=i;}
 for(unsigned i=0;i<n;i++){
  unsigned p=i/3,k=i%3;MpcSynthControl c;mpc_synth_control(extra_index[i],&c);
  str_cpy(extra_labels[i],c.label,24);
  if(k==0){str_cpy(extra_titles[p],c.page,24);extra_pages[p].name=extra_titles[p];}
  extra_pages[p].slots[k]=(PanelBinding){"EXTRA",extra_labels[i],extra_labels[i],0};
 }
 extra_pages[(n+2)/3].name="OUTPUT CONTROL";
}
static const PanelPage *panel_pages(unsigned *count){
 if(panel.engine>=4){*count=(mpc_synth_control_count()+2)/3+1;return extra_pages;}
 if(panel.engine==0){*count=NELEM(prophet_pages);return prophet_pages;}
 if(panel.engine==2){*count=NELEM(kr106_pages);return kr106_pages;}
 *count=NELEM(cloud_pages);return cloud_pages;
}
static void panel_disarm(void){for(unsigned i=0;i<3;i++)panel.armed[i]=0;}
static int panel_resolve(void){
 if(panel.engine>=4){extra_panel_pages();memset(panel.indices,0xff,sizeof panel.indices);
  for(unsigned i=0;i<mpc_synth_control_count();i++)panel.indices[i/3][i%3]=(int)extra_index[i];return 1;}
 unsigned count;const PanelPage *pages=panel_pages(&count);
 for(unsigned p=0;p<count;p++)for(unsigned k=0;k<3;k++){
  const PanelBinding *b=&pages[p].slots[k];panel.indices[p][k]=-1;if(!b->page)continue;
  for(unsigned n=0;n<mpc_synth_control_count();n++){MpcSynthControl c;mpc_synth_control(n,&c);
   if(str_eq(c.page,b->page)&&str_eq(c.label,b->source)){panel.indices[p][k]=(int)n;break;}}
  if(panel.indices[p][k]<0)return 0;
 }
 return 1;
}
API int mpc_panel_init(unsigned engine,unsigned preset){
 if(engine<7||engine>9||!mpc_synth_select(engine,preset))return 0;
 memset(&panel,0,sizeof panel);panel.engine=engine;panel.preset=preset;
 panel.initialized=panel_resolve();return panel.initialized;
}
API int mpc_panel_view(MpcPanelView *out){
 if(!panel.initialized||!out)return 0;memset(out,0,sizeof *out);
 unsigned count;const PanelPage *pages=panel_pages(&count);const PanelPage *p=&pages[panel.page];
 str_cpy(out->engine,mpc_synth_engine_name(panel.engine),sizeof out->engine);
 str_cpy(out->preset,mpc_synth_preset_name(panel.engine,panel.browser?panel.candidate:panel.preset),sizeof out->preset);
 str_cpy(out->page,p->name,sizeof out->page);
 out->page_index=panel.page;out->page_count=count;out->preset_index=panel.browser?panel.candidate:panel.preset;
 out->preset_count=mpc_synth_preset_count(panel.engine);out->dirty=panel.dirty;out->browser=panel.browser;out->confirm_replace=panel.replace;
 str_cpy(out->message,panel.replace?"Replace edited patch? Press encoder again":panel.browser?"Turn: preset / B2: save / B3: cancel":"B1/B2: pages / Encoder: page / B3: presets",sizeof out->message);
 for(unsigned k=0;k<3;k++){
  MpcPanelSlot *s=&out->slots[k];s->index=panel.indices[panel.page][k];if(s->index<0)continue;
  MpcSynthControl c;mpc_synth_control((unsigned)s->index,&c);s->minimum=c.minimum;s->maximum=c.maximum;s->current=c.current;
  s->boolean=p->slots[k].boolean;s->takeover=!panel.armed[k];
  str_cpy(s->label,p->slots[k].label,sizeof s->label);str_cpy(s->value,c.value,sizeof s->value);str_cpy(s->unit,c.unit,sizeof s->unit);
  if(s->boolean){s->minimum=0;s->maximum=1;s->current=!!c.current;str_cpy(s->value,s->current?"ON":"OFF",sizeof s->value);s->unit[0]=0;}

 }
 return 1;
}
API int mpc_panel_encoder(int delta){
 if(!panel.initialized)return 0;unsigned count;panel_pages(&count);
 int64_t next=(int64_t)(panel.browser?panel.candidate:panel.page)+delta;
 if(panel.browser){unsigned presets=mpc_synth_preset_count(panel.engine);if(next<0)next=0;if(next>=presets)next=presets-1;panel.candidate=(unsigned)next;panel.replace=0;}
 else{int64_t n=count;next%=n;if(next<0)next+=n;panel.page=(unsigned)next;panel_disarm();}
 return 1;
}
API int mpc_panel_button(unsigned button){
 if(!panel.initialized||button>2)return 0;
 if(button==2){panel.browser=!panel.browser;panel.candidate=panel.preset;panel.replace=0;panel_disarm();return 1;}
 return mpc_panel_encoder(button==0?-1:1);
}
API int mpc_panel_confirm(void){
 if(!panel.initialized)return 0;
 if(!panel.browser)return mpc_panel_button(2);
 if(mpc_synth_held())return -1; /* No forced replacement while a note is held. */
 if(panel.dirty&&!panel.replace){panel.replace=1;return 2;}
 unsigned page=panel.page,known[3],last[3];memcpy(known,panel.known,sizeof known);memcpy(last,panel.last,sizeof last);
 if(!mpc_panel_init(panel.engine,panel.candidate))return 0;
 panel.page=page;memcpy(panel.known,known,sizeof known);memcpy(panel.last,last,sizeof last);return 1;
}
API int mpc_panel_set(unsigned knob,int32_t value){
 if(!panel.initialized||panel.browser||knob>=3)return 0;
 MpcPanelView v;mpc_panel_view(&v);MpcPanelSlot *s=&v.slots[knob];if(s->index<0)return 0;
 value=clamp(value,s->minimum,s->maximum);if(value==s->current)return 1;
 if(!mpc_synth_set((unsigned)s->index,value))return 0;panel.dirty=1;return 1;
}
API int mpc_panel_knob(unsigned knob,unsigned position){
 if(!panel.initialized||panel.browser||knob>=3||position>16383)return 0;
 MpcPanelView v;mpc_panel_view(&v);MpcPanelSlot *s=&v.slots[knob];if(s->index<0)return 0;
 int32_t range=s->maximum-s->minimum;if(range<=0)return 0;
 unsigned target=(unsigned)(((int64_t)(s->current-s->minimum)*16383)/range);
 unsigned old=panel.last[knob];int near=(int)position-(int)target;
 if(!panel.armed[knob]&&((near>=-128&&near<=128)||(panel.known[knob]&&((old<=target&&position>=target)||(old>=target&&position<=target)))))panel.armed[knob]=1;
 panel.last[knob]=position;panel.known[knob]=1;if(!panel.armed[knob])return 2;
 return mpc_panel_set(knob,s->minimum+(int32_t)(((int64_t)position*range+8191)/16383));
}
API int mpc_panel_save(uint8_t out[512]){return panel.initialized&&mpc_synth_save(out);}
API int mpc_panel_load(unsigned engine,unsigned preset,const uint8_t in[512]){
 if(engine<7||engine>9||preset>=mpc_synth_preset_count(engine)||!in)return 0;
 if(memcmp(in,"MPCNEW01",8)||get32(in+8)!=engine)return 0;
 if(!mpc_synth_load(in))return 0;
 memset(&panel,0,sizeof panel);panel.engine=engine;panel.preset=preset;panel.dirty=1;
 panel.initialized=panel_resolve();return panel.initialized;
}

/* The host writes a checked SD override before acknowledging this operation. */
API int mpc_panel_saved(unsigned preset){
 if(!panel.initialized||preset>=mpc_synth_preset_count(panel.engine))return 0;
 panel.preset=preset;panel.candidate=preset;panel.dirty=0;panel.replace=0;return 1;
}
