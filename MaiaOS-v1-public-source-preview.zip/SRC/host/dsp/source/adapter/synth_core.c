/* SPDX-License-Identifier: GPL-3.0-only
 * MPC port adapter for the user's ChoralRoot 62.1 DSP sources.
 * Each separately loaded library instance owns its complete original DSP state.
 * No platform flash, USB, interrupt or FM-1 UI code is included.
 */
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#define CHORALROOT_DUAL_CORE 0
#define CR_CPU1 0
#define FELUCCA_BASS 1
#define FELUCCA_ANALOG 0
#define FELUCCA_FM4 0
#define FELUCCA_SAMPLE 0
#define FELUCCA_GRAIN 1
#define FELUCCA_DRUM 0
#define FELUCCA_SLICE 0
#define FELUCCA_VA 0
#define FELUCCA_CZ 0
#define FELUCCA_QUAD 1
#define FELUCCA_PROPHET 1
#define FELUCCA_SEQ 0
#define FELUCCA_SLICER 0
#define GRAIN_ASYNC 1
#define FM6_POLY 8
#define memset cr_port_memset
#define memcpy cr_port_memcpy
#define memcmp cr_port_memcmp
#include "libc.c"
#undef memset
#undef memcpy
#undef memcmp
#include "felucca_tables.h"
#include "choralroot_prophet_tables.h"
static void fm1_irq_off(void){}
static void fm1_irq_on(void){}
#include "core.h"
#include "engines.c"
#include "params.c"
#include "eng_morph.c"
#include "mod.c"
#include "voice.c"
/* This build exposes the requested instruments. Keep vendor IDs and
 * patch format unchanged so their original preset blobs remain compatible. */
#undef NENG_SHOWN
#define NENG_SHOWN 3
static const uint8_t port_engine_order[3]={ENGI_PROPHET,ENGI_CLOUD,ENGI_KR106};
#define ENGINE_ORDER port_engine_order
#include "../../extra/extra.h"
static unsigned extra_engine;
#define API __attribute__((visibility("default")))
API unsigned mpc_synth_api_version(void){return 1;}
API int mpc_synth_prepare(unsigned e){return e<3?1:extra_prepare(e);}
API unsigned mpc_synth_engine_count(void){return 7;}
API const char *mpc_synth_engine_name(unsigned index){if(index>=3)return extra_name(index);return index<NENG_SHOWN?ENGINES[ENGINE_ORDER[index]]->name:0;}
API unsigned mpc_synth_preset_count(unsigned index){if(index>=3)return extra_count(index);return index<NENG_SHOWN?ENGINES[ENGINE_ORDER[index]]->npresets:0;}
API const char *mpc_synth_preset_name(unsigned index,unsigned preset){if(index>=3)return extra_preset(index,preset);
 if(index>=NENG_SHOWN)return 0;const engine_t *e=ENGINES[ENGINE_ORDER[index]];
 return preset<e->npresets?e->presets[preset].name:0;
}
API int mpc_synth_select(unsigned index,unsigned preset){
 if(index>=3){if(!extra_select(index,preset))return 0;extra_engine=index;return 1;}
 if(index>=NENG_SHOWN)return 0;extra_engine=0;unsigned eng=ENGINE_ORDER[index];const engine_t *e=ENGINES[eng];
 if(preset>=e->npresets)return 0;
 memset(trk,0,sizeof trk);memset(eng_state,0,sizeof eng_state);memset(vsq,0,sizeof vsq);
 for(unsigned g=0;g<G_COUNT;g++)song.g[g]=GP[g].def;
 for(unsigned t=0;t<NTRK;t++){for(unsigned p=0;p<P_COUNT;p++)trk[t].p[p]=TP[p].def;trk[t].eng_req=trk[t].engine=3;}
 song.master_q12=4096;morph_invalidate();fm6_init();
 track_t *t=&trk[0];const preset_t *p=&e->presets[preset];
 t->engine=t->eng_req=eng;t->preset=preset;
 for(unsigned n=0;n<8;n++)t->p[P_E0+n]=p->e[n];
 t->p[P_ATK]=p->env[0];t->p[P_DEC]=p->env[1];t->p[P_SUS]=p->env[2];t->p[P_REL]=p->env[3];t->p[P_ED_FLT]=p->fenv;
 t->p[P_VOICE]=e->mono?V_MONO:V_POLY;t->p[P_LEVEL]=92;
 if(eng==ENGI_CLUSTER)cluster_preset_to(t,preset);
 fm6_track_loaded(t);
 if(e->deep&&e->deep->blob_preset)e->deep->blob_preset(t,preset);
 return 1;
}
API void mpc_synth_note_on(unsigned note,unsigned velocity){if(extra_engine){extra_on(note,velocity);return;}if(note<128&&velocity>0&&velocity<128)trk_note_on(&trk[0],note,velocity);}
API void mpc_synth_note_off(unsigned note){if(extra_engine){extra_off(note);return;}if(note<128)trk_note_off(&trk[0],note);}
API unsigned mpc_synth_voices(void){if(extra_engine)return extra_voices();unsigned n=0;for(unsigned k=0;k<NTRK;k++)for(unsigned j=0;j<NVOICE;j++)n+=trk[k].v[j].active!=0;return n;}
API unsigned mpc_synth_held(void){if(extra_engine)return extra_held();unsigned n=0;for(unsigned k=0;k<NTRK;k++)for(unsigned j=0;j<NVOICE;j++)n+=trk[k].v[j].gate!=0;return n;}
API void mpc_synth_render(float *left,float *right,unsigned frames){if(extra_engine){extra_render(left,right,frames);return;}
 while(frames){unsigned n=frames<CTL?frames:CTL;int32_t mid[CTL],side[CTL];uint8_t stereo=0;
  engine_block(&trk[0]);if(morph_dual)engine_block(&trk[2]);
  fm6_poll();grain_tick();grain_poll();
  morph_begin(&trk[0],n);mod_begin(&trk[0]);
  track_render_x(&trk[0],mid,side,&stereo,n,0);
  if(trk[0].engine==ENGI_MORPH&&morph_dual){
   track_render_x(&trk[2],morph_b_pcm,morph_b_side,&morph_b_side_on,n,0);
   if(!stereo)memset(side,0,n*sizeof(int32_t));if(!morph_b_side_on)memset(morph_b_side,0,n*sizeof(int32_t));stereo|=morph_b_side_on;
  }
  morph_fade_pcm(&trk[0],mid,stereo?side:0,n);
  int32_t level=LEVEL_Q12[clamp(trk[0].p[P_LEVEL],0,127)],pan=clamp(trk[0].p[P_PAN],-64,63);
  if(trk[0].engine==ENGI_PROPHET||trk[0].engine==ENGI_BASS)level=mulq15(level,24573);
  float gain=(float)level/(4096.0f*131072.0f),gl=(float)(4096-(pan>0?pan*64:0))/4096.0f,gr=(float)(4096+(pan<0?pan*64:0))/4096.0f;
  for(unsigned i=0;i<n;i++){
   int32_t a=mid[i],b=stereo?side[i]:0;
   left[i]=(float)(a-b)*gain*gl;right[i]=(float)(a+b)*gain*gr;
  }
  if(MODP(&trk[0]).on)mod_end(&trk[0]);morph_end(&trk[0]);
  left+=n;right+=n;frames-=n;
 }
}

#include "synth_api.h"
typedef struct {unsigned kind,id,col;const char *page;const param_desc_t *desc;} PortControl;
static int port_control(unsigned index,PortControl *out){
 track_t *t=&trk[0];const engine_t *e=ENGINES[t->eng_req];unsigned n=0;
 /* Keep native performance macros first, then reflow all remaining controls. */
 for(unsigned k=0;k<4;k++){
  unsigned id=e->knob[k];if(id>=P_COUNT)continue;
  int duplicate=0;for(unsigned j=0;j<k;j++)duplicate|=e->knob[j]==id;
  if(duplicate)continue;
  if(n++==index){*out=(PortControl){0,id,0,"PERFORM",track_desc(t,id)};return 1;}
 }
 for(unsigned k=0;k<8;k++){
  unsigned id=P_E0+k;int duplicate=0;
  if(t->eng_req==ENGI_KR106)continue;for(unsigned j=0;j<4;j++)duplicate|=e->knob[j]==id;
  const param_desc_t *d=track_desc(t,id);if(duplicate||!d->label||d->min==d->max)continue;
  if(n++==index){*out=(PortControl){0,id,0,e->page_title[k/4],d};return 1;}
 }
 const unsigned common[]={P_ATK,P_DEC,P_SUS,P_REL,P_LEVEL,P_PAN,P_VOICE,P_GLIDE};
 for(unsigned k=0;k<sizeof(common)/sizeof(common[0]);k++){
  if(t->eng_req==ENGI_KR106&&k<4)continue;
  const param_desc_t *d=track_desc(t,common[k]);if(!d->label||d->min==d->max)continue;
  if(n++==index){*out=(PortControl){0,common[k],0,k<4?"ENVELOPE":"VOICE",d};return 1;}
 }
 if(e->deep)for(unsigned p=0;p<e->deep->npages;p++)for(unsigned c=0;c<4;c++){
  const param_desc_t *d=e->deep->desc?e->deep->desc(t,p,c):0;
  if(!d)d=&e->deep->pages[p].col[c];if(!d->label||d->min==d->max)continue;
  if(n++==index){*out=(PortControl){1,p,c,e->deep->pages[p].title,d};return 1;}
 }
 /* The bringup adapter omitted Cloud's bank/scan controls entirely. */
 if(t->eng_req==ENGI_CLOUD)for(unsigned k=0;k<4;k++){
  unsigned id=CLOUD_EXTRA_IDS[k];const param_desc_t *d=cloud_extra_desc(id);
  if(n++==index){*out=(PortControl){0,id,0,"WAVETABLE",d};return 1;}
 }
 return 0;
}
API unsigned mpc_synth_control_count(void){if(extra_engine)return extra_controls();PortControl c;unsigned n=0;while(n<1024&&port_control(n,&c))n++;return n;}
API int mpc_synth_control(unsigned index,MpcSynthControl *out){if(extra_engine)return extra_control(index,out);
 PortControl c;if(!out||!port_control(index,&c))return 0;
 memset(out,0,sizeof *out);str_cpy(out->page,c.page?c.page:"ENGINE",sizeof out->page);str_cpy(out->label,c.desc->label,sizeof out->label);
 out->minimum=c.desc->min;out->maximum=c.desc->max;out->kind=c.kind;
 out->current=c.kind?ENGINES[trk[0].eng_req]->deep->get(&trk[0],c.id,c.col):trk[0].p[c.id];
 char text[64];const char *unit=0;param_format(c.desc,out->current,text,&unit);
 /* Original four-column FM-1 UI truncated enum labels to five characters. */
 if(c.desc->fmt==F_ENUM&&c.desc->names)str_cpy(text,c.desc->names[clamp(out->current,c.desc->min,c.desc->max)],sizeof text);
 str_cpy(out->value,text,sizeof out->value);if(unit)str_cpy(out->unit,unit,sizeof out->unit);
 return 1;
}
API int mpc_synth_set(unsigned index,int32_t value){if(extra_engine)return extra_set(index,value);
 PortControl c;if(!port_control(index,&c))return 0;value=clamp(value,c.desc->min,c.desc->max);
 if(c.kind)ENGINES[trk[0].eng_req]->deep->set(&trk[0],c.id,c.col,value);
 else trk[0].p[c.id]=(int16_t)value;
 return 1;
}
static uint32_t port_crc(const uint8_t *p,unsigned n){uint32_t c=0xffffffff;for(unsigned i=0;i<n;i++){c^=p[i];for(unsigned b=0;b<8;b++)c=(c>>1)^(0xedb88320u&-(c&1));}return ~c;}
static void put32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(i*8));}
static uint32_t get32(const uint8_t *p){uint32_t n=0;for(unsigned i=0;i<4;i++)n|=(uint32_t)p[i]<<(i*8);return n;}
_Static_assert(32+P_COUNT*2+ENG_BLOB_MAX<=508,"portable patch size");
API int mpc_synth_save(uint8_t out[512]){if(extra_engine)return extra_save(out);
 if(!out)return 0;memset(out,0,512);memcpy(out,"MPCSYN01",8);put32(out+8,44100);put32(out+12,trk[0].eng_req);put32(out+16,P_COUNT);
 for(unsigned i=0;i<P_COUNT;i++){uint16_t v=(uint16_t)trk[0].p[i];out[32+2*i]=(uint8_t)v;out[33+2*i]=(uint8_t)(v>>8);}
 const eng_deep_t *d=ENGINES[trk[0].eng_req]->deep;
 if(d&&d->blob_get&&d->blob_size){put32(out+20,d->blob_size);d->blob_get(&trk[0],out+32+P_COUNT*2);}
 put32(out+508,port_crc(out,508));return 1;
}
API int mpc_synth_load(const uint8_t in[512]){if(in&&!memcmp(in,"MPCEXT01",8)){if(!extra_load(in))return 0;extra_engine=get32(in+8);return 1;}
 if(!in||memcmp(in,"MPCSYN01",8)||get32(in+8)!=44100||get32(in+16)!=P_COUNT||get32(in+508)!=port_crc(in,508))return 0;
 unsigned eng=get32(in+12),index=NENG_SHOWN;
 for(unsigned i=0;i<NENG_SHOWN;i++)if(ENGINE_ORDER[i]==eng){index=i;break;}
 if(index==NENG_SHOWN)return 0;const eng_deep_t *d=ENGINES[eng]->deep;
 unsigned blob=(d&&d->blob_get)?d->blob_size:0;if(get32(in+20)!=blob||blob>ENG_BLOB_MAX)return 0;
 int16_t params[P_COUNT];for(unsigned i=0;i<P_COUNT;i++)params[i]=(int16_t)((unsigned)in[32+2*i]|(unsigned)in[33+2*i]<<8);
 /* Validate every value before touching the active instance. */
 for(unsigned i=0;i<P_COUNT;i++){const param_desc_t *desc=param_desc_of(eng,i);if(params[i]<desc->min||params[i]>desc->max)return 0;}
 if(!mpc_synth_select(index,0))return 0;
 memcpy(trk[0].p,params,sizeof params);
 if(blob&&d->blob_set)d->blob_set(&trk[0],in+32+P_COUNT*2);
 if(!blob)fm6_track_loaded(&trk[0]);
 return 1;
}

#include "panel.c"
#include "panel_draw.c"
