#pragma once
/* Bounded rational tanh approximation for the freestanding ARM port. */
static float rs_tanh(float x){if(x>3)return 1;if(x< -3)return -1;float q=x*x;return x*(27+q)/(27+9*q);}
static float rs_clamp(float x,float a,float b){return x<a?a:x>b?b:x;}
static float rs_abs(float x){return x<0?-x:x;}
static float rs_exp2(float x){x=rs_clamp(x,-24,24);int n=(int)x;if(x<n)n--;float f=x-n;float y=1+f*(.69314718f+f*(.24022651f+f*(.05550411f+f*(.00961813f+f*.00133336f))));union{unsigned u;float f;}p={(unsigned)(n+127)<<23};return p.f*y;}
static float rs_sqrt(float x){return __builtin_sqrtf(x);}
