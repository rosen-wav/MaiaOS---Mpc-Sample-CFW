/* RS-01 parameter storage: TAL normalized values, 0..1000. */
#pragma once
#include <stdint.h>
enum{RS_SAW,RS_PULSE,RS_SUB,RS_NOISE,RS_SUBMODE,RS_WHITE,RS_WIDTH,RS_PWMMODE,RS_PITCHLFO,RS_CUTOFF,RS_RES,RS_ENV,RS_KEY,RS_FLFO,RS_FULL,RS_ATTACK,RS_DECAY,RS_SUSTAIN,RS_RELEASE,RS_ADSRMODE,RS_VCAMODE,RS_LRATE,RS_LWAVE,RS_LINVERT,RS_LTRIGGER,RS_LSYNC,RS_SNAP,RS_GLIDE,RS_PORTAMODE,RS_LINEAR,RS_RANGE,RS_OCTAVE,RS_FINE,RS_VELOCITY,RS_FVELOCITY,RS_DECLICK,RS_LEVEL,RS_COMP,RS_HOLD,RS_N};
#define RS_BYTES (RS_N*2+24)
typedef struct{uint16_t value[RS_N];char name[24];}RsPatch;
typedef struct{const char*page,*label,*key;unsigned initial;}RsDesc;
static const RsDesc RS_DESC[]={
{"OSC MIX","Saw","sawvolume",1000},
{"OSC MIX","Pulse","pulsevolume",0},
{"OSC MIX","Sub","suboscvolume",200},
{"OSC COLOR","Noise","noisevolume",0},
{"OSC COLOR","Sub mode","suboscmode",0},
{"OSC COLOR","White noise","whitenoiseenabled",0},
{"PWM","Width","dcopwmvalue",500},
{"PWM","PWM mode","dcopwmmode",500},
{"PWM","Pitch LFO","dcolfovalue",0},
{"FILTER","Cutoff","filtercutoff",400},
{"FILTER","Resonance","filterresonance",150},
{"FILTER","Env amount","filterenvelopevalue",300},
{"FILTER MOD","Key follow","filterkeyboardvalue",500},
{"FILTER MOD","LFO depth","filtermodulationvalue",0},
{"FILTER MOD","Bipolar env","filterenvelopevaluefullrange",0},
{"AMP ENV","Attack","adsrattack",0},
{"AMP ENV","Decay","adsrdecay",250},
{"AMP ENV","Sustain","adsrsustain",700},
{"GATE / RELEASE","Release","adsrrelease",200},
{"GATE / RELEASE","Retrigger","adsrmode",500},
{"GATE / RELEASE","VCA mode","vcamode",1000},
{"LFO","Rate","lforate",100},
{"LFO","Wave","lfowaveform",0},
{"LFO","Invert","lfoinverted",0},
{"LFO OPTIONS","Key reset","lfotrigger",0},
{"LFO OPTIONS","Tempo sync","lfosync",0},
{"LFO OPTIONS","Pitch snap","dcolfovaluesnap",0},
{"PORTAMENTO","Time","portamentointensity",0},
{"PORTAMENTO","Mode","portamentomode",500},
{"PORTAMENTO","Linear","portamentolinear",0},
{"TUNING","DCO range","dcorange",250},
{"TUNING","Octave","octavetranspose",500},
{"TUNING","Fine tune","masterfinetune",500},
{"DYNAMICS","Amp velocity","controlvelocityvolume",0},
{"DYNAMICS","Env velocity","controlvelocityenvelope",0},
{"DYNAMICS","Soft retrigger","adsrdecklick",300},
{"OUTPUT","Level","volume",800},
{"OUTPUT","Res makeup","filtervolumecorrection",0},
{"OUTPUT","Hold","",0},
};
static void rs_defaults(RsPatch*p){for(unsigned i=0;i<RS_N;i++)p->value[i]=RS_DESC[i].initial;for(unsigned i=0;i<24;i++)p->name[i]=0;}
int pc_rs_import(const uint8_t*,unsigned,uint8_t*,char*,unsigned*);
