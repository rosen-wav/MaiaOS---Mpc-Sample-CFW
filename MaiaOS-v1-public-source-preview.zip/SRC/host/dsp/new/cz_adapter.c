/* SPDX-License-Identifier: GPL-3.0-only
 * MPC adapter to Melodee CZ-1, Copyright (C) 2026 Kerem Kilic (Ellic Studio).
 * Retained envelope/state definitions and phase reset from eng_phase.c:
 * Portions Copyright (C) 2026 Leo Kuroshita, Hügelton Instruments.
 * Native oscillator/envelopes in melodee/cz_native.c keep BSD-3-Clause notices.
 */
#include "backend.h"
#define FS 44100u
#define CTL 32u
#define NTRK 1u
#define NPOLY 8u
#define VOICE_FS 24000
#define NELEM(x) (sizeof(x)/sizeof((x)[0]))
#include "melodee/cz_patch.h"
#include "cz_bank.h"
#include "cz_sine.h"
typedef struct{uint32_t rate[8];int32_t level[8];uint8_t sustain,end;}cz_env_def_t;
typedef struct{int32_t level;uint8_t stage,gate;}cz_env_t;
typedef struct{float level;uint8_t stage,gate;}cz_native_env_t;
typedef struct{float note[2];int32_t fine[2];uint32_t a4[2],inc[2],valid;}cz_native_freq_t;
typedef struct{union{cz_env_t eg[2][3];cz_native_env_t native_eg[2][3];};uint32_t vib_phase,vib_ticks,noise;float native_dc[2];cz_native_freq_t native_freq;}cz_voice_t;
typedef struct{float rate[8],level[8];uint8_t sustain,end;}cz_native_def_t;
typedef struct{cz_voice_t v[NPOLY];cz_native_def_t native_def[2][3];uint8_t native_raw[128],native_valid;}cz_part_t;
typedef struct{uint32_t ph[3];int32_t s[5];unsigned note,vel,gate,active,age;}voice_t;
typedef struct{voice_t v[NPOLY];}track_t;
typedef struct{int32_t pitch16,fine,cutoff,shape,amp0,amp1;}vmod_t;
static track_t trk[1];static cz_part_t part;static cz_patch_t tone;static unsigned voice_was,tuning_a4=440,midi_verb[1],serial,position=CTL,volume=100,pan=64;static uint8_t held[128];static int32_t pcm[CTL];
/* The release override is disabled in this port (native CZ release is retained). */
static const unsigned TIME_MS_X10[128]={1};
static cz_part_t*cz_part(unsigned p){(void)p;return &part;}
static cz_patch_t*cz_patch_of(unsigned p){(void)p;return &tone;}
static cz_voice_t*cz_voice(track_t*t,voice_t*v){return &part.v[v-t->v];}
static void phase_note_on(track_t*t,voice_t*v){
 cz_voice_t*c=cz_voice(t,v);memset(c,0,sizeof*c);for(unsigned l=0;l<2;l++)for(unsigned e=0;e<3;e++)c->eg[l][e].gate=1;
 v->ph[0]=v->ph[1]=v->ph[2]=0;v->s[0]=v->s[1]=v->s[4]=0;if(!voice_was)v->s[2]=v->s[3]=0;c->noise=0x6d2b79f5u^(unsigned)(v-t->v)*0x9e3779b9u;
}
#include "melodee/cz_native.c"
enum{F_INT,F_ENUM,F_ONOFF};
typedef struct{const char*label;uint8_t fmt;int16_t min,max,def;const char*const*names;const char*unit;}param_desc_t;
#include "melodee/cz_edit.h"
unsigned cz_count(void){return 65;}
const char*cz_name(unsigned p){return p==0?"INIT TONE":p<65?CZ_NAMES[p-1]:0;}
int cz_select(unsigned p){if(p>=65)return 0;memset(trk,0,sizeof trk);memset(&part,0,sizeof part);memset(held,0,sizeof held);memset(pcm,0,sizeof pcm);position=CTL;serial=0;volume=100;pan=64;if(p)memcpy(tone.raw,CZ_FACTORY[p-1],144);else cz_patch_init(tone.raw);return cz_patch_valid(tone.raw);}
static unsigned control_id(unsigned index){for(unsigned i=0;i<LCZ_NP;i++)if(CZ_PD[i].label){if(!index)return i;index--;}return LCZ_NP+index;}
unsigned cz_controls(void){unsigned n=2;for(unsigned i=0;i<LCZ_NP;i++)n+=CZ_PD[i].label!=0;return n;}
int cz_control(unsigned index,MpcSynthControl*c){if(!c||index>=cz_controls())return 0;memset(c,0,sizeof*c);unsigned id=control_id(index);uint8_t p[LCZ_PACKED];cz_ed_decode(p,tone.raw);
 if(id>=LCZ_NP){nx_copy(c->page,"OUTPUT",24);nx_copy(c->label,id==LCZ_NP?"Level":"Pan",24);c->minimum=0;c->maximum=127;c->current=id==LCZ_NP?volume:pan;nx_int(c->value,c->current);return 1;}
 const param_desc_t*d=&CZ_PD[id];c->minimum=d->min;c->maximum=d->max;c->current=p[id];nx_copy(c->label,d->label,24);
 if(id<LCZ_GLOBALS)nx_copy(c->page,id<7?"CZ-1 TONE":"VIBRATO",24);
 else if(id>=LCZ_WIN(0))nx_copy(c->page,"WAVE WINDOWS",24);
 else if(id<LCZ_EBASE(0,0))nx_copy(c->page,id<LCZ_LBASE(1)?"LINE 1 OSC":"LINE 2 OSC",24);
 else {unsigned k=(id-LCZ_EBASE(0,0))/18,line=k/3,e=k%3;const char*pages[6]={"LINE 1 DCO ENV","LINE 1 DCW ENV","LINE 1 DCA ENV","LINE 2 DCO ENV","LINE 2 DCW ENV","LINE 2 DCA ENV"};nx_copy(c->page,pages[line*3+e],24);}
 if(d->fmt==F_ENUM&&d->names)nx_copy(c->value,d->names[c->current],32);else if(d->fmt==F_ONOFF)nx_copy(c->value,c->current?"ON":"OFF",32);else nx_int(c->value,c->current);if(!cz_ed_active(tone.raw,id)){c->kind=2;nx_copy(c->unit,"inactive",16);}return 1;
}
int cz_set(unsigned index,int32_t value){if(index>=cz_controls())return 0;unsigned id=control_id(index);MpcSynthControl c;cz_control(index,&c);if(value<c.minimum)value=c.minimum;if(value>c.maximum)value=c.maximum;if(id>=LCZ_NP){if(id==LCZ_NP)volume=value;else pan=value;return 1;}uint8_t raw[144];if(cz_ed_put(0,id,value,raw))memcpy(tone.raw,raw,144);return 1;}
void cz_on(unsigned note,unsigned velocity){if(note>127||!velocity||velocity>127)return;voice_t*v=0;for(unsigned i=0;i<NPOLY;i++)if(!trk[0].v[i].active){v=&trk[0].v[i];break;}if(!v){v=&trk[0].v[0];for(unsigned i=1;i<NPOLY;i++)if((v->gate&&!trk[0].v[i].gate)||(v->gate==trk[0].v[i].gate&&trk[0].v[i].age<v->age))v=&trk[0].v[i];}voice_was=v->active;v->note=note;v->vel=velocity;v->gate=v->active=1;v->age=++serial;cz_native_note_on(trk,v);held[note]=1;}
void cz_off(unsigned note){if(note>127)return;held[note]=0;for(unsigned i=0;i<NPOLY;i++)if(trk[0].v[i].note==note)trk[0].v[i].gate=0;}
unsigned cz_held(void){unsigned n=0;for(unsigned i=0;i<128;i++)n+=held[i]!=0;return n;}
unsigned cz_voices(void){unsigned n=0;for(unsigned i=0;i<NPOLY;i++)n+=trk[0].v[i].active!=0;return n;}
void cz_render(float*l,float*r,unsigned n){for(unsigned i=0;i<n;i++){if(position==CTL){memset(pcm,0,sizeof pcm);cz_native_block(trk);for(unsigned k=0;k<NPOLY;k++){voice_t*v=&trk[0].v[k];if(!v->active)continue;vmod_t m={.pitch16=v->note*16,.shape=64<<8,.amp0=32768,.amp1=32768};cz_native_render(trk,v,pcm,CTL,&m);unsigned ls=tone.raw[0]&3,a=ls==1?1:0,z=ls>=2?1:a;cz_voice_t*c=cz_voice(trk,v);if(c->native_eg[a][2].stage>(tone.raw[CZ_ENV_END[a][2]]&7)&&c->native_eg[z][2].stage>(tone.raw[CZ_ENV_END[ls==2?0:z][2]]&7))v->active=0;}position=0;}
 float x=pcm[position++]*(1.f/131072.f)*(volume/127.f);l[i]=x*(pan>64?(127-pan)/63.f:1.f);r[i]=x*(pan<64?pan/64.f:1.f);}}
int cz_save(uint8_t*p){memcpy(p,tone.raw,144);p[144]=volume;p[145]=pan;return 146;}
int cz_load(const uint8_t*p){if(!cz_patch_valid(p)||p[144]>127||p[145]>127)return 0;cz_select(0);memcpy(tone.raw,p,144);volume=p[144];pan=p[145];return 1;}
