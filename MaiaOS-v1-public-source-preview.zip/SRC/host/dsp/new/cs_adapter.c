/* SPDX-License-Identifier: GPL-3.0-only
 * MPC adapter retaining twochannels' CS-1 voice, effects and preset recipes.
 * See CS1-LICENSING.md for Felucca/Dinghy/FM-106 and other retained attribution.
 */
#include "backend.h"
#define FS 44100u
#define HALF_FRAMES 256u
#define FM1_POOL
static unsigned fm1_ticks(void){return 0;}
static int audio_worker_submit(void(*fn)(void*),void*p){(void)fn;(void)p;return 0;}
static void audio_worker_join(void){}
static void dbg_meter(unsigned a,const int32_t*b,unsigned c){(void)a;(void)b;(void)c;}
#include "cs1/cs1_dsp.h"
#include "cs1/cs1_voice.h"
#include "cs1-gen/cs1_presets.h"
static struct{unsigned tone[2],chan,sound;}set;
#include "cs1_factory.h"
#include "cs_descriptors.h"
static unsigned selected,position=HALF_FRAMES;
static int32_t pcm[2*HALF_FRAMES];static float tempo=120.f;
#include "cs_reset.h"
static void sync_update(void){
 unsigned d=patch.dly_sync&7u,l=patch.lfo_sync>5?5:patch.lfo_sync;
 static const uint8_t DIV_NUM[8] = {0, 1, 1, 1, 3, 1, 3, 2}, DIV_DEN[8] = {1, 4, 3, 2, 4, 1, 2, 1};
 /* Divisions use the original CS-1 tables, including dotted notes. */
 const unsigned ld[6]={0,1,2,4,8,16};unsigned beat=(unsigned)(44100.f*60.f/tempo);
 if(d){unsigned t=beat*DIV_NUM[d]/DIV_DEN[d];sync_dly=t<64?64:t>=DLY_LEN?DLY_LEN-1:t;}
 if(l){unsigned p=beat*ld[l];sync_lfo=(0xffffffffu/(p?p:1))*CTL;}
}
void cs_tempo(float bpm){if(bpm>=20.f&&bpm<=999.f)tempo=bpm;sync_update();}
static const unsigned TONE_PICK[]={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,32,33,34,35,36,37,38,39,40,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57};
#define N_PICK (sizeof(TONE_PICK)/sizeof(TONE_PICK[0]))
unsigned cs_count(void){return NSOUND+N_PICK;}
const char*cs_name(unsigned p){return p<NSOUND?SOUNDS[p].name:p<NSOUND+N_PICK?TONE_NAMES[TONE_PICK[p-NSOUND]]:0;}
int cs_select(unsigned p){if(p>=cs_count())return 0;cs_reset();patch=INIT_PATCH;memset(&set,0,sizeof set);position=HALF_FRAMES;memset(pcm,0,sizeof pcm);selected=p;
 if(p<NSOUND)sound_load(p);else{patch.ch[0]=TONES[TONE_PICK[p-NSOUND]];patch.ch[1]=TONES[TONE_PICK[p-NSOUND]];patch.ch[1].level=0;patch.mix=0;}sync_update();return patch_valid(&patch);}
unsigned cs_controls(void){return sizeof CS_DESC/sizeof CS_DESC[0];}
int cs_control(unsigned i,MpcSynthControl*c){if(!c||i>=cs_controls())return 0;const CsDesc*d=&CS_DESC[i];memset(c,0,sizeof*c);nx_copy(c->page,d->page,24);nx_copy(c->label,d->label,24);c->minimum=0;c->maximum=d->max;c->current=((uint8_t*)&patch)[d->offset];nx_int(c->value,c->current);
 if(d->max==1)nx_copy(c->value,c->current?"ON":"OFF",32);
 if(d->offset==offsetof(patch_t,ch[0].feet)||d->offset==offsetof(patch_t,ch[1].feet)){const char*v[]={"16'","8'","5 1/3'","4'","2 2/3'","2'"};nx_copy(c->value,v[c->current],32);}
 if(d->offset==offsetof(patch_t,ch[0].wave)||d->offset==offsetof(patch_t,ch[1].wave)){const char*v[]={"SAW","PULSE","BOTH"};nx_copy(c->value,v[c->current],32);}return 1;}
int cs_set(unsigned i,int32_t v){if(i>=cs_controls())return 0;const CsDesc*d=&CS_DESC[i];if(v<0)v=0;if(v>d->max)v=d->max;((uint8_t*)&patch)[d->offset]=v;sync_update();return 1;}
void cs_on(unsigned n,unsigned v){if(n<128&&v&&v<128)voice_on(n,v);}
void cs_off(unsigned n){if(n<128)voice_off(n);}
unsigned cs_attack_cost(void){return patch.unison?2:1;}
unsigned cs_held(void){unsigned n=0;for(unsigned i=0;i<NV;i++)n+=voices[i].gate!=0;return n;}
unsigned cs_voices(void){unsigned n=0;for(unsigned i=0;i<NV;i++)n+=(voices[i].active||voices[i].gate);return n;}
void cs_render(float*l,float*r,unsigned n){for(unsigned i=0;i<n;i++){if(position==HALF_FRAMES){memset(pcm,0,sizeof pcm);voices_block(pcm,HALF_FRAMES);position=0;}l[i]=pcm[position*2]*(1.f/32768.f);r[i]=pcm[position*2+1]*(1.f/32768.f);position++;}}
int cs_save(uint8_t*p){memcpy(p,&patch,sizeof patch);return sizeof patch;}
int cs_load(const uint8_t*p){patch_t x;memcpy(&x,p,sizeof x);if(!patch_valid(&x))return 0;cs_reset();patch=x;position=HALF_FRAMES;memset(pcm,0,sizeof pcm);sync_update();return 1;}

unsigned cs_save_size(void){return sizeof(patch_t);}
