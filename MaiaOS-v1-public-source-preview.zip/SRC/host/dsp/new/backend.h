/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#include <stddef.h>
extern void *memset(void*,int,size_t);
extern void *memcpy(void*,const void*,size_t);
extern int memcmp(const void*,const void*,size_t);
#include "../source/adapter/synth_api.h"
unsigned cz_count(void);const char*cz_name(unsigned);int cz_select(unsigned);unsigned cz_controls(void);int cz_control(unsigned,MpcSynthControl*);int cz_set(unsigned,int32_t);void cz_on(unsigned,unsigned);void cz_off(unsigned);unsigned cz_held(void);unsigned cz_voices(void);void cz_render(float*,float*,unsigned);int cz_save(uint8_t*);int cz_load(const uint8_t*);
unsigned cs_save_size(void);unsigned cs_count(void);const char*cs_name(unsigned);int cs_select(unsigned);unsigned cs_controls(void);int cs_control(unsigned,MpcSynthControl*);int cs_set(unsigned,int32_t);void cs_on(unsigned,unsigned);void cs_off(unsigned);unsigned cs_held(void);unsigned cs_voices(void);void cs_render(float*,float*,unsigned);int cs_save(uint8_t*);int cs_load(const uint8_t*);void cs_tempo(float);
static void nx_copy(char*d,const char*s,unsigned n){if(!n)return;unsigned i=0;for(;i+1<n&&s[i];i++)d[i]=s[i];d[i]=0;}
static void nx_int(char*d,int v){char t[16];unsigned n=0,k=0;if(v<0){d[k++]='-';v=-v;}do{t[n++]='0'+v%10;v/=10;}while(v);while(n)d[k++]=t[--n];d[k]=0;}

unsigned rs_count(void);const char*rs_name(unsigned);int rs_select(unsigned);unsigned rs_controls(void);int rs_control(unsigned,MpcSynthControl*);int rs_set(unsigned,int32_t);void rs_on(unsigned,unsigned);void rs_off(unsigned);unsigned rs_held(void);unsigned rs_voices(void);void rs_render(float*,float*,unsigned);int rs_save(uint8_t*);int rs_load(const uint8_t*);void rs_tempo(float);

unsigned cs_attack_cost(void);
