/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_DJ_PLAYBACK_H
#define PC_DJ_PLAYBACK_H
#include <stdint.h>

int pc_dj_play(unsigned,const char*,uint64_t,uint64_t);
void pc_dj_nudge_step(unsigned,int);
void pc_dj_pause(unsigned);
int pc_dj_seek(unsigned,uint64_t,uint64_t);
void pc_dj_rate(unsigned,unsigned);
void pc_dj_monitor(unsigned,unsigned);
void pc_dj_monitor_gain(unsigned);
void pc_dj_monitor_reset(void);
void pc_dj_gain(unsigned,unsigned);
void pc_dj_filter(unsigned,unsigned);
void pc_dj_low(unsigned,int);
void pc_dj_loop(unsigned,uint64_t,uint64_t);
unsigned pc_dj_busy(unsigned);
unsigned pc_dj_playing(unsigned);
unsigned pc_dj_started(unsigned);
unsigned pc_dj_failed(unsigned);
uint64_t pc_dj_position(unsigned);
uint64_t pc_dj_clock(void);
void pc_dj_send(unsigned,unsigned,unsigned);
void pc_dj_space_position(unsigned);
void pc_dj_space_reset(void);
unsigned pc_dj_device_begin(unsigned);
void pc_dj_device_end(float*,float*,unsigned);
void pc_dj_graph_audio(unsigned,float (*)[2][4096],unsigned);
void pc_dj_audio(float*,float*,unsigned);

#endif
