/* Experimental synchronous two-worker DSP barrier. All task pointers and native
 * effect lifetimes remain inside the original callback. Main joins both workers
 * before returning to the graph. No block pipeline, buffers or discarded audio.
 * This barrier may miss a real-time deadline: hardware validation is required. */
#include "internal.h"
typedef struct {unsigned state,ready,failed,count,jobs;PcFxWork tasks[2];} Worker;
static Worker workers[2];static unsigned over_budget;
static unsigned load(unsigned*p){return __atomic_load_n(p,AQ);}
static uint64_t ns(void){long t[2];if(pc_sys(113,1,(long)t,0,0,0,0))return 0;return (uint64_t)t[0]*1000000000ull+t[1];}
static void wake(unsigned*p){pc_sys(98,(long)p,129,1,0,0,0);}
static void join(Worker*w){for(;;){unsigned s=load(&w->state);if(!s)return;pc_sys(98,(long)&w->state,128,s,0,0,0);}}
static void *run(void*arg){
 Worker*w=arg;unsigned index=(unsigned)(w-workers);unsigned long mask=1ul<<(index+1);struct{int priority;}priority={19};
 if(pc_sys(122,0,sizeof mask,(long)&mask,0,0,0)||pc_sys(119,0,2,(long)&priority,0,0,0)){
  __atomic_store_n(&w->failed,1,RL);return 0;
 }
 pc_sys(167,15,(long)(index?"Maia FX3 AT C2":"Maia FX12 C1"),0,0,0,0);__atomic_store_n(&w->ready,1,RL);
 for(;;){
  while(!load(&w->state))pc_sys(98,(long)&w->state,128,0,0,0,0);
  for(unsigned j=0;j<w->count;j++)if(w->tasks[j].run){w->tasks[j].run(w->tasks[j].arg);__atomic_fetch_add(&w->jobs,1,RX);}
  __atomic_store_n(&w->state,0,RL);wake(&w->state);
 }
 return 0;
}
void pc_fx_worker_init(void){
 long fd=pc_sys(56,-100,(long)"/data/mpc-internal-mod/maia-fx-worker.enabled",0x80000,0,0,0);
 if(fd<0)return;pc_sys(57,fd,0,0,0,0,0);
 void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 int(*create)(uintptr_t*,const void*,void*(*)(void*),void*)=symbol(0,"pthread_create");int(*detach)(uintptr_t)=symbol(0,"pthread_detach");
 if(!create||!detach){workers[0].failed=workers[1].failed=2;return;}
 for(unsigned k=0;k<2;k++){uintptr_t thread=0;if(create(&thread,0,run,&workers[k])){__atomic_store_n(&workers[k].failed,2,RL);continue;}detach(thread);}
 struct{long sec,nsec;}pause={0,1000000};
 for(unsigned i=0;i<100;i++){if((load(&workers[0].ready)&&load(&workers[1].ready))||load(&workers[0].failed)||load(&workers[1].failed))break;pc_sys(101,(long)&pause,0,0,0,0,0);}
}
static int ready(void){return load(&workers[0].ready)&&load(&workers[1].ready);}
static void publish(Worker*w,const PcFxWork*t,unsigned count){
 /* Native EngineMode serializes producer callbacks; previous call has joined. */
 w->count=count;for(unsigned j=0;j<count;j++)w->tasks[j]=t[j];__atomic_store_n(&w->state,1,RL);wake(&w->state);
}
int pc_fx_workers_run(const PcFxWork*t,unsigned frames){
 if(!ready())return 0;uint64_t begin=ns();
 unsigned first=t[0].run||t[1].run,second=t[2].run!=0;
 if(first)publish(&workers[0],t,2);if(second)publish(&workers[1],t+2,1);
 if(first)join(&workers[0]);if(second)join(&workers[1]);
 uint64_t end=ns();if(begin&&end>=begin&&end-begin>(uint64_t)frames*1000000000ull/44100)__atomic_fetch_add(&over_budget,1,RX);
 return 1;
}
int pc_fx_worker_tune(PcFxWork task,unsigned frames){
 if(!ready())return 0;uint64_t begin=ns();publish(&workers[1],&task,1);join(&workers[1]);
 uint64_t end=ns();if(begin&&end>=begin&&end-begin>(uint64_t)frames*1000000000ull/44100)__atomic_fetch_add(&over_budget,1,RX);
 return 1;
}
void pc_fx_worker_diagnostics(unsigned*out){out[0]=load(&workers[0].ready);out[1]=load(&workers[1].ready);out[2]=load(&workers[0].jobs);out[3]=load(&workers[1].jobs);out[4]=load(&over_budget);out[5]=load(&workers[0].failed)|(load(&workers[1].failed)<<8);}
