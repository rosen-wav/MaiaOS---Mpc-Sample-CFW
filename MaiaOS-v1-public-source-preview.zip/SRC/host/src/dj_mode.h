#ifndef PC_DJ_MODE_H
#define PC_DJ_MODE_H

int pc_dj_fader(void);
int pc_dj_open(void);
int pc_dj_import(void);
void pc_dj_poll(void);
int pc_dj_browser_frame(uintptr_t);
void pc_dj_browser_layout(uintptr_t);
void pc_dj_browser_paint(uintptr_t,uintptr_t);
void pc_dj_rotate(int);
void pc_dj_fx_shift(unsigned);
void pc_dj_knob(unsigned,unsigned);
void pc_dj_fader_position(unsigned);
void pc_dj_pad(unsigned,unsigned);
void pc_dj_transport(unsigned);
void pc_dj_sd_suspend(void);
int pc_dj_raw_pressure(uintptr_t,float);
int pc_dj_panel_pad(uintptr_t,unsigned,float);
uint64_t pc_dj_colour(uintptr_t,uint64_t);
void pc_dj_lights(void);
uintptr_t pc_import_current(void);
int pc_import_selected_path(uintptr_t,char*,unsigned);
void pc_dj_event(unsigned);
void pc_dj_paint(uintptr_t,uintptr_t);
void pc_dj_visibility(uintptr_t,unsigned);

#endif
