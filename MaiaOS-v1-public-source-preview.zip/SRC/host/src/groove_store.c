/* Trigger-only files, with fixed numeric paths, bounded reads and CRC. */
#include "internal.h"
#include "groove.h"
#include "groove_store.h"
static const char root[]="/media/MPCSSH/grooves";
static const char*folders[]={"Kick","Snare","Hi-hat","Percussion"};
typedef struct {char magic[8],name[24];int64_t span;uint32_t count,version,crc,reserved[3];PcStoredHit hits[PC_GROOVE_HITS_MAX];} Disk;
_Static_assert(offsetof(Disk,hits)==64,"groove disk header");
static Disk disk;
static uint32_t crc(const void*bytes,unsigned n){const uint8_t*p=bytes;uint32_t c=~0u;while(n--){c^=*p++;for(unsigned k=0;k<8;k++)c=c>>1^(0xedb88320u&-(c&1));}return ~c;}
static int transfer(long fd,void*data,unsigned n,int write){unsigned done=0;while(done<n){long v=pc_sys(write?64:63,fd,(long)((uint8_t*)data+done),n-done,0,0,0);if(v==-4)continue;if(v<=0||v>(long)(n-done))return 0;done+=v;}return 1;}
static void folderpath(char*p,unsigned f){unsigned n=sizeof root-1;memcpy(p,root,n);p[n++]='/';const char*s=folders[f];while(*s)p[n++]=*s++;p[n]=0;}
static void path(char*p,unsigned f,unsigned id,int tmp){folderpath(p,f);unsigned n=0;while(p[n])n++;p[n++]='/';p[n++]='0'+id/100;p[n++]='0'+id/10%10;p[n++]='0'+id%10;memcpy(p+n,tmp?".tmp":".pcg",5);}
int pc_groove_read(unsigned f,unsigned id,PcStoredGroove*out,char name[25]){
 if(f>=4||id>=PC_GROOVE_SAVED_MAX)return -1;char p[96];path(p,f,id,0);
 long fd=pc_sys(56,-100,(long)p,0x88800,0,0,0);if(fd==-2)return 0;if(fd<0)return -1;
 int ok=transfer(fd,&disk,64,0);
 if(ok)ok=!memcmp(disk.magic,"MPCGRV01",8)&&disk.version==1&&disk.count&&disk.count<=PC_GROOVE_HITS_MAX&&disk.span>0&&disk.span<=128LL*122880;
 if(ok)for(unsigned n=0;n<24;n++)if(disk.name[n]&&(disk.name[n]<32||disk.name[n]>126)){ok=0;break;}
 if(ok&&out){
  unsigned size=disk.count*sizeof(PcStoredHit);ok=transfer(fd,disk.hits,size,0);uint8_t extra;
  if(ok)ok=pc_sys(63,fd,(long)&extra,1,0,0,0)==0;
  uint32_t expected=disk.crc;disk.crc=0;if(ok)ok=expected==crc(&disk,64+size);
  int64_t previous=-1;
  for(unsigned n=0;ok&&n<disk.count;n++){PcStoredHit*h=&disk.hits[n];ok=h->tick>=0&&h->tick<disk.span&&h->tick>=previous&&h->velocity>0&&h->velocity<=1&&!h->reserved;previous=h->tick;}
  if(ok){memcpy(out->name,disk.name,24);out->name[24]=0;out->span=disk.span;out->count=disk.count;memcpy(out->hits,disk.hits,size);}
 }
 pc_sys(57,fd,0,0,0,0,0);
 if(ok&&name){memcpy(name,disk.name,24);name[24]=0;}return ok?1:-1;
}
int pc_groove_write(unsigned f,unsigned id,const PcStoredGroove*pattern){
 if(f>=4||id>=PC_GROOVE_SAVED_MAX||!pattern||!pattern->count||pattern->count>PC_GROOVE_HITS_MAX)return 0;
 long mk=pc_sys(34,-100,(long)root,0770,0,0,0);if(mk<0&&mk!=-17)return 0;
 char dir[96],p[96],tmp[96];folderpath(dir,f);mk=pc_sys(34,-100,(long)dir,0770,0,0,0);if(mk<0&&mk!=-17)return 0;
 memset(&disk,0,64);memcpy(disk.magic,"MPCGRV01",8);memcpy(disk.name,pattern->name,24);disk.span=pattern->span;disk.count=pattern->count;disk.version=1;
 unsigned bytes=64+disk.count*sizeof(PcStoredHit);memcpy(disk.hits,pattern->hits,bytes-64);disk.crc=crc(&disk,bytes);
 path(p,f,id,0);path(tmp,f,id,1);long fd=pc_sys(56,-100,(long)tmp,0x88800|1|64|512,0660,0,0);if(fd<0)return 0;
 int ok=transfer(fd,&disk,bytes,1);if(ok)ok=!pc_sys(82,fd,0,0,0,0,0);if(pc_sys(57,fd,0,0,0,0,0))ok=0;
 if(ok)ok=!pc_sys(276,-100,(long)tmp,-100,(long)p,1,0);
 if(!ok)pc_sys(35,-100,(long)tmp,0,0,0,0);
 else {fd=pc_sys(56,-100,(long)dir,0x8c000,0,0,0);if(fd>=0){pc_sys(82,fd,0,0,0,0,0);pc_sys(57,fd,0,0,0,0,0);}}
 return ok;
}
