/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "bounce.h"

/* AC50MidiProperties is registered once for the application lifetime.
 * MIDI Sync In is Off=0, MIDI Clock=1, MTC=2. The selected setting is
 * authoritative before the first MIDI pulse and while transport is stopped. */
static uintptr_t midi_properties;
static unsigned hooks_installed;

void pc_flex_clock_poll(void)
{
    if (__atomic_load_n(&hooks_installed, AQ) && !__atomic_load_n(&midi_properties, AQ)) {
        uintptr_t properties = pc_bounce_service(host.base+0x6e16fc0);
        if (properties)
            __atomic_store_n(&midi_properties, properties, RL);
    }
}

int pc_flex_clock_external(void)
{
    uintptr_t properties = __atomic_load_n(&midi_properties, AQ);
    return properties && __atomic_load_n((const int32_t *)(properties+0x94), AQ) == 1;
}

static void flex_process(uintptr_t player, uintptr_t buffer, uintptr_t midi)
{
    /* The native float processor is in-place. Leaving its input untouched
     * is an immediate dry bypass, with no ramp, no DSP and no preset edit. */
    if (!pc_flex_clock_external())
        FN(0x25070d0,void(*)(uintptr_t,uintptr_t,uintptr_t))(player,buffer,midi);
}

static void flex_trigger(uintptr_t interaction, unsigned pad)
{
    if (!pc_flex_clock_external())
        FN(0x152d9e0,void(*)(uintptr_t,unsigned))(interaction,pad);
}

void pc_flex_clock_init(void)
{
    uintptr_t audio = host.base+0x6ea9fe0, trigger = host.base+0x6d8d348;
    if (Q(audio,0) != host.base+0x25070d0 || Q(audio,-0x40) != host.base+0x6ea9f30 ||
        Q(trigger,0) != host.base+0x152d9e0 || Q(trigger,-0x20) != host.base+0x6e0f2f8)
        return;
    void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
    int(*page_size)(void)=symbol(0,"getpagesize");
    unsigned size = page_size ? page_size() : 0;
    if (size != 4096 && size != 16384 && size != 65536) return;
    uintptr_t audio_page = audio & ~((uintptr_t)size-1), trigger_page = trigger & ~((uintptr_t)size-1);
    if (pc_sys(226,audio_page,size,3,0,0,0)) return;
    if (pc_sys(226,trigger_page,size,3,0,0,0)) {
        pc_sys(226,audio_page,size,1,0,0,0);
        return;
    }
    __atomic_store_n((uintptr_t*)audio,(uintptr_t)flex_process,RL);
    __atomic_store_n((uintptr_t*)trigger,(uintptr_t)flex_trigger,RL);
    pc_sys(226,trigger_page,size,1,0,0,0);
    pc_sys(226,audio_page,size,1,0,0,0);
    __atomic_store_n(&hooks_installed, 1, RL);
    pc_flex_clock_poll();
}
