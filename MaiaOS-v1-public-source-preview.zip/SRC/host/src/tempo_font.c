/* r22: native BPM and ERASE are intentionally left untouched. */
#include "internal.h"
void pc_editorial_tempo_font(unsigned active){(void)active;}
