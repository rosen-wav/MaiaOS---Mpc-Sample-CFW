/* SPDX-License-Identifier: GPL-3.0-only
 * Extension libraries keep independent state per slot and per UI/preview owner.
 * All dlopen/dlsym work runs at initialization or on the UI thread.
 */
#include "internal.h"
#include "bounce.h"
static Dsp extra[PC_SLOTS],mirror_old,mirror_new,preview_old,preview_new;
static void(*tempo_fn[PC_SLOTS])(float);
static unsigned tempo_milli=120000,ready;
static void(*preview_tempo)(float);
Dsp*pc_engine_dsp(Slot*s,unsigned engine){return engine>=7&&engine<=9?&extra[s-host.slots]:&s->dsp;}
Dsp*pc_slot_dsp(Slot*s){return pc_engine_dsp(s,s->audio_engine);}
unsigned pc_engine_count(unsigned e){if(e==3||e==5||e==6||e>9)return 0;return e>=7?mirror_new.count?mirror_new.count(e):0:mirror_old.count?mirror_old.count(e):host.mirror.count(e);}
int pc_mirror_use(unsigned e){if(e==3||e==5||e==6||e>9||!ready)return 0;host.mirror=e>=7?mirror_new:mirror_old;return 1;}
int pc_new_engines_init(void){
 mirror_old=host.mirror;
 char path[]="/run/mpc-pc-integrated-v040/libpc-new-00.aarch64.so";
 for(unsigned k=0;k<PC_SLOTS;k++){
  path[38]='0'+k/10;path[39]='0'+k%10;
  if(!pc_load_dsp(&extra[k],path,0))return 0;
  void*h=FN(0xb518a8,void*(*)(const char*,int))(path,2);if(!h)return 0;
  tempo_fn[k]=FN(0xb51898,void*(*)(void*,const char*))(h,"mpc_synth_tempo");if(!tempo_fn[k])return 0;
 }
 if(!pc_load_dsp(&mirror_new,"/run/mpc-pc-integrated-v040/libpc-new-editor.aarch64.so",1))return 0;
 ready=1;return 1;
}
int pc_preview_backend(unsigned e){Dsp*d=e>=7?&preview_new:&preview_old;
 if(!d->version&&!pc_load_dsp(d,e>=7?"/run/mpc-pc-integrated-v040/libpc-new-preview.aarch64.so":"/run/mpc-pc-integrated-v040/libpc-preview.aarch64.so",0))return 0;
 if(e>=7&&!preview_tempo){void*h=FN(0xb518a8,void*(*)(const char*,int))("/run/mpc-pc-integrated-v040/libpc-new-preview.aarch64.so",2);if(!h)return 0;preview_tempo=FN(0xb51898,void*(*)(void*,const char*))(h,"mpc_synth_tempo");if(!preview_tempo)return 0;}
 host.preview=*d;if(e==8||e==9)preview_tempo(__atomic_load_n(&tempo_milli,AQ)*.001f);return 1;
}
void pc_new_tempo_poll(void){uintptr_t t=pc_bounce_service(host.base+0x6e08fe0);if(!t)return;float f=I(t,0x208)==1?F(t,0x1b0):F(t,0x158);if(f>=20&&f<=999)__atomic_store_n(&tempo_milli,(unsigned)(f*1000+.5f),RL);}
void pc_new_tempo_audio(Slot*s){unsigned k=s-host.slots;if((s->audio_engine==8||s->audio_engine==9)&&tempo_fn[k])tempo_fn[k](__atomic_load_n(&tempo_milli,AQ)*.001f);}
