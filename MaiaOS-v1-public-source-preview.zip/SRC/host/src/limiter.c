#include "internal.h"
#include "limiter.h"
#include "stock_caption.h"
#include "../theme/layout.h"

static struct {
 unsigned open,enabled,revision,bank;
 unsigned values[7];
 int mode;
 uintptr_t screen;
} limiter={.values={0,0,8192,8192,8192,8192,16383}};

static const unsigned parameters[]={5,1,0,2,3,4,6};

static int current_mode(void){
 uintptr_t b=Q(pc_state_base(),0x20),manager=b?Q(b,0x30):0;
 if(!manager)return 0;
 int id=I(manager,0xd8);return id==0x3080?I(manager,0x80):id;
}
/* Same stock caption component used by Compressor's Color and Bypass
 * actions. Its parent owns layout and paint. B2 itself remains a raw key. */
static PcStockCaption mastering_caption;
static void mastering_key(uintptr_t screen,unsigned visible){
 if(!host.ready||!screen||Q(screen,0)!=host.base+0x6e1bf30)return;
 if(!visible){pc_stock_caption_hide(mastering_caption,screen);return;}
 uintptr_t b1=screen+0x118,b3=screen+0x338;
 if(Q(b1,0)!=host.base+0x706e940||Q(b3,0)!=host.base+0x706e940)return;
 int x=I(b1,0x20)+I(b1,0x28),y=I(b1,0x24);
 int width=I(b3,0x20)-x,height=I(b1,0x2c);
 if(x<0||y<0||width<60||width>180||height<12||height>64)return;
 pc_stock_caption_show(mastering_caption,screen,"Mastering",x,y,width,height);
}
static void compressor_labels(uintptr_t screen){
 if(Q(screen,0)!=host.base+0x6e1bf30)return;
 uintptr_t color=screen+0x118,threshold=screen+0x1eb8;
 if(Q(color,0)==host.base+0x706e940&&(*(uint8_t*)(color+0xa8)&2))
  FN(0x1172670,void(*)(uintptr_t,unsigned))(color,0);
 if(Q(threshold,0)!=host.base+0x706e5d0)return;
 const char *name=(const char*)Q(threshold,8);
 if(name&&!memcmp(name,"Amount",7)){
  uintptr_t title=0;
  FN(0xf535c0,void(*)(uintptr_t*,const char*))(&title,"Threshold");
  FN(0x116e8b0,void(*)(uintptr_t,const uintptr_t*))(threshold,&title);
  FN(0xf0a290,void(*)(uintptr_t*))(&title);
 }
}
int pc_limiter_compressor(void){
 int id=__atomic_load_n(&limiter.mode,AQ);
 return id&&id==current_mode();
}
int pc_limiter_scope(void){
 if(pc_limiter_compressor())return __atomic_load_n(&limiter.open,AQ);
 __atomic_store_n(&limiter.open,0,RL);return 0;
}
unsigned pc_limiter_enabled(void){return __atomic_load_n(&limiter.enabled,AQ);}
void pc_limiter_event(unsigned kind,unsigned data){
 if(!pc_limiter_compressor())return;
 if(kind==55){
  if(data==1&&!pc_limiter_scope()){
   limiter.bank=0;__atomic_store_n(&limiter.open,1,RL);
  }else if(data==0){
   __atomic_store_n(&limiter.open,0,RL);
  }else if(data==1&&pc_limiter_scope()){
   __atomic_add_fetch(&limiter.revision,1,RL);
   __atomic_fetch_xor(&limiter.enabled,1,RL);
  }
 }else if(pc_limiter_scope()&&kind==56){
  int64_t bank=(int64_t)limiter.bank+(int32_t)data;
  limiter.bank=bank<0?0:bank>2?2:(unsigned)bank;
 }else if(pc_limiter_scope()&&kind==57){
  unsigned p=limiter.bank*3+(data>>16);
  if(p<7)__atomic_store_n(&limiter.values[parameters[p]],data&16383,RL);
 }
 if(limiter.screen){mastering_key(limiter.screen,!pc_limiter_scope());FN(0x1149d70,void(*)(uintptr_t))(limiter.screen);}
}

void pc_mastering2_process(float*,float*,unsigned,const unsigned*,unsigned);
static float with_headroom(float dry,float processed){
 float total=dry+processed;
 float upper=dry>.999f?dry:.999f,lower=dry<-.999f?dry:-.999f;
 return total>upper?upper:total<lower?lower:total;
}
void pc_limiter_process(float*l,float*r,const float*dry_l,const float*dry_r,unsigned n,unsigned epoch){
 static unsigned previous_epoch,previous_revision;
 unsigned values[7],revision=__atomic_load_n(&limiter.revision,AQ);
 for(unsigned p=0;p<7;p++)values[p]=__atomic_load_n(&limiter.values[p],AQ);
 for(unsigned j=0;j<n;j++){l[j]-=dry_l[j];r[j]-=dry_r[j];}
 pc_mastering2_process(l,r,n,values,previous_epoch!=epoch||previous_revision!=revision);
 previous_epoch=epoch;previous_revision=revision;
 for(unsigned j=0;j<n;j++){l[j]=with_headroom(dry_l[j],l[j]);r[j]=with_headroom(dry_r[j],r[j]);}
}
static void rect(void*g,int x,int y,int w,int h,unsigned c){
 FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,pc_theme_colour(c));
 FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);
}
void pc_limiter_visibility(uintptr_t screen,unsigned visible){
 if(!(visible&1)&&limiter.screen==screen){
  __atomic_store_n(&limiter.open,0,RL);
  __atomic_store_n(&limiter.mode,0,RL);
  limiter.screen=0;
 }
 FN(0x15f4a70,void(*)(uintptr_t,unsigned))(screen,visible);
 if((visible&1)&&screen&&host.ready)compressor_labels(screen);
 mastering_key(screen,visible&1);
}
void pc_limiter_paint(uintptr_t screen,uintptr_t graphics){
 FN(0x10e2e10,void(*)(uintptr_t,uintptr_t))(screen,graphics);
 if(!host.ready||!screen||!graphics)return;
 int mode=current_mode();
 if(__atomic_load_n(&limiter.mode,AQ)!=mode)__atomic_store_n(&limiter.open,0,RL);
 limiter.screen=screen;__atomic_store_n(&limiter.mode,mode,RL);
 typedef struct {uint64_t xy,wh;}Bounds;
 Bounds b=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(uint32_t)b.wh,h=b.wh>>32;
 if(w<200||h<130||w>1024||h>1024)return;
 EiCanvas c={(void*)graphics,rect,w,h};
 if(!pc_limiter_scope()){
  compressor_labels(screen);
  mastering_key(screen,1);
  return;
 }
 static const char*const names[]={"DRIVE","GLUE","SIDEPASS","SCOPE","SKRONK","GIRTH","DITHER"};
 static const char*const dither[]={"DARK","TEN NINES","TPDF WIDE","PAUL WIDE","NJAD","BYPASS"};
 char page[]="ENC: PAGE 1/3";page[10]+=limiter.bank;
 unsigned enabled=pc_limiter_enabled(),tall=h>=190;
 ei_header(&c,"OUTPUT FX / MASTERING",enabled?"ON":"BYPASS");
 if(tall)ei_heading(&c,8,30,"mastering.",w-16);
 else ei_value(&c,8,27,"mastering.",w-16,22,MPC_THEME_TEXT);
 ei_text(&c,8,tall?64:55,page,w-16,MPC_THEME_MUTED);
 int label_y=tall?100:h<150?67:73,value_y=label_y+(tall?20:13),bar_y=tall?h-57:h-28;
 for(unsigned k=0;k<3&&3*limiter.bank+k<7;k++){
  unsigned index=3*limiter.bank+k,p=parameters[index],v=__atomic_load_n(&limiter.values[p],AQ);
  unsigned pct=(100*v+8191)/16383;
  char number[5]={'0'+pct/100,'0'+pct/10%10,'0'+pct%10,'%',0};
  char label[16]={'K','1'+k,' ',0};
  unsigned n=0;while(names[index][n]){label[3+n]=names[index][n];n++;}label[3+n]=0;
  int x=8+k*w/3,width=w/3-16;
  if(k)ei_rect(&c,k*w/3,label_y-3,1,bar_y-label_y+7,MPC_THEME_GRID);
  ei_text(&c,x,label_y,label,width,MPC_THEME_MUTED);
  ei_value(&c,x,value_y,p==6?dither[v*5999u/16383000u]:number+(pct<100)+(pct<10),
           width,tall?26:18,MPC_THEME_TEXT);
  ei_bar(&c,x,bar_y,width,v);
 }
 ei_actions(&c,"BACK",enabled?"BYPASS":"ENABLE","");
}
