/* Lightweight custom Guitar Amp, distinct from Akai's stock algorithm. */
#include "internal.h"
static struct {float bass[2],cab[2],dc[2],prev[2];unsigned generation;} amp[3];
static float sat(float x){float a=x<0?-x:x;return x/(1.f+a);}
void pc_amp_process(unsigned slot,float*l,float*r,unsigned n,const float*p,unsigned gen){
 if(slot>=3)return;if(amp[slot].generation!=gen){memset(&amp[slot],0,sizeof amp[slot]);amp[slot].generation=gen;}
 float drive=1.f+24.f*p[0],level=.05f+1.9f*p[5],cab=p[4];
 for(unsigned j=0;j<n;j++)for(unsigned c=0;c<2;c++){
  float *v=c?r:l,x=v[j];if(!(x>=-1000000.f&&x<=1000000.f))x=0;
  amp[slot].bass[c]+=.028f*(x-amp[slot].bass[c]);
  float lo=amp[slot].bass[c],hi=x-lo;
  x=lo*(.25f+1.5f*p[1])+hi*(.25f+1.5f*p[3]);
  x=sat(x*drive)*( .5f+p[2]);
  amp[slot].cab[c]+=.22f*(x-amp[slot].cab[c]);x=x*(1.f-cab)+amp[slot].cab[c]*cab;
  float y=x-amp[slot].prev[c]+.995f*amp[slot].dc[c];amp[slot].prev[c]=x;amp[slot].dc[c]=y;v[j]=y*level;
 }
}
