/* Fixed limits shared by all custom synth slots. Audio owns backend queries;
 * UI/native guards never allocate or mutate a live synth. */
#include "internal.h"
#include "bounce.h"
#include "sample_playback.h"
static unsigned poly_notice,shutdown_scope,shutdown_queued,shutdown_launched;
static int shutdown_label(const char*s){
 const char*labels[]={"shut down","shutdown","power off","spegni","spegnimento"};if(!s)return 0;
 for(unsigned n=0;n<5;n++){unsigned j=0;while(labels[n][j]){unsigned c=(unsigned char)s[j];if(c>='A'&&c<='Z')c+=32;if(c!=(unsigned char)labels[n][j])break;j++;}if(!labels[n][j])return 1;}return 0;
}
static void queue_shutdown(unsigned delay){
 unsigned old=__atomic_load_n(&shutdown_queued,AQ);
 while((!old||delay<old)&&!__atomic_compare_exchange_n(&shutdown_queued,&old,delay,0,__ATOMIC_ACQ_REL,AQ)){}
 pc_sys(98,(long)&shutdown_queued,129,1,0,0,0);
}
/* This vtable belongs only to ShutdownImageComponent. Its native caller
 * displays it after the shutdown request, outside the confirmation dialog. */
static void shutdown_screen(uintptr_t screen,int flags,uintptr_t window){
 if(screen&&Q(screen,0)==host.base+0x6e99270){pc_diag_flag(28,256);queue_shutdown(20);}
 FN(0x1179230,void(*)(uintptr_t,int,uintptr_t))(screen,flags,window);
}
/* Independent of the native message loop and the project archive lock. */
static void*shutdown_watch(void*unused){
 (void)unused;pc_sys(167,15,(long)"Maia Shutdown",0,0,0,0);
 for(;;){
  while(!__atomic_load_n(&shutdown_queued,AQ))pc_sys(98,(long)&shutdown_queued,128,0,0,0,0);
  for(unsigned elapsed=0;elapsed<__atomic_load_n(&shutdown_queued,AQ);elapsed++){
   long delay[2]={1,0};
   while(pc_sys(101,(long)delay,(long)delay,0,0,0,0)==-4){}
  }
  __atomic_store_n(&shutdown_queued,0,RL);
  if(!__atomic_exchange_n(&shutdown_launched,1,__ATOMIC_ACQ_REL)){
   pc_diag_flag(28,16);
   long child=pc_sys(220,17,0,0,0,0,0);
   if(child==0){
    char*args[]={"systemctl","--no-block","poweroff",0};char*env[]={"PATH=/usr/sbin:/usr/bin:/sbin:/bin",0};
    pc_sys(221,(long)"/usr/bin/systemctl",(long)args,(long)env,0,0,0);
    pc_sys(221,(long)"/bin/systemctl",(long)args,(long)env,0,0,0);pc_sys(94,127,0,0,0,0,0);
   }else if(child>0){int status=0;pc_sys(260,child,(long)&status,0,0,0,0);if(status){pc_diag_flag(28,64);__atomic_store_n(&shutdown_launched,0,RL);}}
   else{pc_diag_flag(28,32);__atomic_store_n(&shutdown_launched,0,RL);}
  }
 }return 0;
}
void pc_shutdown_watch_init(void){
 void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 int(*create)(uintptr_t*,const void*,void*(*)(void*),void*)=symbol(0,"pthread_create");int(*detach)(uintptr_t)=symbol(0,"pthread_detach");
 uintptr_t tid;
 if(!create||!detach||create(&tid,0,shutdown_watch,0)!=0){pc_diag_flag(28,128);return;}
 detach(tid);
 int(*pagesize)(void)=symbol(0,"getpagesize");
 uintptr_t slot=host.base+0x6e992e0;
 if(!pagesize||Q(slot,0)!=host.base+0x1179230||Q(slot,-0x78)!=host.base+0x6e99470||
    (uint32_t)I(host.base,0x23de400)!=0xf9403863u||(uint32_t)I(host.base,0x23de404)!=0xd63f0060u){pc_diag_flag(28,512);return;}
 unsigned size=pagesize();if(size!=4096&&size!=16384&&size!=65536){pc_diag_flag(28,512);return;}
 uintptr_t page=slot&~((uintptr_t)size-1);
 if(pc_sys(226,page,size,3,0,0,0)){pc_diag_flag(28,512);return;}
 __atomic_store_n((uintptr_t*)slot,(uintptr_t)shutdown_screen,RL);
 if(pc_sys(226,page,size,1,0,0,0))pc_diag_flag(28,1024);
 else pc_diag_flag(28,2048);
}

/* Admission belongs to an onset, never to the lifetime of its voices.
 * Native timing is a sample offset in the current hardware callback. Both
 * producers admit before dispatch, independent of per-slot render order. */
void pc_trigger_block(void){}
int pc_trigger_admit(unsigned sample,unsigned offset,unsigned cost){
 if(sample>1||offset>=4096||!cost)return 0;
 return pc_bounce_time_ns()||!pc_cpu_overloaded();
}
void pc_poly_forget(Slot*s){__atomic_store_n(&s->voice_mask,0,RL);}
static const unsigned voice_caps[]={5,5,10,6,8,16,16,8,8,8};
static unsigned gated_voices(Slot*s){
 unsigned e=s->audio_engine;
 if(pc_context_engine(e)||e==4)return s->held_keys;
 if(e<3&&s->poly_mode_valid){
  if(!s->poly_mode)return s->held_keys; /* Includes notes queued for the next DSP block. */
  if(s->poly_mode==3)return s->held_keys?voice_caps[e]:0;
  return s->held_keys!=0;
 }
 return pc_slot_dsp(s)->held();
}
void pc_poly_sync(Slot*s){
 /* Diagnostic gate count only. Gates and release tails cannot reserve the
  * next onset's budget. Backend capacity remains protected separately. */
 unsigned held=gated_voices(s);
 __atomic_store_n(&s->voice_mask,held,RL);
 if(!held){Dsp*d=pc_slot_dsp(s);unsigned active=pc_context_engine(s->audio_engine)?pc_ms_voices(s->multisample):s->audio_engine==4?pc_fm6_voices((unsigned)(s-host.slots)):d->voices?d->voices():0;if(!active)s->sequence_protected=0;}
}
void pc_poly_reject(void){
 pc_diag_add(24);
 __atomic_fetch_add(&poly_notice,1,RL);
}
unsigned pc_poly_notice(void){return __atomic_load_n(&poly_notice,AQ);}
int pc_poly_reserve(Slot*s){
 unsigned e=s->audio_engine,cap=e<10?voice_caps[e]:128u,want=1;
 if(e==4)return pc_fm6_voices((unsigned)(s-host.slots))<PC_FM6_VOICES;
 Dsp*d=pc_slot_dsp(s);
 if(e<3&&!s->poly_mode_valid){
  uint8_t patch[512];
  if(!d->save(patch)||memcmp(patch,"MPCSYN01",8))return 0;
  s->poly_mode=patch[106]|(unsigned)patch[107]<<8;
  if(s->poly_mode>3)return 0;
  s->poly_mode_valid=1;
 }
 pc_poly_sync(s);
 unsigned old=__atomic_load_n(&s->voice_mask,AQ);
 if(e==PC_MS_ENGINE)cap=PC_MS_VOICES;
 unsigned active=pc_context_engine(e)?pc_ms_voices(s->multisample):d->voices?d->voices():old;
 if(e<3){
  if(s->poly_mode==3)want=old?0:cap;
  else if(s->poly_mode&&old)want=0;
 }else if(e!=PC_MS_ENGINE&&d->attack_cost)want=d->attack_cost();
 /* Explicit mono/legato/unison modes retain their programmed behavior.
  * Polyphonic engines may start only when all required lanes are free. */
 if(old+want>cap||(want&&active+want>cap)){
  pc_poly_reject();return 0;
 }
 return 1;
}
void pc_dsp_attack(Slot*s,unsigned note,unsigned velocity){
 pc_slot_dsp(s)->on(note,velocity);
}
static unsigned bits(unsigned v){unsigned n=0;while(v){v&=v-1;n++;}return n;}
unsigned pc_performance_gate(unsigned action,uintptr_t packet,unsigned mode){
 if(action==0xfffffffcu){
  if(!mode){__atomic_store_n(&shutdown_scope,(unsigned)packet,RL);return 0;}
  unsigned prior=__atomic_load_n(&shutdown_scope,AQ);uintptr_t label=packet?Q(packet,0):0;
  const char*s=label?(const char*)Q(label,0):0;
  if(shutdown_label(s)){__atomic_store_n(&shutdown_scope,prior+1,RL);pc_diag_flag(28,1);}return prior;
 }
 if(action==0xfffffffbu){
  if(__atomic_load_n(&shutdown_scope,AQ)){pc_diag_flag(28,2);queue_shutdown(2);}
  return 0;
 }
 if(action!=0xfffffffdu||!packet)return 0;
 uintptr_t self=Q(packet,0),props=self?Q(self,0x40):0,effect=props?Q(props,0x88):0;
 if(!props||Q(props,0)!=host.base+0x6da2618||!effect||FN(0x2754590,unsigned(*)(uintptr_t))(effect)<80)return 0;
 uintptr_t d=Q(effect,0xe0),owner=d?Q(d,0):0;
 if(!owner||Q(owner,0)!=host.base+0x6ec8a30||I(d,8)!=0x101)return 0;
 unsigned pad=(unsigned)Q(packet,8)&15;float value=F(packet,16);
 if(!(value>=0&&value<=1))return 0;
 static uintptr_t selected;static unsigned reserved,epoch;
 unsigned gen=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);if(effect!=selected||epoch!=gen){selected=effect;reserved=0;epoch=gen;}
 if(mode==2){reserved=0;return 0;}
 if(value<=.00001f){reserved&=~(1u<<pad);return 0;}
 unsigned active=reserved;
 for(unsigned j=0;j<16;j++){
  float pressure=FN(0x2755220,float(*)(uintptr_t,unsigned))(effect,5*j),latch=FN(0x2755220,float(*)(uintptr_t,unsigned))(effect,5*j+1);
  if(pressure>.00001f||latch>.5f)active|=1u<<j;
 }
 if(!(active&(1u<<pad))&&bits(active)>=3){pc_diag_add(26);return 1;}
 reserved|=1u<<pad;return 0;
}
void pc_shutdown_missing_continue(void){
 if(!__atomic_load_n(&shutdown_queued,AQ))return;
 pc_diag_flag(28,4);host.ui.message="Shutdown requested; project save failed";
 pc_sys(98,(long)&shutdown_queued,129,1,0,0,0);
}
