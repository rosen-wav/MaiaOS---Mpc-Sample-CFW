/* SPDX-License-Identifier: GPL-3.0-only
 * Silence the final output planes while MassStorageScreen owns the SD. */
#include "internal.h"
#include "dj_mode.h"

static unsigned sd_access_active;

unsigned pc_sd_access_muted(void){
 return __atomic_load_n(&sd_access_active,AQ);
}
void pc_sd_access_visibility(uintptr_t screen,unsigned visible){
 if(visible&1){
  if(!__atomic_exchange_n(&sd_access_active,1,RL)){
   pc_preview_stop();
   pc_dj_sd_suspend();
  }
 }
 FN(0x1172670,void(*)(uintptr_t,unsigned))(screen,visible);
 if(!(visible&1))__atomic_store_n(&sd_access_active,0,RL);
}

void pc_sd_access_silence(float **outputs,unsigned channels,unsigned frames){
 if(!__atomic_load_n(&sd_access_active,AQ)||!outputs||channels>32||frames>4096)return;
 for(unsigned channel=0;channel<channels;channel++)
  if(outputs[channel])memset(outputs[channel],0,frames*sizeof(float));
}
