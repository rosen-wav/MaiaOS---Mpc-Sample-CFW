/* Bounded TAL-BassLine-101 XML/VST3 importer, UI owner only, no I/O.
 * Parameter mapping follows supplied Charles Vestal MIT HUSH ONE source.
 * Unknown DSP features are reported, never executed. */
#include <stdint.h>
#include <stddef.h>
extern int memcmp(const void*,const void*,size_t);
extern void*memcpy(void*,const void*,size_t);
#include "../dsp/new/rs01/rs_patch.h"
static const uint8_t*find(const uint8_t*p,unsigned n,const char*s){unsigned k=0;while(s[k])k++;if(k>n)return 0;for(unsigned i=0;i<=n-k;i++)if(!memcmp(p+i,s,k))return p+i;return 0;}
static uint64_t get64(const uint8_t*p){uint64_t x=0;for(unsigned i=0;i<8;i++)x|=(uint64_t)p[i]<<(8*i);return x;}
static unsigned get32(const uint8_t*p){return p[0]|(unsigned)p[1]<<8|(unsigned)p[2]<<16|(unsigned)p[3]<<24;}
static int numeric(const uint8_t*p,unsigned n,float*out){unsigned i=0,digits=0;float x=0,scale=1;int negative=0;if(i<n&&(p[i]=='+'||p[i]=='-'))negative=p[i++]=='-';while(i<n&&p[i]>='0'&&p[i]<='9'){if(++digits>64)return 0;x=x*10+p[i++]-'0';}if(i<n&&p[i]=='.'){i++;while(i<n&&p[i]>='0'&&p[i]<='9'){if(++digits>64)return 0;scale*=.1f;x+=(p[i++]-'0')*scale;}}if(!digits)return 0;
 if(i<n&&(p[i]=='e'||p[i]=='E')){i++;int neg=0,e=0,k=0;if(i<n&&(p[i]=='+'||p[i]=='-'))neg=p[i++]=='-';while(i<n&&p[i]>='0'&&p[i]<='9'){if(++k>2)return 0;e=e*10+p[i++]-'0';}if(!k||e>30)return 0;while(e--)x*=neg?.1f:10;}
 if(i!=n)return 0;if(negative)x=-x;if(!(x>=0&&x<=1))return 0;*out=x;return 1;}
static int equal(const uint8_t*p,unsigned n,const char*s){unsigned k=0;while(s[k])k++;return k==n&&!memcmp(p,s,n);}
int pc_rs_import(const uint8_t*b,unsigned bytes,uint8_t*out,char*name,unsigned*warnings){
 if(!b||!out||!name||!warnings||bytes<10||bytes>1048576)return 0;
 const uint8_t*xml=b;unsigned size=bytes;
 if(bytes>=4&&!memcmp(b,"VST3",4)){
  if(bytes<48||get32(b+4)!=1)return 0;uint64_t off=get64(b+40);if(off<48||off>bytes-8||memcmp(b+off,"List",4))return 0;
  unsigned chunks=get32(b+off+4);if(chunks>64||chunks>(bytes-off-8)/20)return 0;xml=0;
  for(unsigned j=0;j<chunks;j++){const uint8_t*c=b+off+8+20*j;uint64_t at=get64(c+4),n=get64(c+12);if(at<48||at>off||n>off-at)return 0;if(!memcmp(c,"Comp",4)){if(xml)return 0;xml=b+at;size=(unsigned)n;}}
  if(!xml)return 0;
 }
 const uint8_t*tal=find(xml,size,"<tal ");if(!tal)return 0;unsigned rem=size-(unsigned)(tal-xml);const uint8_t*end=find(tal,rem,"</tal>");if(!end)return 0;
 const uint8_t*program=find(tal,(unsigned)(end-tal),"<program ");if(!program)return 0;const uint8_t*stop=program;while(stop<end&&*stop!='>')stop++;if(stop==end||find(stop+1,(unsigned)(end-stop-1),"<program "))return 0;
 RsPatch p;rs_defaults(&p);memcpy(p.name,"Imported TAL",13);unsigned found=0,warn=0,seen[RS_N]={0};int gotname=0;
 const uint8_t*c=program+9;
 while(c<stop){while(c<stop&&(*c==' '||*c=='\t'||*c=='\r'||*c=='\n'||*c=='/'))c++;if(c==stop)break;const uint8_t*k=c;while(c<stop&&*c!='='&&*c!=' ')c++;unsigned kn=c-k;while(c<stop&&*c==' ')c++;if(c==stop||*c++!='=')return 0;while(c<stop&&*c==' ')c++;if(c==stop||(*c!='"'&&*c!='\''))return 0;uint8_t quote=*c++;const uint8_t*v=c;while(c<stop&&*c!=quote)c++;if(c==stop)return 0;unsigned vn=c-v;c++;
  if(equal(k,kn,"programname")){if(gotname++)return 0;unsigned n=0;for(unsigned j=0;j<vn&&n<23;j++){unsigned ch=v[j];p.name[n++]=ch>=32&&ch<=126?(char)ch:'?';}p.name[n]=0;continue;}
  for(unsigned i=0;i<RS_N;i++)if(RS_DESC[i].key[0]&&equal(k,kn,RS_DESC[i].key)){float f;if(seen[i]++||!numeric(v,vn,&f))return 0;p.value[i]=(unsigned)(f*1000+.5f);found++;break;}
  if(equal(k,kn,"arpenabled")||equal(k,kn,"seqenabled")||equal(k,kn,"fmintensity")){float f;if(!numeric(v,vn,&f))return 0;if(f>0)warn|=equal(k,kn,"arpenabled")?1:equal(k,kn,"seqenabled")?2:4;}
 }
 if(found<4||!seen[RS_CUTOFF]||!(seen[RS_SAW]||seen[RS_PULSE]||seen[RS_SUB]||seen[RS_NOISE]))return 0;
 memcpy(out,&p,RS_BYTES);memcpy(name,p.name,24);name[24]=0;*warnings=warn;return 1;
}
