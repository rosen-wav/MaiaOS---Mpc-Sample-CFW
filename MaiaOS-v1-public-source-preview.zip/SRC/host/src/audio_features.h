/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_AUDIO_FEATURES_H
#define PC_AUDIO_FEATURES_H
#include <stdint.h>
#define PC_CLICK_FRAMES 220500u
typedef struct { unsigned frames,rate;float samples[PC_CLICK_FRAMES]; } PcClick;
int pc_click_decode(PcClick *,const void *,unsigned);
void pc_audio_schedule(void);
void pc_audio_chord(unsigned key,unsigned down);
void pc_audio_poll(void);
int pc_audio_config_scope(void);
int pc_audio_open(unsigned page);
void pc_audio_state_poll(void);
unsigned pc_audio_page(void);
int pc_audio_event(unsigned,unsigned);
int pc_audio_paint(uintptr_t,int,int);
void pc_audio_input(uintptr_t,uintptr_t,unsigned,unsigned);
void pc_audio_tick(uintptr_t);
int pc_audio_click(uintptr_t,uintptr_t,unsigned,unsigned);
void pc_audio_info_write(uintptr_t);
void pc_audio_info_read(uintptr_t);
unsigned pc_input_send(unsigned);
void pc_mix_external(float *,float *,unsigned);
#endif
