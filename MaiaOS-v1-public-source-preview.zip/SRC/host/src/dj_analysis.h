/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_DJ_ANALYSIS_H
#define PC_DJ_ANALYSIS_H
#include <stdint.h>
#include <stddef.h>
#include "dj_qm.h"

#define DJ_PEAKS 32768
typedef struct {
 uint64_t frames;
 unsigned rate;
 float tagged_bpm;
 double beat_frames,first_beat; /* Zero period until an audible grid is located. */
 int downbeat;
 uint8_t peak[DJ_PEAKS];
 double first_transient;
 unsigned transient_valid;
 double first_downbeat;
 unsigned downbeat_valid;
} DjAnalysis;
typedef struct {
 uint64_t data,frames;
 unsigned rate,channels,bits,format,block;
} DjWav;
int pc_dj_wav_header(int,uint64_t,DjWav*);
int pc_dj_wav_read(int,void*,unsigned,uint64_t);
float pc_dj_pcm(const uint8_t*,const DjWav*);
typedef struct {
 void *handle;
 long (*seek)(void*,long,int);
 int (*read)(void*,void*,size_t,size_t*);
 void (*destroy)(void*);
} DjMp3;
typedef struct {
 int fd;
 DjWav format;
 DjMp3 mp3;
 uint64_t next,base;
 unsigned count,previous_valid;
 uint64_t previous_frame;
 float previous_left,previous_right;
 uint8_t bytes[16384];
} DjReader;
int pc_dj_reader_open(DjReader*,const char*);
void pc_dj_reader_close(DjReader*);
int pc_dj_reader_frame(DjReader*,uint64_t,float*,float*);
enum {DJ_OK,DJ_READ_ERROR,DJ_FORMAT_ERROR,DJ_TOO_LONG,DJ_MEMORY_ERROR,DJ_CACHE_ERROR};
double pc_dj_filename_bpm(const char*);
int pc_dj_analyse_progress(const char*,const char*,DjAnalysis*,DjProgress*);
int pc_dj_analyse(const char*,DjAnalysis*);
int pc_dj_analyse_named(const char*,const char*,DjAnalysis*);
int pc_dj_prepare_track(const char*,char*,unsigned);

#endif
