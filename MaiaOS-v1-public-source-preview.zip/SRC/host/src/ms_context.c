/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
void pc_ms_retire(Slot*s,uintptr_t p){unsigned w=__atomic_load_n(&s->retire_write,RX);s->retired[w%32]=p;__atomic_store_n(&s->retire_write,w+1,RL);}
void pc_ms_reap(Slot*s){unsigned r=__atomic_load_n(&s->retire_read,RX),w=__atomic_load_n(&s->retire_write,AQ);while(r!=w)pc_ms_free(s->retired[r++%32]);__atomic_store_n(&s->retire_read,r,RL);}
void pc_ms_dispose_locked(Slot*s){pc_discard_pad_notes(s);pc_ms_free(s->multisample);s->multisample=0;unsigned r=__atomic_load_n(&s->read,RX),w=__atomic_load_n(&s->write,AQ);while(r!=w){Command*c=&s->queue[r++%QUEUE];if(c->kind==1&&pc_context_engine(c->index))pc_ms_free(c->context);}__atomic_store_n(&s->read,w,RL);pc_ms_reap(s);s->audio_engine=0;__atomic_store_n(&host.debug->held[s-host.slots],0,RL);}
void*pc_read_file(const char*path,unsigned*size){const unsigned cap=8*1024*1024;long fd=pc_sys(56,-100,(long)path,0x88000,0,0,0);if(fd<0)return 0;long p=pc_sys(222,0,cap,3,0x22,-1,0);if(p<0){pc_sys(57,fd,0,0,0,0,0);return 0;}unsigned n=0;int ok=1;while(n<cap){long k=pc_sys(63,fd,p+n,cap-n,0,0,0);if(k<0){ok=0;break;}if(!k)break;n+=k;}char extra;if(n==cap&&pc_sys(63,fd,(long)&extra,1,0,0,0)!=0)ok=0;pc_sys(57,fd,0,0,0,0,0);if(!ok||!n){pc_sys(215,p,cap,0,0,0,0);return 0;}*size=n;return(void*)p;}
void pc_free_file(void*p){if(p)pc_sys(215,(long)p,8*1024*1024,0,0,0,0);}
void pc_ms_collect(void){
 for(unsigned k=0;k<PC_SLOTS;k++){
  Slot *s=&host.slots[k];
  pc_ms_reap(s);
  if(__atomic_load_n(&s->instrument,AQ)||__atomic_exchange_n(&s->busy,1,AQ))continue;
  if(!__atomic_load_n(&s->instrument,AQ)&&
     (s->multisample||__atomic_load_n(&s->read,AQ)!=__atomic_load_n(&s->write,AQ)||
      __atomic_load_n(&s->event_read,AQ)!=__atomic_load_n(&s->event_write,AQ)))
   pc_ms_dispose_locked(s);
  __atomic_store_n(&s->busy,0,RL);
 }
}
