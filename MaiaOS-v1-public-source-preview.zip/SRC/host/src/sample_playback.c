/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "synth_filter.h"
#include "pressure6.h"
#include "limiter.h"
#include "dj_mode.h"
#include "dj_playback.h"
#include "usb_cue.h"
#include "drumkit.h"
#include "bounce.h"
#include "sample_playback.h"

#define NATIVE_POOL 0x6da6570u
#define DRUM_PROGRAM 0x6ec6860u
#define NATIVE_LIMIT 128u

/* The stock pool preallocates 128 voice objects. This table only tags live
 * attacks; all untagged voices, including sequenced attacks, are protected.
 * Every native attack entry below clears a tag when it reuses its slot. */
static uintptr_t live[NATIVE_LIMIT];
static uintptr_t drum_pool;
static unsigned notices,attack_busy;
static struct {unsigned key,serial,epoch;} sample_keys[NATIVE_LIMIT];
static uint64_t keyed[2];
static unsigned key_serial;
static int (*pool_trylock)(uintptr_t);
static uintptr_t tempo_service, sequencer_service, legacy_allow;
static __thread unsigned bypass_legacy_budget;

unsigned pc_sample_notice(void)
{
    return __atomic_load_n(&notices, AQ);
}

static int live_index(uintptr_t pool, uintptr_t voice)
{
    uintptr_t slots = Q(pool,0x80);
    int count = I(pool,0x8c);
    if (!slots || count != NATIVE_LIMIT) return -1;
    for (int i=0; i<count; i++) if (Q(slots,8*i)==voice) return i;
    return -1;
}

static void remember_sample_key(uintptr_t pool,uintptr_t voice,uintptr_t instrument,uint64_t mask){
 if(pool!=__atomic_load_n(&drum_pool,AQ))return;
 int index=live_index(pool,voice);
 if(index<0)return;
 uint64_t bit=UINT64_C(1)<<((unsigned)index%64);
 keyed[index/64]&=~bit;
 uintptr_t layers=Q(instrument,0x22e8);
 if(!layers||(*(const uint8_t*)(instrument+0x78)&1))return;
 for(unsigned layer=0;layer<8;layer++){
  if(!(mask&(UINT64_C(1)<<layer)))continue;
  uintptr_t sample=Q(layers,0x4a8+layer*0xb30);
  unsigned key=sample?pc_tune_sample_key((const char*)Q(sample,0xa8)):0;
  if(!key)continue;
  sample_keys[index].key=key;sample_keys[index].serial=++key_serial;
  sample_keys[index].epoch=__atomic_load_n(&host.project_epoch,AQ);
  keyed[index/64]|=bit;break;
 }
}
static void update_sample_key(void){
 if(!pc_tune_follow_mode()||pc_bounce_busy())return;
 unsigned held=0;
 for(unsigned n=0;n<PC_SLOTS&&!held;n++){
  Slot *s=&host.slots[n];
  if(!__atomic_load_n(&s->instrument,AQ))continue;
  for(unsigned j=0;j<4;j++)held|=__atomic_load_n(&s->native_sources[j],AQ);
 }
 pc_tune_follow_midi_held(held!=0);
 if(!pool_trylock)return;
 if(__atomic_exchange_n(&attack_busy,1,AQ))return;
 unsigned key=0;
 uintptr_t pool=__atomic_load_n(&drum_pool,AQ);
 if(pool&&(keyed[0]||keyed[1])){
  uintptr_t mutex=pool+0x158;
  if(pool_trylock(mutex)){__atomic_store_n(&attack_busy,0,RL);return;}
  uint64_t seen[2]={0,0};
  unsigned newest=0,walked=0,epoch=__atomic_load_n(&host.project_epoch,AQ);
  uintptr_t end=pool+0x128,slots=Q(pool,0x80);
  for(uintptr_t node=Q(end,0);node&&node!=end&&walked++<NATIVE_LIMIT;node=Q(node,0)){
   uintptr_t voice=Q(node,0x10);
   if(!voice||!I(voice,0x920))continue;
   uintptr_t instrument=Q(voice,0x8f8);
   if(!instrument)continue;
   unsigned muted=(*(const uint8_t*)(instrument+0x78)&1);
   for(unsigned group=0;group<2;group++){
    uint64_t candidates=keyed[group];
    while(candidates){
     unsigned index=group*64+__builtin_ctzll(candidates);
     candidates&=candidates-1;
     if(Q(slots,index*8)!=voice||sample_keys[index].epoch!=epoch)continue;
     seen[group]|=UINT64_C(1)<<(index%64);
     if(muted)break;
     unsigned serial=sample_keys[index].serial;
     if(!key||(int)(serial-newest)>0){key=sample_keys[index].key;newest=serial;}
     break;
    }
   }
  }
  keyed[0]&=seen[0];keyed[1]&=seen[1];
  FN(0xb51808,int(*)(uintptr_t))(mutex);
 }
 pc_tune_follow_sample(key);
 __atomic_store_n(&attack_busy,0,RL);
}
static int is_live(uintptr_t pool, uintptr_t voice, unsigned index)
{
    return pool == __atomic_load_n(&drum_pool,AQ) && index < NATIVE_LIMIT &&
           __atomic_load_n(&live[index],AQ)==voice;
}

static void tag(uintptr_t pool, uintptr_t voice, int physical)
{
    if (pool != __atomic_load_n(&drum_pool,AQ)) return;
    int index=live_index(pool,voice);
    if (index>=0) __atomic_store_n(&live[index],physical ? voice : 0,RL);
}

static int drum(uintptr_t program)
{
    return program && Q(program,0)==host.base+DRUM_PROGRAM && I(program,0x1234)==0;
}

typedef struct {
    uintptr_t live_released[NATIVE_LIMIT], live_held[NATIVE_LIMIT];
    unsigned released, held, layers, cost;
} PoolScan;

static int scan(uintptr_t pool, PoolScan *out)
{
    uintptr_t mutex=pool+0x158;
    if (FN(0xb51818,int(*)(uintptr_t))(mutex)) return 0;
    uintptr_t end=pool+0x128,node=Q(end,0);
    int tagged=pool==__atomic_load_n(&drum_pool,AQ);
    unsigned walked=0;
    for (;node && node!=end && walked++<NATIVE_LIMIT;node=Q(node,0)) {
        uintptr_t voice=Q(node,0x10);
        if (!voice || !drum(Q(voice,0x8f0))) continue;
        unsigned layers=I(voice,0x920);
        if (!layers || layers>8) continue;
        out->layers+=layers;
        if (!tagged) continue;
        unsigned index=0;
        while (index<NATIVE_LIMIT && __atomic_load_n(&live[index],RX)!=voice) index++;
        if (index==NATIVE_LIMIT) continue;
        if (*(const uint8_t*)(voice+0x92c)&1)
            out->live_held[out->held++]=voice;
        else
            out->live_released[out->released++]=voice;
        out->cost+=layers;
    }
    FN(0xb51808,int(*)(uintptr_t))(mutex);
    return node==end;
}

static int retire(uintptr_t pool,uintptr_t voice)
{
    (void)pool;(void)voice;return 0;

}

static int warp_room(uintptr_t pool,uintptr_t instrument,uint64_t layers)
{
    if (!(layers&1) || !(*(const uint8_t*)(instrument+0x2018)&1)) return 1;
    uintptr_t feature=Q(host.base,0x7166220);
    int bank=feature && *(const uint8_t*)(feature+0x1b) ? 14 : I(instrument,0x1f68);
    if (bank<0 || bank>14) return 0;
    uintptr_t warp=Q(pool,0x98+8*bank);
    /* The native Warp pool has its own backing contexts. When all are busy,
     * never enter the native fallback that steals an arbitrary voice. */
    return !warp || I(warp,0x2c)<I(warp,0x28);
}

typedef uintptr_t (*NativeAttack)(uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t,
                                  const uint64_t*,unsigned,uintptr_t,float,float,float);
static uintptr_t allocate_sample(uintptr_t pool,uintptr_t program,uintptr_t event,uintptr_t timing,
                               uintptr_t instrument,const uint64_t *mask,unsigned offset,
                               uintptr_t flags,float velocity,float a,float b)
{
    NativeAttack attack=FN(0x222a3a0,NativeAttack);
    if (!pool || Q(pool,0)!=host.base+NATIVE_POOL || I(pool,0x8c)!=NATIVE_LIMIT || !pc_valid(program,instrument) ||
        !mask) {
        uintptr_t voice=attack(pool,program,event,timing,instrument,mask,offset,flags,velocity,a,b);
        if (voice) tag(pool,voice,0);
        return voice;
    }
    uintptr_t known=__atomic_load_n(&drum_pool,AQ);
    if (known!=pool) {
        keyed[0]=keyed[1]=0;
        for (unsigned i=0;i<NATIVE_LIMIT;i++) __atomic_store_n(&live[i],0,RX);
        __atomic_store_n(&drum_pool,pool,RL);
    }
    unsigned cost=__builtin_popcountll(*mask);
    int physical=pc_physical_pad_dispatch();
    PoolScan active={0};
    if (!cost || cost>8) return 0;
    if (!warp_room(pool,instrument,*mask) ||
        !scan(pool,&active)) goto rejected;
    /* No onset count ceiling. Only sustained CPU load gates new attacks. */
    if (!pc_trigger_admit(1,offset,cost)) goto rejected;
    /* No voice is ever recycled to admit another attack. */
    if(Q(pool,0x110)==pool+0x110 || (unsigned)I(pool,0x18c)+cost>NATIVE_LIMIT)goto rejected;
    bypass_legacy_budget=1;
    uintptr_t voice=attack(pool,program,event,timing,instrument,mask,offset,flags,velocity,a,b);
    bypass_legacy_budget=0;
    if (voice) tag(pool,voice,physical);
    return voice;
rejected:
    __atomic_fetch_add(&notices,1,RL);
    pc_diag_add(27);
    return 0;
}

/* Both native attack callsites enter this relay. A competing producer
 * cannot reuse a tagged slot between victim selection and native recycling.
 * The voice pool's own mutex still owns list publication and traversal. */
static uintptr_t sample_attack(uintptr_t pool,uintptr_t program,uintptr_t event,uintptr_t timing,
                               uintptr_t instrument,const uint64_t *mask,unsigned offset,
                               uintptr_t flags,float velocity,float a,float b)
{
    if (__atomic_exchange_n(&attack_busy,1,AQ)) return 0;
    uintptr_t voice=allocate_sample(pool,program,event,timing,instrument,mask,offset,flags,velocity,a,b);
    if(voice&&mask&&pc_valid(program,instrument)&&!pc_bounce_busy())remember_sample_key(pool,voice,instrument,*mask);
    __atomic_store_n(&attack_busy,0,RL);
    if (voice) pc_record_voice_started(instrument);
    return voice;
}

/* Managed drum attacks use sustained CPU admission instead of either the
 * earlier ten-voice patch or the native weighted budget. */
static unsigned sample_budget(uintptr_t pool,unsigned weight)
{
    if (bypass_legacy_budget) return 1; /* CPU98/5s admission already checked. */
    return FN(0x224f160,unsigned(*)(uintptr_t,unsigned))(pool,weight);
}

static void sample_release(uintptr_t voice,unsigned offset)
{
    uintptr_t pool=__atomic_load_n(&drum_pool,AQ);
    if (pool && voice && drum(Q(voice,0x8f0))) {
        int index=live_index(pool,voice);
        if (index>=0 && is_live(pool,voice,(unsigned)index)!=pc_physical_pad_dispatch())
            return;
    }
    FN(0x221abc0,void(*)(uintptr_t,unsigned))(voice,offset);
}

static void sample_retrigger(uintptr_t voice,unsigned offset)
{
    uintptr_t pool=__atomic_load_n(&drum_pool,AQ);
    if(pool&&voice&&drum(Q(voice,0x8f0))&&!is_live(pool,voice,(unsigned)live_index(pool,voice)))return;
    if (pc_physical_pad_dispatch()) sample_release(voice,offset);
    else FN(0x221abc0,void(*)(uintptr_t,unsigned))(voice,offset);
}

static void native_pressure(uintptr_t pool,unsigned level,unsigned allowed)
{
    if (pool!=__atomic_load_n(&drum_pool,AQ)) {
        FN(0x222a2f0,void(*)(uintptr_t,unsigned,unsigned))(pool,level,allowed);
        return;
    }
    /* Pressure only gates future attacks; never retires an existing voice. */
    (void)level;(void)allowed;

}

void pc_sample_playback_poll(void)
{
    if (!__atomic_load_n(&tempo_service,AQ)) {
        uintptr_t tempo=pc_bounce_service(host.base+0x6e08fe0);
        if (tempo) __atomic_store_n(&tempo_service,tempo,RL);
    }
    if (!__atomic_load_n(&sequencer_service,AQ)) {
        uintptr_t sequencer=pc_bounce_service(host.base+0x6e7ef38);
        if (sequencer && Q(sequencer,0)==host.base+0x6e7f2d0)
            __atomic_store_n(&sequencer_service,sequencer,RL);
    }
}

static float clock_bpm(void)
{
    uintptr_t seq=__atomic_load_n(&sequencer_service,AQ);
    uintptr_t clock=seq?Q(seq,0x788):0;
    if (clock) {
        uint64_t bits=__atomic_load_n((const uint64_t*)(clock+0xf0),AQ);
        double value;memcpy(&value,&bits,sizeof value);
        if (value>=20 && value<=999) return (float)value;
    }
    return 0;
}

static float requested_bpm(void)
{
    uintptr_t tempo=__atomic_load_n(&tempo_service,AQ);
    if (!tempo) return 0;
    float value=I(tempo,0x208)==1 ? F(tempo,0x1b0) : F(tempo,0x158);
    return value>=20 && value<=999 ? value : 0;
}

static int playing(void)
{
    uintptr_t seq=__atomic_load_n(&sequencer_service,AQ);
    uintptr_t facade=seq?Q(seq,0x768):0,transport=facade?Q(facade,0x148):0;
    uintptr_t vt=transport?Q(transport,0):0,method=vt?Q(vt,0x18):0;
    return method && ((unsigned(*)(uintptr_t))method)(transport)&1u;
}

static float absolute(float x) { return x<0?-x:x; }

static float fade_weight(unsigned left)
{
    float t=(float)left/(float)PC_TEMPO_FADE;
    return t*t*(3.f-2.f*t);
}

void pc_tempo_continuity(PcTempoContinuity *state,float *l,float *r,unsigned frames,int change)
{
    if (!frames || !l || !r || l==r) return;
    float *channel[2]={l,r};
    if (change) state->window=PC_TEMPO_WINDOW;
    unsigned watch=frames<state->window?frames:state->window;
    float seam[2]={0,0};
    if (watch && state->primed) {
        for (unsigned c=0;c<2;c++) {
            float step=state->last[c]-state->previous[c];
            float next=frames>1?channel[c][1]-channel[c][0]:step;
            float jump=state->last[c]+.5f*(step+next)-channel[c][0];
            if (absolute(jump)>.003f && absolute(jump)>2.25f*(absolute(step)+absolute(next)))
                seam[c]=jump;
        }
    }
    if (seam[0] || seam[1]) {
        float carry=fade_weight(state->left);
        for (unsigned c=0;c<2;c++) state->correction[c]=state->correction[c]*carry+seam[c];
        state->left=PC_TEMPO_FADE;
        pc_diag_add(52);
    }
    unsigned spikes=0;
    for (unsigned c=0;c<2;c++) {
        float *samples=channel[c];
        float last=samples[frames-1],previous=frames>1?samples[frames-2]:state->last[c];
        /* A one-sample spike can occur inside a block. Require a return
         * to the neighboring signal and leave sustained attacks intact. */
        if (watch && frames>=3) {
            unsigned first=state->primed?0:2;
            float before=first?samples[0]:state->previous[c],prior=first?samples[1]:state->last[c];
            for (unsigned i=first;i<watch&&i+2<frames;i++) {
                float current=samples[i],next=samples[i+1],mid=.5f*(prior+next);
                float spike=absolute(current-mid);
                float surroundings=absolute(prior-before)+absolute(next-prior)+absolute(samples[i+2]-next);
                if (spike>.006f&&spike>3.f*surroundings) {
                    samples[i]=mid;
                    spikes=1;
                }
                before=prior;
                prior=current;
            }
        }
        state->previous[c]=previous;
        state->last[c]=last;
    }
    if (spikes) pc_diag_add(55);
    if (state->left) {
        unsigned count=frames<state->left?frames:state->left;
        for (unsigned i=0;i<count;i++) {
            float weight=fade_weight(state->left-i);
            for (unsigned c=0;c<2;c++)
                channel[c][i]+=state->correction[c]*weight;
        }
        state->left-=count;
    }
    state->window-=watch;
    state->primed=1;
}

static int tempo_changed(float previous,float current)
{
    return previous>0 && current>0 && absolute(current-previous)>.001f;
}

static unsigned dj_pcm_hook,dj_engine_output;
static _Thread_local unsigned dj_staged_frames;
static int stereo_planes(float **out,unsigned channels,unsigned frames){
 return out&&channels>=2&&channels<=32&&frames&&frames<=4096&&out[0]&&out[1]&&out[0]!=out[1];
}
/* JUCE's ALSA thread hands the float output planes to the render callback,
 * then converts them to the hardware format. Native clock and tempo-
 * dependent processors may observe a new setting on different blocks. */
static void output_callback(uintptr_t callback,const float **in,unsigned inputs,
                            float **out,unsigned outputs,unsigned frames)
{
    static PcTempoContinuity continuity;
    static uintptr_t owner;
    static float previous_clock,previous_request;
    pc_trigger_block();
    float before_clock=clock_bpm(),before_request=requested_bpm();
    int stereo=stereo_planes(out,outputs,frames);
    if(!dj_engine_output)pc_dj_device_begin(stereo?frames:0);
    ((void(*)(uintptr_t,const float**,unsigned,float**,unsigned,unsigned))Q(Q(callback,0),0x10))
        (callback,in,inputs,out,outputs,frames);
    update_sample_key();
    float after_clock=clock_bpm(),after_request=requested_bpm();

    if (owner!=callback || !stereo) {
        memset(&continuity,0,sizeof continuity);
        owner=callback;
    }
    if (stereo) {
        int changed=tempo_changed(previous_clock,before_clock)||tempo_changed(before_clock,after_clock)||
                    tempo_changed(previous_request,before_request)||tempo_changed(before_request,after_request);
        if (pc_flex_clock_external()||((changed||continuity.window||continuity.left)&&!playing()))
            memset(&continuity,0,sizeof continuity);
        else
            pc_tempo_continuity(&continuity,out[0],out[1],frames,changed);
        if(!dj_engine_output){
         if(dj_pcm_hook)dj_staged_frames=frames;
         else pc_dj_device_end(out[0],out[1],frames);
        }
    }
    pc_sd_access_silence(out,outputs,frames);
    previous_clock=stereo?after_clock:0;
    previous_request=stereo?after_request:0;
}

/* The callback's channel list is a logical view. Inject the DJ mix into
 * the physical float planes just before ALSA sample-format conversion.
 * This path also runs when the native application callback is absent. */
__attribute__((used)) long pc_dj_alsa_available(uintptr_t pcm,uintptr_t thread){
 long available=FN(0xb51fb8,long(*)(uintptr_t))(pcm);
 uintptr_t device=Q(thread,0x248);
 float **out=(float**)Q(thread,0x3d0);
 unsigned frames=I(thread,0x1a0);
 if(!dj_engine_output&&available>=0&&device&&stereo_planes(out,(unsigned)I(device,0x14),frames)){
  if(dj_staged_frames!=frames)pc_dj_device_begin(frames);
  pc_dj_device_end(out[0],out[1],frames);
 }
 if(device)pc_sd_access_silence(out,(unsigned)I(device,0x14),frames);
 dj_staged_frames=0;
 return available;
}
#if defined(__aarch64__)
extern void pc_dj_alsa_bridge(void);
__asm__(".text\n.hidden pc_dj_alsa_bridge\n.global pc_dj_alsa_bridge\n"
        "pc_dj_alsa_bridge:\n.inst 0xd503245f\nmov x1,x19\nb pc_dj_alsa_available\n");
#endif

/* MpcAudioThread processes the live output on the hardware reported as
 * "Audio Processing". Offline rendering has its own thread and vtable. */
static void dj_engine_audio(uintptr_t thread,uintptr_t context,uintptr_t buffer){
 unsigned frames=context?(unsigned)I(context,8):0;
 float **out=buffer?(float**)Q(buffer,0x10):0;
 int stereo=buffer&&frames<=(unsigned)I(buffer,4)&&stereo_planes(out,(unsigned)I(buffer,0),frames);
 unsigned prepared=pc_dj_device_begin(stereo?frames:0);
 pc_diag_add(72);
 FN(0x18dbcc0,void(*)(uintptr_t,uintptr_t,uintptr_t))(thread,context,buffer);
 if(stereo){
  if(prepared&&(*(uint8_t*)(buffer+0x128)&1)){
   for(unsigned channel=0;channel<(unsigned)I(buffer,0);channel++)
    if(out[channel])memset(out[channel],0,frames*sizeof(float));
   *(uint8_t*)(buffer+0x128)=0;
  }
  pc_dj_device_end(out[0],out[1],frames);
 }
 if(buffer&&frames<=(unsigned)I(buffer,4))pc_sd_access_silence(out,(unsigned)I(buffer,0),frames);
}

/* The internal updater only installs the host library. These small checked
 * call relays are set up in RAM before the native callbacks become active. */
typedef struct { unsigned site, expected; uintptr_t target; } Relay;
static void sync_code(uintptr_t first,uintptr_t end)
{
#if defined(__aarch64__)
    for (uintptr_t p=first&~15ull;p<end;p+=16)
        __asm__ volatile("dc cvau, %0"::"r"(p):"memory");
    __asm__ volatile("dsb ish":::"memory");
    for (uintptr_t p=first&~15ull;p<end;p+=16)
        __asm__ volatile("ic ivau, %0"::"r"(p):"memory");
    __asm__ volatile("dsb ish; isb":::"memory");
#else
    __builtin___clear_cache((char *)first,(char *)end);
#endif
}

#define BRANCH(from,to) (0x94000000u|(((uint32_t)((to)-(from))>>2)&0x03ffffffu))
static unsigned branch_target(unsigned pc,uint32_t instruction)
{
    return pc+((int32_t)(instruction<<6)>>4);
}

static int legacy_budget(void)
{
    unsigned entry=0x224e7a0;
    uint32_t instruction=I(host.base,entry);
    if (instruction==0xd503233f) return 1;
    if ((instruction&0xfc000000u)!=0x14000000u) return 0;
    unsigned gate=branch_target(entry,instruction);
    if (gate<0x7400000 || gate>0x743e000 ||
        (uint32_t)I(host.base,gate)!=0xd100c3ffu ||
        (uint32_t)I(host.base,gate+0x78)!=0xd503233fu)
        return 0;
    uint32_t continuation=I(host.base,gate+0x7c);
    if ((continuation&0xfc000000u)!=0x14000000u ||
        branch_target(gate+0x7c,continuation)!=entry+4)
        return 0;
    legacy_allow=host.base+gate+0x78;
    return 1;
}
static int relay_install(const Relay *relays,unsigned count,unsigned page_size)
{
    uintptr_t pages[8];unsigned np=0;
    if (!count || count>8) return 0;
    for (unsigned n=0;n<count;n++) {
        if ((unsigned)I(host.base,relays[n].site)!=relays[n].expected) return 0;
        uintptr_t page=(host.base+relays[n].site)&~((uintptr_t)page_size-1);
        unsigned i=0;
        while (i<np&&pages[i]!=page) i++;
        if (i==np) pages[np++]=page;
    }
    uintptr_t hint=(host.base+0x07800000)&~((uintptr_t)page_size-1);
    long memory=-1;
    for (unsigned i=0;i<16;i++) {
        /* MAP_FIXED_NOREPLACE reserves only an unused page. */
        uintptr_t at=hint+(uintptr_t)i*page_size;
        memory=pc_sys(222,at,page_size,3,0x100022,-1,0);
        if (memory<0) continue;
        if ((uintptr_t)memory==at) break;
        pc_sys(215,memory,page_size,0,0,0,0);
        memory=-1;
    }
    if (memory<0) return 0;
    uintptr_t code=(uintptr_t)memory;
    for (unsigned n=0;n<count;n++) {
        intptr_t delta=(code+16*n)-(host.base+relays[n].site);
        if (delta<-(1<<27) || delta>=(1<<27)) goto failed;
        uint32_t *entry=(uint32_t *)(code+16*n);
        entry[0]=0x58000050u; /* ldr x16, [pc,#8] */
        entry[1]=0xd61f0200u; /* br x16 */
        *(uintptr_t *)(entry+2)=relays[n].target;
    }
    sync_code(code,code+16*count);
    if (pc_sys(226,code,page_size,5,0,0,0)) goto failed;
    unsigned opened=0;
    for (;opened<np;opened++)
        if (pc_sys(226,pages[opened],page_size,7,0,0,0)) break;
    if (opened!=np) {
        while (opened) pc_sys(226,pages[--opened],page_size,5,0,0,0);
        goto failed;
    }
    for (unsigned n=0;n<count;n++) {
        uintptr_t site=host.base+relays[n].site;
        __atomic_store_n((uint32_t *)site,BRANCH(site,code+16*n),RL);
        sync_code(site,site+4);
    }
    while (opened) pc_sys(226,pages[--opened],page_size,5,0,0,0);
    return 1;
failed:
    pc_sys(215,code,page_size,0,0,0,0);
    return 0;
}

static int install_poly_default(unsigned page_size)
{
    /* Instrument::initialize from defaults, reached only with no source
     * instrument. The adjacent copy/restore path reads its saved mode. */
    uintptr_t site=host.base+0x280e2ac;
    if ((uint32_t)I(site,0)!=0x52800021u ||
        (uint32_t)I(site,8)!=BRANCH(0x280e2b4,0x13b3740))
        return 0;
    uintptr_t page=site&~((uintptr_t)page_size-1);
    if (pc_sys(226,page,page_size,7,0,0,0)) return 0;
    __atomic_store_n((uint32_t *)site,0x52800001u,RL); /* mov w1, #0 (Poly) */
    sync_code(site,site+4);
    pc_sys(226,page,page_size,5,0,0,0);
    return 1;
}

static uintptr_t layer_sample(uintptr_t layers,unsigned index)
{
    return layers?Q(layers,0x4a8+index*0xb30):0;
}

unsigned pc_sample_default_mode(uintptr_t sample){
 if(!sample)return 0;
 unsigned frames=FN(0x2941f80,unsigned(*)(uintptr_t))(sample);
 unsigned rate=FN(0x2941f90,unsigned(*)(uintptr_t))(sample);
 return rate>=8000&&rate<=768000&&(uint64_t)frames>30ull*rate;
}

static int assign_sample_poly(uintptr_t cmd)
{
    uintptr_t program=Q(cmd,0x80),before=Q(cmd,0x98);
    uintptr_t old_layers=drum(program)&&pc_valid(program,before)?Q(before,0x22e8):0;
    uintptr_t old[8];
    for(unsigned n=0;n<8;n++)old[n]=layer_sample(old_layers,n);
    int result=FN(0x199a3b0,int(*)(uintptr_t))(cmd);
    uintptr_t after=Q(cmd,0x98);
    if(!result&&drum(program)&&pc_valid(program,after)){
        uintptr_t layers=Q(after,0x22e8);
        unsigned changed=0,mono=0;
        for(unsigned n=0;n<8;n++){
            uintptr_t sample=layer_sample(layers,n);
            if(!sample)continue;
            changed|=sample!=old[n];
            if(!mono)mono=pc_sample_default_mode(sample);
        }
        if(changed)FN(0x2806c90,void(*)(uintptr_t,unsigned))(after,mono);
    }
    return result;
}

static void install_assign_poly(unsigned page_size)
{
    uintptr_t slot=host.base+0x6e41520;
    if (Q(slot,0)!=host.base+0x199a3b0) return;
    uintptr_t page=slot&~((uintptr_t)page_size-1);
    if (pc_sys(226,page,page_size,3,0,0,0)) return;
    __atomic_store_n((uintptr_t *)slot,(uintptr_t)assign_sample_poly,RL);
    pc_sys(226,page,page_size,1,0,0,0);
}

__attribute__((noinline)) static void install_live_input(unsigned page_size){
 const unsigned sites[]={0x6e3b0b8,0x6ec6d48,0x6ec7460,0x6eca1e8};
 for(unsigned n=0;n<4;n++)if(Q(host.base,sites[n])!=host.base+0x286fcf0)return;
 for(unsigned n=0;n<4;n++){
  uintptr_t site=host.base+sites[n],page=site&~((uintptr_t)page_size-1);
  if(pc_sys(226,page,page_size,3,0,0,0))continue;
  __atomic_store_n((uintptr_t*)site,(uintptr_t)pc_synth_live_input,RL);
  pc_sys(226,page,page_size,1,0,0,0);
 }
}
/* Both the hardware surface and its pad-controller path write these
 * native properties before any mode-specific listeners are dispatched. */
static uintptr_t raw_pressure_original,raw_colour_original,panel_pad_original;
static void kit_panel_pad(uintptr_t panel,unsigned pad,float pressure){
 if(!pc_dj_panel_pad(panel,pad,pressure)&&!pc_drumkit_panel_pad(panel,pad,pressure))
  ((void(*)(uintptr_t,unsigned,float))panel_pad_original)(panel,pad,pressure);
}
static void kit_raw_pressure(uintptr_t property,float value){
 if(!pc_dj_raw_pressure(property,value)&&!pc_drumkit_pressure(property,value))
  ((void(*)(uintptr_t,float))raw_pressure_original)(property,value);
}
static void kit_raw_colour(uintptr_t property,const uint64_t *value){
 uint64_t colour=pc_dj_colour(property,pc_drumkit_hw_colour(property,*value));
 ((void(*)(uintptr_t,const uint64_t*))raw_colour_original)(property,&colour);
}
static uintptr_t synth_mapping_original;
static void synth_mapping(uintptr_t property,unsigned mapping){
 pc_synth_fader_mapping_changed();
 ((void(*)(uintptr_t,unsigned))synth_mapping_original)(property,mapping);
}
static uintptr_t dj_fader_original;
static void dj_fader_value(uintptr_t responder,float value){
 if(pc_dj_open()&&value>=0.f&&value<=1.f)pc_dj_fader_position((unsigned)(value*16383.f+.5f));
 if(!pc_dj_open()&&!pc_dj_import()&&!pc_synth_fader_input(responder,value))((void(*)(uintptr_t,float))dj_fader_original)(responder,value);
}
static uintptr_t ui_code_page(unsigned page){
 for(unsigned i=16;i<32;i++){
  uintptr_t address=(host.base+0x07800000)&~((uintptr_t)page-1);
  address+=(uintptr_t)i*page;
  long result=pc_sys(222,address,page,3,0x100022,-1,0);
  if(result==(long)address)return address;
  if(result>0)pc_sys(215,result,page,0,0,0,0);
 }
 return 0;
}
/* Checked one-instruction entry detour. The replay signs its own LR, then
 * rejoins the native function immediately after the displaced PACIASP. */
__attribute__((noinline)) static int install_property_detour(unsigned site,uintptr_t target,uintptr_t *original,unsigned page){
 const uint32_t paciasp=0xd503233fu;
 if((uint32_t)I(host.base,site)!=paciasp)return 0;
 uintptr_t at=host.base+site;
 uintptr_t code=ui_code_page(page);
 if(!code)return 0;
 uint32_t *entry=(uint32_t*)code;
 entry[0]=0x58000050u;
 entry[1]=0xd61f0200u;
 *(uintptr_t*)(entry+2)=target;
 entry[4]=0xd503245fu; /* BTI c */
 entry[5]=paciasp;
 entry[6]=BRANCH(code+24,at+4)&0x7fffffffu;
 sync_code(code,code+28);
 uintptr_t native_page=at&~((uintptr_t)page-1);
 if(pc_sys(226,code,page,5,0,0,0)||pc_sys(226,native_page,page,7,0,0,0)){
  pc_sys(215,code,page,0,0,0,0);return 0;
 }
 *original=code+16;
 __atomic_store_n((uint32_t*)at,BRANCH(at,code)&0x7fffffffu,RL);
 sync_code(at,at+4);
 pc_sys(226,native_page,page,5,0,0,0);
 return 1;
}
/* Override the Shift bit read by the native parameter-page update.
 * Mix is selector index 1. The hardware Shift property stays intact. */
__attribute__((noinline)) static void install_sample_mix_shift(unsigned page){
 const unsigned site=0x1654b8c;
 const uint32_t load_shift=0x394a8034u; /* ldrb w20,[x1,#0x2a0] */
 if((uint32_t)I(host.base,site)!=load_shift||
    (uint32_t)I(host.base,site+4)!=0xeb00005fu)return; /* cmp x2,x0 */
 uintptr_t at=host.base+site,code=ui_code_page(page);
 if(!code)return;
 uint32_t *entry=(uint32_t*)code;
 entry[0]=0xb943aab4u; /* ldr w20,[x21,#0x3a8] */
 entry[1]=0x71000694u; /* subs w20,w20,#1 */
 entry[2]=0x54000040u; /* b.eq to the return branch, leaving w20=0 */
 entry[3]=load_shift;
 entry[4]=BRANCH(code+16,at+4)&0x7fffffffu;
 sync_code(code,code+20);
 uintptr_t native_page=at&~((uintptr_t)page-1);
 if(pc_sys(226,code,page,5,0,0,0)||pc_sys(226,native_page,page,7,0,0,0)){
  pc_sys(215,code,page,0,0,0,0);return;
 }
 __atomic_store_n((uint32_t*)at,BRANCH(at,code)&0x7fffffffu,RL);
 sync_code(at,at+4);
 pc_sys(226,native_page,page,5,0,0,0);
}
static uintptr_t clear_pad_original;
static void clear_pad(uintptr_t commands,uintptr_t program,int index){
 /* Clear Pad can return early when the pad has no native sample. */
 if(program&&Q(program,0)==host.base+0x6ec6860&&I(program,0x1234)==0){
  uintptr_t instrument=FN(0x286bbe0,uintptr_t(*)(uintptr_t,int))(program,index);
  if(instrument)pc_ms_clear_native_pad(instrument);
 }
 ((void(*)(uintptr_t,uintptr_t,int))clear_pad_original)(commands,program,index);
}
static uintptr_t shutdown_prompt_original;
static void shutdown_prompt(uintptr_t behaviour){
 pc_drumkit_close();
 ((void(*)(uintptr_t))shutdown_prompt_original)(behaviour);
}
static void patch_vtable_slot(unsigned offset,unsigned expected,uintptr_t replacement,unsigned page_size){
 uintptr_t slot=host.base+offset;
 if(Q(slot,0)!=host.base+expected)return;
 uintptr_t page=slot&~((uintptr_t)page_size-1);
 if(pc_sys(226,page,page_size,3,0,0,0))return;
 __atomic_store_n((uintptr_t*)slot,replacement,RL);
 pc_sys(226,page,page_size,1,0,0,0);
}
void pc_sample_playback_init(void)
{
    void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
    pool_trylock=symbol(0,"pthread_mutex_trylock");
    int(*getpagesize)(void)=symbol(0,"getpagesize");
    unsigned page=getpagesize?getpagesize():0;
    if (page!=4096&&page!=16384&&page!=65536) return;
    install_sample_mix_shift(page);
    pc_usb_cue_init(page);
    patch_vtable_slot(0x6e1e530,0x1172670,(uintptr_t)pc_sd_access_visibility,page);
    patch_vtable_slot(0x7078500,0x3c59c10,(uintptr_t)pc_pressure6_native,page);
    patch_vtable_slot(0x6e3b238,0x18dbcc0,(uintptr_t)dj_engine_audio,page);
    dj_engine_output=Q(host.base+0x6e3b238,0)==(uintptr_t)dj_engine_audio;
    pc_diag_value(71,dj_engine_output);
    install_property_detour(0x195a040,(uintptr_t)clear_pad,&clear_pad_original,page);
    /* Native Power callback opens the confirmation after the kit is dismissed. */
    if((uint32_t)I(host.base,0x14ebd78)==(BRANCH(0x14ebd78,0x14eb910)&0x7fffffffu))
        install_property_detour(0x14eb910,(uintptr_t)shutdown_prompt,&shutdown_prompt_original,page);
    unsigned raw_pressure_hook=install_property_detour(0x14a7580,(uintptr_t)kit_raw_pressure,&raw_pressure_original,page);
    unsigned colour=install_property_detour(0x13be8b0,(uintptr_t)kit_raw_colour,&raw_colour_original,page);
    unsigned panel_hook=install_property_detour(0x1a30300,(uintptr_t)kit_panel_pad,&panel_pad_original,page);
    install_property_detour(0x14c6ed0,(uintptr_t)dj_fader_value,&dj_fader_original,page);
    install_property_detour(0x1564ae0,(uintptr_t)synth_mapping,&synth_mapping_original,page);
    pc_diag_value(64,raw_pressure_hook|(colour<<1)|(panel_hook<<2));
    patch_vtable_slot(0x6e1c008,0x10e2e10,(uintptr_t)pc_limiter_paint,page);
    patch_vtable_slot(0x6e1c090,0x15f4a70,(uintptr_t)pc_limiter_visibility,page);
    patch_vtable_slot(0x6e1d0c8,0x1608bb0,(uintptr_t)pc_dj_browser_layout,page);
    patch_vtable_slot(0x6e1d090,0x10e2e10,(uintptr_t)pc_dj_browser_paint,page);
    patch_vtable_slot(0x6e1cb90,0x10e2e10,(uintptr_t)pc_dj_paint,page);
    patch_vtable_slot(0x6e1cb18,0x1172670,(uintptr_t)pc_dj_visibility,page);
    const Relay audio[]={{0xdfb968,0xd63f00c0u,(uintptr_t)output_callback}};
    if (relay_install(audio,1,page)) pc_diag_value(51,1);
#if defined(__aarch64__)
    const Relay pcm[]={{0xdfb9cc,BRANCH(0xdfb9cc,0xb51fb8),(uintptr_t)pc_dj_alsa_bridge}};
    dj_pcm_hook=relay_install(pcm,1,page);
#endif
    const Relay roll[]={{0x7428d8c,BRANCH(0x7428d8c,0x74140b8),(uintptr_t)pc_roll_encoder_click}};
    if (relay_install(roll,1,page)) pc_diag_value(54,1);
    if (install_poly_default(page)) pc_diag_value(56,1);
    install_assign_poly(page);
    install_live_input(page);
    const Relay quantize[]={
     {0x214fd5c,BRANCH(0x214fd5c,0x214e800),(uintptr_t)pc_quantize_poly},
     {0x214d9bc,BRANCH(0x214d9bc,0x214be90),(uintptr_t)pc_quantize_cleanup},
     {0x214e2bc,BRANCH(0x214e2bc,0x214be90),(uintptr_t)pc_quantize_cleanup},
     {0x214fecc,BRANCH(0x214fecc,0x214be90),(uintptr_t)pc_quantize_cleanup},
    };
    if(relay_install(quantize,sizeof quantize/sizeof *quantize,page))pc_diag_flag(61,1);
    const Relay record[]={
        {0x154e280,BRANCH(0x154e280,0x20826c0),(uintptr_t)pc_record_arm_reset},
        {0x154e314,BRANCH(0x154e314,0x206b350),(uintptr_t)pc_record_arm_sync},
        {0x206b408,BRANCH(0x206b408,0x2159ab0),(uintptr_t)pc_record_capture_wait},
        {0x15501cc,BRANCH(0x15501cc,0x19d0a00),(uintptr_t)pc_record_finish_entry},
        {0x18dbe7c,BRANCH(0x18dbe7c,0x2114c00),(uintptr_t)pc_record_first_pass},
        {0x18dc00c,BRANCH(0x18dc00c,0x2226fb0),(uintptr_t)pc_record_end_block},
        {0x221f99c,BRANCH(0x221f99c,0x2949a80),(uintptr_t)pc_record_slice_entry},
    };
    const Relay sample[]={
        {0x22270f4,BRANCH(0x22270f4,0x222a3a0),(uintptr_t)sample_attack},
        {0x222a410,BRANCH(0x222a410,0x224f160),(uintptr_t)sample_budget},
        {0x283e848,BRANCH(0x283e848,0x222a3a0),(uintptr_t)sample_attack},
        {0x28698e4,BRANCH(0x28698e4,0x221abc0),(uintptr_t)sample_release},
        {0x2869bec,BRANCH(0x2869bec,0x221abc0),(uintptr_t)sample_release},
        {0x286d518,BRANCH(0x286d518,0x221abc0),(uintptr_t)sample_retrigger},
    };
    uintptr_t pressure=host.base+0x6da6588;
    if (Q(pressure,0)!=host.base+0x222a2f0 || !legacy_budget()) return;
    uintptr_t slot_page=pressure&~((uintptr_t)page-1);
    if (pc_sys(226,slot_page,page,3,0,0,0)) return;
    if (relay_install(sample,sizeof sample/sizeof *sample,page)) {
        __atomic_store_n((uintptr_t *)pressure,(uintptr_t)native_pressure,RL);
        pc_diag_value(50,1);
    }
    pc_sys(226,slot_page,page,1,0,0,0);
    if (relay_install(record,sizeof record/sizeof *record,page)) pc_diag_value(57,1);
    pc_sample_playback_poll();
}
