/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
typedef struct {unsigned value;void (*notify)(void);} DjProgress;
static inline void pc_dj_progress_report(DjProgress *p,unsigned value){
 if(!p)return;
 unsigned old=__atomic_exchange_n(&p->value,value,__ATOMIC_ACQ_REL);
 if(old/10!=value/10&&p->notify)p->notify();
}
#ifdef __cplusplus
extern "C" {
#endif
void *pc_dj_qm_create(unsigned rate);
void pc_dj_qm_feed(void *,float);
int pc_dj_qm_finish(void *,double tagged,double *period,double *first,DjProgress *progress);
void pc_dj_qm_destroy(void *);
#ifdef __cplusplus
}
#endif
