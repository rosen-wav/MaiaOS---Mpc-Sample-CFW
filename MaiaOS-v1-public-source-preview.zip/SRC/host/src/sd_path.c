/* Resolve the mounted SD block device from Linux mountinfo/sysfs. Directory
 * names (including "internal-sd") are not evidence that a volume is a card. */
#include "internal.h"
static unsigned size(const char*s){unsigned n=0;while(s[n])n++;return n;}
static int join(char*out,unsigned cap,const char*a,const char*b){
 unsigned n=size(a),m=size(b);if(n+m+1>cap)return 0;memcpy(out,a,n);memcpy(out+n,b,m+1);return 1;
}
static int read_small(const char*path,char*out,unsigned cap){
 long fd=pc_sys(56,-100,(long)path,0x80000,0,0,0);if(fd<0)return 0;
 unsigned n=0;while(n+1<cap){long got=pc_sys(63,fd,(long)(out+n),cap-n-1,0,0,0);if(got==-4)continue;if(got<=0)break;n+=(unsigned)got;}
 pc_sys(57,fd,0,0,0,0,0);out[n]=0;return n!=0;
}
static int sd_type(const char*device){
 char root[128]="/sys/dev/block/",path[192],type[32];
 if(!join(root,sizeof root,"/sys/dev/block/",device))return 0;
 /* Partitions expose the type on the parent disk. Whole-card mounts expose
  * it directly. eMMC reports MMC and must never qualify as the microSD. */
 const char*suffixes[]={"/device/type","/../device/type"};
 for(unsigned i=0;i<2;i++)if(join(path,sizeof path,root,suffixes[i])&&read_small(path,type,sizeof type)){
  if(type[0]=='S'&&type[1]=='D'&&(type[2]=='\n'||type[2]=='\r'||type[2]==0))return 1;
 }
 return 0;
}
static int unescape(char*out,unsigned cap,const char*in){
 unsigned n=0;
 for(unsigned i=0;in[i];i++){
  unsigned c=(unsigned char)in[i];
  if(c=='\\'){
   if(in[i+1]<'0'||in[i+1]>'7'||!in[i+1]||in[i+2]<'0'||in[i+2]>'7'||!in[i+2]||in[i+3]<'0'||in[i+3]>'7'||!in[i+3])return 0;
   c=((in[i+1]-'0')<<6)|((in[i+2]-'0')<<3)|(in[i+3]-'0');i+=3;if(!c)return 0;
  }
  if(n+1>=cap)return 0;out[n++]=(char)c;
 }
 out[n]=0;return 1;
}
static int mounted_folder(char*line,char*out,unsigned cap,const char*suffix){
 char*fields[6];unsigned count=0;char*p=line;
 while(*p&&count<6){while(*p==' ')p++;if(!*p)break;fields[count++]=p;while(*p&&*p!=' ')p++;if(*p)*p++=0;}
 if(count<6||fields[3][0]!='/'||fields[3][1])return 0;
 /* Validate the numeric major:minor field before using it in a sysfs path. */
 unsigned colon=0;
 for(unsigned i=0;fields[2][i];i++)if(fields[2][i]==':')colon++;else if(fields[2][i]<'0'||fields[2][i]>'9')return 0;
 if(colon!=1||!sd_type(fields[2]))return 0;
 char mount[768];if(!unescape(mount,sizeof mount,fields[4])||mount[0]!='/')return 0;
 unsigned n=size(mount),m=size(suffix);if(n+m+2>cap)return 0;
 memcpy(out,mount,n);if(n&&out[n-1]!='/')out[n++]='/';memcpy(out+n,suffix,m+1);
 long fd=pc_sys(56,-100,(long)out,0x84000,0,0,0);if(fd<0)return 0;
 pc_sys(57,fd,0,0,0,0,0);return 1;
}
int pc_sd_folder(char*out,unsigned cap,const char*suffix){
 if(!out||!cap)return 0;out[0]=0;
 long fd=pc_sys(56,-100,(long)"/proc/self/mountinfo",0x80000,0,0,0);if(fd<0)return 0;
 char chunk[2048],line[4096];unsigned n=0,overflow=0;long got;int found=0;
 while(!found&&(got=pc_sys(63,fd,(long)chunk,sizeof chunk,0,0,0))!=0){
  if(got==-4)continue;if(got<0)break;
  for(unsigned i=0;i<(unsigned)got;i++){
   if(chunk[i]=='\n'){
    if(!overflow){line[n]=0;if(mounted_folder(line,out,cap,suffix)){found=1;break;}}
    n=overflow=0;
   }else if(n+1<sizeof line)line[n++]=chunk[i];else overflow=1;
  }
 }
 if(!found&&!overflow&&n){line[n]=0;found=mounted_folder(line,out,cap,suffix);}
 pc_sys(57,fd,0,0,0,0,0);if(!found)out[0]=0;return found;
}
