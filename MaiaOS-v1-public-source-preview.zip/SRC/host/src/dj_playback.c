/* SPDX-License-Identifier: GPL-3.0-only
 * AkaiLib Warp rendering and microSD reads run on per-deck workers. The
 * device callback only consumes SPSC rings and interpolates mixer gains.
 */
#include "internal.h"
#include "dj_analysis.h"
#include "dj_playback.h"
#include "airwindows.h"
#include "usb_cue.h"
#include "dj_controls.h"

#define DJ_RING 16384u
#define DJ_PREFILL 2048u
#define DJ_HISTORY 2048u
#define DJ_SEAM 132u
#define DJ_BLOCK 256u
#define DJ_OUTPUT_RATE 44100u
#define DJ_FILE_PATH 1024u
#define DJ_WARP_VTABLE 0x6da6750u

typedef struct {
 float l,r;
 uint32_t frame;
} DjFrame;
typedef struct {
 unsigned read,write,request,running,done,started,error,ratio,gain,busy,filter;
 int low_db,pending_nudge;
 uint64_t start,position,loop,sends,timeline,seek_frame,seek_clock;
 unsigned seek_serial;
 uint64_t cue;
 char path[DJ_FILE_PATH];
 DjFrame ring[DJ_RING];
 /* Audio-callback-owned state. */
 float level,last_l,last_r,signal,send_gain[3];
 unsigned buffering,nudge_left;
 float nudge_l,nudge_r;
} Playback;
static Playback decks[2]={{.ratio=1000000,.gain=16383,.filter=8192},{.ratio=1000000,.gain=16383,.filter=8192}};
static uint64_t device_clock;

typedef struct {
 /* AkaiLib input and output callback slots at +0x140 and +0x150. */
 uint64_t prefix[0x140/8];
 void(*pull)(uintptr_t,uintptr_t,unsigned,float);
 uintptr_t reserved;
 void(*push)(const float*,const float*,uintptr_t,uintptr_t,unsigned);
 DjReader reader;
 uint64_t loop;
 uint64_t source_phase;
 float previous_l,previous_r,seam_l,seam_r;
 unsigned seam_left;
 unsigned output_at,error;
 float left[DJ_BLOCK],right[DJ_BLOCK];
} WarpIo;
_Static_assert(offsetof(WarpIo,pull)==0x140&&offsetof(WarpIo,push)==0x150,"native warp callback layout");

static void read_audio(WarpIo *io,float *l,float *r,unsigned frames){
 const DjWav *format=&io->reader.format;
 uint64_t loop=io->loop;
 uint32_t begin=(uint32_t)loop,end=(uint32_t)(loop>>32);
 if(end<=begin||end>format->frames)end=0;
 unsigned direct=format->rate==DJ_OUTPUT_RATE&&io->source_phase%DJ_OUTPUT_RATE==0;
 uint64_t direct_frame=io->source_phase/DJ_OUTPUT_RATE;
 for(unsigned n=0;n<frames;n++,io->source_phase+=format->rate){
  unsigned wrapped=0;
  if(end&&io->source_phase>=(uint64_t)end*DJ_OUTPUT_RATE){
   uint64_t first=(uint64_t)begin*DJ_OUTPUT_RATE,length=(uint64_t)(end-begin)*DJ_OUTPUT_RATE;
   io->source_phase=first+(io->source_phase-first)%length;wrapped=1;
   if(direct)direct_frame=io->source_phase/DJ_OUTPUT_RATE;
  }
  uint64_t frame=direct?direct_frame++:io->source_phase/DJ_OUTPUT_RATE;
  unsigned phase=direct?0:io->source_phase%DJ_OUTPUT_RATE;
  if(io->error||frame>=format->frames){l[n]=r[n]=0;continue;}
  if(!pc_dj_reader_frame(&io->reader,frame,&l[n],&r[n])){
   io->error=1;l[n]=r[n]=0;continue;
  }
  if(phase){
   uint64_t next=frame+1;
   if(end&&next>=end)next=begin;
   if(next<format->frames){
    float left,right;
    if(!pc_dj_reader_frame(&io->reader,next,&left,&right)){io->error=1;continue;}
    float fraction=phase*(1.f/DJ_OUTPUT_RATE);
    l[n]+=(left-l[n])*fraction;r[n]+=(right-r[n])*fraction;
   }
  }
  /* Crossfade from the previous endpoint over three
   * milliseconds. Loop length and the beat transient retain their timing. */
  if(wrapped){
   io->seam_l=io->previous_l;io->seam_r=io->previous_r;
   io->seam_left=DJ_SEAM;
  }
  if(io->seam_left){
   float weight=(float)io->seam_left/DJ_SEAM;
   weight*=weight;
   l[n]=io->seam_l*weight+l[n]*(1-weight);
   r[n]=io->seam_r*weight+r[n]*(1-weight);
   io->seam_left--;
  }
  io->previous_l=l[n];io->previous_r=r[n];
 }
}
static void pull(uintptr_t opaque,uintptr_t dest,unsigned frames,float control){
 (void)control;
 uintptr_t planes=Q(dest,0x10);
 read_audio((WarpIo*)opaque,(float*)Q(planes,0),(float*)Q(planes,8),frames);
}
static void push(const float *l,const float *r,uintptr_t context,uintptr_t output,unsigned frames){
 (void)output;
 WarpIo *io=(WarpIo*)(context-0x58);
 if(frames>DJ_BLOCK-io->output_at){io->error=1;return;}
 memcpy(io->left+io->output_at,l,frames*sizeof *l);
 memcpy(io->right+io->output_at,r,frames*sizeof *r);
 io->output_at+=frames;
}
/* Mixxx FilterEffect's linked left/right logarithmic corners and exact
 * dry centre. The fixed resonance is 30% of its logarithmic 0.4–4 Q range. */
extern double pow(double,double),cos(double),sin(double);
typedef struct {
 double b0,b1,b2,a1,a2,z[2][2];
 float mix;
} DjFilter;
static void filter_block(DjFilter *f,WarpIo *io,unsigned position,unsigned frames){
 unsigned enabled=position!=8192,high=position>8192;
 if(enabled){
  double scale=high?(position-8192)/8191.0:position/8192.0;
  double hz=13*pow(22050.0/13.0,scale);
  if(hz>21500)hz=21500;
  double omega=6.283185307179586*hz/DJ_OUTPUT_RATE,c=cos(omega);
  double a=sin(omega)/(2*.93),norm=1/(1+a);
  f->b0=(high?1+c:1-c)*.5*norm;
  f->b1=(high?-2:2)*f->b0;f->b2=f->b0;
  f->a1=-2*c*norm;f->a2=(1-a)*norm;
 }
 if(!enabled&&f->mix<=0)return;
 for(unsigned i=0;i<frames;i++){
  float *sample[]={&io->left[i],&io->right[i]};
  f->mix+=enabled?.0078125f:-.0078125f;
  if(f->mix>1)f->mix=1;if(f->mix<0)f->mix=0;
  for(unsigned c=0;c<2;c++){
   double dry=*sample[c],wet=f->b0*dry+f->z[c][0];
   f->z[c][0]=f->b1*dry-f->a1*wet+f->z[c][1];
   f->z[c][1]=f->b2*dry-f->a2*wet;
   *sample[c]=(float)(dry+(wet-dry)*f->mix);
  }
 }
}
static void low_eq(WarpIo *io,float state[2],float *gain,int db,unsigned frames){
 float target=(float)pow(10,db/20.0);
 if(target==1&&*gain==1)return;
 float step=(target-*gain)/frames;
 for(unsigned i=0;i<frames;i++){
  *gain+=step;
  float *sample[]={&io->left[i],&io->right[i]};
  for(unsigned c=0;c<2;c++){
   state[c]+=.01975f*(*sample[c]-state[c]); /* 140 Hz low shelf at 44.1 kHz */
   *sample[c]+=(*gain-1)*state[c];
  }
 }
 *gain=target;
}
static int warp_abi(void){
 return Q(host.base,DJ_WARP_VTABLE)==host.base+0x2244b90&&
        Q(host.base,DJ_WARP_VTABLE+0x10)==host.base+0x2243de0&&
        Q(host.base,DJ_WARP_VTABLE+0x18)==host.base+0x2243e80&&
        (uint32_t)I(host.base,0x22440d0)==0xd503233f;
}
static void notify(Playback *deck){
 unsigned index=deck==&decks[1];
 FN(0x6d43500,void(*)(uint64_t))((uint64_t)(12+index)<<32|(59u<<1)|1u);
}
static void *render_worker(void *opaque){
 Playback *d=opaque;
 unsigned long cpu_mask=d==&decks[0]?1ul:4ul;
 pc_sys(122,0,sizeof cpu_mask,(long)&cpu_mask,0,0,0);
 WarpIo io={.pull=pull,.push=push,.source_phase=d->cue*DJ_OUTPUT_RATE};
 unsigned error=1;
 if(pc_dj_reader_open(&io.reader,d->path)!=DJ_OK)goto done;
 const DjWav *format=&io.reader.format;
 if(d->cue>=format->frames)goto close_file;
 double source_step=(double)format->rate/DJ_OUTPUT_RATE;
 uint64_t processor[0x430/8]={0},configuration[0xb0/8]={0};
 I(configuration,0xa8)=64;
 uintptr_t warp=(uintptr_t)processor;
 unsigned warp_ready=0;
 float rate=1.f;
 unsigned write=0,last_report=0;
 int filter_position=8192;
 float low_state[2]={0},low_gain=1;
 DjFilter filter={0};
 double position=(double)d->cue;
 float previous_output_l=0,previous_output_r=0,transition_l=0,transition_r=0;
 unsigned transition_left=0,seek_seen=0;
 while(__atomic_load_n(&d->request,AQ)&&!io.error){
  if(write-__atomic_load_n(&d->read,AQ)>DJ_RING-DJ_HISTORY-DJ_BLOCK){
   const long sleep[2]={0,2000000};
   pc_sys(101,(long)sleep,0,0,0,0,0);continue;
  }
  uint64_t loop=__atomic_load_n(&d->loop,AQ);
  uint32_t begin=(uint32_t)loop,end=(uint32_t)(loop>>32);
  if(end>format->frames||end<=begin)end=0;
  io.loop=end?loop:0;
  if(!end&&position>=format->frames)break;
  unsigned target_ratio=__atomic_load_n(&d->ratio,AQ),activating=0;
  if(target_ratio!=1000000&&!warp_ready&&warp_abi()){
   FN(0x22440d0,void(*)(uintptr_t,uintptr_t,uintptr_t))(warp,0,(uintptr_t)configuration);
   warp_ready=Q(warp,0)==host.base+DJ_WARP_VTABLE;
   if(warp_ready){
    activating=1;
    rate=write?1.f:target_ratio*.000001f;
    FN(0x2243de0,void(*)(uintptr_t,float,float))(warp,1.f/rate,1.f);
   }
  }
  unsigned count=DJ_BLOCK;
  unsigned serial=__atomic_load_n(&d->seek_serial,AQ);
  if(serial&&!(serial&1)&&serial!=seek_seen){
   uint64_t destination=__atomic_load_n(&d->seek_frame,AQ),deadline=__atomic_load_n(&d->seek_clock,AQ);
   if(serial==__atomic_load_n(&d->seek_serial,AQ)&&destination<format->frames){
    uint64_t timeline=__atomic_load_n(&d->timeline,AQ);
    uint32_t output=(uint32_t)(timeline>>32)+(write-(uint32_t)timeline);
    int32_t remaining=(int32_t)((uint32_t)deadline-output);
    if(remaining<=0){
     /* Keep the ring and worker alive. Only the decoder/stock Warp position
      * changes at the requested future output frame. */
     io.source_phase=destination*DJ_OUTPUT_RATE;io.seam_left=0;
     position=(double)destination;seek_seen=serial;
     if(warp_ready)FN(0x2243de0,void(*)(uintptr_t,float,float))(warp,1.f/rate,1.f);
     transition_l=previous_output_l;transition_r=previous_output_r;transition_left=DJ_SEAM;
    }else if((unsigned)remaining<count)count=(unsigned)remaining;
   }
  }
  io.output_at=0;
  if(warp_ready){
   FN(0x2243e80,void(*)(uintptr_t,uintptr_t,unsigned,uintptr_t,float,float,float))
    (warp,0,count,(uintptr_t)&io,1.f/rate,1.f,1.f);
   if(io.output_at!=count){io.error=1;break;}
  }else{
   if(target_ratio!=1000000){io.error=1;break;}
   read_audio(&io,io.left,io.right,count);
  }
  int filter_delta=(int)__atomic_load_n(&d->filter,AQ)-filter_position;
  if(filter_delta>320)filter_delta=320;if(filter_delta< -320)filter_delta= -320;
  filter_position+=filter_delta;
  filter_block(&filter,&io,filter_position,count);
  low_eq(&io,low_state,&low_gain,__atomic_load_n(&d->low_db,AQ),count);
  if(activating&&write){
   transition_l=previous_output_l;transition_r=previous_output_r;transition_left=DJ_SEAM;
  }
  for(unsigned i=0;i<count;i++){
   if(end&&position>=end)position=begin+(position-begin)-(uint64_t)((position-begin)/(end-begin))*(end-begin);
   if(position>=format->frames)break;
   float left=io.left[i],right=io.right[i];
   if(transition_left){
    float weight=(float)transition_left/DJ_SEAM;weight*=weight;
    left=transition_l*weight+left*(1-weight);right=transition_r*weight+right*(1-weight);
    transition_left--;
   }
   d->ring[write&(DJ_RING-1)]=(DjFrame){left,right,(uint32_t)position};
   previous_output_l=left;previous_output_r=right;
   write++;position+=rate*source_step;
  }
  __atomic_store_n(&d->write,write,RL);
  if((!last_report&&write)||write-last_report>=2048){last_report=write;notify(d);}
  /* AkaiLib takes duration/input, the reciprocal of deck speed. Its
   * pitch/resampling argument remains unity. Smooth the speed changes. */
  float target=(float)__atomic_load_n(&d->ratio,AQ)*.000001f;
  float delta=target-rate;
  if(delta>.003f)delta=.003f;
  if(delta<-.003f)delta=-.003f;
  rate+=delta;
 }
 error=io.error||(!write&&__atomic_load_n(&d->request,AQ));
 if(warp_ready)FN(0x2244b90,void(*)(uintptr_t))(warp);
close_file:
 pc_dj_reader_close(&io.reader);
done:
 pc_diag_value(75,error);
 __atomic_store_n(&d->error,error,RL);
 __atomic_store_n(&d->done,1,RL);
 __atomic_store_n(&d->running,0,RL);
 notify(d);
 return 0;
}
int pc_dj_play(unsigned deck,const char *path,uint64_t cue,uint64_t start){
 if(deck>=2||!path)return 0;
 Playback *d=&decks[deck];
 if(__atomic_load_n(&d->running,AQ)||__atomic_load_n(&d->request,AQ))return 0;
 void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 int(*thread)(uintptr_t*,void*,void*(*)(void*),void*)=symbol(0,"pthread_create");
 int(*detach)(uintptr_t)=symbol(0,"pthread_detach");
 if(!thread||!detach)return 0;
 unsigned length=0;while(length<sizeof d->path&&path[length])length++;
 if(!length||length>=sizeof d->path)return 0;
 if(__atomic_exchange_n(&d->busy,1,AQ))return -1;
 memcpy(d->path,path,length+1);d->cue=cue;
 d->level=d->last_l=d->last_r=d->signal=0;d->buffering=1;d->nudge_left=0;__atomic_store_n(&d->pending_nudge,0,RL);
 __atomic_store_n(&d->seek_serial,0,RL);
 __atomic_store_n(&d->timeline,(uint64_t)(uint32_t)start<<32,RL);
 __atomic_store_n(&d->position,cue,RL);
 __atomic_store_n(&d->read,0,RL);__atomic_store_n(&d->write,0,RL);
 __atomic_store_n(&d->start,start,RL);__atomic_store_n(&d->done,0,RL);
 __atomic_store_n(&d->started,0,RL);__atomic_store_n(&d->error,0,RL);
 __atomic_store_n(&d->running,1,RL);
 uintptr_t id;
 /* The worker observes request only after its immutable setup is ready. */
 __atomic_store_n(&d->request,1,RL);
 __atomic_store_n(&d->busy,0,RL);
 pc_diag_add(74);
 if(thread(&id,0,render_worker,d)){
  __atomic_store_n(&d->request,0,RL);__atomic_store_n(&d->running,0,RL);return 0;
 }
 detach(id);return 1;
}
int pc_dj_seek(unsigned deck,uint64_t source,uint64_t deadline){
 if(deck>=2||!__atomic_load_n(&decks[deck].request,AQ)||!__atomic_load_n(&decks[deck].started,AQ)||!__atomic_load_n(&decks[deck].running,AQ)||__atomic_load_n(&decks[deck].done,AQ))return 0;
 Playback *d=&decks[deck];
 __atomic_add_fetch(&d->seek_serial,1,RL);
 __atomic_store_n(&d->seek_frame,source,RL);__atomic_store_n(&d->seek_clock,deadline,RL);
 __atomic_add_fetch(&d->seek_serial,1,RL);return 1;
}
void pc_dj_nudge_step(unsigned deck,int direction){
 if(deck<2&&__atomic_load_n(&decks[deck].request,AQ))
  __atomic_add_fetch(&decks[deck].pending_nudge,direction>0?441:-441,RL);
}
void pc_dj_pause(unsigned deck){if(deck<2)__atomic_store_n(&decks[deck].request,0,RL);}
void pc_dj_gain(unsigned deck,unsigned gain){if(deck<2&&gain<=16383)__atomic_store_n(&decks[deck].gain,gain,RL);}
void pc_dj_filter(unsigned deck,unsigned position){if(deck<2&&position<=16383)__atomic_store_n(&decks[deck].filter,dj_filter_position(position),RL);}
void pc_dj_low(unsigned deck,int db){if(deck<2&&db>=-24&&db<=6)__atomic_store_n(&decks[deck].low_db,db,RL);}
void pc_dj_loop(unsigned deck,uint64_t first,uint64_t last){
 if(deck<2&&last<=0xffffffffu&&first<=last)
  __atomic_store_n(&decks[deck].loop,(last<<32)|first,RL);
}
unsigned pc_dj_busy(unsigned deck){return deck<2&&__atomic_load_n(&decks[deck].running,AQ);}
void pc_dj_rate(unsigned deck,unsigned ratio){
 if(deck<2&&ratio>=500000&&ratio<=2000000)__atomic_store_n(&decks[deck].ratio,ratio,RL);
}
unsigned pc_dj_playing(unsigned deck){return deck<2&&__atomic_load_n(&decks[deck].request,AQ);}
unsigned pc_dj_started(unsigned deck){
 return pc_dj_playing(deck)&&__atomic_load_n(&decks[deck].started,AQ);
}
unsigned pc_dj_failed(unsigned deck){return deck<2&&__atomic_exchange_n(&decks[deck].error,0,__ATOMIC_ACQ_REL);}
uint64_t pc_dj_position(unsigned deck){return deck<2?__atomic_load_n(&decks[deck].position,AQ):0;}
uint64_t pc_dj_clock(void){return __atomic_load_n(&device_clock,AQ);}
void pc_dj_send(unsigned deck,unsigned bus,unsigned value){
 if(deck>=2||bus>=3||value>16383)return;
 unsigned shift=bus*14;
 uint64_t old=__atomic_load_n(&decks[deck].sends,AQ);
 __atomic_store_n(&decks[deck].sends,(old&~(UINT64_C(16383)<<shift))|((uint64_t)value<<shift),RL);
}
static unsigned fader,space_epoch;
void pc_dj_space_position(unsigned position){
 if(position<=16383)__atomic_store_n(&fader,position,RL);
}
void pc_dj_space_reset(void){
 __atomic_store_n(&fader,0,RL);__atomic_add_fetch(&space_epoch,1,RL);
}
#define DJ_AUDIO_MAX 4096u
static float deck_audio[2][2][DJ_AUDIO_MAX];
static float dj_mix_audio[2][DJ_AUDIO_MAX];
static float cue_audio[2][2][DJ_AUDIO_MAX],monitor_audio[2][DJ_AUDIO_MAX];
static unsigned monitor_settings=16383u<<1,monitor_reset,monitor_gain_position=16383;
static float monitor_deck,monitor_cue=1,monitor_gain=1;
void pc_dj_monitor_gain(unsigned gain){
 if(gain<=16383)__atomic_store_n(&monitor_gain_position,gain,RL);
}
void pc_dj_monitor_reset(void){__atomic_store_n(&monitor_reset,1,RL);}
void pc_dj_monitor(unsigned deck,unsigned cue){
 if(deck<2&&cue<=16383)__atomic_store_n(&monitor_settings,(cue<<1)|deck,RL);
}
static _Thread_local unsigned device_total,device_used,device_rendered,monitor_prepared;

static int prepare_audio(unsigned frames){
 uint64_t clock=__atomic_load_n(&device_clock,RX);
 unsigned rendered=0;
 monitor_prepared=0;
 if(frames>DJ_AUDIO_MAX)return 0;
 monitor_prepared=pc_usb_cue_enabled();
 for(unsigned index=0;index<2;index++){
  memset(deck_audio[index][0],0,frames*sizeof(float));
  memset(deck_audio[index][1],0,frames*sizeof(float));
  if(monitor_prepared){
   memset(cue_audio[index][0],0,frames*sizeof(float));
   memset(cue_audio[index][1],0,frames*sizeof(float));
  }
 }
 for(unsigned index=0;index<2;index++){
  Playback *d=&decks[index];
  if(__atomic_exchange_n(&d->busy,1,AQ))continue;
  unsigned running=__atomic_load_n(&d->request,AQ);
  if(!running&&d->level==0){__atomic_store_n(&d->busy,0,RL);continue;}
  unsigned read=__atomic_load_n(&d->read,RX),write=__atomic_load_n(&d->write,AQ),initial=read;
  int nudge=__atomic_exchange_n(&d->pending_nudge,0,__ATOMIC_ACQ_REL);
  if(nudge&&running&&__atomic_load_n(&d->started,AQ)){
   unsigned shift=nudge>0?(unsigned)nudge:(unsigned)-nudge;
   if(nudge>0){if(shift>write-read)shift=write-read;}
   else{unsigned queued=write-read,history=queued<DJ_RING-DJ_BLOCK?DJ_RING-DJ_BLOCK-queued:0;
    /* Leave room for the producer block already in flight. */
    if(history>read)history=read;if(shift>history)shift=history;}
   if(shift){d->nudge_l=d->last_l;d->nudge_r=d->last_r;d->nudge_left=DJ_SEAM;read=nudge>0?read+shift:read-shift;}
  }
  uint64_t start=__atomic_load_n(&d->start,AQ);
  unsigned done=__atomic_load_n(&d->done,AQ);
  float target=__atomic_load_n(&d->gain,AQ)*(0.5f/16383),level=d->level;
  if(running&&clock+frames<=start){__atomic_store_n(&d->busy,0,RL);continue;}
  unsigned first=running&&start>clock?(unsigned)(start-clock):0;
  rendered=1;
  unsigned waiting=d->buffering||(!__atomic_load_n(&d->started,AQ)&&write-read<DJ_PREFILL);
  if(waiting&&d->signal==0&&(write-read>=DJ_PREFILL||done))waiting=0;
  for(unsigned i=first;i<frames;i++){
   if(running&&!waiting&&read!=write){
    const DjFrame *f=&d->ring[read++&(DJ_RING-1)];
    d->last_l=f->l;d->last_r=f->r;
    d->signal+=1.f/DJ_SEAM;if(d->signal>1)d->signal=1;
   }else{
    if(running&&!waiting&&!done)pc_diag_add(76);
    waiting=1;
    d->signal-=1.f/DJ_SEAM;if(d->signal<0)d->signal=0;
   }
   float delta=(running?target:0)-level;
   if(delta>.004f)delta=.004f;if(delta<-.004f)delta=-.004f;
   level+=delta;
   float l=d->last_l,r=d->last_r;
   if(d->nudge_left){float w=d->nudge_left*(1.f/DJ_SEAM);l=l*(1-w)+d->nudge_l*w;r=r*(1-w)+d->nudge_r*w;d->nudge_left--;}
   if(monitor_prepared){
    cue_audio[index][0][i]=l*.5f*d->signal;
    cue_audio[index][1][i]=r*.5f*d->signal;
   }
   deck_audio[index][0][i]=l*level*d->signal;
   deck_audio[index][1][i]=r*level*d->signal;
  }
  d->buffering=waiting;
  d->level=level;
  if(read!=initial){
   __atomic_store_n(&d->position,d->ring[(read-1)&(DJ_RING-1)].frame,RL);
   __atomic_store_n(&d->started,1,RL);
  }
  __atomic_store_n(&d->read,read,RL);
  __atomic_store_n(&d->timeline,((uint64_t)(uint32_t)(clock+frames)<<32)|read,RL);
  if(running&&done&&read==write)__atomic_store_n(&d->request,0,RL);
  __atomic_store_n(&d->busy,0,RL);
 }
 __atomic_store_n(&device_clock,clock+frames,RL);
 pc_diag_value(73,(unsigned)(clock+frames));
 if(!rendered&&!__atomic_load_n(&fader,AQ)&&!pc_dj_space_active())return 0;
 return 1;
}
static void route_sends(unsigned offset,unsigned frames,float (*buses)[2][4096],unsigned active){
 for(unsigned d=0;d<2;d++){
  uint64_t settings=__atomic_load_n(&decks[d].sends,AQ);
  float *gain=decks[d].send_gain;
  float step[3],targets[3];
  for(unsigned k=0;k<3;k++){
   targets[k]=(active&(1u<<k))?((settings>>(14*k))&16383)*(1.f/16383):0;
   if(!(active&(1u<<k)))gain[k]=0;
   step[k]=(targets[k]-gain[k])/frames;
  }
  for(unsigned i=0;i<frames;i++){
   float *left=&deck_audio[d][0][offset+i],*right=&deck_audio[d][1][offset+i],wet=0;
   for(unsigned k=0;k<3;k++)if(active&(1u<<k)){
    gain[k]+=step[k];if(gain[k]>wet)wet=gain[k];
    buses[k][0][i]+=*left*gain[k];buses[k][1][i]+=*right*gain[k];
   }
   *left*=1-wet;*right*=1-wet;
  }
  memcpy(gain,targets,sizeof targets);
 }
}
static void mix_to_device(float *l,float *r,unsigned frames){
 for(unsigned i=0;i<frames;i++){
  dj_mix_audio[0][i]=deck_audio[0][0][i]+deck_audio[1][0][i];
  dj_mix_audio[1][i]=deck_audio[0][1][i]+deck_audio[1][1][i];
 }
 pc_dj_space_process(dj_mix_audio[0],dj_mix_audio[1],frames,
   __atomic_load_n(&fader,AQ),__atomic_load_n(&space_epoch,AQ));
 for(unsigned i=0;i<frames;i++){
  l[i]+=dj_mix_audio[0][i];r[i]+=dj_mix_audio[1][i];
  if(l[i]>1)l[i]=1;else if(l[i]<-1)l[i]=-1;
  if(r[i]>1)r[i]=1;else if(r[i]<-1)r[i]=-1;
 }
}
static void monitor_to_usb(const float *l,const float *r,unsigned frames){
 if(monitor_prepared&&pc_usb_cue_enabled()){
  unsigned settings=__atomic_load_n(&monitor_settings,AQ);
  float target_deck=(float)(settings&1),target_cue=(settings>>1)*(1.f/16383);
  float target_gain=__atomic_load_n(&monitor_gain_position,AQ)*(1.f/16383);
  if(__atomic_exchange_n(&monitor_reset,0,AQ)){monitor_deck=target_deck;monitor_cue=target_cue;monitor_gain=target_gain;}
  for(unsigned i=0;i<frames;i++){
   float delta=target_deck-monitor_deck;
   if(delta>.007575758f)delta=.007575758f;
   if(delta<-.007575758f)delta=-.007575758f;
   monitor_deck+=delta;
   monitor_cue+=(target_cue-monitor_cue)*.0015f;
   float remaining=target_cue-monitor_cue;
   if(remaining<.000001f&&remaining>-.000001f)monitor_cue=target_cue;
   float cue_l=cue_audio[0][0][i]+(cue_audio[1][0][i]-cue_audio[0][0][i])*monitor_deck;
   float cue_r=cue_audio[0][1][i]+(cue_audio[1][1][i]-cue_audio[0][1][i])*monitor_deck;
   monitor_gain+=(target_gain-monitor_gain)*.0015f;
   float gain_left=target_gain-monitor_gain;
   if(gain_left<.000001f&&gain_left>-.000001f)monitor_gain=target_gain;
   monitor_audio[0][i]=(cue_l*monitor_cue+l[i]*(1-monitor_cue))*monitor_gain;
   monitor_audio[1][i]=(cue_r*monitor_cue+r[i]*(1-monitor_cue))*monitor_gain;
  }
  pc_usb_cue_publish(monitor_audio[0],monitor_audio[1],frames);
 }

}
void pc_dj_audio(float *l,float *r,unsigned frames){
 if(prepare_audio(frames))mix_to_device(l,r,frames);
 monitor_to_usb(l,r,frames);
}
unsigned pc_dj_device_begin(unsigned frames){
 device_total=frames;device_used=0;monitor_prepared=0;
 device_rendered=frames&&prepare_audio(frames);
 return device_rendered;
}
void pc_dj_graph_audio(unsigned frames,float (*buses)[2][4096],unsigned active){
 if(!device_rendered||!frames||frames>device_total-device_used)return;
 route_sends(device_used,frames,buses,active);
 device_used+=frames;
}
void pc_dj_device_end(float *l,float *r,unsigned frames){
 if(device_total==frames&&device_rendered){
  // With no native pad voices the stock graph may skip its silent submix.
  // Drain only the not-yet-routed DJ frames before adding the dry decks.
  if(device_used<frames)pc_mix_dj_fallback(l,r,device_used,frames-device_used);
  mix_to_device(l,r,frames);
 }
 if(device_total==frames&&frames)monitor_to_usb(l,r,frames);
 device_total=device_used=device_rendered=monitor_prepared=0;
}
