/* SPDX-License-Identifier: GPL-3.0-only */
#include "host.h"
extern uintptr_t pc_imagebase(void);
#define PC_SHARED_API_OFFSET 0x1d00u
#ifdef PC_RELOCATABLE_BRIDGE
#ifdef PC_ARM64_STATE_SLOT
extern uintptr_t maia_bridge_state_load(void);
extern void maia_bridge_state_publish(uintptr_t);
#else
static uintptr_t pc_loader_shared_state;
static uintptr_t maia_bridge_state_load(void){
 return __atomic_load_n(&pc_loader_shared_state,__ATOMIC_ACQUIRE);
}
static void maia_bridge_state_publish(uintptr_t state){
 __atomic_store_n(&pc_loader_shared_state,state,__ATOMIC_RELEASE);
}
#endif
#endif

uintptr_t pc_loader_statebase(void){
#ifdef PC_RELOCATABLE_BRIDGE
 uintptr_t state=maia_bridge_state_load();
 if(state)return state;
#endif
 return pc_imagebase()+PC_LEGACY_STATE_OFFSET;
}

static const PcApi *get(void){return __atomic_load_n((const PcApi **)(pc_loader_statebase()+PC_SHARED_API_OFFSET),__ATOMIC_ACQUIRE);}
void pc_loader_init(void){
 uintptr_t base=pc_imagebase();((void (*)(void))(base+0xb51388))();
 void *(*open)(const char *,int)=(void *(*)(const char *,int))(base+0xb518a8);
 void *(*sym)(void *,const char *)=(void *(*)(void *,const char *))(base+0xb51898);
 PcDebug *debug=(PcDebug *)(pc_loader_statebase()+PC_SHARED_DEBUG_OFFSET);debug->magic=PC_MAGIC;debug->error=90;
 void *h=open("/run/mpc-pc-integrated-v040/libpc-host.aarch64.so",2);if(!h)return;
 const PcApi *(*init)(uintptr_t,PcDebug *)=sym(h,"pc_init");if(!init){debug->error=91;return;}
 const PcApi *a=init(base,debug);if(!a){if(!debug->error)debug->error=92;return;}
 if(a->magic!=PC_MAGIC||a->version!=6){debug->error=92;return;}
 *(const PcApi **)(pc_loader_statebase()+PC_SHARED_API_OFFSET)=a;
}
#ifdef PC_RELOCATABLE_BRIDGE
/* The stock initializer runs through its original path. This entry only
 * binds MaiaOS after the new loader has prepared the native bridge code. */
int pc_loader_init_with_state(void *storage,size_t size){
 uintptr_t state=(uintptr_t)storage,base=pc_imagebase();
 if(!state||state%16||size<PC_SHARED_STATE_SIZE||
    state>UINTPTR_MAX-PC_SHARED_STATE_SIZE)return 0;
 uintptr_t previous=maia_bridge_state_load();
 if(previous)return previous==state&&get()!=0;
 void *(*open)(const char *,int)=(void *(*)(const char *,int))(base+0xb518a8);
 void *(*sym)(void *,const char *)=(void *(*)(void *,const char *))(base+0xb51898);
 void *h=open("/run/mpc-pc-integrated-v040/libpc-host.aarch64.so",2);
 if(!h)return 0;
 const PcApi *(*init)(uintptr_t,void *,size_t)=sym(h,"pc_init_with_state");
 if(!init)return 0;
 maia_bridge_state_publish(state);
 const PcApi *api=init(base,storage,size);
 if(!api||api->magic!=PC_MAGIC||api->version!=6){
  maia_bridge_state_publish(0);
  return 0;
 }
 __atomic_store_n((const PcApi **)(state+PC_SHARED_API_OFFSET),api,__ATOMIC_RELEASE);
 return 1;
}
#endif
int pc_loader_note(uintptr_t p,uintptr_t t,uintptr_t c,uintptr_t i,const uint8_t *d,unsigned f){const PcApi *a=get();return a?a->note_on(p,t,c,i,d,f):0;}
void pc_loader_off(uintptr_t p,uintptr_t t,unsigned tr,unsigned ch,unsigned k){const PcApi *a=get();if(a)a->note_off(p,t,tr,ch,k);}
int pc_loader_active(uintptr_t i){const PcApi *a=get();return a?a->active(i):0;}
void pc_loader_render(uintptr_t i,uintptr_t b,unsigned n,unsigned p){const PcApi *a=get();if(a)a->render(i,b,n,p);}
void pc_loader_stop(uintptr_t p,uintptr_t t,unsigned tr,unsigned ch){const PcApi *a=get();if(a)a->stop(p,t,tr,ch);}
void pc_loader_destroy(uintptr_t p){const PcApi *a=get();if(a)a->destroy(p);}
int pc_loader_physical(uintptr_t control,unsigned down){const PcApi *a=get();return a?a->physical(control,down):0;}
int pc_loader_knob(uintptr_t control,uint32_t value){const PcApi *a=get();return a?a->knob(control,value):0;}
int pc_loader_rotation(uintptr_t signal,int delta){const PcApi *a=get();return a?a->rotation(signal,delta):0;}
int pc_loader_capture(int source,int kind){const PcApi *a=get();return a?a->capture(source,kind):0;}
int pc_loader_event(const uint64_t *event){const PcApi *a=get();return a&&event?a->event(*event):0;}
int pc_loader_paint(uintptr_t screen,uintptr_t graphics){
 const PcApi *a=get();int handled=a?a->paint(screen,graphics):0;
 if(handled==2){
  ((void(*)(uintptr_t,uintptr_t))(pc_imagebase()+0x7404ef8))(screen,graphics);
  a->paint(screen,graphics);return 1;
 }
 return handled;
}
int pc_loader_write(uintptr_t i,uintptr_t xml){const PcApi *a=get();return a?a->write_xml(i,xml):1;}
int pc_loader_read(uintptr_t i,uintptr_t xml){const PcApi *a=get();return a?a->read_xml(i,xml):0;}
void pc_loader_destroy_instrument(uintptr_t i){const PcApi *a=get();if(a)a->destroy_instrument(i);}

int pc_loader_import_paint(uintptr_t screen,uintptr_t graphics){
 ((void (*)(uintptr_t,uintptr_t))(pc_imagebase()+0x10e2e10))(screen,graphics);
 const PcApi *a=get();if(a)a->paint(screen,graphics);return 1;
}

int pc_loader_light_has(uintptr_t p,unsigned source,uintptr_t lighting){const PcApi *a=get();return a?a->light_has(p,source,lighting):0;}
int pc_loader_light_playing(uintptr_t p,uintptr_t i,unsigned key){const PcApi *a=get();return a?a->light_playing(p,i,key):0;}

void pc_loader_sidechain(uintptr_t i,uintptr_t b,unsigned n,unsigned p){const PcApi *a=get();if(a)a->sidechain(i,b,n,p);}

void pc_loader_info_write(uintptr_t a,uintptr_t i){const PcApi *p=get();if(p)p->info_write(a,i);}
void pc_loader_info_read(uintptr_t i){const PcApi *p=get();if(p)p->info_read(i);}

/* Audio scheduler callback: a numeric snapshot only, no model access. */
uint64_t pc_loader_sequence_length(void){return __atomic_load_n((uint64_t *)(pc_loader_statebase()+0x1e10),__ATOMIC_ACQUIRE);}
uint64_t pc_loader_sequence_start_length(uintptr_t property){
 uint64_t old=pc_loader_sequence_length();if(!old)return 0;
 uint64_t full=property?*(uint64_t *)(property+0x50):0;
 if(full && full<0x100000000ULL){__atomic_store_n((uint64_t *)(pc_loader_statebase()+0x1e10),full,__ATOMIC_RELEASE);return full;}return old;
}

/* Native readers can see a Track-derived short end after live updates.
 * Reassert full Sequence bounds at the final shared-clock read, not just at
 * start/update setters. No model traversal, allocation or property signals. */
void pc_loader_clock_guard(uintptr_t shared){
 uintptr_t base=pc_imagebase();uint64_t full=pc_loader_sequence_length();
 if(!full||!shared)return;
 uintptr_t map=*(uintptr_t *)(shared+0x110);if(!map)return;
 uint64_t samples=((uint64_t(*)(uintptr_t,uint64_t,uint64_t,uint64_t,uint64_t,uint64_t))(base+0x2159ab0))(map,full,0,0,0,0);
 if(!samples)return;
 uint64_t before=*(uint64_t *)(shared+0x120);
 __atomic_store_n((uint64_t *)(pc_loader_statebase()+0x1e28),full,__ATOMIC_RELAXED);
 __atomic_store_n((uint64_t *)(pc_loader_statebase()+0x1e30),before,__ATOMIC_RELAXED);
 __atomic_store_n((uint64_t *)(pc_loader_statebase()+0x1e38),samples,__ATOMIC_RELAXED);
 __atomic_fetch_add((uint64_t *)(pc_loader_statebase()+0x1e20),1,__ATOMIC_RELAXED);
 *(uint64_t *)(shared+0x58)=0;*(uint64_t *)(shared+0xb0)=full;
 *(uint64_t *)(shared+0x118)=0;*(uint64_t *)(shared+0x120)=samples;
 *(uint8_t *)(shared+0x108)=1;
}

/* Resolve the actual Project service independently of CurrentThings. Native
 * controls use this exact ServiceLocator lookup for typeinfo Project. Retain
 * its stable holder so a replaced service is observed on subsequent saves. */
void pc_loader_capture_project(uintptr_t locator){
 if(!locator)return;
 __atomic_store_n((uintptr_t *)(pc_loader_statebase()+0x1e98),locator,__ATOMIC_RELEASE);
 uintptr_t base=pc_imagebase();
 uintptr_t type=*(uintptr_t *)(base+0x71658b8);
 uintptr_t holder=((uintptr_t(*)(uintptr_t,uintptr_t *))(base+0x143ad50))(locator,&type);
 uintptr_t p=holder?*(uintptr_t *)holder:0;
 __atomic_fetch_add((uint64_t *)(pc_loader_statebase()+0x1e58),1,__ATOMIC_RELAXED);
 __atomic_store_n((uintptr_t *)(pc_loader_statebase()+0x1e48),p?*(uintptr_t *)p:0,__ATOMIC_RELAXED);
 if(p&&*(uintptr_t *)p==base+0x6ecc648){
  __atomic_store_n((uintptr_t *)(pc_loader_statebase()+0x1e70),holder,__ATOMIC_RELEASE);
  __atomic_store_n((uintptr_t *)(pc_loader_statebase()+0x1e40),p,__ATOMIC_RELEASE);
 }
}

void pc_loader_fx_input(uintptr_t i,uintptr_t b,uintptr_t route,unsigned n){const PcApi *a=get();if(a)a->fx_input(i,b,route,n);}
int pc_loader_fx_chain(uintptr_t ins,uintptr_t b,unsigned n){const PcApi *a=get();return a?a->fx_chain(ins,b,n):0;}
int pc_loader_fx_guard(void){const PcApi *a=get();return a?a->fx_guard():0;}

void pc_loader_fx_release(uintptr_t c){uintptr_t *slot=(uintptr_t *)(pc_loader_statebase()+0x1eb0);if(*slot==c){*slot=0;__atomic_add_fetch((unsigned *)(pc_loader_statebase()+0x1ef4),1,__ATOMIC_RELEASE);}}

/* Native paint-only theme entry points. No host access or audio state: these
 * are valid during native startup before the synth extension is initialized. */
#include "../theme/minimal.h"
unsigned pc_loader_theme_colour(unsigned colour,uintptr_t caller){
 uintptr_t base=pc_imagebase();
 /* External/custom painters already apply their exact semantic palette.
  * Do not quantize their antialias colours or alpha coverage a second time. */
 if(caller<base||caller>=base+0x7400000u)return pc_theme_colour(colour);
 return pc_native_theme_colour(colour);
}
extern void pc_theme_gradient_original(uintptr_t,uintptr_t);
extern void pc_theme_fill_original(uintptr_t,uintptr_t);
static void pc_theme_gradient_points(uint64_t *points,unsigned count){
 unsigned first=*(unsigned *)((uintptr_t)points+8),last=*(unsigned *)((uintptr_t)points+(count-1)*16+8),flat=1,average=0;
 for(unsigned shift=0;shift<32;shift+=8)average|=((((first>>shift)&255)+((last>>shift)&255)+1)/2)<<shift;
 for(unsigned i=0;i<count;i++){
  unsigned c=*(unsigned *)((uintptr_t)points+16*i+8),r=c>>16&255,g=c>>8&255,b=c&255;
  unsigned hi=r>g?r:g;if(b>hi)hi=b;unsigned lo=r<g?r:g;if(b<lo)lo=b;
  if((c>>24)!=(first>>24)||hi-lo>=20)flat=0;
 }
 for(unsigned i=0;i<count;i++){unsigned *c=(unsigned *)((uintptr_t)points+16*i+8);*c=(*c&0xff000000u)|(pc_native_theme_colour(0xff000000u|(first&0xffffffu))&0xffffffu);}
}
static int pc_theme_copy_gradient(uintptr_t source,uint64_t copy[5],uint64_t points[512]){
 if(!source)return 0;int count=*(int *)(source+0x24);uintptr_t p=*(uintptr_t *)(source+0x18);
 if(count<1||count>256||!p)return 0;
 for(unsigned i=0;i<5;i++)copy[i]=((uint64_t *)source)[i];
 for(unsigned i=0;i<(unsigned)count*2;i++)points[i]=((uint64_t *)p)[i];
 pc_theme_gradient_points(points,(unsigned)count);*(uintptr_t *)((uintptr_t)copy+0x18)=(uintptr_t)points;return 1;
}
int pc_loader_theme_gradient(uintptr_t graphics,uintptr_t gradient){
 if(!graphics)return 0;uint64_t copy[5],points[512];if(!pc_theme_copy_gradient(gradient,copy,points))return 0;
 pc_theme_gradient_original(graphics,(uintptr_t)copy);return 1;
}
void pc_loader_theme_gradient_move(uintptr_t graphics,uintptr_t gradient){
 (void)graphics;if(!gradient)return;int count=*(int *)(gradient+0x24);uintptr_t p=*(uintptr_t *)(gradient+0x18);
 if(count>=1&&count<=256&&p)pc_theme_gradient_points((uint64_t *)p,(unsigned)count);
 /* Original rvalue setter follows and preserves its exact ownership transfer. */
}
int pc_loader_theme_fill(uintptr_t graphics,uintptr_t fill){
 if(!graphics||!fill||*(uintptr_t *)(fill+0x10))return 0; /* image data unchanged */
 uint64_t copy[6],gradient[5],points[512];for(unsigned i=0;i<6;i++)copy[i]=((uint64_t *)fill)[i];
 uintptr_t g=*(uintptr_t *)(fill+8);
 if(g){if(!pc_theme_copy_gradient(g,gradient,points))return 0;*(uintptr_t *)((uintptr_t)copy+8)=(uintptr_t)gradient;}
 else *(unsigned *)copy=pc_native_theme_colour(*(unsigned *)copy);
 /* Keep FillType opacity/transform intact; native renderer copies before return. */
 pc_theme_fill_original(graphics,(uintptr_t)copy);return 1;
}

/* Verified DrumProgram mute query takes an Instrument ordinal (native vtable +0xd0). */
int pc_loader_mute_index(uintptr_t program,unsigned index){
 uintptr_t base=pc_imagebase();if(!program||index>=128||*(uintptr_t*)program!=base+0x6ec6860)return 0;
 uintptr_t first=*(uintptr_t*)(program+0x2808),end=*(uintptr_t*)(program+0x2810);if(!first||end<first||end-first>128*8||end-first<((uintptr_t)index+1)*8)return 0;
 const PcApi *a=get();return a?a->active(*(uintptr_t*)(first+index*8)):0;
}

unsigned pc_loader_pad_enter(unsigned source,uintptr_t tune,unsigned releasing){const PcApi *a=get();return a?a->pad_enter(source,tune,releasing):0;}
void pc_loader_pad_leave(unsigned token){const PcApi *a=get();if(a)a->pad_leave(token);}
