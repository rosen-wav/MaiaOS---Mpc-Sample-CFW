/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_GROOVE_H
#define PC_GROOVE_H
#include <stdint.h>

enum { GROOVE_KICK, GROOVE_SNARE, GROOVE_HAT, GROOVE_PERC, GROOVE_BASS, GROOVE_LEAD, GROOVE_ARP, GROOVE_FOLDERS };
enum { GROOVE_BAR = 3840, GROOVE_MAX_BARS = 128 };
typedef struct { uint16_t tick; uint8_t velocity; } PcGrooveHit;
typedef struct { const char *name; PcGrooveHit hits[16]; } PcGroovePattern;
extern const char *const pc_groove_folders[GROOVE_FOLDERS];
const PcGroovePattern *pc_groove_pattern(unsigned folder, unsigned index);
unsigned pc_groove_pattern_count(unsigned folder);

/* A pad lane is polyphonic when three distinct pitches sound at once. The
 * three latest distinct end times are enough to determine that property. */
typedef struct { int64_t end[3]; int pitch[3]; } PcChordLane;
int pc_groove_chord_feed(PcChordLane *, int pitch, int64_t tick, int64_t end);

int pc_groove_save_open(uintptr_t,uintptr_t,unsigned,unsigned);
void pc_step_erase_current(void);
int pc_groove_active(void);
int pc_groove_open(uintptr_t behaviour, uintptr_t program, unsigned source, unsigned instrument_index);
void pc_groove_close(void);
void pc_groove_event(unsigned kind, uint32_t data);
int pc_groove_paint(uintptr_t screen, uintptr_t graphics);
void pc_groove_chord_labels(uintptr_t list, int64_t ticks, uint8_t labels[128]);
#endif
