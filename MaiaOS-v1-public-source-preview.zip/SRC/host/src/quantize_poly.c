/* Quantize note events independently. Native mono collision caches must
 * never combine distinct notes, including simultaneous unison layers. */
#include "internal.h"
typedef struct {uintptr_t unused;unsigned color,pad;uintptr_t parent,left,right;uint64_t count;} EventSet;
void pc_quantize_poly(uintptr_t quantizer,uintptr_t selection,uintptr_t input,uintptr_t changes,uintptr_t additions){
 uintptr_t end=input+8,node=Q(input,0x18);unsigned walked=0;
 for(;node&&node!=end&&walked++<65536;node=FN(0xb51738,uintptr_t(*)(uintptr_t))(node)){}
 if(node!=end){pc_error(81);return;}
 EventSet other={0};other.left=other.right=(uintptr_t)&other+8;
 for(node=Q(input,0x18);node!=end;node=FN(0xb51738,uintptr_t(*)(uintptr_t))(node)){
  const uint8_t*event=(const uint8_t*)(node+0x20);
  if(event[8]!=3){FN(0x1574460,void(*)(EventSet*,const void*))(&other,event);continue;}
  if(!(FN(0x214bb40,unsigned(*)(uintptr_t,const void*,uintptr_t))(quantizer,event,selection)&1))continue;
  int64_t tick;memcpy(&tick,event,8);int64_t corrected=FN(0x214b610,int64_t(*)(uintptr_t,int64_t))(quantizer,tick);
  if(corrected==tick)continue;
  uint8_t pair[112];memcpy(pair,event,56);memcpy(pair+56,event,56);memcpy(pair+56,&corrected,8);
  FN(0x2151bf0,void(*)(uintptr_t,const void*))(changes,pair);
 }
 if(other.count)FN(0x214e800,void(*)(uintptr_t,uintptr_t,EventSet*,uintptr_t,uintptr_t))(quantizer,selection,&other,changes,additions);
 if(other.parent)FN(0x157df10,void(*)(uintptr_t))(other.parent);
}

/* Time Correct runs a second native 'duplicate' cleanup AFTER publishing
 * the quantized events. It compares pad/time but not pitch. Chords must
 * bypass that monophonic cleanup, including the other quantize paths. */
void pc_quantize_cleanup(uintptr_t list,uintptr_t manager){
 int16_t pitches[128];for(unsigned n=0;n<128;n++)pitches[n]=-1;
 int64_t previous=-1;uintptr_t end=list+0x68,node=Q(list,0x78);unsigned scanned=0;
 for(;node&&node!=end&&scanned++<65536;node=FN(0xb51738,uintptr_t(*)(uintptr_t))(node)){
  const uint8_t*e=(const uint8_t*)(node+0x20);int64_t tick;memcpy(&tick,e,8);
  if(tick!=previous){for(unsigned n=0;n<128;n++)pitches[n]=-1;previous=tick;}
  if(e[8]!=3||e[48]>=128)continue;
  unsigned key=e[48],pitch=e[20]&1?e[22]:120;
  if(pitches[key]>=0)return; /* Preserve intentional unison layering as well. */
  pitches[key]=pitch;
 }
 if(node==end)FN(0x214be90,void(*)(uintptr_t,uintptr_t))(list,manager);
}
