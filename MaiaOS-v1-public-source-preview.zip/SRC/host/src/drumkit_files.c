/* Bounded filesystem scan. No files are opened or allocated in audio. */
#include "internal.h"
#include "drumkit_files.h"
const uint8_t pc_kit_category[16]={0,0,1,1,1,2,2,3,3,3,3,4,4,4,5,5};
const char*const pc_kit_folders[6]={"Kick","Snare","Claps","Hats","Perc","Cymbals"};
unsigned pc_kit_gain_group(unsigned p){return p<16?(pc_kit_category[p]==0?0:pc_kit_category[p]<=2?1:2):3;}
static char folders[128][PC_KIT_PATH],chosen[4][PC_KIT_PATH];
static unsigned length(const char*s){unsigned n=0;while(s[n])n++;return n;}
static int join(char*out,const char*a,const char*b){unsigned n=length(a),m=length(b);if(n+m+2>PC_KIT_PATH)return 0;memcpy(out,a,n);if(n&&out[n-1]!='/')out[n++]='/';memcpy(out+n,b,m+1);return 1;}
static uint32_t random_next(uint32_t*s){uint32_t v=*s?*s:0x9e3779b9;v^=v<<13;v^=v>>17;v^=v<<5;return *s=v;}
static int sample_name(const char*s){unsigned n=length(s),dot=n;while(dot&&s[dot-1]!='.')dot--;if(!dot)return 0;char ext[6]={0};unsigned k=n-dot;if(k>5)return 0;for(unsigned i=0;i<k;i++){unsigned c=(unsigned char)s[dot+i];ext[i]=c>='A'&&c<='Z'?c+32:c;}return !memcmp(ext,"wav",4)||!memcmp(ext,"aif",4)||!memcmp(ext,"aiff",5)||!memcmp(ext,"flac",5);}
static int scan(const char*root,unsigned category,uint32_t*seed){
 if(!join(folders[0],root,pc_kit_folders[category]))return -1;unsigned queued=1,seen=0;
 for(unsigned folder=0;folder<queued;folder++){
  long fd=pc_sys(56,-100,(long)folders[folder],0x8c000,0,0,0);if(fd<0)return -1;
  uint8_t dents[4096];long size;int error=0;
  while((size=pc_sys(61,fd,(long)dents,sizeof dents,0,0,0))>0){
   for(unsigned at=0;at+20<=(unsigned)size;){unsigned bytes=dents[at+16]|(unsigned)dents[at+17]<<8;if(bytes<20||at+bytes>(unsigned)size){error=1;break;}
    const char*name=(const char*)dents+at+19;unsigned n=0;while(n<bytes-19&&name[n])n++;
    if(n&&n<bytes-19&&name[0]!='.'){
     char path[PC_KIT_PATH];if(!join(path,folders[folder],name)){error=1;break;}
     unsigned dir=dents[at+18]==4;
     if(!dents[at+18]){long sub=pc_sys(56,-100,(long)path,0x8c000,0,0,0);if(sub>=0){dir=1;pc_sys(57,sub,0,0,0,0,0);}}
     if(dir){if(queued==128){error=1;break;}memcpy(folders[queued++],path,length(path)+1);}
     else if((dents[at+18]==8||!dents[at+18])&&sample_name(name)){
      if(seen==65536){error=1;break;}unsigned index=seen<4?seen:random_next(seed)%(seen+1);seen++;
      if(index<4)memcpy(chosen[index],path,length(path)+1);
     }
    }at+=bytes;
   }if(error)break;
  }pc_sys(57,fd,0,0,0,0,0);if(error||size<0)return -1;
 }
 return seen>4?4:(int)seen;
}
int pc_kit_pick(const char*root,uint16_t locked,uint32_t seed,char paths[16][PC_KIT_PATH],unsigned*failed){
 for(unsigned p=0;p<16;p++)paths[p][0]=0;
 for(unsigned c=0;c<6;c++){
  unsigned needed=0;for(unsigned p=0;p<16;p++)if(pc_kit_category[p]==c&&!(locked&(1u<<p)))needed++;
  if(!needed)continue;int found=scan(root,c,&seed);if(found<=0){if(failed)*failed=c;return 0;}
  for(unsigned i=(unsigned)found;i>1;i--){unsigned j=random_next(&seed)%i;char tmp[PC_KIT_PATH];memcpy(tmp,chosen[i-1],sizeof tmp);memcpy(chosen[i-1],chosen[j],sizeof tmp);memcpy(chosen[j],tmp,sizeof tmp);}
  unsigned index=0;for(unsigned p=0;p<16;p++)if(pc_kit_category[p]==c&&!(locked&(1u<<p))){const char*file=chosen[index++%(unsigned)found];memcpy(paths[p],file,length(file)+1);}
 }
 return 1;
}
