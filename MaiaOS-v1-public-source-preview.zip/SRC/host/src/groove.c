/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "bounce.h"
#include "groove.h"
#include "groove_store.h"
#include "harmony_groove.h"
#include "../theme/layout.h"

#define STEP_SCREEN 0x6e24f38u
#define STEP_CONTROLLER 0x6d8ec20u
#define EVENT_LIMIT 65536u
#define EVENT_NEXT 0xb51738u
#define CHORD_ENTER 0x7410018u
#define CHORD_LEAVE 0x7410098u
#define TRIGGER_LENGTH 120
#define ROOT_FOLDER GROOVE_FOLDERS

typedef struct {
    int64_t tick;
    uint32_t type, reserved;
    float velocity;
    uint8_t options[20];
    int64_t duration;
    uint8_t key, tail[7];
} NativeEvent;
typedef struct { uintptr_t unused; unsigned color, pad; uintptr_t parent, left, right; uint64_t count; } NativeSet;
typedef struct { int bar, beat, tick; } NativePosition;
_Static_assert(sizeof(NativeEvent) == 56 && offsetof(NativeEvent, duration) == 0x28 &&
               offsetof(NativeEvent, key) == 0x30, "native note ABI");
_Static_assert(sizeof(NativeSet) == 48, "native event set ABI");

typedef struct {
    uintptr_t behaviour, controller, project, program, sequence, track, list, instrument;
    unsigned epoch, source, index, key, bars;
    int64_t ticks;
} Target;

static struct {
    unsigned active, folder, index, chord_count, saving, cursor, saved_count, arp_phase, arp_source;
    unsigned saved_ids[PC_GROOVE_SAVED_MAX];char saved_names[PC_GROOVE_SAVED_MAX][25];
    uint8_t chords[128];
    Target target;
    const char *message;
} browser;
static PcStoredGroove stored;
static void scan_saved(void){browser.saved_count=0;if(browser.folder>=4)return;for(unsigned id=0;id<PC_GROOVE_SAVED_MAX;id++){char name[25];if(pc_groove_read(browser.folder,id,0,name)==1){unsigned n=browser.saved_count++;browser.saved_ids[n]=id;memcpy(browser.saved_names[n],name,25);}}}


static int step_context(uintptr_t behaviour)
{
    uintptr_t manager = behaviour ? Q(behaviour, 0x30) : 0;
    int id = manager ? I(manager, 0xd8) : 0;
    if (id == 0x3080) id = I(manager, 0x80);
    return id == 0x20ad && !I(pc_state_base(), 0x860) && !I(pc_state_base(), 0x5000);
}

static int target_at(Target *out, uintptr_t behaviour, uintptr_t program, unsigned source, unsigned index)
{
    if (!step_context(behaviour) || source >= 128 || index >= 128 || !program)
        return 0;
    uintptr_t ctrl = Q(behaviour, 0x150), project = Q(pc_state_base(), 0x1d08);
    if (!ctrl || Q(ctrl, 0) != host.base+STEP_CONTROLLER || !project ||
        Q(project, 0) != host.base+0x6ecc648 || Q(ctrl, 0x248) != project ||
        Q(project, 0xb8) != program || Q(program, 0) != host.base+0x6ec6860 ||
        I(program, 0x1234))
        return 0;

    uintptr_t clip = Q(project, 0x3d0), list = Q(ctrl, 0xc0);
    uintptr_t seq = Q(project, 0x1c8), track = Q(project, 0x140);
    if (!clip || list != clip+0x688 || !seq || Q(seq, 0) != host.base+0x6ecdff0 ||
        !track || Q(track, 0) != host.base+0x6ecf118)
        return 0;

    int key = I(program, 0x12a8+4*source);
    uintptr_t first = Q(program, 0x2808), last = Q(program, 0x2810);
    if (key < 0 || key > 127 || I(program, 0x14a8+4*key) != (int)index ||
        !first || last < first || (last-first)%8 || last-first > 128*8 ||
        index >= (last-first)/8)
        return 0;

    uintptr_t instrument = Q(first, 8*index);
    int bars = I(seq, 0x200);
    int64_t ticks = *(const int64_t *)(seq+0x348);
    if (!pc_valid(program, instrument) ||
        bars < 1 || bars > GROOVE_MAX_BARS || ticks < 1 || ticks > 128LL*122880)
        return 0;

    *out = (Target){behaviour, ctrl, project, program, seq, track, list, instrument,
                    __atomic_load_n((unsigned *)(pc_state_base()+0x1ef4), AQ),
                    source, index, (unsigned)key, (unsigned)bars, ticks};
    return 1;
}

static int target_current(const Target *t)
{
    if (Q(pc_state_base(), 0x20) != t->behaviour || Q(pc_state_base(), 0x1d08) != t->project ||
        __atomic_load_n((unsigned *)(pc_state_base()+0x1ef4), AQ) != t->epoch)
        return 0;
    Target now;
    return target_at(&now, t->behaviour, t->program, t->source, t->index) &&
           now.controller == t->controller && now.sequence == t->sequence &&
           now.track == t->track && now.list == t->list && now.instrument == t->instrument &&
           now.key == t->key && now.ticks == t->ticks && now.bars == t->bars;
}

static int note(const NativeEvent *event, int64_t limit)
{
    return (event->type & 0x2ff) == 3 && event->key < 128 &&
           event->tick >= 0 && event->tick < limit && event->duration > 0 &&
           event->velocity > 0 && event->velocity <= 1.f;
}

static unsigned pitch(const NativeEvent *event)
{
    return event->options[0] & 1 ? event->options[2] : 120;
}

static int64_t note_end(const NativeEvent *event, int64_t limit)
{
    return event->duration > limit-event->tick ? limit : event->tick+event->duration;
}

static uintptr_t next(uintptr_t node)
{
    return FN(EVENT_NEXT, uintptr_t(*)(uintptr_t))(node);
}

static int chord_keys(uintptr_t list, int64_t ticks, uint8_t keys[128])
{
    PcChordLane lanes[128] = {0};
    uintptr_t end = list+0x68, node = Q(list, 0x78);
    unsigned scanned = 0;
    for (; node && node != end && scanned++ < EVENT_LIMIT; node = next(node)) {
        const NativeEvent *event = (const NativeEvent *)(node+0x20);
        if (event->tick >= ticks) return 1;
        if (!note(event, ticks) || keys[event->key]) continue;
        keys[event->key] = pc_groove_chord_feed(&lanes[event->key], pitch(event),
                                               event->tick, note_end(event, ticks));
    }
    return node == end;
}

static int pad_labels(uintptr_t list, uintptr_t program, int64_t ticks, uint8_t labels[128])
{
    uint8_t keys[128] = {0};
    if (!chord_keys(list, ticks, keys)) return 0;
    for (unsigned pad = 0; pad < 128; pad++) {
        int key = I(program, 0x12a8+4*pad);
        labels[pad] = key >= 0 && key < 128 ? keys[key] : 0;
    }
    return 1;
}

/* Used only by Step Edit paint, where the native model guard is already held.
 * Recheck periodically because changing an event need not change tree size. */
void pc_groove_chord_labels(uintptr_t list, int64_t ticks, uint8_t labels[128])
{
    static struct {
        uintptr_t list, project, program;
        uint64_t count;
        int64_t ticks, updated;
        unsigned epoch;
        uint8_t labels[128];
    } cache;
    uintptr_t project = Q(pc_state_base(), 0x1d08);
    uintptr_t program = project && Q(project, 0) == host.base+0x6ecc648 ? Q(project, 0xb8) : 0;
    memset(labels, 0, 128);
    if (!list || !program || Q(program, 0) != host.base+0x6ec6860 || ticks < 1)
        return;
    int64_t clock[2];
    if (pc_sys(113, 1, (long)clock, 0, 0, 0, 0)) return;
    int64_t ms = clock[0]*1000+clock[1]/1000000;
    unsigned epoch = __atomic_load_n((unsigned *)(pc_state_base()+0x1ef4), AQ);
    uint64_t count = Q(list, 0x88);
    if (cache.list != list || cache.project != project || cache.program != program ||
        cache.epoch != epoch || cache.ticks != ticks || cache.count != count || ms-cache.updated >= 250) {
        cache.list = list;
        cache.project = project;
        cache.program = program;
        cache.epoch = epoch;
        cache.ticks = ticks;
        cache.count = count;
        cache.updated = ms;
        memset(cache.labels, 0, sizeof cache.labels);
        pad_labels(list, program, ticks, cache.labels);
    }
    memcpy(labels, cache.labels, 128);
}

static void init_set(NativeSet *set)
{
    memset(set, 0, sizeof *set);
    set->left = set->right = (uintptr_t)set+8;
}

/* Preserve unrelated pad lanes and automation. Include muted notes so a
 * replacement cannot bring the previous groove back when the pad is unmuted. */
static int stage_removals(NativeSet *set, const Target *t)
{
    uintptr_t end = t->list+0x68, node = Q(t->list, 0x78);
    unsigned scanned = 0;
    for (; node && node != end && scanned++ < EVENT_LIMIT; node = next(node)) {
        const NativeEvent *event = (const NativeEvent *)(node+0x20);
        if ((event->type & 255) == 3 && event->key == t->key)
            FN(0x1574460, void(*)(NativeSet *,const NativeEvent *))(set, event);
    }
    return node == end;
}

static void free_set(NativeSet *set)
{
    if (set->parent) FN(0x157df10, void(*)(uintptr_t))(set->parent);
}

static void stage_note(NativeSet *set, const Target *t, int64_t tick, int64_t duration,
                       unsigned tuning, float velocity, int bass)
{
    NativeEvent event = FN(0x27e54d0, NativeEvent(*)(unsigned,int64_t,int64_t,unsigned,unsigned,float))
                            (t->key, tick, duration, 100, 0, velocity);
    if (bass)
        FN(0x27e4400, void(*)(void *,int,int,int))(event.options, 0, 0, (int)tuning-120);
    FN(0x1574460, void(*)(NativeSet *, const NativeEvent *))(set, &event);
}

static int stage_drums(NativeSet *set, const Target *t, const PcGroovePattern *pattern)
{
    uintptr_t meter = FN(0x29becf0, uintptr_t(*)(uintptr_t))(t->sequence+0xe0);
    int64_t start = 0;
    for (unsigned bar = 0; bar < t->bars; bar++) {
        NativePosition position = {(int)bar+1, 0, 0};
        int64_t end = bar+1 == t->bars ? t->ticks :
            meter ? FN(0x29bf150, int64_t(*)(uintptr_t,const NativePosition *))(meter, &position) :
            (int64_t)(bar+1)*GROOVE_BAR;
        if (end <= start || end > t->ticks || end-start > 122880) return 0;
        for (unsigned i = 0; i < 16 && pattern->hits[i].velocity; i++) {
            const PcGrooveHit *hit = &pattern->hits[i];
            int64_t tick = start+(end-start)*hit->tick/GROOVE_BAR;
            int64_t duration = end-tick < TRIGGER_LENGTH ? end-tick : TRIGGER_LENGTH;
            stage_note(set, t, tick, duration, 120, hit->velocity/127.f, 0);
        }
        start = end;
    }
    return 1;
}

/* Capture values under the existing native model guard, then generate
 * melodic events without retaining pointers into the source lane. */
static PcHarmonyNote harmony_notes[EVENT_LIMIT];
typedef struct {NativeSet*set;const Target*target;} HarmonyOutput;
static int harmony_emit(void*context,int64_t tick,int64_t duration,unsigned tuning,float velocity){
 HarmonyOutput*out=context;stage_note(out->set,out->target,tick,duration,tuning,velocity,1);return 1;
}
static int stage_harmony(NativeSet*set,const Target*t,unsigned key,unsigned mode,unsigned pattern){
 uintptr_t end=t->list+0x68,node=Q(t->list,0x78);unsigned scanned=0,count=0;
 for(;node&&node!=end&&scanned++<EVENT_LIMIT;node=next(node)){
  const NativeEvent*event=(const NativeEvent*)(node+0x20);
  if(event->key==key&&note(event,t->ticks))harmony_notes[count++]=(PcHarmonyNote){event->tick,event->duration,event->velocity,pitch(event)};
 }
 if(node!=end||!count)return 0;int64_t time[2]={0};pc_sys(113,1,(long)time,0,0,0,0);
 HarmonyOutput output={set,t};return pc_harmony_generate(harmony_notes,count,t->ticks,mode,pattern,(uint32_t)time[1],harmony_emit,&output)>0;
}

static int publish(uintptr_t factory, uintptr_t list, NativeSet *removals,
                   NativeSet *additions, const char *name)
{
    if ((!additions->count && !removals->count) || !factory || !Q(factory, 0x60) ||
        Q(list, 0x88) < removals->count) return 0;
    NativeSet pairs;
    init_set(&pairs);
    uintptr_t title = 0, merge = 0;
    FN(0xf535c0, void(*)(void *, const char *))(&title, name);
    FN(0xf1c620, void(*)(void *))(&merge);
    uint64_t expected = Q(list, 0x88)-removals->count+additions->count;
    PcNativeReturn command = FN(0x19500e0, PcNativeReturn(*)(uintptr_t,uintptr_t,NativeSet *,
                                   NativeSet *,NativeSet *,void *,void *,unsigned,uintptr_t))
        (factory, list, removals, additions, &pairs, &title, &merge, 0, 0);
    if (command.owner) FN(0x123bca0, void(*)(uintptr_t))(command.owner);
    FN(0xf0a290, void(*)(void *))(&merge);
    FN(0xf0a290, void(*)(void *))(&title);
    return command.object && Q(list, 0x88) == expected;
}

int pc_record_add_triggers(uintptr_t factory, uintptr_t list, int64_t ticks, uint8_t keys[128])
{
    /* A native root event at the downbeat already launches this pad. */
    uintptr_t end = list+0x68;
    uintptr_t node = FN(0x27d00f0, uintptr_t(*)(uintptr_t,int64_t))(list+0x60, 0);
    unsigned scanned = 0;
    for (; node && node != end; node = next(node)) {
        const NativeEvent *event = (const NativeEvent *)(node+0x20);
        if (event->tick != 0) break;
        if (++scanned > EVENT_LIMIT) return 0;
        if (note(event, ticks) && pitch(event) == 120) keys[event->key] = 0;
    }
    if (!node) return 0;

    NativeSet empty, additions;
    init_set(&empty);
    init_set(&additions);
    for (unsigned key = 0; key < 128; key++) {
        if (!keys[key]) continue;
        Target target = {.key = key};
        stage_note(&additions, &target, 0, ticks, 120, 1.f, 0);
    }
    int ok = !additions.count || publish(factory, list, &empty, &additions, "Trigger recorded sample");
    free_set(&additions);
    return ok;
}

static void apply(unsigned folder, unsigned selection)
{
    const Target *t = &browser.target;
    int melodic=folder>=GROOVE_BASS&&folder<GROOVE_FOLDERS,kick=folder==GROOVE_KICK;
    NativeSet removals, additions;
    init_set(&removals);
    init_set(&additions);
    int ready;
    if (melodic) {
        unsigned source=folder==GROOVE_ARP?browser.arp_source:selection;
        int key = I(t->program, 0x12a8+4*source);
        ready = key>=0&&key<128&&key!=(int)t->key&&stage_harmony(&additions,t,key,folder-GROOVE_BASS,selection);
    } else {
        const PcGroovePattern *pattern = pc_groove_pattern(folder, selection);
        if(selection<pc_groove_pattern_count(folder))ready=pattern&&stage_drums(&additions,t,pattern);
        else {
            unsigned n=selection-pc_groove_pattern_count(folder);ready=n<browser.saved_count&&pc_groove_read(folder,browser.saved_ids[n],&stored,0)==1;
            if(ready){
                uint64_t estimated=((uint64_t)t->ticks+stored.span-1)/stored.span*stored.count;
                if(estimated>EVENT_LIMIT)ready=0;
                else for(int64_t start=0;start<t->ticks;start+=stored.span)for(unsigned j=0;j<stored.count;j++){
                    int64_t tick=start+stored.hits[j].tick;if(tick>=t->ticks)break;
                    stage_note(&additions,t,tick,t->ticks-tick<TRIGGER_LENGTH?t->ticks-tick:TRIGGER_LENGTH,120,stored.hits[j].velocity,0);
                }
            }
        }
    }

    int removable = ready && stage_removals(&removals, t);
    unsigned previous_role = kick ? pc_sc_role(t->instrument) : 0;
    if (!ready) {
        browser.message = melodic ? "No chords on that pad" : "Cannot fit this pattern";
    } else if (!removable) {
        browser.message = "Cannot read the pad events";
    } else if (kick && !pc_sc_set(t->program, t->instrument, 1)) {
        browser.message = "Sidechain Send unavailable";
    } else if (!publish(Q(t->controller, 0x240), t->list, &removals, &additions, folder==GROOVE_BASS?"Replace Bass":folder==GROOVE_LEAD?"Replace Lead":folder==GROOVE_ARP?"Replace Arp Chords":"Replace Groove")) {
        if (kick) {
            if (previous_role) pc_sc_set(t->program, t->instrument, previous_role);
            else pc_sc_forget(t->instrument, 0);
        }
        browser.message = "Sequence import failed";
    } else {
        pc_editorial_step_invalidate();
        pc_groove_close();
    }
    free_set(&removals);
    free_set(&additions);
}

int pc_groove_active(void)
{
    return __atomic_load_n(&browser.active, AQ)||pc_chord_browser_active();
}

void pc_groove_close(void)
{
    pc_chord_browser_close();
    __atomic_store_n(&browser.active, 0, RL);
}

int pc_groove_open(uintptr_t behaviour, uintptr_t program, unsigned source, unsigned index)
{
    if (!FN(CHORD_ENTER, int(*)(void))()) return 0;
    int valid = target_at(&browser.target, behaviour, program, source, index);
    FN(CHORD_LEAVE, void(*)(void))();
    if (!valid) return 0;
    browser.saving=0;browser.arp_phase=0;
    browser.folder = ROOT_FOLDER;
    browser.index = 0;
    browser.message = 0;
    __atomic_store_n(&browser.active, 1, RL);
    return 1;
}

int pc_groove_save_open(uintptr_t b,uintptr_t p,unsigned source,unsigned index){
 if(!pc_groove_open(b,p,source,index))return 0;
 if(!FN(CHORD_ENTER,int(*)(void))()){pc_groove_close();return 0;}
 stored.count=0;stored.span=browser.target.ticks;memset(stored.name,' ',24);memcpy(stored.name,"New groove",10);stored.name[24]=0;
 uintptr_t list=browser.target.list,end=list+0x68,node=Q(list,0x78);unsigned scanned=0;
 for(;node&&node!=end&&scanned++<EVENT_LIMIT;node=next(node)){
  const NativeEvent*e=(const NativeEvent*)(node+0x20);
  if(e->key!=browser.target.key||!note(e,stored.span))continue;
  if(stored.count&&stored.hits[stored.count-1].tick==e->tick){if(e->velocity>stored.hits[stored.count-1].velocity)stored.hits[stored.count-1].velocity=e->velocity;continue;}
  if(stored.count==PC_GROOVE_HITS_MAX)break;
  stored.hits[stored.count++]=(PcStoredHit){e->tick,e->velocity,0};
 }
 FN(CHORD_LEAVE,void(*)(void))();
 if(node!=end||!stored.count){pc_groove_close();host.ui.message="Empty or oversized groove";return 0;}
 browser.saving=1;browser.cursor=0;return 1;
}
static void save_pattern(void){
 unsigned len=24;while(len&&stored.name[len-1]==' ')len--;
 if(!len){browser.message="Enter a groove name";return;}
 char name[25]={0};memcpy(name,stored.name,len);
 unsigned id;for(id=0;id<PC_GROOVE_SAVED_MAX;id++)if(!pc_groove_read(browser.folder,id,0,0))break;
 if(id==PC_GROOVE_SAVED_MAX){browser.message="Category is full";return;}
 char original[25];memcpy(original,stored.name,25);memcpy(stored.name,name,25);
 if(pc_groove_write(browser.folder,id,&stored)){pc_groove_close();host.ui.message="Groove saved";}
 else browser.message="Save failed / check SD card";
 memcpy(stored.name,original,25);
}
static unsigned item_count(void)
{
    if(browser.saving==1)return 4;
    if (browser.folder == ROOT_FOLDER) return GROOVE_FOLDERS;
    if(browser.folder==GROOVE_ARP&&browser.arp_phase)return pc_arp_count();
    if (browser.folder>=GROOVE_BASS) return browser.chord_count;
    return pc_groove_pattern_count(browser.folder)+browser.saved_count;
}

void pc_groove_event(unsigned kind, uint32_t data)
{
    if(pc_chord_browser_active()){pc_chord_browser_event(kind,data);return;}
    if (!pc_groove_active()) return;
    if (kind == 12 && data == 2) {
        pc_groove_close();
        return;
    }
    if(browser.saving==2){
        if(kind==14){
            static const char chars[]=" ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.";
            unsigned at=0;while(at<sizeof chars-1&&chars[at]!=stored.name[browser.cursor])at++;
            int64_t value=(int64_t)at+(int32_t)data;value%=(int)(sizeof chars-1);if(value<0)value+=sizeof chars-1;
            stored.name[browser.cursor]=chars[value];browser.message=0;
        }else if(kind==35){int cursor=(int)browser.cursor+(int32_t)data;browser.cursor=cursor<0?0:cursor>23?23:cursor;}
        else if(kind==12&&(data==0||data==3))save_pattern();
        else if(kind==12&&data==1){browser.saving=1;browser.index=browser.folder;browser.folder=ROOT_FOLDER;}
        return;
    }
    if(browser.saving==1&&kind==12&&data==3){browser.folder=browser.index;browser.saving=2;browser.message=0;return;}
    if (kind == 12 && data == 0) {
        if(browser.folder==GROOVE_ARP&&browser.arp_phase&&browser.chord_count>1){browser.arp_phase=0;browser.index=0;browser.message="Choose a Chords source";return;}
        if (browser.folder == ROOT_FOLDER) pc_groove_close();
        else {
            browser.index = browser.folder;
            browser.folder = ROOT_FOLDER;
            browser.message = 0;
        }
        return;
    }
    if (kind == 14) {
        int64_t index = (int64_t)browser.index+(int32_t)data;
        unsigned count = item_count();
        browser.index = index < 0 || !count ? 0 : index >= count ? count-1 : (unsigned)index;
        browser.message = 0;
        return;
    }
    if (kind != 12 || data != 3) return;
    if (!FN(CHORD_ENTER, int(*)(void))()) {
        browser.message = "Project busy / try again";
        return;
    }
    if (!target_current(&browser.target)) {
        browser.message = "Sequence or target changed";
    } else if (browser.folder == ROOT_FOLDER) {
        unsigned folder = browser.index;
        if (folder < GROOVE_BASS) {
            browser.folder = folder;
            scan_saved();
            browser.index = 0;
            browser.message = 0;
        } else {
            uint8_t labels[128] = {0};
            browser.chord_count = 0;
            if (pad_labels(browser.target.list, browser.target.program, browser.target.ticks, labels)) {
                for (unsigned pad = 0; pad < 128; pad++) {
                    if (labels[pad] && I(browser.target.program, 0x12a8+4*pad) != (int)browser.target.key)
                        browser.chords[browser.chord_count++] = pad;
                }
            }
            browser.arp_phase=0;
            if (browser.chord_count == 1&&folder!=GROOVE_ARP) apply(folder, browser.chords[0]);
            else if (browser.chord_count) {
                browser.folder = folder;
                if(folder==GROOVE_ARP&&browser.chord_count==1){browser.arp_source=browser.chords[0];browser.arp_phase=1;}
                browser.index = 0;
                browser.message = browser.arp_phase?"Choose an arp pattern":"Choose a Chords source";
            } else browser.message = "No other Chords pad";
        }
    } else if(browser.folder==GROOVE_ARP){
        if(browser.arp_phase)apply(GROOVE_ARP,browser.index);
        else if(browser.index<browser.chord_count){browser.arp_source=browser.chords[browser.index];browser.arp_phase=1;browser.index=0;browser.message="Choose an arp pattern";}
    } else if (browser.folder>=GROOVE_BASS) {
        if (browser.index < browser.chord_count) apply(browser.folder, browser.chords[browser.index]);
    } else apply(browser.folder, browser.index);
    FN(CHORD_LEAVE, void(*)(void))();
}

static void rect(void *graphics, int x, int y, int w, int h, unsigned color)
{
    FN(0x102d5e0, void(*)(uintptr_t,unsigned))((uintptr_t)graphics, pc_theme_colour(color));
    FN(0x102e000, void(*)(uintptr_t,int,int,int,int))((uintptr_t)graphics, x, y, w, h);
}

static void pad_label(char *label, unsigned pad)
{
    label[0] = 'A'+pad/16;
    label[1] = '0'+(pad%16+1)/10;
    label[2] = '0'+(pad%16+1)%10;
}

int pc_groove_paint(uintptr_t screen, uintptr_t graphics)
{
    if(pc_chord_browser_active())return pc_chord_browser_paint(screen,graphics);
    if (!pc_groove_active()) return 0;
    if (Q(pc_state_base(), 0x20) != browser.target.behaviour || !step_context(browser.target.behaviour) ||
        __atomic_load_n((unsigned *)(pc_state_base()+0x1ef4), AQ) != browser.target.epoch) {
        pc_groove_close();
        return 0;
    }
    if (Q(screen, 0) != host.base+STEP_SCREEN) return 0;
    typedef struct {uint64_t xy, wh;} Bounds;
    Bounds bounds = FN(0x10f8ec0, Bounds(*)(uintptr_t))(screen);
    int w = (uint32_t)bounds.wh, h = bounds.wh>>32;
    if (w < 200 || h < 130 || w > 1024 || h > 1024) return 0;
    EiCanvas c = {(void *)graphics, rect, w, h};
    ei_rect(&c, 0, 0, w, h, MPC_THEME_BG);
    char target[] = "PAD A01";
    pad_label(target+4, browser.target.source);
    ei_header(&c, browser.saving?"SAVE GROOVE":"GROOVE IMPORT", target);
    if(browser.saving==2){
        ei_text(&c,8,30,pc_groove_folders[browser.folder],w-16,MPC_THEME_ACCENT);
        ei_text(&c,8,58,stored.name,w-16,MPC_THEME_TEXT);
        char cursor[25];memset(cursor,' ',24);cursor[browser.cursor]='^';cursor[24]=0;
        ei_text(&c,8,74,cursor,w-16,MPC_THEME_ACCENT);
        ei_text(&c,8,h-45,browser.message?browser.message:"ENC character  +/- cursor",w-16,MPC_THEME_MUTED);
        ei_text(&c,8,h-17,"B1 SAVE   B2 CATEGORY   B3 CANCEL",w-16,MPC_THEME_MUTED);return 1;
    }
    ei_text(&c, 8, 25, browser.folder == ROOT_FOLDER ? "SELECT INSTRUMENT" :
            pc_groove_folders[browser.folder], w-16, MPC_THEME_ACCENT);
    unsigned rows = (h-83)/22;
    unsigned first = browser.index >= rows ? browser.index-rows+1 : 0;
    unsigned count = item_count();
    for (unsigned i = first; i < count && i-first < rows; i++) {
        int y = 44+22*(i-first);
        int selected = i == browser.index;
        if (selected) ei_rect(&c, 5, y-3, w-10, 20, MPC_THEME_SELECTED);
        char chord[] = "A01 / CHORDS";
        const char *name;
        if (browser.folder == ROOT_FOLDER) name = pc_groove_folders[i];
        else if(browser.folder==GROOVE_ARP&&browser.arp_phase)name=pc_arp_name(i);
        else if (browser.folder>=GROOVE_BASS) {
            pad_label(chord, browser.chords[i]);
            name = chord;
        } else {
            unsigned builtins=pc_groove_pattern_count(browser.folder);
            name=i<builtins?pc_groove_pattern(browser.folder,i)->name:browser.saved_names[i-builtins];
        }
        ei_text(&c, 10, y, name, w-20, selected ? MPC_THEME_TEXT : MPC_THEME_MUTED);
    }
    if (browser.message) ei_text(&c, 8, h-36, browser.message, w-16, MPC_THEME_ACCENT);
    ei_rule(&c, h-21);
    ei_text(&c, 8, h-17, "B1 BACK    ENC SELECT    B3 CLOSE", w-16, MPC_THEME_MUTED);
    return 1;
}

/* B3 erases the highlighted lane and cursor cell, independent of pad-down. */
void pc_step_erase_current(void){
 if(!FN(CHORD_ENTER,int(*)(void))())return;
 uintptr_t b=Q(pc_state_base(),0x20),p=Q(pc_state_base(),0x1d08),program=p?Q(p,0xb8):0;
 Target t;int found=0;unsigned index=p?(unsigned)I(p,0x500):128;
 if(program&&index<128)for(unsigned source=0;source<128;source++)
  if(target_at(&t,b,program,source,index)){found=1;break;}
 if(found){
  typedef struct {int32_t index,padding;int64_t tick,grid,first,last,length;int32_t max,padding2;} StepInfo;
  StepInfo info=FN(0x157f310,StepInfo(*)(uintptr_t,int))(t.controller,I(t.controller,0xe4));
  if(info.index>=0&&info.grid>0&&info.grid<=15360){
   int64_t tick=(int64_t)info.index*info.grid;
   NativeSet removals,additions;init_set(&removals);init_set(&additions);
   uintptr_t end=t.list+0x68,node=Q(t.list,0x78);unsigned scanned=0;
   for(;node&&node!=end&&scanned++<EVENT_LIMIT;node=next(node)){
    const NativeEvent*e=(const NativeEvent*)(node+0x20);
    if((e->type&255)==3&&e->key==t.key&&e->tick>=tick&&e->tick<tick+info.grid)
     FN(0x1574460,void(*)(NativeSet*,const NativeEvent*))(&removals,e);
   }
   if(node==end&&removals.count&&publish(Q(t.controller,0x240),t.list,&removals,&additions,"Erase selected step"))pc_editorial_step_invalidate();
   free_set(&removals);
  }
 }
 FN(CHORD_LEAVE,void(*)(void))();
}

