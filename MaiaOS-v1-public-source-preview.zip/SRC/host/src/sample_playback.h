/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_SAMPLE_PLAYBACK_H
#define PC_SAMPLE_PLAYBACK_H
#include <stdint.h>
#define PC_TEMPO_FADE 128u
#define PC_TEMPO_WINDOW 2646u
typedef struct {
    float last[2], previous[2], correction[2];
    unsigned left, primed, window;
} PcTempoContinuity;
void pc_tempo_continuity(PcTempoContinuity *,float *,float *,unsigned,int);
void pc_sample_playback_init(void);
void pc_sample_playback_poll(void);
unsigned pc_sample_notice(void);
int pc_physical_pad_dispatch(void);
#endif
