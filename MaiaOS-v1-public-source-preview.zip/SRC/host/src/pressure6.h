/* Airwindows Pressure6 adapter. MIT DSP, GPL host bridge. */
#pragma once
#include <stdint.h>
typedef struct {float amount,attack_ms,release_ms,boost,rate;unsigned colour;} PcPressure6;
#ifdef __cplusplus
extern "C" {
#endif
float pc_pressure6_process(uintptr_t,unsigned,float*,float*,unsigned,const PcPressure6*);
void pc_pressure6_native(uintptr_t,const float**,float**,uintptr_t,uintptr_t,uintptr_t);
#ifdef __cplusplus
}
#endif
