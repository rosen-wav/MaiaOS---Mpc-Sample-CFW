/* MULTISAMPLES playback, SD preset archive and external capture. */
#include "internal.h"
#include "synth_filter.h"
#include "multisamples.h"
#include "bounce.h"
#include "preset_delete.h"
#include "../theme/multisample_text.h"

#define MS_RATE 44100u
#define MS_COUNT 9u
#define MS_LAYERS 4u
#define MS_MIN_SECONDS 2u
#define MS_MAX_SECONDS 10u
#define MS_TAIL_SECONDS 28u
#define MS_HOLD (MS_MIN_SECONDS*MS_RATE)
#define MS_LIMIT ((MS_MAX_SECONDS+MS_TAIL_SECONDS)*MS_RATE)
#define MS_QUIET (MS_RATE*35u/100u)
#define MS_KEEP (MS_RATE/10u)
#define MS_PATH 640
#define MS_PRESETS 96
#define MS_DIRECTORY 0x84000u /* AArch64 O_CLOEXEC | O_DIRECTORY */
#define MS_PCM_BUDGET (160u*1024u*1024u)
static const unsigned roots[MS_COUNT]={36,43,48,55,60,67,72,79,84};

typedef struct {uint32_t frames,offset,onset;} MsRegion;
typedef struct {
 char magic[8],name[32];
 uint32_t version,rate,bytes,layers;
 MsRegion zone[MS_COUNT*MS_LAYERS];
} MsFile;
typedef struct {double phase,step;unsigned zone,owner,attack,age,release,release_total;float gain,level,sustain,release_level;} MsVoice;
typedef struct {const MsFile *file;unsigned envelope[3],active,resident;MsVoice voices[PC_MS_VOICES];} MsPlayer;
static unsigned resident_bytes;

unsigned pc_ms_zone(unsigned note){
 if(note<40)return 0;
 if(note>=83)return 8;
 unsigned octave=(note-35)/12;
 return 2*octave+(note>=40+12*octave);
}
static unsigned len(const char*s,unsigned max){unsigned n=0;while(n<max&&s[n])n++;return n;}
static void copy(char*out,unsigned cap,const char*s){unsigned n=len(s,cap-1);memcpy(out,s,n);out[n]=0;}
static int root_path(char*path){
 char root[512];
 if(!pc_sd_folder(root,sizeof root,""))return 0;
 unsigned n=len(root,sizeof root);
 if(n+15>=MS_PATH)return 0;
 memcpy(path,root,n);
 if(n&&path[n-1]!='/')path[n++]='/';
 memcpy(path+n,"multisamples",13);
 return 1;
}
static int valid_id(const char*id){
 for(unsigned n=0;n<PC_MS_ID;n++)if(!((id[n]>='0'&&id[n]<='9')||(id[n]>='a'&&id[n]<='f')))return 0;
 return 1;
}
static int preset_path(char*path,const char*id,int temp){
 if(!root_path(path)||!valid_id(id))return 0;
 unsigned n=len(path,MS_PATH);
 path[n++]='/';memcpy(path+n,id,PC_MS_ID);n+=PC_MS_ID;
 if(temp==1)memcpy(path+n,".part",6);
 else if(temp==2)memcpy(path+n,".hide",6);
 else memcpy(path+n,".msamp",7);
 return 1;
}
static unsigned file_layers(const MsFile *file){
 if(file->version==1&&!file->layers)return 1;
 return file->version==2&&file->layers>=2&&file->layers<=MS_LAYERS?file->layers:0;
}
static unsigned header_size(unsigned layers){return offsetof(MsFile,zone)+layers*MS_COUNT*sizeof(MsRegion);}
static int read_header(int fd,MsFile*h){
 unsigned base=header_size(1);
 if(pc_sys(67,fd,(long)h,base,0,0,0)!=base)return 0;
 unsigned layers=file_layers(h);
 if(layers<=1)return layers!=0;
 unsigned extra=header_size(layers)-base;
 return pc_sys(67,fd,(long)((uint8_t*)h+base),extra,base,0,0)==extra;
}
static int valid_file(const MsFile*h){
 unsigned layers=file_layers(h);
 if(memcmp(h->magic,"MAIAMUL1",8)||!layers||h->rate!=MS_RATE||
    !h->name[0]||len(h->name,sizeof h->name)==sizeof h->name)return 0;
 unsigned offset=header_size(layers);
 for(unsigned n=0;n<MS_COUNT*layers;n++){
  if(h->zone[n].frames<MS_HOLD||h->zone[n].frames>MS_LIMIT||h->zone[n].offset!=offset||h->zone[n].onset>=h->zone[n].frames-1)return 0;
  offset+=h->zone[n].frames*8;
 }
 return h->bytes==offset;
}
static unsigned layer_velocity(unsigned layers,unsigned layer){return (layer+1)*127/layers;}
static unsigned playback_layer(unsigned layers,unsigned velocity){
 unsigned layer=0;
 while(velocity>layer_velocity(layers,layer))layer++;
 return layer;
}
uintptr_t pc_ms_load(const uint8_t *patch){
 if(!patch||memcmp(patch,"MPCMUL01",8))return 0;
 char path[MS_PATH];if(!preset_path(path,(const char*)patch+8,0))return 0;
 long fd=pc_sys(56,-100,(long)path,0xa0000,0,0,0);
 if(fd<0)return 0;
 MsFile header;long size=pc_sys(62,fd,0,2,0,0,0);
 if(!read_header((int)fd,&header)||!valid_file(&header)||size!=(long)header.bytes){
  pc_sys(57,fd,0,0,0,0,0);return 0;
 }
 unsigned old=__atomic_load_n(&resident_bytes,AQ),resident=0;
 while((unsigned)size<=MS_PCM_BUDGET-old){
  if(__atomic_compare_exchange_n(&resident_bytes,&old,old+(unsigned)size,1,__ATOMIC_ACQ_REL,AQ)){
   resident=(unsigned)size;break;
  }
 }
 /* Keep the preloaded path while the PCM budget allows it. Large layered
  * sets use a read-only file mapping rather than reserving that much RAM. */
 if(!resident&&file_layers(&header)==1){pc_sys(57,fd,0,0,0,0,0);return 0;}
 long memory=resident?pc_sys(222,0,size,3,0x22,-1,0):pc_sys(222,0,size,1,2,fd,0);
 if(memory>=0){
  unsigned read=resident?0:(unsigned)size;
  while(read<(unsigned)size){
   long got=pc_sys(67,fd,memory+read,(unsigned)size-read,read,0,0);
   if(got==-4)continue;if(got<=0)break;read+=(unsigned)got;
  }
  if(read==(unsigned)size&&valid_file((const MsFile*)memory)&&((const MsFile*)memory)->bytes==(unsigned)size){
   long ctx=pc_sys(222,0,sizeof(MsPlayer),3,0x22,-1,0);
   if(ctx>=0){
    MsPlayer*p=(MsPlayer*)ctx;p->file=(const MsFile*)memory;p->resident=resident;
    for(unsigned k=0;k<3;k++)p->envelope[k]=pc_ms_envelope(patch,k);
    pc_sys(57,fd,0,0,0,0,0);return (uintptr_t)p|1;
   }
  }
  pc_sys(215,memory,size,0,0,0,0);
 }
 if(resident)__atomic_fetch_sub(&resident_bytes,resident,RL);
 pc_sys(57,fd,0,0,0,0,0);return 0;
}
static MsPlayer *player(uintptr_t ctx){return (MsPlayer*)(ctx&~(uintptr_t)1);}
void pc_ms_free(uintptr_t ctx){
 MsPlayer*p=player(ctx);if(!p)return;
 unsigned bytes=p->file->bytes;
 pc_sys(215,(long)p->file,bytes,0,0,0,0);if(p->resident)__atomic_fetch_sub(&resident_bytes,p->resident,RL);pc_sys(215,(long)p,sizeof *p,0,0,0,0);
}
static double ratio(int semitones){
 static const double scale[]={1.,1.0594630944,1.1224620483,1.189207115,1.25992105,1.334839854,
  1.414213562,1.498307077,1.587401052,1.681792831,1.781797436,1.887748625};
 int octave=semitones/12,degree=semitones%12;
 if(degree<0){degree+=12;octave--;}
 return octave<0?scale[degree]/(1u<<-octave):scale[degree]*(1u<<octave);
}
static const unsigned envelope_defaults[]={3,100,40};
static const unsigned envelope_max[]={2000,100,5000};
unsigned pc_ms_envelope(const uint8_t*patch,unsigned k){
 if(k>=3)return 0;
 unsigned at=57+2*k,value=patch[at]|(unsigned)patch[at+1]<<8;
 return patch[56]==1&&value<=envelope_max[k]?value:envelope_defaults[k];
}
void pc_ms_set(uintptr_t ctx,unsigned k,unsigned value){
 MsPlayer*p=player(ctx);
 if(p&&k<3&&value<=envelope_max[k])p->envelope[k]=value;
}
static unsigned envelope_frames(unsigned ms){
 unsigned frames=ms*MS_RATE/1000;
 return frames<132?132:frames;
}
int pc_ms_on(uintptr_t ctx,unsigned note,unsigned velocity,unsigned owner){
 MsPlayer*p=player(ctx);if(!p||note>=128||!velocity||velocity>127||p->active>=PC_MS_VOICES)return 0;
 unsigned root=pc_ms_zone(note),layers=file_layers(p->file);
 unsigned zone=root*layers+playback_layer(layers,velocity);
 for(unsigned n=0;n<PC_MS_VOICES;n++){
  MsVoice*v=&p->voices[n];if(v->gain)continue;
  *v=(MsVoice){.phase=p->file->zone[zone].onset,.step=ratio((int)note-(int)roots[root]),
   .zone=zone,.owner=owner,.gain=velocity/127.f,.attack=envelope_frames(p->envelope[0]),
   .sustain=p->envelope[1]/100.f};
  p->active++;return 1;
 }
 return 0;
}
static void release_voice(MsVoice*v,unsigned frames){
 v->release_level=v->level;v->release=v->release_total=frames;
}
void pc_ms_off(uintptr_t ctx,unsigned owner){
 MsPlayer*p=player(ctx);if(!p)return;
 for(unsigned n=0;n<PC_MS_VOICES;n++){
  MsVoice*v=&p->voices[n];
  if(v->gain&&v->owner==owner&&!v->release){release_voice(v,envelope_frames(p->envelope[2]));return;}
 }
}
void pc_ms_stop(uintptr_t ctx){
 MsPlayer*p=player(ctx);
 if(p)for(unsigned n=0;n<PC_MS_VOICES;n++)
  if(p->voices[n].gain)release_voice(&p->voices[n],132);
}
unsigned pc_ms_voices(uintptr_t ctx){
 MsPlayer*p=player(ctx);return p?p->active:0;
}
void pc_ms_render(uintptr_t ctx,float*l,float*r,unsigned frames){
 memset(l,0,frames*sizeof *l);memset(r,0,frames*sizeof *r);
 MsPlayer*p=player(ctx);if(!p||!p->active)return;
 for(unsigned n=0;n<PC_MS_VOICES;n++){
  MsVoice*v=&p->voices[n];if(!v->gain)continue;
  MsRegion region=p->file->zone[v->zone];
  const float *data=(const float*)((const uint8_t*)p->file+region.offset);
  for(unsigned j=0;j<frames;j++){
   unsigned at=(unsigned)v->phase;
   if(at+1>=region.frames){v->gain=0;p->active--;break;}
   if(v->release)v->level=v->release_level*(float)v->release/(float)v->release_total;
   else if(v->age<v->attack)v->level=v->sustain*(float)v->age++/(float)v->attack;
   else v->level=v->sustain;
   float blend=(float)(v->phase-at),gain=v->gain*v->level;
   double left=(region.frames-1-v->phase)/v->step;
   if(left<132)gain*=(float)(left/132);
   l[j]+=gain*(data[2*at]+(data[2*at+2]-data[2*at])*blend);
   r[j]+=gain*(data[2*at+1]+(data[2*at+3]-data[2*at+1])*blend);
   v->phase+=v->step;
   if(v->release&&!--v->release){v->gain=0;p->active--;break;}
  }
 }
}
/* The fixed-length ALSA sequencer note event ABI. Destination is explicit
 * so recording never broadcasts notes to unrelated instruments. */
typedef struct {
 uint8_t type,flags,tag,queue;
 uint32_t time[2];
 uint8_t source_client,source_port,dest_client,dest_port;
 uint8_t channel,note,velocity,off_velocity;
 uint32_t duration,unused;
} MsMidiEvent;
_Static_assert(sizeof(MsMidiEvent)==28,"ALSA sequencer note event");
static struct {
 void *seq;int port,client;
 int(*open)(void**,const char*,int,int),(*close)(void*),(*client_id)(void*);
 int(*create_port)(void*,const char*,unsigned,unsigned);
 int(*next_client)(void*,void*),(*next_port)(void*,void*),(*send)(void*,const MsMidiEvent*);
 int(*client_alloc)(void**),(*port_alloc)(void**),(*get_client)(void*),(*get_port)(void*);
 void(*client_free)(void*),(*port_free)(void*),(*set_client)(void*,int),(*set_port_client)(void*,int),(*set_port)(void*,int);
 unsigned(*capability)(void*);
 const char*(*client_name)(void*),*(*port_name)(void*);
} midi;
typedef struct {uint8_t client,port;} MsPort;
typedef struct {char id[17],name[32];} MsPreset;
enum {MS_CLOSED,MS_BROWSER,MS_SETUP,MS_RUNNING,MS_RENAME,MS_DELETE};
static struct {
 unsigned screen,epoch,presets,channel,selection,cursor,seconds,layers,delete_choice;
 uintptr_t program,instrument,project;
 MsPort destination;
 MsPreset preset[MS_PRESETS];
 char id[17],name[32],part[MS_PATH],final[MS_PATH];
 const char *message;
 unsigned cancel,finished,success,note,collecting,writer,frames,first_hot,last_hot;
 uintptr_t input_object;
 float *pcm;
} ms={.seconds=MS_MIN_SECONDS,.layers=1};

static int midi_open(void){
 if(midi.seq)return 1;
 void*(*sym)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
#define ALSA(field,symbol) midi.field=sym(0,"snd_seq_" symbol);if(!midi.field)return 0
 ALSA(open,"open");ALSA(close,"close");ALSA(client_id,"client_id");ALSA(create_port,"create_simple_port");
 ALSA(next_client,"query_next_client");ALSA(next_port,"query_next_port");ALSA(send,"event_output_direct");
 ALSA(client_alloc,"client_info_malloc");ALSA(port_alloc,"port_info_malloc");
 ALSA(client_free,"client_info_free");ALSA(port_free,"port_info_free");
 ALSA(get_client,"client_info_get_client");ALSA(get_port,"port_info_get_port");
 ALSA(set_client,"client_info_set_client");ALSA(set_port_client,"port_info_set_client");
 ALSA(set_port,"port_info_set_port");ALSA(client_name,"client_info_get_name");ALSA(capability,"port_info_get_capability");ALSA(port_name,"port_info_get_name");
#undef ALSA
 if(midi.open(&midi.seq,"default",1,1)<0){midi.seq=0;return 0;}
 midi.port=midi.create_port(midi.seq,"Maia Multisamples",1|32,2|1048576);
 midi.client=midi.client_id(midi.seq);
 if(midi.port<0||midi.client<0){midi.close(midi.seq);midi.seq=0;return 0;}
 return 1;
}
static int gadget_name(const char*name){
 return name&&len(name,6)==6&&!memcmp(name,"f_midi",6)&&
        (!name[6]||name[6]=='-'||name[6]==' ');
}
static void midi_ports(void){
 ms.destination=(MsPort){0};
 if(!midi_open())return;
 void *client=0,*port=0;
 if(midi.client_alloc(&client)<0)return;
 if(midi.port_alloc(&port)<0){midi.client_free(client);return;}
 midi.set_client(client,-1);
 while(midi.next_client(midi.seq,client)>=0){
  int number=midi.get_client(client);
  /* Kernel/device endpoints only. Exclude system, MIDI Through and Maia. */
  if(number<=14||number>=128||number==midi.client)continue;
  int gadget=gadget_name(midi.client_name(client));
  midi.set_port_client(port,number);midi.set_port(port,-1);
  while(midi.next_port(midi.seq,port)>=0){
   unsigned caps=midi.capability(port);const char*name=midi.port_name(port);
   if(!(caps&2)||(caps&(128|256))||!name)continue;
   unsigned port_number=midi.get_port(port);
   if(port_number>255)continue;
   if((gadget||gadget_name(name))&&(!ms.destination.client||(!port_number&&ms.destination.port))){
    ms.destination.client=(uint8_t)number;ms.destination.port=(uint8_t)port_number;
   }
  }
 }
 midi.port_free(port);midi.client_free(client);
}
static const char*midi_out_notice(void){
 return ms.destination.client?0:"f_midi unavailable";
}
static int midi_note(unsigned note,unsigned velocity){
 const MsPort*d=&ms.destination;
 MsMidiEvent e={.type=velocity?6:7,.queue=253,.source_client=midi.client,.source_port=midi.port,
  .dest_client=d->client,.dest_port=d->port,.channel=ms.channel,.note=note,.velocity=velocity};
 return midi.send(midi.seq,&e)>=0;
}
static int64_t now_ms(void){
 int64_t ts[2];if(pc_sys(113,1,(long)ts,0,0,0,0))return -1;
 return ts[0]*1000+ts[1]/1000000;
}
static void pause_worker(void){
 const int64_t ts[]={0,4000000};pc_sys(101,(long)ts,0,0,0,0,0);
}
static void notify(void){FN(0x6d43500,void(*)(uint64_t))((58u<<1)|1u);}
static int writing(int fd,const void*data,unsigned bytes){
 const uint8_t*p=data;
 while(bytes){
  long n=pc_sys(64,fd,(long)p,bytes,0,0,0);
  if(n==-4)continue;if(n<=0)return 0;
  p+=n;bytes-=(unsigned)n;
 }
 return 1;
}
static void stop_input(void){
 __atomic_store_n(&ms.collecting,0,RL);
 while(__atomic_load_n(&ms.writer,AQ))pause_worker();
}
static int cancelled(void){return __atomic_load_n(&ms.cancel,AQ)||ms.epoch!=__atomic_load_n(&host.project_epoch,AQ);}
void pc_ms_input(uintptr_t object,uintptr_t channels,unsigned frames,unsigned offset){
 if(!__atomic_load_n(&ms.collecting,AQ)||!object||!channels||!frames||frames>4096)return;
 if(__atomic_exchange_n(&ms.writer,1,AQ))return;
 if(!__atomic_load_n(&ms.collecting,AQ))goto done;
 const float*l=(const float*)Q(channels,0),*r=(const float*)Q(channels,8);
 if(!l||!r)goto done;
 if(!ms.input_object)ms.input_object=object;
 if(ms.input_object!=object)goto done;
 unsigned at=__atomic_load_n(&ms.frames,RX),last=__atomic_load_n(&ms.last_hot,RX);
 for(unsigned j=0;j<frames&&at<MS_LIMIT;j++,at++){
  float a=l[offset+j],b=r[offset+j];
  if(!(a>=-16.f&&a<=16.f))a=0;
  if(!(b>=-16.f&&b<=16.f))b=0;
  ms.pcm[2*at]=a;ms.pcm[2*at+1]=b;
  if(a>.001f||a<-.001f||b>.001f||b<-.001f){if(!last)ms.first_hot=at;last=at+1;}
 }
 __atomic_store_n(&ms.last_hot,last,RL);
 __atomic_store_n(&ms.frames,at,RL);
 done:__atomic_store_n(&ms.writer,0,RL);
}
static void*record_worker(void*unused){
 (void)unused;
 unsigned layers=ms.layers,header_bytes=header_size(layers);
 MsFile header={.magic="MAIAMUL1",.name="Multisample",.version=layers==1?1:2,
                .rate=MS_RATE,.bytes=header_bytes,.layers=layers==1?0:layers};
 long fd=pc_sys(56,-100,(long)ms.part,0xa00c1,0600,0,0);
 const char*error="Cannot write preset on microSD";
 int ok=fd>=0&&writing((int)fd,&header,header_bytes);
 unsigned hold=ms.seconds*MS_RATE;
 for(unsigned n=0;n<MS_COUNT*layers&&ok;n++){
  unsigned note=roots[n/layers],velocity=layer_velocity(layers,n%layers);
  if(cancelled()){error="Capture cancelled";ok=0;break;}
  __atomic_store_n(&ms.note,n,RL);notify();
  __atomic_store_n(&ms.frames,0,RL);__atomic_store_n(&ms.last_hot,0,RL);
  ms.input_object=0;
  __atomic_store_n(&ms.collecting,1,RL);
  int64_t start=now_ms();
  if(start<0||!midi_note(note,velocity)){error="MIDI OUT unavailable";ok=0;break;}
  int64_t now=start;
  while(!cancelled()&&now>=start&&now-start<(int64_t)ms.seconds*1000){
   pause_worker();now=now_ms();
  }
  int sent_off=0;
  for(unsigned attempt=0;attempt<4&&!sent_off;attempt++){
   sent_off=midi_note(note,0);if(!sent_off)pause_worker();
  }
  if(!sent_off){error="MIDI OUT disconnected";ok=0;break;}
  if(now<start){error="Capture timer unavailable";ok=0;break;}
  int64_t release_start=now_ms();
  unsigned released=__atomic_load_n(&ms.frames,AQ);
  int settled=0;
  while(!cancelled()){
   unsigned at=__atomic_load_n(&ms.frames,AQ),last=__atomic_load_n(&ms.last_hot,AQ);
   unsigned boundary=last>released?last:released;
   if(last&&at>=hold&&at>=boundary&&at-boundary>=MS_QUIET){settled=1;break;}
   int64_t tail=now_ms()-release_start;
   if(at>=MS_LIMIT||release_start<0||tail<0||tail>=MS_TAIL_SECONDS*1000||(!last&&tail>=2500))break;
   pause_worker();
  }
  stop_input();
  if(!settled||cancelled()){
   error=cancelled()?"Capture cancelled":__atomic_load_n(&ms.last_hot,AQ)?"Tail did not reach silence":"No DAW audio on MPC input";
   ok=0;break;
  }
  unsigned at=__atomic_load_n(&ms.frames,AQ),last=__atomic_load_n(&ms.last_hot,AQ);
  unsigned keep=last+MS_KEEP;if(keep<hold)keep=hold;if(keep>at)keep=at;
  unsigned onset=ms.first_hot>132?ms.first_hot-132:0;
  header.zone[n]=(MsRegion){keep,header.bytes,onset};
  header.bytes+=keep*8;
  if(!writing((int)fd,ms.pcm,keep*8)){ok=0;break;}
 }
 stop_input();
 if(ok&&cancelled()){error="Capture cancelled";ok=0;}
 if(ok)ok=pc_sys(68,fd,(long)&header,header_bytes,0,0,0)==header_bytes&&pc_sys(82,fd,0,0,0,0,0)==0;
 if(fd>=0)pc_sys(57,fd,0,0,0,0,0);
 if(ok){
  ok=pc_sys(276,-100,(long)ms.part,-100,(long)ms.final,1,0)==0;
  if(ok){
   /* Sync the containing directory after publishing the already synced file. */
   char root[MS_PATH];copy(root,sizeof root,ms.final);
   unsigned slash=len(root,sizeof root);
   while(slash&&root[slash-1]!='/')slash--;
   if(slash>1){
    root[slash-1]=0;
    long dir=pc_sys(56,-100,(long)root,MS_DIRECTORY,0,0,0);
    if(dir>=0){pc_sys(82,dir,0,0,0,0,0);pc_sys(57,dir,0,0,0,0,0);}
   }
  }
 }
 if(!ok&&fd>=0)pc_sys(35,-100,(long)ms.part,0,0,0,0);
 pc_sys(215,(long)ms.pcm,MS_LIMIT*8,0,0,0,0);
 ms.pcm=0;ms.message=ok?"Saved on microSD":error;
 ms.success=(unsigned)ok;
 __atomic_store_n(&ms.finished,1,RL);notify();
 return 0;
}
static int begin_capture(void){
 midi_ports();
 if(!ms.destination.client||pc_bounce_busy())return 0;
 int64_t ts[2];if(pc_sys(113,0,(long)ts,0,0,0,0))return 0;
 uint64_t id=(uint64_t)ts[0]*1000000000u+ts[1];
 for(unsigned n=0;n<16;n++)ms.id[n]="0123456789abcdef"[(id>>(60-n*4))&15];
 ms.id[16]=0;
 char root[MS_PATH];if(!root_path(root))return 0;
 long created=pc_sys(34,-100,(long)root,0755,0,0,0);
 if(created&&created!=-17)return 0;
 if(!preset_path(ms.part,ms.id,1)||!preset_path(ms.final,ms.id,0))return 0;
 void*(*sym)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 int(*thread)(uintptr_t*,void*,void*(*)(void*),void*)=sym(0,"pthread_create");
 int(*detach)(uintptr_t)=sym(0,"pthread_detach");
 if(!thread||!detach)return 0;
 long memory=pc_sys(222,0,MS_LIMIT*8,3,0x22,-1,0);
 if(memory<0)return 0;
 ms.pcm=(float*)memory;
 __atomic_store_n(&ms.cancel,0,RL);__atomic_store_n(&ms.finished,0,RL);__atomic_store_n(&ms.note,0,RL);
 __atomic_store_n(&ms.screen,MS_RUNNING,RL);
 uintptr_t worker;
 if(thread(&worker,0,record_worker,0)){
  pc_sys(215,memory,MS_LIMIT*8,0,0,0,0);ms.pcm=0;__atomic_store_n(&ms.screen,MS_SETUP,RL);return 0;
 }
 detach(worker);return 1;
}

static int delete_preset(const char *id){
 char path[MS_PATH];
 if(!preset_path(path,id,0))return 0;
 long status=pc_sys(35,-100,(long)path,0,0,0,0);
 if(status&&status!=-2)return 0;
 pc_ms_unassign_preset(id);
 if(preset_path(path,id,2))pc_sys(35,-100,(long)path,0,0,0,0);
 return 1;
}
static void scan_presets(void){
 ms.presets=ms.selection=0;
 char root[MS_PATH],path[MS_PATH];if(!root_path(root))return;
 long dir=pc_sys(56,-100,(long)root,MS_DIRECTORY,0,0,0);
 if(dir<0)return;
 uint8_t data[2048];
 while(ms.presets<MS_PRESETS){
  long size=pc_sys(61,dir,(long)data,sizeof data,0,0,0);
  if(size<=0)break;
  for(unsigned pos=0;pos+20<=(unsigned)size&&ms.presets<MS_PRESETS;){
   unsigned rec=data[pos+16]|(unsigned)data[pos+17]<<8;
   if(rec<20||rec>(unsigned)size-pos)break;
   const char*name=(const char*)data+pos+19;pos+=rec;
   if(rec<42||len(name,rec-19)!=22||!valid_id(name)||memcmp(name+16,".msamp",7))continue;
   if(!preset_path(path,name,2))continue;
   long marker=pc_sys(56,-100,(long)path,0xa0000,0,0,0);
   if(marker>=0){
    long bytes=pc_sys(62,marker,0,2,0,0,0);
    pc_sys(57,marker,0,0,0,0,0);
    /* r90/r91 created an empty marker only after confirming Delete. */
    if(bytes==0&&!delete_preset(name))ms.message="Cannot delete a previously hidden preset";
    continue;
   }
   if(!preset_path(path,name,0))continue;
   long fd=pc_sys(56,-100,(long)path,0xa0000,0,0,0);
   if(fd<0)continue;
   MsFile h;int ok=read_header((int)fd,&h)&&valid_file(&h)&&pc_sys(62,fd,0,2,0,0,0)==h.bytes;
   pc_sys(57,fd,0,0,0,0,0);
   if(!ok)continue;
   MsPreset*p=&ms.preset[ms.presets++];memcpy(p->id,name,16);p->id[16]=0;copy(p->name,sizeof p->name,h.name);
  }
 }
 pc_sys(57,dir,0,0,0,0,0);
}
static int same_project(void){
 return ms.epoch==__atomic_load_n(&host.project_epoch,AQ)&&
     ms.project==Q(pc_state_base(),0x1d08)&&ms.project&&Q(ms.project,0xb8)==ms.program;
}
int pc_ms_open(uintptr_t program,uintptr_t instrument){
 if(pc_ms_active()||!pc_valid(program,instrument))return 0;
 ms.program=program;ms.instrument=instrument;ms.project=Q(pc_state_base(),0x1d08);
 ms.epoch=__atomic_load_n(&host.project_epoch,AQ);ms.message=0;
 scan_presets();__atomic_store_n(&ms.screen,MS_BROWSER,RL);return 1;
}
int pc_ms_preset_browser(void){
 unsigned screen=__atomic_load_n(&ms.screen,AQ);
 return screen==MS_BROWSER||screen==MS_DELETE;
}
int pc_ms_active(void){return __atomic_load_n(&ms.screen,AQ)!=MS_CLOSED;}
static int assign_id(const char*id,const char*name){
 uint8_t patch[512]={0};memcpy(patch,"MPCMUL01",8);memcpy(patch+8,id,PC_MS_ID);
 copy((char*)patch+24,32,name);
 if(!pc_ms_assign(ms.program,ms.instrument,patch)){ms.message="Pad busy or preset unavailable";return 0;}
 __atomic_store_n(&ms.screen,MS_CLOSED,RL);
 uintptr_t b=Q(pc_state_base(),0x20),manager=b?Q(b,0x30):0;
 if(manager)FN(0x1c0e5c0,void(*)(uintptr_t,int))(manager,0x20a7);
 return 1;
}
static int rename_capture(void){
 char name[sizeof ms.name]={0};
 unsigned end=sizeof name-1;
 while(end&&(!ms.name[end-1]||ms.name[end-1]==' '))end--;
 if(end)memcpy(name,ms.name,end);else copy(name,sizeof name,"Multisample");
 long fd=pc_sys(56,-100,(long)ms.final,0xa0002,0,0,0);
 if(fd<0)return 0;
 long n=pc_sys(68,fd,(long)name,sizeof name,8,0,0);
 MsFile saved;
 int ok=n==sizeof name&&pc_sys(82,fd,0,0,0,0,0)==0&&
     read_header((int)fd,&saved)&&valid_file(&saved)&&!memcmp(saved.name,name,sizeof name);
 pc_sys(57,fd,0,0,0,0,0);
 if(ok)memcpy(ms.name,name,sizeof name);
 return ok;
}
void pc_ms_event(unsigned kind,unsigned data){
 unsigned screen=__atomic_load_n(&ms.screen,AQ);
 if(!screen)return;
 if(!same_project()){
  if(screen==MS_RUNNING&&!__atomic_load_n(&ms.finished,AQ))__atomic_store_n(&ms.cancel,1,RL);
  else __atomic_store_n(&ms.screen,MS_CLOSED,RL);
  return;
 }
 if(screen==MS_RUNNING){
  if(__atomic_load_n(&ms.finished,AQ)){
   if(ms.success){
    memset(ms.name,' ',sizeof ms.name-1);ms.name[sizeof ms.name-1]=0;
    memcpy(ms.name,"Multisample",11);ms.cursor=0;ms.message=0;
    __atomic_store_n(&ms.screen,MS_RENAME,RL);
   }else __atomic_store_n(&ms.screen,MS_SETUP,RL);
  }else if(kind==12&&(data==0||data==2))__atomic_store_n(&ms.cancel,1,RL);
  return;
 }
 if(screen==MS_DELETE){
  if(kind==14)ms.delete_choice=pc_delete_choice(ms.delete_choice,(int32_t)data);
  else if(kind==12&&(data==0||data==3)){
   if(data==3&&ms.delete_choice==PC_DELETE){
    unsigned previous=ms.selection;
    if(!delete_preset(ms.preset[previous].id)){
     ms.message="Cannot delete preset";
    }else{
     scan_presets();
     if(ms.presets)ms.selection=previous<ms.presets?previous:ms.presets-1;
     ms.message="Preset deleted";
    }
   }
   __atomic_store_n(&ms.screen,MS_BROWSER,RL);
  }
  return;
 }
 if(screen==MS_BROWSER){
  if(kind==12&&data==0)__atomic_store_n(&ms.screen,MS_CLOSED,RL);
  else if(kind==12&&data==1){midi_ports();ms.message=midi_out_notice();__atomic_store_n(&ms.screen,MS_SETUP,RL);}
  else if(kind==12&&(data==2||data==3)&&ms.presets)assign_id(ms.preset[ms.selection].id,ms.preset[ms.selection].name);
  else if(kind==12&&data==PC_PRESET_ERASE&&ms.presets){
   ms.delete_choice=PC_KEEP;ms.message=0;
   __atomic_store_n(&ms.screen,MS_DELETE,RL);
  }
  else if(kind==14&&ms.presets){int64_t next=(int64_t)ms.selection+(int32_t)data;ms.selection=next<0?0:next>=ms.presets?ms.presets-1:(unsigned)next;}
 }else if(screen==MS_SETUP){
  if(kind==12&&data==0){scan_presets();ms.message=0;__atomic_store_n(&ms.screen,MS_BROWSER,RL);}
  else if(kind==12&&data==1){midi_ports();ms.message=midi_out_notice();}
  else if(kind==12&&data==3){ms.message=0;if(!begin_capture())ms.message=midi_out_notice()?midi_out_notice():"Check MIDI OUT, audio and microSD";}
  else if(kind==13){
   unsigned knob=data>>16,pos=data&16383;
   if(knob==0)ms.seconds=MS_MIN_SECONDS+pos*(MS_MAX_SECONDS-MS_MIN_SECONDS+1)/16384;
   if(knob==1)ms.channel=pos*16/16384;
   if(knob==2)ms.layers=1+pos*MS_LAYERS/16384;
  }
 }else if(screen==MS_RENAME){
  if(kind==12&&data==1){
   if(ms.cursor){
    unsigned index=--ms.cursor;
    for(;index+2<sizeof ms.name;index++)ms.name[index]=ms.name[index+1];
    ms.name[sizeof ms.name-2]=' ';
   }
  }else if(kind==12&&data==2){
   if(!delete_preset(ms.id))ms.message="Cannot delete preset";
   else{scan_presets();ms.message="Capture deleted";__atomic_store_n(&ms.screen,MS_BROWSER,RL);}
  }else if(kind==12&&(data==0||data==3)){
   if(!rename_capture())ms.message="Rename failed: check microSD";
   else if(!assign_id(ms.id,ms.name)){scan_presets();__atomic_store_n(&ms.screen,MS_BROWSER,RL);}
  }else if(kind==35){
   int64_t next=(int64_t)ms.cursor+(int32_t)data;
   ms.cursor=next<0?0:next>30?30:(unsigned)next;
  }else if(kind==14){
   static const char characters[]=" ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
   unsigned index=0;while(characters[index]&&characters[index]!=ms.name[ms.cursor])index++;
   int total=sizeof characters-1;
   int step=(int32_t)data%total;
   ms.name[ms.cursor]=characters[((int)index+step+total)%total];
  }
 }
}
static void paint_rect(void*g,int x,int y,int w,int h,unsigned colour){
 FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,pc_theme_colour(colour));
 FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);
}
static void large_text(EiCanvas*c,int x,int y,const char*text,int width,unsigned height,unsigned colour){
 for(unsigned k=0;k<MS_PLEX_24;k++){
  if(ms_fonts[k].height!=height)continue;
  ms_font_draw(c,x,y,text,width,&ms_fonts[k],colour);
  return;
 }
}
static void line(EiCanvas*c,int y,const char*text,unsigned colour){
 large_text(c,8,y,text,c->w-16,16,colour);
}
static void heading(EiCanvas*c,const char*title,const char*detail){
 ei_rect(c,0,0,c->w,c->h,MPC_THEME_BG);
 large_text(c,8,4,title,c->w-100,18,MPC_THEME_TEXT);
 large_text(c,c->w-90,5,detail,82,16,MPC_THEME_MUTED);
 ei_rule(c,24);
}
static void actions(EiCanvas*c,const char*b1,const char*b2,const char*b3){
 const char*const labels[]={b1,b2,b3};int y=c->h-27;
 ei_rule(c,y);
 for(unsigned k=0;k<3;k++){
  if(!labels[k][0])continue;
  int x=k*c->w/3;char key[]={'B','1'+k,0};
  if(k)ei_rect(c,x,y+5,1,16,MPC_THEME_GRID);
  large_text(c,x+6,y+5,key,22,16,MPC_THEME_MUTED);
  large_text(c,x+30,y+5,labels[k],c->w/3-35,16,MPC_THEME_TEXT);
 }
}
static void format_value(char*,unsigned,const char*);
static void rename_paint(EiCanvas*c){
 heading(c,"SAVE MULTISAMPLE","RENAME");
 int tall=c->h>=175,top=tall?52:30;
 line(c,top,"Preset name",MPC_THEME_MUTED);
 int field=top+20,height=tall?51:34,ink=tall?30:25,step=tall?19:16;
 ei_rect(c,8,field,c->w-16,height,MPC_THEME_SURFACE);
 unsigned cols=(c->w-24)/step;if(cols>31)cols=31;
 unsigned first=ms.cursor>=cols?ms.cursor-cols+1:0;
 for(unsigned k=0;k<cols;k++){
  int x=12+k*step;char ch[]={ms.name[first+k],0};
  if(first+k==ms.cursor)ei_rect(c,x,field+height-4,step-2,2,MPC_THEME_ACCENT);
  large_text(c,x,field+(height-ink)/2,ch,step-2,ink,MPC_THEME_TEXT);
 }
 line(c,field+height+2,ms.message?ms.message:"ENC Character   +/- Cursor",
      ms.message?MPC_THEME_WARNING:MPC_THEME_MUTED);
 actions(c,"Save","Backspace","Delete");
}
int pc_ms_paint(uintptr_t screen,uintptr_t graphics){
 unsigned active=__atomic_load_n(&ms.screen,AQ);if(!active)return 0;
 if(active==MS_RUNNING&&__atomic_load_n(&ms.finished,AQ)){
  pc_ms_event(58,0);active=__atomic_load_n(&ms.screen,AQ);if(!active)return 0;
 }
 if(!same_project()){pc_ms_event(0,0);return 0;}
 typedef struct{uint64_t xy,wh;}Bounds;
 Bounds b=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(uint32_t)b.wh,h=b.wh>>32;
 if(w<200||h<130||w>1024||h>1024)return 0;
 EiCanvas c={(void*)graphics,paint_rect,w,h};
 if(active==MS_RENAME){rename_paint(&c);return 1;}
 if(active==MS_DELETE){pc_delete_paint(&c,ms.preset[ms.selection].name,ms.delete_choice);return 1;}
 int tall=h>=(active==MS_SETUP?200:175),top=tall?66:32;
 heading(&c,"MULTISAMPLES",active==MS_BROWSER?"PRESETS":active==MS_SETUP?"CAPTURE":"RECORDING");
 if(tall)ms_font_draw(&c,8,28,active==MS_BROWSER?"presets.":active==MS_SETUP?"capture.":"recording.",w-16,&ms_fonts[MS_SPACE_28],MPC_THEME_TEXT);
 if(active==MS_BROWSER){
  unsigned rows=(unsigned)(h-top-47)/24;if(!rows)rows=1;
  unsigned first=ms.selection>=rows?ms.selection-rows+1:0;
  if(!ms.presets)line(&c,top,"No presets on microSD",MPC_THEME_MUTED);
  for(unsigned n=first;n<ms.presets&&n-first<rows;n++){
   int y=top+24*(n-first);
   if(n==ms.selection)ei_selection(&c,y-2,23);
   large_text(&c,14,y,ms.preset[n].name,w-28,20,MPC_THEME_TEXT);
  }
  line(&c,h-47,ms.message?ms.message:ms.presets?"ENC load / ERASE+ENC delete":0,MPC_THEME_ACCENT);
  actions(&c,"Back","Capture",ms.presets?"Import":"");
 }else if(active==MS_SETUP){
  int help=tall?top:29;
  line(&c,help,"Route DAW audio to INPUT CONFIG.",MPC_THEME_ACCENT);
  line(&c,help+17,h<154&&ms.message?ms.message:"f_midi OUT / match VST channel.",
       h<154&&ms.message?MPC_THEME_WARNING:MPC_THEME_TEXT);
  char duration[12],channel[12],layers[12];
  format_value(duration,ms.seconds," s");format_value(channel,ms.channel+1,"");format_value(layers,ms.layers,"");
  const char*const labels[]={"K1 DURATION","K2 CHANNEL","K3 VELOCITIES"};
  const char*const values[]={duration,channel,layers};
  int y=help+(tall?42:35);
  for(unsigned k=0;k<3;k++){
   int x=8+k*w/3,width=w/3-14;
   large_text(&c,x,y,labels[k],width,15,MPC_THEME_MUTED);
   large_text(&c,x,y+17,values[k],width,tall?23:18,MPC_THEME_TEXT);
  }
  if(h>=154)line(&c,h-47,ms.message?ms.message:"Press ENC to start",ms.message?MPC_THEME_WARNING:MPC_THEME_MUTED);
  actions(&c,"Back","Rescan","");
  if(h<154)large_text(&c,2*w/3+6,h-22,"ENC Start",w/3-12,16,MPC_THEME_TEXT);
 }else{
  static const char*const names[]={"C2","G2","C3","G3","C4","G4","C5","G5","C6"};
  unsigned n=__atomic_load_n(&ms.note,AQ);
  unsigned total=MS_COUNT*ms.layers;
  if(n<total){
   ms_font_draw(&c,8,top,names[n/ms.layers],w/2-16,&ms_fonts[MS_PLEX_28],MPC_THEME_TEXT);
   char value[12];format_value(value,layer_velocity(ms.layers,n%ms.layers),"");
   large_text(&c,w/2,top+5,"VELOCITY",w/4,16,MPC_THEME_MUTED);
   large_text(&c,w*3/4,top+5,value,w/4-8,18,MPC_THEME_TEXT);
  }
  ei_bar(&c,8,top+37,w-16,n*16383/total);
  line(&c,top+46,__atomic_load_n(&ms.cancel,AQ)?"Cancelling":"Capturing note and tail",MPC_THEME_MUTED);
  actions(&c,"","","Cancel");
 }
 return 1;
}
static struct {uintptr_t instrument;unsigned generation,page;} editor;
void pc_ms_editor_reset(void){editor.instrument=0;editor.page=0;}
static Slot* editor_slot(uintptr_t instrument){
 int k=pc_find(instrument);
 if(k<0||host.slots[k].engine!=PC_MS_ENGINE)return 0;
 Slot*s=&host.slots[k];
 if(editor.instrument!=instrument||editor.generation!=s->generation){
  editor.instrument=instrument;editor.generation=s->generation;editor.page=0;
 }
 return s;
}
void pc_ms_editor_event(uintptr_t instrument,unsigned kind,unsigned data){
 Slot*s=editor_slot(instrument);if(!s)return;
 if(kind==14){
  int64_t page=(int64_t)editor.page+(int32_t)data;editor.page=page<0?0:page>2?2:(unsigned)page;
 }else if(kind==12&&(data==1||data==2)){
  if(pc_ms_open(s->program,instrument)&&data==1)pc_ms_event(12,1);
 }else if(kind==13){
  unsigned k=data>>16,pos=data&16383;if(k>=3)return;
  if(!editor.page){pc_synth_filter_knob(instrument,k,pos);return;}
  if(editor.page==1){
   if(k==0)pc_mix_set_volume(s->program,instrument,-240+(int)(pos*480/16383));
   if(k==1)pc_sc_set(s->program,instrument,pos*3/16384);
   return;
  }
  if(s->patch[56]!=1){
   for(unsigned n=0;n<3;n++){
    unsigned v=envelope_defaults[n];s->patch[57+2*n]=v;s->patch[58+2*n]=v>>8;
   }
   s->patch[56]=1;
  }
  const uint64_t full=16383,area=full*full;
  unsigned value=k==1?(unsigned)((pos*100+full/2)/full):
      (unsigned)(((uint64_t)pos*pos*envelope_max[k]+area/2)/area);
  s->patch[57+2*k]=value;s->patch[58+2*k]=value>>8;
  __atomic_store_n(&s->values[k],((uint64_t)s->generation<<32)|value,RL);
  __atomic_fetch_or(&s->pending[0],1u<<k,RL);
 }
}
static void format_value(char*out,unsigned value,const char*unit){
 unsigned places=1,divisor=1;
 while(value/divisor>=10){divisor*=10;places++;}
 for(unsigned k=0;k<places;k++,divisor/=10)out[k]='0'+value/divisor%10;
 copy(out+places,8,unit);
}
int pc_ms_editor(uintptr_t instrument,uintptr_t graphics,int w,int h){
 Slot*s=editor_slot(instrument);if(!s)return 0;
 EiCanvas c={(void*)graphics,paint_rect,w,h};
 heading(&c,"MULTISAMPLES",editor.page==0?"1 / 3":editor.page==1?"2 / 3":"3 / 3");
 if(!editor.page){
  MpcPanelView v={0};pc_synth_filter_view(instrument,&v);
  line(&c,33,"STOCK FILTER",MPC_THEME_TEXT);
  for(unsigned k=0;k<3;k++){int x=k*w/3+8,width=w/3-16;large_text(&c,x,65,v.slots[k].label,width,16,MPC_THEME_MUTED);large_text(&c,x,86,v.slots[k].value,width,23,MPC_THEME_TEXT);ei_bar(&c,x,h-52,width,pc_synth_filter_position(instrument,k));}
 }else if(editor.page==2){
  int top=h<155?29:38;
  line(&c,top,"AMP ENVELOPE",MPC_THEME_TEXT);
  const char*const names[]={"K1 ATTACK","K2 SUSTAIN","K3 RELEASE"};
  for(unsigned k=0;k<3;k++){
   int x=k*w/3+8,width=w/3-16;
   char value[16];format_value(value,pc_ms_envelope(s->patch,k),k==1?" %":" ms");
   large_text(&c,x,top+23,names[k],width,16,MPC_THEME_MUTED);
   ms_font_draw(&c,x,top+43,value,width,&ms_fonts[MS_PLEX_24],MPC_THEME_TEXT);
  }
 }else{
  large_text(&c,8,33,(const char*)s->patch+24,w-16,25,MPC_THEME_TEXT);
  large_text(&c,8,65,"K1 VOLUME",w/2-12,16,MPC_THEME_MUTED);
  large_text(&c,w/2,65,"K2 SIDECHAIN",w/2-8,16,MPC_THEME_MUTED);
  unsigned role=pc_sc_role(instrument);
  large_text(&c,w/2,83,role==1?"SEND":role==2?"RECEIVE":"OFF",w/2-8,20,MPC_THEME_TEXT);
 }
 actions(&c,"","Capture","Import");return 1;
}
