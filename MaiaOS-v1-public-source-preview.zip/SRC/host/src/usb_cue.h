/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_USB_CUE_H
#define PC_USB_CUE_H
#include <stdint.h>
void pc_usb_cue_init(unsigned page_size);
void pc_usb_cue_enable(unsigned enabled);
unsigned pc_usb_cue_enabled(void);
void pc_usb_cue_publish(const float*,const float*,unsigned);
long pc_usb_cue_write(uintptr_t,const void*,unsigned long);
#endif
