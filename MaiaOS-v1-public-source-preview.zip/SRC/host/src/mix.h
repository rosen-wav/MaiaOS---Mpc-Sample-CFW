/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_MIX_H
#define PC_MIX_H
#define MIX_MAX_PARAMS 256
#define MIX_PADS 1024
#define MIX_POSITION 16383u
#define MIX_GAIN_MIN (-240)
#define MIX_GAIN_MAX 240
typedef struct {int32_t type;uint32_t count;float params[MIX_MAX_PARAMS];} PcFxState;
typedef struct {uint32_t version;PcFxState slots[3];} PcFxProject;
void pc_mix_input(uintptr_t,uintptr_t,uintptr_t,unsigned);
int pc_mix_chain(uintptr_t,uintptr_t,unsigned);
int pc_mix_guard(void);
int pc_mix_ensure(void);
int pc_mix_ready(void);
void pc_mix_forget(uintptr_t,uintptr_t);
void pc_mix_reset(void);
void pc_mix_route_program(uintptr_t);
void pc_mix_route_project(void);
uint64_t pc_mix_controls(uintptr_t);
int pc_mix_set_controls(uintptr_t,uintptr_t,uint64_t);
uint64_t pc_mix_default(void);
int pc_mix_nondefault(uintptr_t);
unsigned pc_mix_send(uintptr_t,unsigned);
int pc_mix_set_send(uintptr_t,uintptr_t,unsigned,unsigned);
int pc_mix_volume(uintptr_t);
int pc_mix_set_volume(uintptr_t,uintptr_t,int);
float pc_mix_gain(uintptr_t);
unsigned pc_fx_count(void);
int pc_fx_type(unsigned);
const char *pc_fx_name(int);
const char *pc_fx_label(unsigned,unsigned);
const char *pc_fx_option(unsigned,unsigned);
unsigned pc_fx_position(unsigned,unsigned);
int pc_fx_select(unsigned,int);
int pc_fx_knob(unsigned,unsigned,unsigned);
int pc_fx_snapshot(PcFxProject *);
int pc_fx_restore(const PcFxProject *);
void pc_mix_info_write(uintptr_t);
void pc_mix_info_read(uintptr_t);
void pc_mix_restore_poll(void);
int pc_mix_needs_poll(void);
int pc_mix_xml_write(uintptr_t,uintptr_t);
int pc_mix_xml_read(uintptr_t,uintptr_t);
#endif

unsigned pc_mix_volume_position(uintptr_t);

void pc_mix_dj_fallback(float*,float*,unsigned,unsigned);
