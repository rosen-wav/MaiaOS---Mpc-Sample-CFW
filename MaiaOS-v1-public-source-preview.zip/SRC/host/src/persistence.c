/* SPDX-License-Identifier: GPL-3.0-only
 * The extension is a child of the native Instrument XML node. Native project
 * and kit writers therefore carry it together with that actual instrument.
 * No paths, object addresses, sidecars or filesystem calls are serialized.
 */
#include "internal.h"
static const char tag[]="MpcPcEngineV2";
static int equal(const char *a,const char *b){if(!a||!b)return 0;for(unsigned n=0;n<64;n++){if(a[n]!=b[n])return 0;if(!a[n])return 1;}return 0;}
static int hex(char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:-1;}
static const char sc_tag[]="MpcPcSidechainV1";
static int sc_write(uintptr_t instrument,uintptr_t xml){
 unsigned role=pc_sc_role(instrument);if(!role)return 1;if(!xml)return 0;
 char encoded[2]={(char)('0'+role),0};uintptr_t name=0,value=0;
 FN(0xf535c0,void(*)(uintptr_t *,const char *))(&name,sc_tag);
 FN(0xf535c0,void(*)(uintptr_t *,const char *))(&value,encoded);
 uintptr_t node=FN(0x1da04a0,uintptr_t(*)(uintptr_t,uintptr_t *,uintptr_t *))(xml,&name,&value);
 FN(0xf0a290,void(*)(uintptr_t *))(&value);FN(0xf0a290,void(*)(uintptr_t *))(&name);
 return node!=0;
}
int pc_xml_write(uintptr_t instrument,uintptr_t xml){
 if(!pc_mix_xml_write(instrument,xml)||!sc_write(instrument,xml)){pc_error(51);return 0;}
 int k=pc_find(instrument);if(k<0)return 1;
 if(!xml||!pc_meta()){pc_error(50);return 0;}
 Slot *s=&host.slots[k];
 if(__atomic_load_n(&s->instrument,AQ)!=instrument){pc_unmeta();return 1;}
 uint8_t bytes[520];memset(bytes,0,sizeof bytes);bytes[0]=2;bytes[1]=(uint8_t)s->engine;
 bytes[2]=(uint8_t)s->preset;bytes[3]=(uint8_t)(s->preset>>8);memcpy(bytes+8,s->patch,512);
 pc_unmeta();char encoded[1041];static const char digits[]="0123456789abcdef";
 for(unsigned n=0;n<520;n++){encoded[n*2]=digits[bytes[n]>>4];encoded[n*2+1]=digits[bytes[n]&15];}encoded[1040]=0;
 uintptr_t name=0,value=0;
 FN(0xf535c0,void (*)(uintptr_t *,const char *))(&name,tag);
 FN(0xf535c0,void (*)(uintptr_t *,const char *))(&value,encoded);
 uintptr_t node=FN(0x1da04a0,uintptr_t (*)(uintptr_t,uintptr_t *,uintptr_t *))(xml,&name,&value);
 FN(0xf0a290,void (*)(uintptr_t *))(&value);FN(0xf0a290,void (*)(uintptr_t *))(&name);
 if(!node){pc_error(51);return 0;}__atomic_fetch_add(&host.debug->saves,1,RX);return 1;
}
int pc_xml_read(uintptr_t instrument,uintptr_t xml){
 if(!xml)return 0;
 if(pc_mix_xml_read(instrument,xml))return 1;
 if(equal((const char *)Q(xml,0x18),sc_tag)){
  uintptr_t value=FN(0x1da12b0,uintptr_t(*)(uintptr_t))(xml);
  const char *text=value?(const char *)Q(value,0):0;
  if(!text||text[0]<'0'||text[0]>'2'||text[1]){pc_error(52);return 1;}
  if(!pc_meta()){pc_error(50);return 1;}
  if(!pc_sc_set(Q(instrument,0x2310),instrument,(unsigned)(text[0]-'0')))pc_error(53);
  pc_unmeta();return 1;
 }
 if(!equal((const char *)Q(xml,0x18),tag))return 0;
 uintptr_t string=FN(0x1da12b0,uintptr_t (*)(uintptr_t))(xml);
 const char *text=string?(const char *)Q(string,0):0;uint8_t bytes[520];
 if(!text){pc_error(52);return 1;}
 for(unsigned n=0;n<520;n++){
  int a=hex(text[n*2]);if(a<0){pc_error(52);return 1;}
  int b=hex(text[n*2+1]);if(b<0){pc_error(52);return 1;}bytes[n]=(uint8_t)(16*a+b);
 }
 if(text[1040]||bytes[0]!=2||(bytes[1]==6||bytes[1]>PC_MS_ENGINE)||bytes[4]||bytes[5]||bytes[6]||bytes[7]){pc_error(52);return 1;}
 if(bytes[1]==3||bytes[1]==5)return 1; /* Removed engine, retain native pad content. */
 if(!pc_meta()){pc_error(50);return 1;}
 uintptr_t program=Q(instrument,0x2310);
 if(pc_assign(program,instrument,bytes[1],(unsigned)bytes[2]|(unsigned)bytes[3]<<8,bytes+8))__atomic_fetch_add(&host.debug->loads,1,RX);
 __atomic_store_n(&host.ui.loaded_valid,0,RL);pc_unmeta();return 1;
}
