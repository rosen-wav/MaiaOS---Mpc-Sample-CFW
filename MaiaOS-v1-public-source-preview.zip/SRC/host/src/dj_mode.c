/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "dj_mode.h"
#include "dj_analysis.h"
#include "dj_controls.h"
#include "dj_playback.h"
#include "usb_cue.h"
#include "dj_mixxx.h"
#include "stock_caption.h"
#include "../theme/layout.h"

#define FADER_VTABLE 0x6e1cab8u
#define SAMPLE_IMPORT 0x20a9
#define DJ_PATH 1024
#define DJ_LOAD_DONE 8u
static PcStockCaption dj_caption,browser_caption[6],page_caption[6];
static DjControls controls=DJ_CONTROLS_DEFAULT;
static const char *const load_label[]={"Song Import","Load 1","Load 2","Back"};
static unsigned browser_default;
static struct {unsigned open,slot,candidate,page,armed,known,last[3];} dj_fx;
static PcStockCaption dj_fx_caption[3];
static unsigned dj_shift,cue_blend=DJ_KNOB_MAX,cue_gain=DJ_KNOB_MAX;
static uintptr_t browser_view;
static const char *browser_status;
typedef struct {
 DjAnalysis audio;
 char path[DJ_PATH];
 uint64_t cue;
 char render_path[DJ_PATH];
 uint64_t load_order;
} DjDeck;
typedef struct {
 uint64_t cue,start,resume,loop_start,loop_end,sync_at;
 unsigned sync,nudge,loop,pending,correction,resumable,cue_edited,bpm_held;
 uint64_t repeat_at;
 double manual_bpm;
} DjTransport;
typedef struct {
 unsigned state,play_when_ready,named_tempo;
 int error;
 DjDeck result;
 DjProgress progress;
} DjJob;
static struct {
 uintptr_t screen;
 int mode,return_mode,resume_mode;
 unsigned open,selected,exit_confirm,exit_choice,fader_armed;
 int exit_mode;
 int master;
 const char *message;
 DjDeck deck[2];
 DjJob job[2];
 DjTransport transport[2];
 uint64_t load_serial;
} dj={.master=-1};

static uintptr_t manager(void){
 uintptr_t behaviour=Q(pc_state_base(),0x20);
 return behaviour?Q(behaviour,0x30):0;
}
static int current_mode(void){
 uintptr_t menu=manager();if(!menu)return 0;
 int mode=I(menu,0xd8);
 return mode==0x3080?I(menu,0x80):mode;
}
int pc_dj_fader(void){
 int mode=__atomic_load_n(&dj.mode,AQ);
 return mode&&mode==current_mode();
}
int pc_dj_open(void){return pc_dj_fader()&&__atomic_load_n(&dj.open,AQ);}
int pc_dj_import(void){return __atomic_load_n(&dj.return_mode,AQ)&&current_mode()==SAMPLE_IMPORT;}

static uintptr_t pad_properties(void);
static unsigned led_mask,dj_led_write,saved_led_mask;
static uintptr_t saved_led_pads;
static uint64_t saved_led[16];
static void restore_leds(void){
 uintptr_t pads=pad_properties();
 if(pads&&pads==saved_led_pads)for(unsigned i=0;i<16;i++)if(saved_led_mask&(1u<<i))
  FN(0x13be8b0,void(*)(uintptr_t,const uint64_t*))(pads+i*0x128+0x20,&saved_led[i]);
 saved_led_mask=0;saved_led_pads=0;
}
static uintptr_t pad_properties(void){
 uintptr_t b=Q(pc_state_base(),0x20),surface=b?Q(b,0x78):0;
 if(surface&&I(surface,0x29d0)==16&&Q(surface,0x29d8))return Q(surface,0x29d8);
 uintptr_t controller=b?Q(b,0x270):0;
 uintptr_t panel=controller&&Q(controller,0)==host.base+0x6d98388?Q(controller,0x198):0;
 return panel&&I(panel,0x20)==16?Q(panel,0x28):0;
}
static unsigned raw_pad_held;
static int raw_pad(unsigned pad,float pressure){
 if(!pc_dj_open()&&!pc_dj_import()){__atomic_store_n(&raw_pad_held,0,RL);return 0;}
 unsigned bit=1u<<pad,old=pressure>0?__atomic_fetch_or(&raw_pad_held,bit,RL):
                                      __atomic_fetch_and(&raw_pad_held,~bit,RL);
 if(pc_dj_open()&&!!(old&bit)!=(pressure>0)){
  uint64_t data=pad|(pressure>0?0:16);
  FN(0x6d43500,void(*)(uint64_t))((data<<32)|(62u<<1)|1u);
 }
 return 1;
}
int pc_dj_raw_pressure(uintptr_t property,float pressure){
 uintptr_t pads=pad_properties();
 if(!pads||property<pads)return 0;
 uintptr_t offset=property-pads;
 return offset<16*0x128&&offset%0x128==0&&raw_pad(offset/0x128,pressure);
}
int pc_dj_panel_pad(uintptr_t panel,unsigned pad,float pressure){
 uintptr_t pads=pad_properties();
 return pad<16&&pads&&I(panel,0x48)==16&&Q(panel,0x50)==pads&&raw_pad(pad,pressure);
}
uint64_t pc_dj_colour(uintptr_t property,uint64_t stock){
 if(!pc_dj_open())return stock;
 uintptr_t pads=pad_properties();
 if(!pads||property<pads+0x20)return stock;
 uintptr_t delta=property-pads-0x20;
 if(delta%0x128||delta/0x128>=16)return stock;
 unsigned index=delta/0x128;
 if(!dj_led_write){
  if(saved_led_pads!=pads){saved_led_pads=pads;saved_led_mask=0;}
  saved_led[index]=stock;saved_led_mask|=1u<<index;
 }
 unsigned active=__atomic_load_n(&led_mask,AQ)&(1u<<index);
 unsigned rgb;
 if(index<4)rgb=active?0x0040ff:0x00bbff;
 else if(index<8)rgb=index&1?active?0x00ff50:0xff8200:active?0xe030ff:0xa000ff;
 else if(index<12)rgb=active?0x0040ff:0x00bbff;
 else rgb=active?0x00ff50:0xffff00;
 return UINT64_C(0x3f80000000000000)|rgb;
}
void pc_dj_lights(void){
 if(!pc_dj_open()){if(saved_led_mask)restore_leds();return;}
 unsigned bits=0;
 for(unsigned i=0;i<2;i++){
  const DjTransport *t=&dj.transport[i];
  bits|=(t->bpm_held&3u)<<(2*i);
  if(t->sync)bits|=1u<<(4+2*i);
  if(dj.master==(int)i)bits|=1u<<(5+2*i);
  bits|=(t->nudge&3u)<<(8+2*i);
  if(t->loop)bits|=1u<<(12+2*i+(t->loop==4));
 }
 __atomic_store_n(&led_mask,bits,RL);
 uintptr_t pads=pad_properties();if(!pads)return;
 if(saved_led_pads!=pads){saved_led_pads=pads;saved_led_mask=0;}
 dj_led_write=1;
 for(unsigned i=0;i<16;i++){
  uintptr_t property=pads+i*0x128+0x20;
  if(!(saved_led_mask&(1u<<i))){memcpy(&saved_led[i],(void*)(property+0x1c),8);saved_led_mask|=1u<<i;}
  uint64_t value=pc_dj_colour(property,0);
  FN(0x13be8b0,void(*)(uintptr_t,const uint64_t*))(property,&value);
 }
 dj_led_write=0;
}
static void rect(void*,int,int,int,int,unsigned);
static void dj_key(uintptr_t screen,int visible){
 if(!visible){pc_stock_caption_hide(dj_caption,screen);return;}
 uintptr_t left=screen+0x1f8,right=screen+0x418;
 if(Q(left,0)!=host.base+0x706e940||Q(right,0)!=host.base+0x706e940)return;
 int x=I(left,0x20)+I(left,0x28),width=I(right,0x20)-x;
 int y=I(left,0x24),height=I(left,0x2c);
 if(x<0||y<0||width<60||width>180||height<12||height>64)return;
 pc_stock_caption_show(dj_caption,screen,"DJ Mode",x,y,width,height);
}
static void hide_browser_keys(uintptr_t view){
 if(view)for(unsigned i=0;i<6;i++)pc_stock_caption_hide(browser_caption[i],view);
}
int pc_dj_browser_frame(uintptr_t view){
 if(!pc_dj_import()){
  hide_browser_keys(view);
  return 0;
 }
 browser_view=view;
 I(view,0xa2c)=0; /* Prevent stock file-audition on selection changes. */
 if(browser_default&&Q(view,0x1390)&&Q(view,0x120)&&
    (FN(0x14fa400,unsigned(*)(uintptr_t))(Q(view,0x1390))&1)){
  browser_default=0;
  FN(0x6d43500,void(*)(uint64_t))((6ull<<32)|(59u<<1)|1u);
 }
 /* These are the six top controls laid out by FileSelectScreen::resized.
  * Collapse their bounds, leaving stock visibility flags intact. */
 static const unsigned stock[]={0x1f8,0x418,0x638,0x858,0xa78,0xc98};
 for(unsigned i=0;i<sizeof stock/sizeof *stock;i++){
  uintptr_t child=view+stock[i];
  if(Q(child,0x18)==view)pc_stock_caption_bounds(child,0,0,0,0);
 }
 pc_stock_caption_show(browser_caption[3],view,load_label[3],7,0,104,38);
 pc_stock_caption_show(browser_caption[1],view,load_label[1],111,0,104,38);
 pc_stock_caption_show(browser_caption[2],view,load_label[2],215,0,104,38);
 pc_stock_caption_show(browser_caption[0],view,load_label[0],0,216,154,22);
 uintptr_t model=Q(view,0x1390);
 unsigned internal=model&&(*(uint8_t*)(model+0xb0)&1);
 pc_stock_caption_hide(browser_caption[4+!internal],view);
 pc_stock_caption_show(browser_caption[4+internal],view,internal?"K3 Internal":"K3 External",166,216,154,22);
 uintptr_t path=view+0x11d0;
 if(Q(path,0x18)==view&&I(path,0x24)==198&&I(path,0x2c)>18)
  pc_stock_caption_bounds(path,I(path,0x20),198,I(path,0x28),18);
 return 1;
}
void pc_dj_browser_layout(uintptr_t view){
 FN(0x1608bb0,void(*)(uintptr_t))(view);
 if(pc_dj_import()&&!I(view,0x1388))pc_dj_browser_frame(view);
}
void pc_dj_browser_paint(uintptr_t view,uintptr_t graphics){
 if(!view||!graphics||!pc_dj_import()||Q(view,0)!=host.base+0x6e1cfb8||I(view,0x1388)||!browser_status)return;
 EiCanvas canvas={(void*)graphics,rect,320,240};
 ei_rect(&canvas,0,190,320,22,MPC_THEME_BG);
 ei_text(&canvas,8,195,browser_status,304,MPC_THEME_MUTED);
}
static void return_to_decks(uintptr_t view){
 int mode=__atomic_exchange_n(&dj.return_mode,0,__ATOMIC_ACQ_REL);
 if(!mode)return;
 hide_browser_keys(view);
 if(view)FN(0x1608bb0,void(*)(uintptr_t))(view);
 browser_view=0;
 dj.resume_mode=mode;
 uintptr_t menu=manager();
 if(menu)FN(0x1c0e5c0,void(*)(uintptr_t,int))(menu,mode);
}
static void analysis_tick(void){
 FN(0x6d43500,void(*)(uint64_t))((10ull<<32)|(59u<<1)|1u);
}
static void *analyse_job(void *opaque){
 DjJob *job=opaque;
 unsigned index=job==&dj.job[1];
 pc_sys(140,0,0,10,0,0,0); /* Offline conversion/analysis yields to playback. */
 job->error=pc_dj_prepare_track(job->result.path,job->result.render_path,DJ_PATH);
 if(!job->error)job->error=pc_dj_analyse_progress(job->result.render_path,job->result.path,&job->result.audio,&job->progress);
 __atomic_store_n(&job->state,2,RL);
 FN(0x6d43500,void(*)(uint64_t))((uint64_t)(DJ_LOAD_DONE+index)<<32|(59u<<1)|1u);
 return 0;
}
static int begin_job(unsigned deck,const char *path){
 DjJob *job=&dj.job[deck];
 if(__atomic_load_n(&job->state,AQ))return 0;
 void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 int(*thread)(uintptr_t*,void*,void*(*)(void*),void*)=symbol(0,"pthread_create");
 int(*detach)(uintptr_t)=symbol(0,"pthread_detach");
 if(!thread||!detach)return 0;
 unsigned n=0;while(path[n])n++;
 memcpy(job->result.path,path,n+1);
 job->result.cue=0;job->result.load_order=++dj.load_serial;job->play_when_ready=0;
 job->named_tempo=pc_dj_filename_bpm(path)>0;
 job->progress.notify=analysis_tick;__atomic_store_n(&job->progress.value,0,RL);
 __atomic_store_n(&job->state,1,RL);
 uintptr_t id;
 if(thread(&id,0,analyse_job,job)){
  __atomic_store_n(&job->state,0,RL);return 0;
 }
 detach(id);
 return 1;
}
static void choose_master(void){
 int first=-1;
 for(unsigned i=0;i<2;i++)if(dj.deck[i].audio.frames&&
     (first<0||dj.deck[i].load_order<dj.deck[first].load_order))first=(int)i;
 if(first!=dj.master){
  dj.master=first;
  if(first>=0)dj.transport[first].sync=dj.transport[first].correction=0;
 }
}
static void collect_jobs(void){
 static const char *const error[]={"","Cannot read track","Use a mono/stereo WAV or MP3","Maximum track length: 30 min","Analysis memory unavailable","Cannot prepare 44.1k cache on SD"};
 for(unsigned i=0;i<2;i++){
  DjJob *job=&dj.job[i];
  if(__atomic_load_n(&job->state,AQ)!=2)continue;
  if(job->error==DJ_OK){
   pc_dj_pause(i);pc_dj_loop(i,0,0);
   dj.transport[i]=(DjTransport){0};
   dj.deck[i]=job->result;choose_master();dj.message=0;
   if(job->play_when_ready&&pc_dj_open()){
    dj.transport[i].pending=1;dj.transport[i].start=pc_dj_clock();
   }
  }
  else dj.message=error[job->error];
  __atomic_store_n(&job->state,0,RL);
 }
}
static double grid_origin(const DjAnalysis *a){
 double anchor=a->downbeat_valid?a->first_downbeat:
        a->first_beat+(a->downbeat<0?0:a->downbeat*a->beat_frames);
 if(a->beat_frames<=0)return anchor;
 // Extend the detected bar phase back through the intro. The first
 // downbeat in the file is bar 1, even if the kick enters much later.
 double bar=4*a->beat_frames;
 return anchor-(uint64_t)(anchor/bar)*bar;
}
static double original_bpm(const DjAnalysis *a){
 return a->tagged_bpm>0?a->tagged_bpm:a->beat_frames>0?a->rate*60/a->beat_frames:0;
}
static double deck_bpm(unsigned index){
 double manual=dj.transport[index].manual_bpm;
 return manual>0?manual:original_bpm(&dj.deck[index].audio);
}
static double base_ratio(unsigned deck){
 int master=dj.master;double follower=original_bpm(&dj.deck[deck].audio);
 if(follower<=0)return 1;
 if(!dj.transport[deck].sync||master<0||master==(int)deck)return deck_bpm(deck)/follower;
 double leader=deck_bpm((unsigned)master);
 return leader>0?dj_sync_target(leader,follower)/follower:1;
}
static double grid_scale(const DjAnalysis *a,const DjAnalysis *b){
 (void)b;double leader=dj.master>=0?deck_bpm((unsigned)dj.master):0;
 return leader>0?dj_sync_target(leader,original_bpm(a))/leader:1;
}
static void update_rate(unsigned deck){
 DjTransport *t=&dj.transport[deck];
 double ratio=base_ratio(deck);
 if(ratio<.5||ratio>2)ratio=1;
 if(t->nudge==1)ratio*=.92;
 if(t->nudge==2)ratio*=1.08;
 if(t->correction&&pc_dj_clock()>=t->sync_at&&dj.master>=0&&pc_dj_started((unsigned)dj.master)&&pc_dj_started(deck)&&!t->nudge){
  const DjAnalysis *a=&dj.deck[deck].audio,*b=&dj.deck[dj.master].audio;
  if(a->beat_frames>0&&b->beat_frames>0){
   double x=((double)pc_dj_position(deck)-grid_origin(a))/a->beat_frames;
   double y=((double)pc_dj_position(dj.master)-grid_origin(b))*grid_scale(a,b)/b->beat_frames;
   double error=y-x;error-=(int)error;
   if(error>.5)error-=1;if(error<-.5)error+=1;
   /* Ignore inaudible phase noise instead of waking KeyLock at unity. */
   if(error<.02&&error>-.02)error=0;
   if(error>.12)error=.12;if(error<-.12)error=-.12;
   ratio*=1+error*.08;
  }
 }
 if(ratio<.5)ratio=.5;if(ratio>2)ratio=2;
 pc_dj_rate(deck,(unsigned)(ratio*1000000+.5));
}
/* Only the UI thread changes BPM. This small timer posts UI ticks while
 * pads are held, so repeat also works when both decks and the screen are idle. */
static unsigned bpm_timer_mask,bpm_timer_running;
static void *bpm_timer_worker(void *unused){
 (void)unused;
 for(;;){
  while(__atomic_load_n(&bpm_timer_mask,AQ)){
   long delay[2]={0,100000000};
   pc_sys(101,(long)delay,0,0,0,0,0);
   if(__atomic_load_n(&bpm_timer_mask,AQ))
    FN(0x6d43500,void(*)(uint64_t))((10ull<<32)|(59u<<1)|1u);
  }
  __atomic_store_n(&bpm_timer_running,0,RL);
  if(!__atomic_load_n(&bpm_timer_mask,AQ)||
     __atomic_exchange_n(&bpm_timer_running,1,__ATOMIC_ACQ_REL))return 0;
 }
}
__attribute__((noinline)) static void start_bpm_timer(void){
 if(__atomic_exchange_n(&bpm_timer_running,1,__ATOMIC_ACQ_REL))return;
 void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 int(*thread)(uintptr_t*,void*,void*(*)(void*),void*)=symbol(0,"pthread_create");
 int(*detach)(uintptr_t)=symbol(0,"pthread_detach");
 uintptr_t id;
 if(!thread||!detach||thread(&id,0,bpm_timer_worker,0)){
  __atomic_store_n(&bpm_timer_running,0,RL);return;
 }
 detach(id);
}
static uint64_t dj_milliseconds(void){
 uint64_t time[2]={0};
 if(pc_sys(113,1,(long)time,0,0,0,0)<0)return 0;
 return time[0]*1000+time[1]/1000000;
}
static int bpm_step(unsigned index,int delta){
 DjTransport *t=&dj.transport[index];const DjAnalysis *a=&dj.deck[index].audio;
 double original=original_bpm(a);
 if(!a->frames||original<=0){dj.message="Analyse BPM first";return 0;}
 double next=original*base_ratio(index)+delta;
 double minimum=original*.5,maximum=original*2;
 if(minimum<20)minimum=20;if(maximum>400)maximum=400;
 if(next<minimum)next=minimum;if(next>maximum)next=maximum;
 t->manual_bpm=next;t->sync=t->correction=0;
 for(unsigned deck=0;deck<2;deck++)update_rate(deck);
 dj.message=0;return 1;
}
static void clear_bpm_holds(void){
 __atomic_store_n(&bpm_timer_mask,0,RL);
 for(unsigned i=0;i<2;i++){dj.transport[i].bpm_held=0;dj.transport[i].repeat_at=0;}
}
static void bpm_repeat_poll(void){
 if(!pc_dj_open()||dj.exit_confirm){clear_bpm_holds();return;}
 if(!(dj.transport[0].bpm_held|dj.transport[1].bpm_held))return;
 uint64_t now=dj_milliseconds();unsigned changed=0;
 for(unsigned i=0;i<2;i++){
  DjTransport *t=&dj.transport[i];int delta=(!!(t->bpm_held&2))-(!!(t->bpm_held&1));
  if(delta&&now>=t->repeat_at){
   /* One update per 100 ms. A delayed UI frame never emits a BPM burst. */
   changed|=bpm_step(i,delta);t->repeat_at=now+100;
  }
 }
 if(changed&&dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
}
static void queue_play(unsigned deck,uint64_t cue,uint64_t start){
 DjTransport *t=&dj.transport[deck];
 if(pc_dj_playing(deck))pc_dj_pause(deck);
 t->cue=cue;t->start=start;t->pending=1;t->cue_edited=0;
}
static void transport_poll(void){
 bpm_repeat_poll();choose_master();
 for(unsigned i=0;i<2;i++){
  DjTransport *t=&dj.transport[i];
  update_rate(i);
  if(pc_dj_failed(i))dj.message="Cannot read or render track";
  if(t->pending&&!dj.exit_confirm&&!pc_dj_busy(i)){
   int launched=pc_dj_play(i,dj.deck[i].render_path,t->cue,t->start);
   if(launched>0){t->pending=t->resumable=0;dj.message=0;}
   else if(!launched){t->pending=0;dj.message="Cannot start deck";}
  }
 }
}
static void stop_decks(void){
 pc_dj_space_reset();clear_bpm_holds();
 for(unsigned i=0;i<2;i++){
  DjTransport *t=&dj.transport[i];
  if(pc_dj_started(i)){t->resume=pc_dj_position(i);t->resumable=1;}
  t->pending=t->nudge=t->correction=dj.job[i].play_when_ready=0;
  pc_dj_pause(i);
 }
}
void pc_dj_sd_suspend(void){
 pc_usb_cue_enable(0);
 stop_decks();
}

static int sync_timing(unsigned index,uint64_t requested,int playing,
                       uint64_t *source_frame,uint64_t *start_clock){
 unsigned master=(unsigned)dj.master;
 const DjAnalysis *a=&dj.deck[index].audio,*b=&dj.deck[master].audio;
 const DjTransport *leader=&dj.transport[master],*follower=&dj.transport[index];
 double master_origin=grid_origin(b),follower_origin=grid_origin(a);
 double master_bar=4*b->beat_frames/grid_scale(a,b),local_bar=4*a->beat_frames;
 double master_speed=base_ratio(master),follower_speed=base_ratio(index);
 uint64_t head=pc_dj_position(master),now=pc_dj_clock();
 double source=requested;
 double lead_in=0;
 if(!playing){
  // Start the bar containing the selected cue. A partial first bar
  // keeps its intro and reaches its first downbeat at the master bar.
  int bar=dj_mixxx_beat_at_or_after(source+.5,follower_origin,local_bar)-1;
  source=follower_origin+bar*local_bar;
  if(source<0){
   lead_in=(follower_origin/local_bar)*master_bar;
   source=0;
  }
  if(follower->loop&&(source<follower->loop_start||source>=follower->loop_end)){
   source=follower->loop_start;
   lead_in=0;
  }
 }
 double earliest=head+b->rate*.45*master_speed+lead_in;
 int bar=dj_mixxx_beat_at_or_after(earliest-.25,master_origin,master_bar);
 double master_frame=master_origin+bar*master_bar;
 if(leader->loop&&head<leader->loop_end&&master_frame>=leader->loop_end){
  double overshoot=earliest-leader->loop_end;
  double wrap=leader->loop_end-leader->loop_start;
  if(overshoot<0)overshoot=0;
  double at=leader->loop_start+overshoot-(uint64_t)(overshoot/wrap)*wrap;
  double next=master_origin+master_bar*dj_mixxx_beat_at_or_after(at-.25,master_origin,master_bar);
  master_frame=(earliest>leader->loop_end?earliest:leader->loop_end)+
               (next>=leader->loop_end?leader->loop_end-at:next-at);
 }else if(master_frame>=b->frames){
  dj.message="Master is near the end";
  return 0;
 }
 double elapsed=(master_frame-head)/b->rate/master_speed;
 if(playing){
  double projected=source+elapsed*a->rate*follower_speed;
  int local=dj_mixxx_beat_at_or_after(projected-local_bar*.5,follower_origin,local_bar);
  source=follower_origin+local*local_bar;
  if(source<0)source+=local_bar;
  if(source>=a->frames&&source-local_bar>=0)source-=local_bar;
  if(follower->loop&&(source<follower->loop_start||source>=follower->loop_end))
   source=follower->loop_start;
 }
 if(source<0||source>=a->frames){dj.message="Choose an earlier cue";return 0;}
 *source_frame=(uint64_t)(source+.5);
 *start_clock=now+(uint64_t)((elapsed-lead_in/b->rate/master_speed)*44100+.5);
 return 1;
}
static void sync_deck(unsigned index){
 int master=dj.master;
 DjTransport *t=&dj.transport[index];
 const DjAnalysis *a=&dj.deck[index].audio;
 if(master<0||master==(int)index){dj.message="Load a Sync Master";return;}
 if(!a->beat_frames||!dj.deck[master].audio.beat_frames){
  dj.message="SYNC needs a beatgrid on both decks";return;
 }
 double ratio=dj_sync_target(deck_bpm((unsigned)master),original_bpm(a))/original_bpm(a);
 if(ratio<.5||ratio>2){dj.message="BPM ratio out of range";return;}
 t->sync=1;
 t->correction=0;
 dj.message=0;
 if(pc_dj_started(index)&&pc_dj_started((unsigned)master)){
  uint64_t source,deadline;
  if(sync_timing(index,pc_dj_position(index),1,&source,&deadline)){
   if(pc_dj_seek(index,source,deadline)){
    t->correction=1;
    t->sync_at=deadline;
   }else dj.message="Deck busy / retry SYNC";
  }
 }
 update_rate(index);
}
static void play_deck(unsigned index,uint64_t cue){
 DjTransport *t=&dj.transport[index];
 uint64_t source=cue,start=pc_dj_clock();
 t->correction=0;
 if(t->sync&&dj.master>=0&&dj.master!=(int)index&&pc_dj_started((unsigned)dj.master)&&
    dj.deck[index].audio.beat_frames>0&&dj.deck[dj.master].audio.beat_frames>0){
  if(!sync_timing(index,cue,0,&source,&start))return;
  t->correction=1;
  t->sync_at=start;
 }
 queue_play(index,source,start);
}
void pc_dj_transport(unsigned action){
 if(!pc_dj_open()||dj.exit_confirm||action>=4)return;
 unsigned index=action/2;DjDeck *d=&dj.deck[index];DjTransport *t=&dj.transport[index];
 if(__atomic_load_n(&dj.job[index].state,AQ)==1){
  dj.job[index].play_when_ready=(action&1)&&!dj.job[index].play_when_ready;return;
 }
 if(!d->audio.frames)return;
 if(!(action&1)){
  t->pending=0;pc_dj_pause(index);t->resume=d->cue;t->resumable=1;
 }else if(pc_dj_playing(index)||t->pending){
  t->resume=pc_dj_position(index);t->resumable=1;t->pending=0;pc_dj_pause(index);
 }else play_deck(index,t->resumable?t->resume:d->cue);
 transport_poll();pc_dj_lights();
 if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
}
void pc_dj_pad(unsigned pad,unsigned down){
 if(!pc_dj_open()||pad>=16||dj.exit_confirm)return;
 unsigned index=(pad/2)&1;
 DjDeck *d=&dj.deck[index];DjTransport *t=&dj.transport[index];
 if(pad<4){
  unsigned bit=1u<<(pad&1),before=t->bpm_held;
  if(down)t->bpm_held|=bit;else t->bpm_held&=~bit;
  if(down&&!(before&bit))bpm_step(index,pad&1?1:-1);
  t->repeat_at=dj_milliseconds()+400;
  unsigned mask=dj.transport[0].bpm_held|(dj.transport[1].bpm_held<<2);
  __atomic_store_n(&bpm_timer_mask,mask,RL);
  if(mask)start_bpm_timer();
  pc_dj_lights();
  if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
  return;
 }
 if(pad>=8&&pad<12){
  unsigned bit=1u<<(pad&1);
  unsigned before=t->nudge;
  if(down)t->nudge|=bit;else t->nudge&=~bit;
  if(down&&!(before&bit)){
   t->correction=0; // Manual phase adjustments survive releasing the pad.
   pc_dj_nudge_step(index,pad&1?1:-1);
  }
  update_rate(index);pc_dj_lights();return;
 }
 if(!down)return;
 if(!d->audio.frames)return;
 if(pad<8){
  if(pad&1){
   choose_master();
   dj.message=0;
  }else sync_deck(index);
 }else{
  unsigned bars=(pad&1)?4:2;
  if(t->loop==bars){t->loop=0;t->loop_start=t->loop_end=0;pc_dj_loop(index,0,0);}
  else if(d->audio.beat_frames){
   const DjAnalysis *a=&d->audio;
   double origin=grid_origin(a);
   uint64_t focus=pc_dj_playing(index)&&!t->cue_edited?pc_dj_position(index):d->cue;
   int beat=dj_mixxx_beat_at_or_after(focus+.5,origin,a->beat_frames)-1;
   if(beat<0)beat=0;
   beat-=beat%4;
   double from=origin+beat*a->beat_frames,to=from+bars*4*a->beat_frames;
   if(from>=0&&to<=a->frames){
    t->loop=bars;t->resumable=0;
    t->loop_start=(uint64_t)(from+.5);t->loop_end=(uint64_t)(to+.5);
    pc_dj_loop(index,t->loop_start,t->loop_end);
    if(!pc_dj_playing(index))d->cue=t->loop_start;
   }else dj.message="Loop does not fit";
  }else dj.message="Beatgrid required for loop";
 }
 transport_poll();
 pc_dj_lights();
 if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
}
void pc_dj_poll(void){
 if(dj_fx.open&&!pc_dj_open())dj_fx.open=0;
 int returning=__atomic_load_n(&dj.return_mode,AQ),mode=current_mode();
 if(returning&&mode!=SAMPLE_IMPORT&&mode!=returning){
  __atomic_store_n(&dj.return_mode,0,RL);pc_usb_cue_enable(0);stop_decks();
 }
 if(dj.resume_mode&&mode!=dj.resume_mode&&mode!=SAMPLE_IMPORT)dj.resume_mode=0;
 collect_jobs();transport_poll();
}
static void browser_event(unsigned button){
 uintptr_t view=pc_import_current();
 if(!view)view=browser_view;
 if(button==6||button==7){
  uintptr_t model=view?Q(view,0x1390):0;
  unsigned internal=button==7;
  if(button==7)browser_default=0;
  browser_status=0;
  if(model&&Q(view,0x120)&&
     (FN(0x14fa400,unsigned(*)(uintptr_t))(model)&1)&&
     !!(*(uint8_t*)(model+0xb0)&1)!=internal){
   /* Stock popup order is Internal=0, External=1. */
   FN(0x1604a40,void(*)(uintptr_t,unsigned))(view,!internal);
   FN(0x1149d70,void(*)(uintptr_t))(view);
  }
  return;
 }
 if(button==0){
  uintptr_t model=view?Q(view,0x1390):0;
  if(model&&(FN(0x14fa0a0,unsigned(*)(uintptr_t))(model)&1))
   FN(0x1605e90,void(*)(uintptr_t))(view); /* Stock B1 parent-folder action. */
  else return_to_decks(view);
  return;
 }
 if(button==4){return_to_decks(view);return;}
 if(button!=1&&button!=2&&button!=3)return;
 char path[DJ_PATH];
 if(!pc_import_selected_path(view,path,sizeof path)){
  if(view){browser_status="Select a WAV or MP3";FN(0x1149d70,void(*)(uintptr_t))(view);}
  return;
 }
 uintptr_t file=0;
 FN(0xf535c0,void(*)(uintptr_t*,const char*))(&file,path);
 unsigned directory=FN(0xf41a00,unsigned(*)(uintptr_t*))(&file)&1;
 FN(0xf0a290,void(*)(uintptr_t*))(&file);
 if(directory){
  browser_status=0;
  FN(0x3b71c30,void(*)(uintptr_t))(view+0xff0);
  return;
 }
 if(button!=1&&button!=2)return;
 if(!begin_job(button-1,path)){
  browser_status="Deck busy or analysis unavailable";
  FN(0x1149d70,void(*)(uintptr_t))(view);
  return;
 }
 dj.selected=button-1;
 pc_dj_monitor(dj.selected,cue_blend);
 dj.message=0;
 return_to_decks(view);
}
void pc_dj_visibility(uintptr_t screen,unsigned visible){
 FN(0x1172670,void(*)(uintptr_t,unsigned))(screen,visible);
 if(!(visible&1)&&dj.screen==screen){
  dj_fx.open=0;dj.exit_confirm=0;clear_bpm_holds();
  __atomic_store_n(&dj.mode,0,RL);
  __atomic_store_n(&dj.open,0,RL);
  dj.screen=0;
  dj_key(screen,0);
  if(!__atomic_load_n(&dj.return_mode,AQ)){pc_usb_cue_enable(0);stop_decks();}
  pc_light_refresh();
 }
}
static void fx_choose(void){
 if(!pc_meta()){dj.message="FX busy / try again";return;}
 if(!pc_mix_ensure())dj.message="FX preparing";
 else if(!pc_fx_select(dj_fx.slot,pc_fx_catalog_type(dj_fx.candidate)))
  dj.message=host.ui.message?host.ui.message:"FX load failed";
 else {dj.message=0;dj_fx.armed=dj_fx.known=0;}
 pc_unmeta();
}
void pc_dj_event(unsigned button){
 if(button>=DJ_LOAD_DONE){
  collect_jobs();transport_poll();
  if(pc_dj_open()&&dj.screen){pc_dj_lights();FN(0x1149d70,void(*)(uintptr_t))(dj.screen);}
  return;
 }
 if(pc_dj_import()){browser_event(button);return;}
 if(!pc_dj_fader()||!dj.screen)return;
 if(pc_dj_open()&&dj.exit_confirm){
  if(button==0||button==5){dj.exit_confirm=0;}
  else if(button==3){
   unsigned yes=dj.exit_choice==0;dj.exit_confirm=0;
   if(yes){
    int target=dj.exit_mode==0x20ad?0x20ad:0x20a7;
    uintptr_t screen=dj.screen,menu=manager();
    dj_fx.open=0;dj.resume_mode=0;
    __atomic_store_n(&dj.return_mode,0,RL);
    __atomic_store_n(&raw_pad_held,0,RL);
    stop_decks();pc_usb_cue_enable(0);
    __atomic_store_n(&dj.open,0,RL);dj_disarm(&controls,7);
    dj_key(screen,0);
    /* Force the native mode transition: SetMode returns early when an
     * overlay is open over the already-selected Sample mode. */
    if(menu)FN(0x1c0d690,void(*)(uintptr_t,int))(menu,target);
    restore_leds();pc_ui_dj_release();pc_light_refresh();
    return;
   }
  }
  if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
  return;
 }
 if(pc_dj_open()&&button==5){
  dj.exit_choice=1;dj.exit_confirm=1;clear_bpm_holds();
  for(unsigned i=0;i<2;i++)dj.transport[i].nudge=0;
  pc_dj_lights();
  if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
  return;
 }
 if(pc_dj_open()&&button==7){
  dj_fx.open^=1;
  dj_fx.armed=dj_fx.known=0;
  if(dj_fx.open)dj_fx.candidate=pc_fx_catalog_index(pc_fx_type(dj_fx.slot));
  dj.message=0;
 }else if(pc_dj_open()&&dj_fx.open&&button<4){
  if(button==0)dj_fx.open=0;
  else if(button==1){
   dj_fx.slot=(dj_fx.slot+1)%3;dj_fx.armed=dj_fx.known=0;
   dj_fx.candidate=pc_fx_catalog_index(pc_fx_type(dj_fx.slot));
  }else fx_choose();
 }else if(!pc_dj_open()){
  if(button!=1)return;
  controls.page=DJ_VOLUME;dj_disarm(&controls,7);
  dj_fx.open=0;
  pc_ui_dj_dismiss_fx();
  uintptr_t menu=manager();dj.exit_mode=menu?I(menu,0x80):0x20a7;dj.exit_confirm=0;
  __atomic_store_n(&dj.fader_armed,0,RL);pc_dj_space_reset();
  pc_native_sequence_stop();
  cue_blend=DJ_KNOB_MAX;dj_shift=0;
  pc_dj_monitor(dj.selected,cue_blend);
  pc_dj_monitor_reset();
  pc_usb_cue_enable(1);
  __atomic_store_n(&dj.open,1,RL);
  pc_ui_dj_dismiss_fx();
 }else if(button==4){
  dj_fx.open=0;
  pc_ui_dj_dismiss_fx();
  uintptr_t menu=manager();
  if(menu){
   dj.message=0;browser_default=1;browser_view=0;browser_status=0;
   __atomic_store_n(&dj.return_mode,current_mode(),RL);
   FN(0x1c0e5c0,void(*)(uintptr_t,int))(menu,SAMPLE_IMPORT);
  }
  return;
 }else if(button==3){
  dj.selected^=1;
  pc_dj_monitor(dj.selected,cue_blend);
 }else if(!dj_page_button(&controls,button))return;
 if(button==1&&!dj_fx.open&&controls.page!=DJ_SENDS){
  pc_dj_filter(0,DJ_KNOB_CENTRE);pc_dj_filter(1,DJ_KNOB_CENTRE);
 }
 dj_key(dj.screen,!pc_dj_open());
 if(pc_dj_open())pc_dj_lights();else pc_light_refresh();
 FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
}
void pc_dj_fx_shift(unsigned page){
 page=!!page;
 if(dj_shift!=page){dj_shift=page;dj_disarm(&controls,7);}

 if(dj_fx.page!=page){dj_fx.page=page;dj_fx.armed=dj_fx.known=0;}
 if(pc_dj_open()&&dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
}
void pc_dj_knob(unsigned knob,unsigned position){
 if(pc_dj_import()){
  if(knob==2){
   if(position<=6553)browser_event(7);
   else if(position>=9830)browser_event(6);
  }
  return;
 }
 if(dj.exit_confirm)return;
 if(dj_fx.open){
  if(knob>=3||position>16383)return;
  unsigned parameter=knob+3*dj_fx.page,target=pc_fx_position(dj_fx.slot,parameter),bit=1u<<knob,last=dj_fx.last[knob];
  unsigned distance=position>target?position-target:target-position;
  if(distance<=128||((dj_fx.known&bit)&&((last<=target&&position>=target)||(last>=target&&position<=target))))dj_fx.armed|=bit;
  dj_fx.known|=bit;dj_fx.last[knob]=position;
  if((dj_fx.armed&bit)&&pc_meta()){pc_fx_knob(dj_fx.slot,parameter,position);pc_unmeta();}
  if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
  return;
 }
 if(pc_dj_open()&&dj_shift&&controls.page==DJ_VOLUME){
  if(knob==0&&dj_pickup_value(&controls,knob,position,&cue_blend))
   pc_dj_monitor(dj.selected,cue_blend);
  if(knob==2&&dj_pickup_value(&controls,knob,position,&cue_gain))
   pc_dj_monitor_gain(cue_gain);
  if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
  return;
 }
 if(!pc_dj_open()||!dj_pickup(&controls,knob,position))return;
 if(controls.page!=DJ_SENDS&&knob==1)pc_dj_filter(controls.filter_deck,position);
 if(controls.page==DJ_VOLUME&&knob!=1)pc_dj_gain(knob/2,position);
 if(controls.page==DJ_EQ&&knob!=1)pc_dj_low(knob/2,dj_low_db(position));
 if(controls.page==DJ_SENDS)pc_dj_send(controls.send_deck,knob,position);
 if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
}
void pc_dj_fader_position(unsigned position){
 if(!pc_dj_open()||position>16383)return;
 if(!__atomic_load_n(&dj.fader_armed,AQ)){
  if(position>128)return;
  __atomic_store_n(&dj.fader_armed,1,RL);position=0;
 }
 pc_dj_space_position(position);
}
void pc_dj_rotate(int delta){
 if(!pc_dj_open()||!delta)return;
 if(dj.exit_confirm){
  int64_t next=(int64_t)dj.exit_choice+delta;
  dj.exit_choice=next<0?0:next>1?1:(unsigned)next;
  if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
  return;
 }
 if(dj_fx.open){
  int64_t next=(int64_t)dj_fx.candidate+delta;
  unsigned count=pc_fx_count();
  dj_fx.candidate=next<0?0:next>count?count:(unsigned)next;
  if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
  return;
 }
 DjDeck *d=&dj.deck[dj.selected];if(!d->audio.frames)return;
 const DjAnalysis *a=&d->audio;
 double next;
 if(a->beat_frames>0){
  double origin=grid_origin(a);
  int beat=dj_mixxx_beat_at_or_after(d->cue+.5,origin,a->beat_frames)-1;
  next=origin+((double)beat+delta)*a->beat_frames;
 }else next=(double)d->cue+(double)delta*a->rate;
 dj.transport[dj.selected].resumable=0;dj.transport[dj.selected].cue_edited=1;
 d->cue=next<0?0:next>=a->frames-1?a->frames-1:(uint64_t)(next+.5);
 if(dj.screen)FN(0x1149d70,void(*)(uintptr_t))(dj.screen);
}
static void rect(void*g,int x,int y,int w,int h,unsigned colour){
 FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,colour);
 FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);
}
static const char *filename(const char *path){
 const char *name=path;
 for(;*path;path++)if(*path=='/')name=path+1;
 return name;
}
static void number_outline(void *canvas,int x,int y,int w,int h,unsigned colour){
 EiCanvas *c=canvas;
 ei_rect(c,x-1,y-1,w+2,h+2,colour&0xff000000u);
}
static void number_red(void *canvas,int x,int y,int w,int h,unsigned colour){
 ei_rect((EiCanvas*)canvas,x,y,w,h,(colour&0xff000000u)|0xff3030u);
}
static void wave_number(EiCanvas *c,int x,int y,const char *text,int width){
 if(width<=0)return;
 pc_theme_text_face_width(c,number_outline,x,y,text,8,MPC_THEME_TEXT,0,12,width);
 pc_theme_text_face_width(c,number_red,x,y,text,8,MPC_THEME_TEXT,0,12,width);
}
static void wave(EiCanvas *c,const DjDeck *deck,unsigned index,int y,int height){
 const DjAnalysis *a=&deck->audio;
 int x=15,width=c->w-30,mid=y+height/2;
 uint64_t head=pc_dj_position(index);
 int playing=pc_dj_started(index);
 uint64_t focus=playing?head:dj.transport[index].resumable?dj.transport[index].resume:deck->cue;
 // One output-time scale for both decks: eight bars of the master.
 // Source spans follow each deck's tempo ratio, never full-file duration.
 double bpm=dj.master>=0?deck_bpm((unsigned)dj.master):120;if(bpm<=0)bpm=120;
 double frames=1920.0*a->rate/bpm*base_ratio(index);
 if(frames<1)frames=1;
 double start=(double)focus-frames*.5;
 const DjTransport *transport=&dj.transport[index];
 if(transport->loop&&transport->loop_end>start&&transport->loop_start<start+frames){
  double first=transport->loop_start>start?transport->loop_start:start;
  double last=transport->loop_end<start+frames?transport->loop_end:start+frames;
  int left=x+(int)((first-start)*width/frames),right=x+(int)((last-start)*width/frames);
  if(right>left){
   ei_rect(c,left,y,right-left,height,MPC_THEME_SELECTED);
   ei_rect(c,left,y,right-left,2,MPC_THEME_ACCENT);
   if(transport->loop_start>=start)ei_rect(c,left,y,2,height,MPC_THEME_ACCENT);
   if(transport->loop_end<start+frames)ei_rect(c,right-1,y,1,height,MPC_THEME_ACCENT);
  }
 }
 ei_rect(c,x,mid,width,1,MPC_THEME_GRID);
 for(int i=0;i<width;i++){
  double from=start+frames*i/width,to=start+frames*(i+1)/width;
  if(to<=0||from>=a->frames)continue;
  if(from<0)from=0;if(to>a->frames)to=a->frames;
  unsigned first=from*DJ_PEAKS/a->frames,end=to*DJ_PEAKS/a->frames;
  if(end<=first)end=first+1;
  unsigned peak=0;
  for(unsigned bin=first;bin<end&&bin<DJ_PEAKS;bin++)if(a->peak[bin]>peak)peak=a->peak[bin];
  int bar=(height-2)*peak/255;
  if(bar)ei_rect(c,x+i,mid-bar/2,1,bar,index==0?0xff48d982:0xffb879f2);
 }
 if(a->beat_frames>0){
  double origin=grid_origin(a);
  int beat=dj_mixxx_beat_at_or_after(start,origin,a->beat_frames);
  for(;;beat++){
   double frame=origin+beat*a->beat_frames;
   if(frame>=start+frames||frame>=a->frames)break;
   if(frame<0)continue;
   int at=(int)((frame-start)*width/frames);
   if(at<0)continue;
   int down=beat%4==0;
   ei_rect(c,x+at,y,down?2:1,height,down?MPC_THEME_TEXT:MPC_THEME_MUTED);
   if(down&&height>=24&&at<width-20&&beat>=0){
    unsigned number=(unsigned)beat/4+1;
    char text[8];unsigned used=0,divisor=1;
    while(number/divisor>=10)divisor*=10;
    for(;divisor;divisor/=10)text[used++]='0'+number/divisor%10;
    text[used]=0;
    wave_number(c,x+at+4,y+2,text,width-at-4);
   }
  }
 }
 if(a->transient_valid&&a->first_transient>=start&&a->first_transient<start+frames)
  ei_rect(c,x+(int)((a->first_transient-start)*width/frames),y,1,height,MPC_THEME_WARNING);
 if(deck->cue>=start&&deck->cue<start+frames)
  ei_rect(c,x+(int)((deck->cue-start)*width/frames),y,1,height,MPC_THEME_ACCENT);
 if(playing&&head>=start&&head<start+frames)
  ei_rect(c,x+(int)((head-start)*width/frames),y,2,height,MPC_THEME_ACCENT);
}
static void deck_paint(EiCanvas *c,unsigned index,int y,int height){
 const DjDeck *d=&dj.deck[index];const DjAnalysis *a=&d->audio;
 ei_rect(c,8,y,c->w-16,height-4,MPC_THEME_SURFACE);
 if(index==dj.selected)ei_rect(c,8,y,2,height-4,MPC_THEME_ACCENT);
 const DjTransport *transport=&dj.transport[index];
 ei_text(c,92,y+4,pc_dj_playing(index)?"PLAY":"PAUSE",53,MPC_THEME_MUTED);
 if(transport->sync||dj.master==(int)index)
  ei_text(c,144,y+4,transport->sync?"SYNC":"MASTER",68,MPC_THEME_ACCENT);
 if(transport->loop)ei_text(c,c->w-55,y+17,transport->loop==2?"LOOP 2":"LOOP 4",48,MPC_THEME_ACCENT);
 unsigned target=controls.page==DJ_SENDS?controls.send_deck:controls.filter_deck;
 if(index==target){
  for(int row=0;row<4;row++)ei_rect(c,77+row,y+5+row,1,7-2*row,MPC_THEME_ACCENT);
 }
 ei_text(c,15,y+4,index?"DECK 2":"DECK 1",c->w-120,MPC_THEME_TEXT);
 if(__atomic_load_n(&dj.job[index].state,AQ)==1)
  ei_text(c,c->w-120,y+4,"ANALYSING",112,MPC_THEME_WARNING);
 else if(a->beat_frames>0||a->tagged_bpm>0){
  unsigned original=(unsigned)(original_bpm(a)*10+.5);
  unsigned bpm=(unsigned)(original_bpm(a)*base_ratio(index)*10+.5);
  char tempo[]="BPM 000.0";
  if(transport->sync){
   unsigned current=(bpm+5)/10;
   original=(original+5)/10;
   tempo[0]=original>=100?'0'+original/100:' ';
   tempo[1]='0'+original/10%10;tempo[2]='0'+original%10;
   tempo[3]='>';tempo[4]=current>=100?'0'+current/100:' ';
   tempo[5]='0'+current/10%10;tempo[6]='0'+current%10;tempo[7]=0;
  }else{
   tempo[4]=bpm>=1000?'0'+bpm/1000:' ';
   tempo[5]='0'+bpm/100%10;tempo[6]='0'+bpm/10%10;tempo[8]='0'+bpm%10;
  }
  ei_text(c,c->w-100,y+4,tempo,92,MPC_THEME_TEXT);
 }else ei_text(c,c->w-100,y+4,a->frames?"NO BEATGRID":"BPM --",92,MPC_THEME_MUTED);
 unsigned analysing=__atomic_load_n(&dj.job[index].state,AQ)==1;
 int loading_height=analysing?24:0;
 if(analysing){
  unsigned progress=__atomic_load_n(&dj.job[index].progress.value,AQ);if(progress>1000)progress=1000;
  int bottom=y+height-6;
  ei_rect(c,15,bottom-3,c->w-30,3,MPC_THEME_GRID);
  ei_rect(c,15,bottom-3,(c->w-30)*progress/1000,3,MPC_THEME_ACCENT);
  char status[]="ANALYSIS 000%";status[9]='0'+progress/1000;status[10]='0'+progress/100%10;status[11]='0'+progress/10%10;
  ei_text(c,15,y+height-21,progress<10?"PREPARING AUDIO":progress<710?(dj.job[index].named_tempo?"BEATGRID / ONSETS":"READING / ONSETS"):progress<870&&!dj.job[index].named_tempo?"BPM / STRUCTURE":"BEATGRID / PHASE",c->w-110,MPC_THEME_MUTED);
  ei_text(c,c->w-85,y+height-21,status+9,70,MPC_THEME_TEXT);
 }
 if(!a->frames){
  ei_text(c,15,y+height/2,"No track loaded",c->w-30,MPC_THEME_MUTED);return;
 }
 int top=height>=49?29:16;
 if(height>=49)ei_text(c,15,y+16,filename(d->path),c->w-76,MPC_THEME_TEXT);
 if(height>top+5)wave(c,d,index,y+top,height-top-4-loading_height);
}
static void page_keys(uintptr_t screen,uintptr_t graphics,int width){
 static const char *const title[]={"EQ","Volume","Filter Deck","Sends","Select Deck"};
 static const unsigned button[3][3]={{0,2,3},{1,2,3},{0,4,1}};
 for(unsigned k=0;k<3;k++){
  unsigned caption=button[controls.page][k];if(caption>=5)continue;
  int x=k*width/3,end=(k+1)*width/3;
  pc_stock_caption_paint(page_caption[caption],screen,graphics,title[caption],x,0,end-x,38);
 }
}
static void percent_text(char out[7],unsigned value){
 unsigned n=(value*100+DJ_KNOB_MAX/2)/DJ_KNOB_MAX,at=0;
 if(n==100)out[at++]='1';
 if(n>=10)out[at++]='0'+n/10%10;
 out[at++]='0'+n%10;out[at++]='%';out[at]=0;
}
static void eq_text(char out[8],int value){
 unsigned at=0;
 if(value<0){out[at++]='-';value=-value;}else if(value)out[at++]='+';
 if(value>=10)out[at++]='0'+value/10;
 out[at++]='0'+value%10;out[at++]=' ';out[at++]='d';out[at++]='B';out[at]=0;
}
static void controls_paint(EiCanvas *c,int y){
 if(dj_shift&&controls.page==DJ_VOLUME){
  char blend[16],gain[7];
  percent_text(blend,cue_blend);
  unsigned at=0;while(blend[at])at++;
  blend[at++]='/';
  percent_text(blend+at,DJ_KNOB_MAX-cue_blend);
  percent_text(gain,cue_gain);
  int width=c->w/3-16,x3=2*c->w/3+8;
  ei_rule(c,y);
  ei_text(c,8,y+4,"K1 CUE / MASTER",width,MPC_THEME_MUTED);
  ei_text(c,8,y+18,blend,width,MPC_THEME_TEXT);
  ei_bar(c,8,c->h-5,width,cue_blend);
  ei_text(c,c->w/3+8,y+18,dj.selected?"DECK 2":"DECK 1",width,MPC_THEME_TEXT);
  ei_text(c,x3,y+4,"K3 CUE OUT GAIN",width,MPC_THEME_MUTED);
  ei_text(c,x3,y+18,gain,width,MPC_THEME_TEXT);
  ei_bar(c,x3,c->h-5,width,cue_gain);
  return;
 }
 static const char *const label[3][3]={
  {"K1 D1 VOLUME","K2 DJ FILTER","K3 D2 VOLUME"},
  {"K1 D1 LOW EQ","K2 DJ FILTER","K3 D2 LOW EQ"},
  {"K1 FX 1 SEND","K2 FX 2 SEND","K3 FX 3 SEND"},
 };
 ei_rule(c,y);
 for(unsigned k=0;k<3;k++){
  unsigned position=*dj_control_value(&controls,k);
  if(controls.page!=DJ_SENDS&&k==1)position=dj_filter_position(position);
  int x=8+k*c->w/3,width=c->w/3-16;
  ei_text(c,x,y+4,label[controls.page][k],width,MPC_THEME_MUTED);
  char value[12];
  if(controls.page!=DJ_SENDS&&k==1&&position==DJ_KNOB_CENTRE)memcpy(value,"DRY",4);
  else if(controls.page==DJ_EQ&&k!=1)eq_text(value,dj_low_db(position));
  else percent_text(value,position);
  ei_text(c,x,y+18,value,width,MPC_THEME_TEXT);
  ei_bar(c,x,c->h-5,width,position);
  if(k)ei_rect(c,k*c->w/3,y+5,1,c->h-y-8,MPC_THEME_GRID);
 }
}
static void fx_paint(EiCanvas *c,uintptr_t screen,uintptr_t graphics){
 ei_rect(c,0,0,c->w,c->h,0xff000000u);
 const char *const actions[]={"Back","Send","Load"};
 for(unsigned k=0;k<3;k++){
  int x=k*c->w/3,end=(k+1)*c->w/3;
  pc_stock_caption_paint(dj_fx_caption[k],screen,graphics,actions[k],x,0,end-x,38);
 }
 ei_rule(c,38);
 const char *const slot[]={"SEND 1","SEND 2","SEND 3"};
 ei_text(c,8,45,slot[dj_fx.slot],70,MPC_THEME_ACCENT);
 ei_text(c,82,45,pc_fx_name(pc_fx_type(dj_fx.slot)),c->w-90,MPC_THEME_MUTED);
 unsigned rows=c->h>150?(c->h-150)/20:1;
 if(!rows)rows=1;
 unsigned first=dj_fx.candidate>=rows?dj_fx.candidate-rows+1:0;
 for(unsigned row=0;row<rows&&first+row<=pc_fx_count();row++){
  unsigned n=first+row;
  int y=66+row*20;
  if(n==dj_fx.candidate)ei_selection(c,y,19);
  ei_text(c,15,y+3,pc_fx_name(pc_fx_catalog_type(n)),c->w-30,MPC_THEME_TEXT);
 }
 int y=c->h-68;
 ei_rule(c,y-3);
 for(unsigned k=0;k<3;k++){
  unsigned parameter=k+3*dj_fx.page,position=pc_fx_position(dj_fx.slot,parameter);
  int x=k*c->w/3+8,width=c->w/3-16;
  ei_text(c,x,y+2,pc_fx_label(dj_fx.slot,parameter),width,MPC_THEME_MUTED);
  char value[12];percent_text(value,position);
  const char *option=pc_fx_option(dj_fx.slot,parameter);
  ei_text(c,x,y+20,option?option:value,width,MPC_THEME_TEXT);
  ei_bar(c,x,y+40,width,position);
 }
 ei_text(c,8,c->h-17,dj.message?dj.message:dj_fx.page?"SHIFT PAGE 2/2 / ENC load":"PAGE 1/2 / SHIFT page 2 / ENC load",c->w-16,dj.message?MPC_THEME_WARNING:MPC_THEME_MUTED);
}
static void exit_paint(EiCanvas *c){
 ei_rect(c,0,0,c->w,c->h,MPC_THEME_BG);
 int middle=c->h/2;
 ei_heading(c,16,middle-68,"EXIT DJ MODE?",c->w-32);
 const char *const label[]={"YES","NO"};
 for(unsigned i=0;i<2;i++){
  int x=16+i*c->w/2,width=c->w/2-32;
  if(dj.exit_choice==i){
   ei_rect(c,x,middle,width,48,MPC_THEME_SELECTED);
   ei_rect(c,x,middle,2,48,MPC_THEME_ACCENT);
  }
  ei_value(c,x+14,middle+7,label[i],width-28,26,MPC_THEME_TEXT);
 }
 ei_text(c,16,c->h-25,"ENC choose / press confirm",c->w-32,MPC_THEME_MUTED);
}
void pc_dj_paint(uintptr_t screen,uintptr_t graphics){
 FN(0x10e2e10,void(*)(uintptr_t,uintptr_t))(screen,graphics);
 if(!host.ready||!screen||!graphics||Q(screen,0)!=host.base+FADER_VTABLE||
    !(*(uint8_t*)(screen+0xa8)&2))return;
 int mode=current_mode();if(!mode)return;
 int restored=dj.resume_mode==mode;
 if(restored){
  dj.resume_mode=0;
  __atomic_store_n(&dj.open,1,RL);
  pc_ui_dj_dismiss_fx();
 }else if(dj.screen!=screen||!pc_dj_fader())__atomic_store_n(&dj.open,0,RL);
 dj.screen=screen;
 __atomic_store_n(&dj.mode,mode,RL);
 dj_key(screen,!pc_dj_open());
 if(!pc_dj_open())return;
 if(restored)pc_dj_lights();
 collect_jobs();transport_poll();
 typedef struct{uint64_t xy,wh;} Bounds;
 Bounds b=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);
 int w=(uint32_t)b.wh,h=b.wh>>32;
 if(w<200||w>1024||h<130||h>1024)return;
 EiCanvas c={(void*)graphics,rect,w,h};
 if(dj.exit_confirm){exit_paint(&c);return;}
 if(dj_fx.open){fx_paint(&c,screen,graphics);return;}
 ei_rect(&c,0,0,w,h,MPC_THEME_BG);
 page_keys(screen,graphics,w);
 ei_rule(&c,38);
 static const char *const names[]={"DJ MODE / VOLUME","DJ MODE / EQ","DJ MODE / SENDS"};
 if(dj_shift&&controls.page==DJ_VOLUME&&h>=155)ei_text(&c,8,41,"DJ MODE / USB CUE",w-16,MPC_THEME_MUTED);
 else if(h>=155)ei_text(&c,8,41,__atomic_load_n(&dj.fader_armed,AQ)?names[controls.page]:"FADER: PICKUP 0",w/2,MPC_THEME_MUTED);
 if(h>=180&&!(dj_shift&&controls.page==DJ_VOLUME))ei_text(&c,w/2,41,controls.page==DJ_SENDS?"ARROW: SEND DECK":"ARROW: FILTER DECK",w/2-8,MPC_THEME_MUTED);
 int top=54,footer=h>=180?43:29,deck_height=(h-top-footer)/2;
 if(h<155){top=40;deck_height=(h-top-footer)/2;}
 for(unsigned deck=0;deck<2;deck++)deck_paint(&c,deck,top+deck*deck_height,deck_height);
 controls_paint(&c,h-footer);
 if(dj.message)ei_text(&c,8,h-57,dj.message,w-16,MPC_THEME_WARNING);
}
