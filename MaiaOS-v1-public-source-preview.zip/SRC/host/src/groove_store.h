#ifndef PC_GROOVE_STORE_H
#define PC_GROOVE_STORE_H
#define PC_GROOVE_SAVED_MAX 128u
#define PC_GROOVE_HITS_MAX 4096u
typedef struct {int64_t tick;float velocity;uint32_t reserved;} PcStoredHit;
typedef struct {char name[25];int64_t span;unsigned count;PcStoredHit hits[PC_GROOVE_HITS_MAX];} PcStoredGroove;
int pc_groove_read(unsigned folder,unsigned id,PcStoredGroove*out,char name[25]);
int pc_groove_write(unsigned folder,unsigned id,const PcStoredGroove*pattern);
#endif
