/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "bounce.h"
#include "../theme/text.h"
extern void pc_bounce_progress(uint64_t*,uint64_t*,unsigned*,unsigned*);
static void rect(void*g,int x,int y,int w,int h,unsigned c){FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,pc_theme_colour(c));FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);}
static void text(uintptr_t g,int x,int y,const char*s,unsigned c){pc_theme_text((void*)g,rect,x,y,s,38,c);}
static unsigned number(char*s,unsigned n,uint64_t v){char b[24];unsigned k=0;do{b[k++]='0'+v%10;v/=10;}while(v);while(k)s[n++]=b[--k];s[n]=0;return n;}
int pc_bounce_paint(uintptr_t g,int w,int h){
 if(!pc_bounce_modal()||w<200||h<80)return 0;
 uint64_t frames,total;unsigned choice,cancel;pc_bounce_progress(&frames,&total,&choice,&cancel);
 rect((void*)g,0,0,w,h,0xff10151c);text(g,7,5,"BOUNCE IN PLACE / POST FX",0xffffffff);
 if(pc_bounce_busy()){
  text(g,7,28,cancel?"Cancelling...":"Rendering post FX + tails",0xff65e5c0);unsigned percent=total?(frames>=total?100:frames*100/total):0;
  char value[80];unsigned a=number(value,0,percent);memcpy(value+a,"% | remaining <= ",16);a+=16;a=number(value,a,total>frames?(total-frames+44099)/44100:0);memcpy(value+a," s audio",9);text(g,7,53,value,0xffffffff);
  rect((void*)g,7,77,w-14,8,0xff293f50);if(percent)rect((void*)g,7,77,(w-14)*percent/100,8,0xff65e5c0);text(g,7,h-17,"B1 / B3 CANCEL",0xffadb7c4);
 }else{
  text(g,9,35,choice?"PAD SEQUENCE + FX TAIL":"PAD SOUND + FX TAIL",0xffffffff);
  text(g,9,60,"ENC CHOOSE / PRESS TO RENDER",0xffadb7c4);
  text(g,7,h-17,"B1 / B3 CANCEL",0xff65e5c0);
 }
 if(host.ui.message)text(g,7,h-35,host.ui.message,0xffffcf66);return 1;
}
void pc_bounce_lcd(uintptr_t component,uintptr_t g){
 if(!pc_bounce_modal())return;uintptr_t b=Q(pc_state_base(),0x20);if(!b||component!=Q(b,0x58))return;
 typedef struct{uint64_t xy,wh;} Bounds;Bounds a=FN(0x10f8ec0,Bounds(*)(uintptr_t))(component);int w=(int)(uint32_t)a.wh,h=(int)(a.wh>>32);if(w>=200&&w<=1024&&h>=80&&h<=1024)pc_bounce_paint(g,w,h);
}
