/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "groove.h"
#include "drumkit.h"
#include "limiter.h"
#include "dj_mode.h"
#include "stock_caption.h"
#include "sample_playback.h"
#include "synth_filter.h"
#include "../theme/text.h"
#include "../theme/minimal.h"
static unsigned groove_owned, groove_queued;
static uintptr_t groove_sequence;
static unsigned limiter_owned,dj_owned;
static uint64_t dj_pad_owned[2];
void pc_ui_dj_release(void){
 __atomic_store_n(&dj_pad_owned[0],0,RL);__atomic_store_n(&dj_pad_owned[1],0,RL);
}
static unsigned bounce_owned,user_select_owned,user_nav_owned,preview_shift,fx_button_owned;
extern void pc_input_config_frame(uintptr_t);
extern void pc_input_config_layout(uintptr_t);
static uintptr_t behaviour(void){return Q(pc_state_base(),0x20);}
static int mode(void){uintptr_t b=behaviour(),m=b?Q(b,0x30):0;if(!m)return 0;int id=I(m,0xd8);return id==0x3080?I(m,0x80):id;}
static uintptr_t current_program(void){
 uintptr_t wrapper=Q(pc_state_base(),0x1d08),track=wrapper?Q(wrapper,0x140):0;
 __atomic_store_n(&host.debug->track_vtable,track?Q(track,0)-host.base:0,RX);
 __atomic_store_n(&host.debug->program_vtable,0,RX);
 if(!track||Q(track,0)!=host.base+0x6ecf118)return 0;
 uintptr_t p=Q(track,0xbb8);if(p)__atomic_store_n(&host.debug->program_vtable,Q(p,0)-host.base,RX);
 return p&&Q(p,0)==host.base+0x6ec6860&&I(p,0x1234)==0?p:0;
}
static uintptr_t mapped_instrument(uintptr_t p,unsigned source){
 if(!p||source>=128)return 0;
 int key=I(p,0x12a8+4*source);if(key<0||key>127)return 0;
 int index=I(p,0x14a8+4*(unsigned)key);
 uintptr_t begin=Q(p,0x2808),end=Q(p,0x2810);
 if(!begin||end<begin||end-begin>128*8||(end-begin)%8||index<0||(uintptr_t)index>=(end-begin)/8)return 0;
 uintptr_t instrument=Q(begin,8*(unsigned)index);return pc_valid(p,instrument)?instrument:0;
}
/* Roll and chord pads have their own native painters. General synth
 * lighting must not race their updates or refresh a cached old mode. */
static int editor_owns_pad_lights(void){
 int screen_mode=mode();
 if(screen_mode==0x20ad&&I(pc_state_base(),0x860)==1)return 1;
 return screen_mode==0x20a7&&FN(PC_CH_SCOPE,int(*)(void))();
}
/* Extend only the visual native pad queries; sample editing stays native. */
int pc_light_has(uintptr_t p,unsigned source,uintptr_t lighting){
 pc_project_schedule();pc_preview_schedule();pc_audio_schedule();
 __atomic_fetch_add(&host.debug->reserved[0],1,RX);
 if(lighting&&pc_drumkit_active())__atomic_store_n(&host.ui.lighting,lighting,RL);
 if(editor_owns_pad_lights()||pc_project_new_pending())return 0;
 if(lighting)__atomic_store_n(&host.ui.lighting,lighting,RL);
 /* Colour callbacks can receive other Program types: reject before reading
  * DrumProgram-specific maps or its Instrument vector. */
 if(!p||Q(p,0)!=host.base+0x6ec6860||I(p,0x1234)!=0||source>=128)return 0;
 unsigned epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 int k=pc_find(mapped_instrument(p,source));
 int present=k>=0&&__atomic_load_n(&host.slots[k].program,AQ)==p;
 if(epoch!=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ))return 0;
 if(present)__atomic_fetch_add(&host.debug->reserved[1],1,RX);return present;
}
int pc_light_playing(uintptr_t p,uintptr_t instrument,unsigned key){
 (void)key;
 if(editor_owns_pad_lights()||pc_project_new_pending())return 0;
 __atomic_fetch_add(&host.debug->reserved[2],1,RX);int k=pc_find(instrument);
 int held=!pc_bounce_busy()&&k>=0&&__atomic_load_n(&host.slots[k].program,AQ)==p&&__atomic_load_n(&host.debug->held[k],AQ)>0;
 if(held)__atomic_fetch_add(&host.debug->reserved[3],1,RX);return held;
}
static unsigned light_refresh_pending;
void pc_light_refresh(void){
 if(!__atomic_exchange_n(&light_refresh_pending,1,__ATOMIC_ACQ_REL))FN(0x6d43500,void(*)(uint64_t))((49u<<1)|1u);
}
void pc_light_refresh_ui(void){
 __atomic_store_n(&light_refresh_pending,0,RL);
 if(pc_project_new_pending()||(!pc_drumkit_active()&&editor_owns_pad_lights()))return;
 uintptr_t light=__atomic_load_n(&host.ui.lighting,AQ);
 if(light&&(Q(light,0)==host.base+0x6e10068||Q(light,0)==host.base+0x6e10fb8))FN(0x1534d30,void(*)(uintptr_t))(light);
 pc_drumkit_refresh_lights();
 pc_dj_lights();
}
static uintptr_t current_instrument(void){
 uintptr_t p=current_program();if(!p)return 0;
 if(__atomic_load_n(&host.ui.catalog,AQ))return mapped_instrument(p,host.ui.source);
 /* Native selection, also when changed through menus or track recall. */
 uintptr_t wrapper=Q(pc_state_base(),0x1d08),selected=wrapper?Q(wrapper,0x668):0;
 if(!pc_valid(p,selected))return 0;
 if(mapped_instrument(p,host.ui.source)!=selected){
  for(unsigned source=0;source<128;source++)if(mapped_instrument(p,source)==selected){host.ui.source=source;break;}
 }
 return selected;
}
static int tune(void){uintptr_t b=behaviour(),seq=b?Q(b,0x48):0,s=seq?Q(seq,0x780):0;return s&&(*(uint8_t *)(s+0x2f8)&1);}
static int chord_levels(void){
 uintptr_t b=behaviour(),seq=b?Q(b,0x48):0,s=seq?Q(seq,0x780):0;
 return s&&(*(uint8_t *)(s+0x2f8)&1)&&I(s,0x88)==1&&I(pc_state_base(),0x18c0);
}
/* Native SampleModeScreen's Trim/Mix/Amp Env selector (Juce combo
 * current index at +0x218, component at +0x190). Mix is index 1. */
static int sample_mix(void){
 uintptr_t screen=host.ui.sample_screen;
 return mode()==0x20a7&&!chord_levels()&&!I(pc_state_base(),0x1c10)&&pc_find(current_instrument())<0&&screen&&
  Q(screen,0)==host.base+0x6e212a0&&I(screen,0x3a8)==1;
}
static PcStockCaption sample_sidechain_title,sample_sidechain[3];
__attribute__((noinline)) static void sample_mix_caption(uintptr_t screen,unsigned mix,uintptr_t instrument){
 if(!screen||Q(screen,0)!=host.base+0x6e212a0)return;
 static const char*const labels[]={"Off","Send","Receive"};
 unsigned role=mix?pc_sc_role(instrument):3;
 for(unsigned n=0;n<3;n++)if(n!=role)pc_stock_caption_hide(sample_sidechain[n],screen);
 if(role<3){
  pc_stock_caption_show(sample_sidechain_title,screen,"Sidechain",106,198,107,19);
  pc_stock_caption_show(sample_sidechain[role],screen,labels[role],106,217,107,19);
 }else pc_stock_caption_hide(sample_sidechain_title,screen);
}
static PcStockCaption piano_roll_caption;
void pc_step_roll_paint_caption(uintptr_t screen,uintptr_t graphics){
 if(!screen||!graphics||Q(screen,0)!=host.base+0x6e24f38||mode()!=0x20ad||
    pc_audio_config_scope()||pc_groove_active()||I(pc_state_base(),0x860)||I(pc_state_base(),0x5000))return;
 uintptr_t erase=screen+0x760; /* Native B3, used as the top-row layout anchor. */
 if(Q(erase,0)!=host.base+0x706e940)return;
 int right=I(erase,0x20),x=right/2,width=right-x,height=I(erase,0x2c),y=I(erase,0x24);
 if(x<0||y<0||width<60||width>180||height<12||height>64)return;
 uintptr_t caption=(uintptr_t)piano_roll_caption;
 pc_stock_caption_init(caption,"Piano Roll");
 if(Q(caption,0)!=host.base+0x706e940)return;
 pc_stock_caption_bounds(caption,x,y,width,height);
 if(Q(caption,0x18)!=screen)
  FN(0x1178f00,void(*)(uintptr_t,uintptr_t,int))(screen,caption,-1);
 /* This is a late paint pass. Replace the legacy ink and paint the same
  * native caption used by Mastering into the cleared cell immediately. */
 FN(0x102d5e0,void(*)(uintptr_t,unsigned))(graphics,MPC_THEME_BG);
 FN(0x102e000,void(*)(uintptr_t,int,int,int,int))(graphics,x,y,width,height);
 FN(0x102d360,void(*)(uintptr_t))(graphics); /* Graphics::saveState */
 FN(0x102d470,void(*)(uintptr_t,int,int))(graphics,x,y);
 FN(0x10f99b0,void(*)(uintptr_t,uintptr_t))(caption,graphics);
 FN(0x102d3b0,void(*)(uintptr_t))(graphics); /* Graphics::restoreState */
}
static int editor_scope(void){return mode()==0x20a7&&!chord_levels()&&pc_find(current_instrument())>=0;}
static void repaint(void){
 uintptr_t b=behaviour(),screen=b?Q(b,0x58):0;
 if(screen)FN(0x1149d70,void (*)(uintptr_t))(screen);
}
static int fx_scope(void);
static unsigned fx_entry_pending=1;
static uintptr_t fx_display,fx_display_owner;
static void fx_repaint(void){
 uintptr_t b=behaviour();
 if(fx_display&&b&&b==fx_display_owner)FN(0x1149d70,void(*)(uintptr_t))(fx_display);
 repaint();
}
static void fx_native_close(void);
static unsigned fx_overlay;
static int fx_overlay_mode;
static uintptr_t fx_overlay_root;
static unsigned fx_overlay_epoch;
static uintptr_t fx_visible_root;
static unsigned fx_visible_epoch;
static int fx_visible_mode;
static int fx_active(void){
 if(pc_dj_open()||pc_dj_import())return 0;
 if(!__atomic_load_n(&fx_overlay,AQ))return 0;
 uintptr_t b=behaviour(),root=b?Q(b,0x58):0;
 /* Native FX and Input Config overlays can replace the behaviour root after
  * the shortcut. Only explicit navigation, project change or behaviour death
  * dismisses the custom overlay; a child/root swap must not disable controls. */
 if(!b||fx_overlay_epoch!=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)){__atomic_store_n(&fx_overlay,0,RL);return 0;}
 return 1;
}
static unsigned fx_global_page;
static int fx_global(void){return fx_active()&&fx_global_page;}
static uintptr_t fx_native_selection;
static unsigned fx_shift_value,fx_shift_seen;
static unsigned fx_shift(void){
 if(fx_active()&&__atomic_load_n(&fx_shift_seen,AQ))return __atomic_load_n(&fx_shift_value,AQ);
 uintptr_t b=behaviour(),surface=b?Q(b,0x78):0;return surface?(*(uint8_t*)(surface+0x22a0)&1):0;
}
static void fx_sync_entry(void);
static int takeover(unsigned,unsigned,unsigned);
typedef struct{uintptr_t behaviour,controller,list,program,screen,recorder,last_controller,last_list,last_program,router;int32_t source,last_source,reference,key;uint32_t active,erase,last_valid,held_mask,reentrant,error,b2_owned,b3_owned;uint8_t held[16][64];uint32_t chord_mode;}PcRollPrefix;
_Static_assert(offsetof(PcRollPrefix,active)==0x60,"roll active ABI");
_Static_assert(offsetof(PcRollPrefix,chord_mode)==0x480,"roll chord-mode ABI");
static int roll_context(int allow_chords){
 if(mode()!=0x20ad||pc_audio_config_scope()||pc_bounce_modal())return 0;
 PcRollPrefix*r=(PcRollPrefix*)(pc_state_base()+0x800);uintptr_t b=behaviour(),ctrl=b?Q(b,0x150):0,ctx=ctrl?Q(ctrl,0x248):0;
 return b&&ctrl&&ctx&&Q(ctx,0)==host.base+0x6ecc648&&r->active==1&&r->behaviour==b&&r->controller==ctrl&&((allow_chords&&r->chord_mode)||(!r->chord_mode&&r->list==Q(ctrl,0xc0)&&r->program&&r->program==Q(ctx,0xb8)&&Q(r->program,0)==host.base+0x6ec6860&&r->source>=0&&r->source<128&&r->key>=0&&r->key<128&&I(r->program,0x12a8+4*(unsigned)r->source)==r->key));
}
static int midi_roll_context(void){return roll_context(0);}
static int flex_locked(void){return mode()==0x30f0&&pc_flex_clock_external();}
static int groove_scope(void){
 return mode()==0x20ad&&!pc_audio_config_scope()&&!pc_audio_page()&&!pc_bounce_modal()&&!fx_scope()&&
        !pc_user_active()&&!pc_syx_active()&&!I(pc_state_base(),0x860)&&!I(pc_state_base(),0x5000);
}
static void enqueue(unsigned kind,unsigned down,uint32_t data){uint64_t event=(uint64_t)data<<32|(kind<<1)|(down&1);FN(0x6d43500,void (*)(uint64_t))(event);}
int pc_synth_fader_input(uintptr_t responder,float value){
 if(!(value>=0.f&&value<=1.f))return 0;
 uintptr_t i=current_instrument(),properties=responder?Q(responder,0xf8):0;
 int k=pc_find(i);if(k<0||!properties||!(*(uint8_t*)(properties+0x1b)&1))return 0;
 if(!pc_synth_fader_default(i)&&I(properties,0x3c)!=0)return 0;
 enqueue(66,1,(unsigned)k<<16|(unsigned)(value*16383.f+.5f));return 1;
}
void pc_synth_fader_mapping_changed(void){pc_synth_fader_custom(current_instrument());}

/* These four raw callbacks touch atomics and the existing UI queue only.
 * They are safe before the property/signal dispatcher releases its mutex. */
#include "preset_delete.h"

static uintptr_t factory_browser;
static unsigned preset_erase_held;
static unsigned dj_transport_owned,dj_sample_owned;
static struct {uintptr_t instrument;unsigned epoch,engine,index,choice;} factory_delete;
static int preset_erase_scope(void){
 unsigned user=pc_user_active();
 return pc_ms_preset_browser()||user==2||user==6||
        (!user&&!pc_syx_active()&&editor_scope()&&
         __atomic_load_n(&factory_browser,AQ)==current_instrument());
}
int pc_ui_physical(uintptr_t control,unsigned down){
 if(control==(uintptr_t)-3){if((down&1)&&!pc_groove_active())enqueue(41,1,0);return 1;}
 if(control==(uintptr_t)-2){if(pc_dj_import())return 1;if(pc_dj_open()){if(down&1)enqueue(59,1,7);return 1;}if(down&1)pc_diag_add(45);if(!(down&1)||pc_bounce_modal()||pc_groove_active())return 1;enqueue(26,1,fx_shift()?1:0);return 1;}
 if(control==(uintptr_t)-1){
  if((down&1)&&midi_roll_context()){enqueue(32,1,0);return 1;}
  if((down&1)&&mode()==0x20a9&&__atomic_load_n(&host.ui.catalog,AQ))enqueue(25,1,0);
  return 0;
 }
 if(!fx_scope())__atomic_store_n(&fx_entry_pending,1,RL);
 if(!fx_active())__atomic_store_n(&fx_shift_seen,0,RL);
 uintptr_t b=behaviour(),surface=b?Q(b,0x78):0;if(!surface)return 0;
 /* Shift is a momentary native modifier. Modal screens must never own its
  * press or release property, including while a browser is closing. */
 if(control==surface+0x2250||control==surface+0x22a0){
  unsigned was=__atomic_exchange_n(&preview_shift,down&1,__ATOMIC_ACQ_REL);
  if(pc_dj_open())enqueue(65,1,down&1);
  if(fx_scope()||pc_audio_page()==2||pc_audio_config_scope()){
   __atomic_store_n(&fx_shift_value,down&1,RL);__atomic_store_n(&fx_shift_seen,1,RL);enqueue(24,1,down&1);
  }else if((down&1)&&!was&&!pc_dj_import()&&!pc_groove_active()&&!pc_bounce_modal()&&(mode()==0x20a9||editor_scope()))enqueue(40,1,0);
  return 0;
 }
 /* Sample asks before leaving DJ; its release is owned even after YES. */
 if(control==surface+0x1f90){
  unsigned pressed=down&1;
  if(!pressed&&__atomic_exchange_n(&dj_sample_owned,0,RL)){
   *(uint8_t*)(control+0x50)=0;return 1;
  }
  if(pressed&&pc_dj_open()){
   *(uint8_t*)(control+0x50)=1;
   if(!__atomic_exchange_n(&dj_sample_owned,1,RL))enqueue(59,1,5);
   return 1;
  }
 }
 /* DJ-only transport aliases. Consume both edges, including a release
  * received after changing menus, before native erase/repeat/transport runs. */
 unsigned dj_key=control==surface+0x23b0?0:control==surface+0x2460?1:
                 control==surface+0x2bf0?2:control==surface+0x2ca0?3:4;
 if(dj_key<4){
  unsigned pressed=down&1,bit=1u<<dj_key;
  if(!pressed&&(__atomic_fetch_and(&dj_transport_owned,~bit,RL)&bit)){
   *(uint8_t*)(control+0x50)=0;return 1;
  }
  if(pressed&&(pc_dj_open()||pc_dj_import())){
   *(uint8_t*)(control+0x50)=1;
   if(!(__atomic_fetch_or(&dj_transport_owned,bit,RL)&bit)&&pc_dj_open())
    enqueue(64,1,dj_key);
   return 1;
  }
 }
 /* AC50EraseButtonResponder registers surface + 0x23b0 at 0x14ae560. */
 if(control==surface+0x23b0){
  unsigned pressed=down&1;
  if((!pressed&&__atomic_exchange_n(&preset_erase_held,0,RL))||
     (pressed&&preset_erase_scope())){
   if(pressed)__atomic_store_n(&preset_erase_held,1,RL);
   *(uint8_t*)(control+0x50)=pressed;return 1;
  }
 }
 if(pc_ms_active()&&control>=surface+0x1b00&&control<surface+0x2e00){
  unsigned button=control==surface+0x1bc8?0:control==surface+0x1c20?1:control==surface+0x1c78?2:control==surface+0x2d50?3:4;
  unsigned previous=*(uint8_t*)(control+0x50)&1;*(uint8_t*)(control+0x50)=down&1;
  if(!(down&1)&&button<4)__atomic_fetch_and(&host.ui.owned,~(1u<<button),RL);
  if((down&1)&&!previous){
   if(button<4)enqueue(12,1,button==3&&__atomic_load_n(&preset_erase_held,AQ)&&pc_ms_preset_browser()?PC_PRESET_ERASE:button);
   else if(control==surface+0x2930||control==surface+0x29e0)
    enqueue(35,1,control==surface+0x2930?(unsigned)-1:1);
  }
  return 1;
 }
 if(control==surface+0x1bc8||control==surface+0x1c20||control==surface+0x1c78||
    control==surface+0x2d50||control==surface+0x27d0){
  unsigned button=control==surface+0x1bc8?0:control==surface+0x1c20?1:
                  control==surface+0x1c78?2:control==surface+0x2d50?3:4;
  unsigned bit=1u<<button;
  if(!(down&1)&&(__atomic_fetch_and(&dj_owned,~bit,RL)&bit)){
   *(uint8_t*)(control+0x50)=0;return 1;
  }
  if((down&1)&&!pc_drumkit_active()&&!pc_bounce_modal()&&
     (pc_dj_import()||pc_dj_open()||(button==1&&pc_dj_fader()))){
   *(uint8_t*)(control+0x50)=1;
   if(!(__atomic_fetch_or(&dj_owned,bit,RL)&bit))
    enqueue(59,1,button);
   return 1;
  }
 }
 if(control==surface+0x1bc8||control==surface+0x1c20){
  unsigned button=control==surface+0x1c20,bit=1u<<button;
  if(!(down&1)&&(__atomic_fetch_and(&limiter_owned,~bit,RL)&bit)){
   *(uint8_t*)(control+0x50)=0;return 1;
  }
  if((down&1)&&!pc_drumkit_active()&&pc_limiter_compressor()){
   *(uint8_t*)(control+0x50)=1;
   if(!(__atomic_fetch_or(&limiter_owned,bit,RL)&bit)&&(button||pc_limiter_scope()))enqueue(55,1,button);
   return 1;
  }
 }
 if(pc_drumkit_active()&&control>=surface+0x1b00&&control<surface+0x2e00){
  unsigned button=control==surface+0x1bc8?0:control==surface+0x1c20?1:control==surface+0x1c78?2:control==surface+0x2d50?3:4;
  /* Unowned physical keys, including Power, keep native dispatch. */
  if(button==4)return 0;
  unsigned previous=*(uint8_t*)(control+0x50)&1;*(uint8_t*)(control+0x50)=down&1;
  if(button<4&&(down&1)&&!previous){
   if(button==1)pc_drumkit_lock_edit();
   else enqueue(12,1,button);
  }
  return 1;
 }
 if((down&1)&&control>=surface+0x1b00&&control<surface+0x2e00)pc_diag_value(44,(unsigned)(control-surface));
 if(control==surface+0x1c78&&flex_locked()){
  *(uint8_t*)(control+0x50)=(uint8_t)(down&1);return 1;
 }
 if(control==surface+0x27d0){
  unsigned pressed=down&1;
  if(pressed&&!pc_groove_active()&&FN(PC_CH_SCOPE,int(*)(void))()){
   *(uint8_t*)(control+0x50)=1;
   if(!__atomic_exchange_n(&groove_owned,1,__ATOMIC_ACQ_REL))enqueue(54,1,0);
   return 1;
  }
  if(!pressed&&__atomic_exchange_n(&groove_owned,0,__ATOMIC_ACQ_REL)){
   *(uint8_t*)(control+0x50)=0;return 1;
  }
  if(pressed&&(pc_groove_active()||groove_scope())){
   *(uint8_t*)(control+0x50)=1;
   if(!__atomic_exchange_n(&groove_owned,1,__ATOMIC_ACQ_REL)&&
      !__atomic_exchange_n(&groove_queued,1,__ATOMIC_ACQ_REL)){
    uintptr_t project=Q(pc_state_base(),0x1d08);
    unsigned epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
    unsigned index=project&&Q(project,0)==host.base+0x6ecc648?(unsigned)I(project,0x500):255;
    __atomic_store_n(&groove_sequence,index<128?Q(project,0x1c8):0,RL);
    enqueue((*(uint8_t*)(surface+0x22a0)&1)?52:50,1,(epoch<<8)|(index<128?index:255));
   }
   return 1;
  }
 }
 if(pc_groove_active()&&control>=surface+0x1b00&&control<surface+0x2e00&&
    control!=surface+0x1bc8&&control!=surface+0x1c20&&control!=surface+0x1c78&&control!=surface+0x2d50&&
    control!=surface+0x2930&&control!=surface+0x29e0&&control!=surface+0x2250&&control!=surface+0x22a0&&control!=surface+0x2bf0){
  *(uint8_t*)(control+0x50)=(uint8_t)(down&1);return 1;
 }
 /* Native registration at 0x14caed4 binds Knob FX to surface + 0x21a0.
  * Consume the physical property BEFORE its native subscribers run. The old
  * -2 hook covers only the shifted mode-change branch, not normal presses. */
 if(control==surface+0x21a0){
  unsigned pressed=down&1,was=__atomic_exchange_n(&fx_button_owned,pressed,__ATOMIC_ACQ_REL);
  *(uint8_t*)(control+0x50)=(uint8_t)pressed;
  if(pressed&&!was){
   pc_diag_add(35);
   if(pc_dj_open())enqueue(59,1,7);
   else if(!pc_dj_import()&&!pc_bounce_modal())enqueue(26,1,fx_shift()?1:0);
  }
  if(!pressed&&was)pc_diag_add(36);
  return 1;
 }
 if((down&1)&&pc_padfx_visible()&&control>=surface+0x1b00&&control<surface+0x2e00)pc_diag_value(18,(unsigned)(control-surface));
 if(control==surface+0x2a90){
  if(!(down&1)&&__atomic_exchange_n(&bounce_owned,0,__ATOMIC_ACQ_REL)){*(uint8_t*)(control+0x50)=down;return 1;}
  if((down&1)&&(*(uint8_t*)(surface+0x22a0)&1)){__atomic_store_n(&bounce_owned,1,RL);*(uint8_t*)(control+0x50)=down;enqueue(30,1,0);return 1;}
 }
 /* This callback also receives model bool properties. Only a physical
  * surface button may dismiss FX; parameter publication must never close it. */
 if((down&1)&&control>=surface+0x1b00&&control<surface+0x2e00&&fx_active()&&control!=surface+0x1bc8&&control!=surface+0x1c20&&control!=surface+0x1c78&&control!=surface+0x2d50&&control!=surface+0x22a0&&control!=surface+0x2250){
  pc_diag_value(42,(unsigned)(control-surface));pc_diag_value(43,0);__atomic_store_n(&fx_overlay,0,RL);enqueue(26,1,2);return 0;
 }
 
 /* sample-select is registered at +0x27d0 in native 0x14af160;
  * +/- are +0x2930/+0x29e0 (native 0x14af0a0/0x14af0c0). */
 if(control==surface+0x27d0){
  if(!(down&1)&&__atomic_exchange_n(&user_select_owned,0,__ATOMIC_ACQ_REL)){*(uint8_t*)(control+0x50)=down;return 1;}
  if((down&1)&&(*(uint8_t*)(surface+0x22a0)&1)&&pc_find(current_instrument())>=0&&!pc_bounce_modal()&&!pc_audio_page()){
   if(!__atomic_exchange_n(&user_select_owned,1,__ATOMIC_ACQ_REL))enqueue(33,1,0);
   *(uint8_t*)(control+0x50)=down;return 1;
  }
 }
 if(control==surface+0x2930||control==surface+0x29e0){
  unsigned bit=control==surface+0x2930?1:2;
  if(!(down&1)&&(__atomic_fetch_and(&user_nav_owned,~bit,RX)&bit)){*(uint8_t*)(control+0x50)=down;return 1;}
  if((down&1)&&!fx_scope()&&!pc_audio_page()&&!I(pc_state_base(),0x5000)&&midi_roll_context()&&pc_roll_has_selection()){
   if(!(__atomic_fetch_or(&user_nav_owned,bit,RX)&bit))enqueue(51,1,bit==1?(unsigned)-12:12);
   *(uint8_t*)(control+0x50)=down;return 1;
  }
  if((down&1)&&mode()==0x20ad&&!pc_groove_active()&&!pc_audio_config_scope()&&!pc_audio_page()&&!pc_bounce_modal()&&!fx_scope()&&!I(pc_state_base(),0x860)&&!I(pc_state_base(),0x5000)){
   if(!(__atomic_fetch_or(&user_nav_owned,bit,RX)&bit))enqueue(38,1,bit==1?(unsigned)-1:1);
   *(uint8_t*)(control+0x50)=down;return 1;
  }
  if((down&1)&&(pc_groove_active()||pc_user_active()||pc_syx_active())){if(!(__atomic_fetch_or(&user_nav_owned,bit,RX)&bit))enqueue(35,1,bit==1?(unsigned)-1:1);*(uint8_t*)(control+0x50)=down;return 1;}
 }

 if(pc_bounce_modal()&&control>=surface+0x1b00&&control<surface+0x2e00&&control!=surface+0x1bc8&&control!=surface+0x1c78&&control!=surface+0x2d50){*(uint8_t*)(control+0x50)=down;return 1;}
 if(control==surface+0x23b0){
  unsigned owned=__atomic_load_n(&host.ui.owned,RX),bit=1u<<4;
  if(down&1){if(!(owned&bit)&&!FN(PC_CH_SCOPE,int(*)(void))())return 0;__atomic_fetch_or(&host.ui.owned,bit,RX);}
  else{if(!(owned&bit))return 0;__atomic_fetch_and(&host.ui.owned,~bit,RX);}
  *(uint8_t *)(control+0x50)=(uint8_t)down;return 1;
 }
 unsigned button;
 if(control==surface+0x1bc8)button=0;
 else if(control==surface+0x1c20)button=1;
 else if(control==surface+0x1c78)button=2;
 else if(control==surface+0x2d50)button=3;
 else return 0;
 unsigned bit=1u<<button,owned=__atomic_load_n(&host.ui.owned,RX);
 if(!(down&1)){
  if(!(owned&bit))return 0;__atomic_fetch_and(&host.ui.owned,~bit,RX);
 }else{
  if(!pc_user_active()&&!fx_scope()&&pc_audio_config_scope()&&!pc_audio_page()&&button!=1&&button!=2)return 0;
  if(owned&bit)return 1;
  int id=mode();unsigned scope=__atomic_load_n(&host.ui.scope,AQ)&&((id==0x20a7&&!chord_levels())||(id==0x20a9&&__atomic_load_n(&host.ui.catalog,AQ)));
  if(!(pc_groove_active()||(button==2&&groove_scope())||pc_user_active()||pc_syx_active()||scope||fx_scope()||pc_audio_page()||pc_bounce_modal()||((button==1||button==2)&&pc_audio_config_scope())||button==2&&id==0x20a9))return 0;
  __atomic_fetch_or(&host.ui.owned,bit,RX);
 }
 *(uint8_t *)(control+0x50)=(uint8_t)down;enqueue(button==2&&groove_scope()&&!pc_groove_active()?53:12,down,
  button==3&&__atomic_load_n(&preset_erase_held,AQ)&&preset_erase_scope()?PC_PRESET_ERASE:button);return 1;
}
int pc_ui_knob(uintptr_t control,uint32_t bits){
 uintptr_t b=behaviour(),surface=b?Q(b,0x78):0;if(!surface)return 0;
 if(!fx_active()&&(pc_groove_active()||pc_user_active()||pc_syx_active()))return 1;
 unsigned k;for(k=0;k<3;k++)if(Q(surface,0x3110+8*k)==control)break;if(k==3)return 0;
 float value;memcpy(&value,&bits,4);if(!(value>=0&&value<=1))return 0;
 if(pc_ms_active()){*(uint32_t*)(control+0x50)=bits;enqueue(13,1,k<<16|(unsigned)(value*16383.f+.5f));return 1;}
 if(pc_dj_open()||pc_dj_import()){
  *(uint32_t*)(control+0x50)=bits;
  if(pc_dj_open()||k==2)enqueue(61,1,k<<16|(fx_shift()?1u<<18:0)|(unsigned)(value*16383.f+.5f));
  return 1;
 }
 if(pc_limiter_scope()){*(uint32_t*)(control+0x50)=bits;enqueue(57,1,k<<16|(unsigned)(value*16383.f+.5f));return 1;}
 if(pc_drumkit_active()){*(uint32_t*)(control+0x50)=bits;enqueue(13,1,k<<16|(unsigned)(value*16383+.5f));return 1;}
 if(pc_bounce_modal()||pc_groove_active()||flex_locked()){*(uint32_t *)(control+0x50)=bits;return 1;}
 if(fx_scope()){*(uint32_t *)(control+0x50)=bits;enqueue(21,1,k<<16|(fx_shift()?1u<<18:0)|(unsigned)(value*16383+.5f));return 1;}
 if(pc_audio_page()){*(uint32_t *)(control+0x50)=bits;enqueue(21,1,k<<16|(fx_shift()?1u<<18:0)|(unsigned)(value*16383+.5f));return 1;}
 if(roll_context(1)){*(uint32_t*)(control+0x50)=bits;enqueue(48,1,k<<16|(unsigned)(value*16383.f+.5f));return 1;}
 if(pc_import_knob_scope()&&(k==0||k==2)){*(uint32_t *)(control+0x50)=bits;enqueue(43,1,k<<16|(unsigned)(value*16383.f+.5f));return 1;}
 if(pc_audio_config_scope())return 0;
 if(fx_scope()){enqueue(37,1,0);*(uint32_t *)(control+0x50)=bits;enqueue(21,1,k<<16|(fx_shift()?1u<<18:0)|(unsigned)(value*16383+.5f));return 1;}
 if(k==1&&sample_mix()){
  *(uint32_t *)(control+0x50)=bits;enqueue(17,1,(unsigned)(value*16383+.5f));return 1;
 }
 if(k<2&&FN(PC_CH_SCOPE,int(*)(void))()){
  *(uint32_t *)(control+0x50)=bits;enqueue(6+k,1,bits);return 1;
 }
 int id=mode();if(!__atomic_load_n(&host.ui.scope,AQ)||!((id==0x20a7&&!chord_levels())||(id==0x20a9&&__atomic_load_n(&host.ui.catalog,AQ))))return 0;
 *(uint32_t *)(control+0x50)=bits;enqueue(13,1,(k<<16)|(unsigned)(value*16383+.5f));return 1;
}
static int import_delta(int delta,int shift){
 if(!shift)return delta;
 if(delta>214748364)return 2147483647;
 if(delta< -214748364)return (-2147483647-1);
 return delta*10;
}
int pc_ui_rotation(uintptr_t signal,int delta){
 uintptr_t b=behaviour(),surface=b?Q(b,0x78):0;
 if(!surface||signal!=surface+0x2da8||!delta)return 0;
 int shift=(*(uint8_t*)(surface+0x22a0)&1)!=0;
 if(pc_ms_active()){enqueue(14,1,(uint32_t)delta);return 1;}
 if(pc_dj_open()){enqueue(60,1,(uint32_t)delta);return 1;}
 if(pc_dj_import())return 0;
 if(pc_limiter_scope()){enqueue(56,1,(uint32_t)delta);return 1;}
 if(pc_drumkit_active())return 1;
 if(pc_groove_active()){enqueue(14,1,(uint32_t)import_delta(delta,shift));return 1;}
 unsigned user=pc_user_active(),sysex=pc_syx_active(),audio=pc_audio_page();
 if(user||sysex){enqueue(14,1,(uint32_t)import_delta(delta,shift&&(user==2||sysex)));return 1;}
 if(pc_bounce_modal()){enqueue(14,1,(uint32_t)delta);return 1;}
 if(audio){enqueue(14,1,(uint32_t)import_delta(delta,shift&&audio==3));return 1;}
 if(!fx_active()&&pc_audio_config_scope())return 0;
 int id=mode();
 if(shift&&(id==0x20a7||id==0x20ad)&&I(pc_state_base(),0x5000)){
  enqueue(10,1,(uint32_t)import_delta(delta,1));return 1;
 }
 if(!fx_scope()&&FN(PC_CH_SCOPE,int(*)(void))()){enqueue(10,1,(uint32_t)delta);return 1;}
 if(fx_scope()||(__atomic_load_n(&host.ui.scope,AQ)&&
    ((id==0x20a7&&!chord_levels())||(id==0x20a9&&__atomic_load_n(&host.ui.catalog,AQ))))){
  enqueue(14,1,(uint32_t)delta);return 1;
 }
 if(shift&&(pc_import_knob_scope()||pc_native_import_scope(id))&&
    (uint32_t)I(host.base,0x6d3dc00)==0xf0002b29u){
  /* Stock file navigation is a detent callback. Use the original trampoline,
   * bypassing this hook, with ten signed detents. */
  unsigned steps=delta< -32||delta>32?32:(unsigned)(delta<0?-delta:delta);
  for(unsigned n=0;n<10*steps;n++)FN(0x6d3dc00,void(*)(uintptr_t,int))(signal,delta<0?-1:1);
  return 1;
 }
 return 0;
}
int pc_ui_capture(int source,int kind){
 if(source<0||source>127)return 0;
 if(pc_ms_active())return 1;
 static unsigned click_owned;
 unsigned half=(unsigned)source/64;uint64_t bit=1ull<<((unsigned)source%64);
 if(kind==2&&(__atomic_fetch_and(&dj_pad_owned[half],~bit,RL)&bit)){
  enqueue(62,1,16|((unsigned)source&15));return 1;
 }
 if(kind==1&&(__atomic_load_n(&dj_pad_owned[half],AQ)&bit))return 1;
 if(kind==0&&(pc_dj_open()||pc_dj_import())&&!fx_shift()){
  __atomic_fetch_or(&dj_pad_owned[half],bit,RL);
  if(pc_dj_open())enqueue(62,1,(unsigned)source&15);
  return 1;
 }
 if(pc_drumkit_active()){
  if(kind==2)__atomic_fetch_and(&host.ui.pads[half],~bit,RX);
  return 0; /* Audition and native pad selection remain available. */
 }
 if(pc_groove_active()&&kind==0){__atomic_fetch_or(&host.ui.pads[half],bit,RX);return 1;}
 if((source&15)==1){
  if(kind==2&&__atomic_exchange_n(&click_owned,0,__ATOMIC_ACQ_REL))return 1;
  if(kind==1&&__atomic_load_n(&click_owned,AQ))return 1;
  if(kind==0){uintptr_t b=behaviour(),surface=b?Q(b,0x78):0;
   if(surface&&(*(uint8_t*)(surface+0x22a0)&1)&&!pc_bounce_modal()){
    if(mode()==0x20a7){
     uintptr_t instrument=mapped_instrument(current_program(),(unsigned)source);
     if(instrument&&pc_find(instrument)<0)return 0;
    }
    __atomic_store_n(&click_owned,1,RL);enqueue(41,1,0);return 1;
   }
  }
 }
 if(pc_bounce_modal())return 1;
 if(kind==2){return !!(__atomic_fetch_and(&host.ui.pads[half],~bit,RX)&bit);}
 if(kind==1)return !!(__atomic_load_n(&host.ui.pads[half],RX)&bit);
 int id=mode();/* Track pad selections on native screens as well as Sample. */
 if(__atomic_load_n(&host.ui.catalog,AQ)){
  __atomic_fetch_or(&host.ui.pads[half],bit,RX);enqueue(11,1,(unsigned)source);return 1;
 }
 if(fx_scope()||id!=0x20a7||!tune())enqueue(11,1,(unsigned)source);return 0;
}
static int output_page(const MpcPanelView *v){
 return !v->browser&&v->page_index+1==v->page_count&&v->slots[0].index<0&&v->slots[1].index<0&&v->slots[2].index<0;
}
static int sidechain_knob(const MpcPanelView *v){return output_page(v)?1:-1;}
static struct {unsigned slot,browser,candidate,paint_mode,armed[3],known[3],last[3];uintptr_t pad,program;unsigned source,source_valid;int page;} fx_ui;
static void fx_disarm(void){for(unsigned n=0;n<3;n++)fx_ui.armed[n]=fx_ui.known[n]=0;}
/* Reset the overlay target on entry, including reopening on the same
 * program after selecting a different pad. Physical dispatch only requests
 * synchronization; model reads stay on the UI thread. */
static void fx_sync_entry(void){
 uintptr_t p=current_program();unsigned entry=__atomic_exchange_n(&fx_entry_pending,0,__ATOMIC_ACQ_REL);
 uintptr_t wrapper=Q(pc_state_base(),0x1d08),selected=wrapper?Q(wrapper,0x668):0;
 if(!entry&&fx_ui.source_valid&&fx_ui.program==p&&fx_native_selection==selected)return;
 fx_native_selection=selected;
 fx_ui.program=p;fx_ui.source_valid=0;fx_ui.pad=0;fx_disarm();
 if(pc_valid(p,selected))for(unsigned n=0;n<128;n++)if(mapped_instrument(p,n)==selected){fx_ui.source=n;fx_ui.source_valid=1;host.ui.source=n;break;}
}
static uintptr_t fx_target(void){fx_sync_entry();return fx_ui.source_valid?mapped_instrument(fx_ui.program,fx_ui.source):0;}
static int fx_scope(void){
 if(pc_dj_open()||pc_dj_import())return 0;
 if(fx_active())return 1;
 uintptr_t visible_owner=behaviour();
 uintptr_t visible=__atomic_load_n(&fx_visible_root,AQ);
 if(visible&&visible_owner&&visible==Q(visible_owner,0x58)&&__atomic_load_n(&fx_visible_mode,AQ)==mode()&&__atomic_load_n(&fx_visible_epoch,AQ)==__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ))return 1;
 if(pc_audio_config_scope()||pc_audio_page())return 0;
 uintptr_t b=behaviour(),screen=b?Q(b,0x58):0,vt=screen?Q(screen,0):0;
 return vt==host.base+0x6e1e258||vt==host.base+0x6e1d890;
}
/* r45: the native KnobFxOverlayScreen is a separate Component with children.
 * Its paint hook runs AFTER those children. Drawing a smaller replacement there
 * cannot remove the already painted stock UI. Suppress the actual instance,
 * not the surrounding display or the unrelated FxSelectScreen. UI thread only. */
static unsigned fx_stock_pending;
static uintptr_t fx_stock_found;
static void fx_suppress_stock(uintptr_t c){
 if(!c||Q(c,0)!=host.base+0x6e1e258)return;
 unsigned visible=(*(unsigned char*)(c+0xa8)&2)!=0;
 int changed=visible||I(c,0x28)||I(c,0x2c);
 if(visible&&!pc_dj_open()&&!pc_dj_import()&&!fx_active()&&!__atomic_exchange_n(&fx_stock_pending,1,__ATOMIC_ACQ_REL))enqueue(37,1,0);
 if(visible)FN(0x1172670,void(*)(uintptr_t,unsigned))(c,0);
 /* Keep it empty if native parameter/Shift notifications publish visible=true
  * again. The native resize method lays out children using fixed dimensions;
  * a zero parent bounds clips that subtree without modifying the model. */
 if(I(c,0x28)||I(c,0x2c))FN(0x1160fc0,void(*)(uintptr_t,uint64_t,uint64_t))(c,*(uint64_t*)(c+0x20),0);
 if(changed)fx_repaint();
}
static int fx_find_visible(uintptr_t c,unsigned depth,unsigned*budget){
 if(!c||!depth||!*budget||!(*(uint8_t*)(c+0xa8)&2))return 0;--*budget;
 uintptr_t vt=Q(c,0);if(vt==host.base+0x6e1e258){fx_stock_found=c;return 0;}if(vt==host.base+0x6e1d890)return 1;
 uintptr_t list=Q(c,0x40);int n=I(c,0x4c);if(n<0||n>256||(!list&&n))return 0;
 for(int j=n;j>0;j--)if(fx_find_visible(Q(list,8*(j-1)),depth-1,budget))return 1;return 0;
}
static uintptr_t dj_find_playhead(uintptr_t c,unsigned depth,unsigned *budget){
 if(!c||!depth||!*budget)return 0;--*budget;
 if(Q(c,0)==host.base+0x6e17688)return c;
 uintptr_t list=Q(c,0x40);int n=I(c,0x4c);
 if(n<0||n>256||(!list&&n))return 0;
 for(int i=0;i<n;i++){
  uintptr_t found=dj_find_playhead(Q(list,8*i),depth-1,budget);
  if(found)return found;
 }
 return 0;
}
static void dj_playhead_frame(uintptr_t display){
 static unsigned hidden,was_visible;
 unsigned budget=384;uintptr_t c=dj_find_playhead(display,12,&budget);
 if(!c)return;
 if(pc_dj_open()||pc_dj_import()){
  if(!hidden){was_visible=!!(*(uint8_t*)(c+0xa8)&2);hidden=1;}
  if(*(uint8_t*)(c+0xa8)&2)FN(0x1172670,void(*)(uintptr_t,unsigned))(c,0);
 }else if(hidden){
  hidden=0;FN(0x1172670,void(*)(uintptr_t,unsigned))(c,was_visible);
 }
}
static void fx_visible_frame(uintptr_t display){
 unsigned budget=768;uintptr_t b=behaviour();
 __atomic_store_n(&fx_visible_root,0,RL);
 fx_stock_found=0;
 unsigned visible=b&&fx_find_visible(display,16,&budget);
 /* Finish walking before visibility callbacks can alter child arrays. */
 if(fx_stock_found)fx_suppress_stock(fx_stock_found);
 __atomic_store_n(&fx_visible_mode,mode(),RL);__atomic_store_n(&fx_visible_epoch,__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ),RL);
 __atomic_store_n(&fx_visible_root,visible?Q(b,0x58):0,RL);
}
static void fx_open(unsigned global){
 pc_diag_add(39);pc_diag_value(46,(unsigned)mode());
 /* A sends popup belongs over the current page, never over the old native FX child. */
 if(!global)fx_native_close();
 fx_global_page=global!=0;
 pc_user_close();pc_syx_close();
 fx_overlay_epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 uintptr_t owner=behaviour();fx_overlay_root=owner?Q(owner,0x58):0;
 pc_audio_close();
 fx_overlay_mode=mode();fx_ui.browser=0;fx_disarm();host.ui.message=0;
 __atomic_store_n(&fx_overlay,1,RL);pc_diag_value(43,1);
}

static void fx_native_close(void){uintptr_t e=Q(pc_state_base(),0x1e00);if(e)FN(0x13ae070,void(*)(uintptr_t,unsigned))(e+0x68,0);}
void pc_ui_dj_dismiss_fx(void){
 __atomic_store_n(&fx_overlay,0,RL);
 __atomic_store_n(&fx_visible_root,0,RL);
 __atomic_store_n(&fx_stock_pending,0,RL);
 fx_disarm();
 fx_native_close();
 fx_repaint();
}
static void fx_back(void){
 pc_diag_add(40);
 if(fx_ui.browser){fx_ui.browser=0;return;}
 pc_diag_value(43,0);unsigned had=__atomic_exchange_n(&fx_overlay,0,__ATOMIC_ACQ_REL);fx_disarm();fx_native_close();
 uintptr_t owner=behaviour(),root=owner?Q(owner,0x58):0,vt=root?Q(root,0):0;
 if(had&&vt!=host.base+0x6e1e258&&vt!=host.base+0x6e1d890)return;
 uintptr_t b=behaviour(),manager=b?Q(b,0x30):0;int id=I(pc_state_base(),0x1ef0);if(id<0x2000||id>0x4000||id==0x20a4)id=0x20a7;
 if(manager)FN(0x1c0e5c0,void(*)(uintptr_t,int))(manager,id);
}
static int takeover(unsigned knob,unsigned position,unsigned target){
 unsigned old=fx_ui.last[knob];int d=(int)position-(int)target;
 if(!fx_ui.armed[knob]&&((d>=-128&&d<=128)||(fx_ui.known[knob]&&((old<=target&&position>=target)||(old>=target&&position<=target)))))fx_ui.armed[knob]=1;
 fx_ui.last[knob]=position;fx_ui.known[knob]=1;return fx_ui.armed[knob];
}
static int fx_event(unsigned kind,unsigned data){
 if(!fx_scope()||(kind!=12&&kind!=14&&kind!=21&&kind!=24))return 0;
 fx_sync_entry();
 if(kind==12&&((!fx_global()&&data==2)||(fx_global()&&data==0))){fx_back();return 1;}
 if(kind==12&&!fx_global()&&data==1){fx_open(1);return 1;}
 if(!pc_mix_ensure()){host.ui.message="FX preparing: try again";return 1;}
 if(fx_global()){
  if(kind==24){fx_ui.page=(int)(data&1);fx_disarm();return 1;}
  if(kind==12){
   if(data==0)fx_back();
   else if(data==2&&!fx_ui.browser){fx_ui.slot=(fx_ui.slot+1)%3;fx_disarm();}
   else if(data==1||data==3){
    if(fx_ui.browser&&data==3){if(pc_fx_select(fx_ui.slot,pc_fx_catalog_type(fx_ui.candidate))){fx_ui.browser=0;fx_disarm();}else if(!host.ui.message)host.ui.message="FX load failed";}
    else{fx_ui.browser=1;fx_ui.candidate=pc_fx_catalog_index(pc_fx_type(fx_ui.slot));}
   }else if(data==2)fx_ui.browser=0;
  }else if(kind==14){
   int64_t next=(int64_t)(fx_ui.browser?fx_ui.candidate:fx_ui.slot)+(int32_t)data;
   int max=fx_ui.browser?(int)pc_fx_count():2;if(next<0)next=0;if(next>max)next=max;
   if(fx_ui.browser)fx_ui.candidate=(unsigned)next;else{fx_ui.slot=(unsigned)next;fx_disarm();}
  }else if(!fx_ui.browser){unsigned knob=(data>>16)&3,page=(data>>18)&1,position=data&65535;
   if(fx_ui.page!=(int)page){fx_ui.page=(int)page;fx_disarm();}
   unsigned parameter=knob+page*3;if(knob<3&&takeover(knob,position,pc_fx_position(fx_ui.slot,parameter)))pc_fx_knob(fx_ui.slot,parameter,position);}
 }else{
  uintptr_t p=current_program(),i=fx_target();if(fx_ui.pad!=i){fx_ui.pad=i;fx_disarm();}
  if(kind==14){int next=(int)fx_ui.source+(int32_t)data;if(next<0)next=0;if(next>127)next=127;fx_ui.source=(unsigned)next;fx_ui.source_valid=1;fx_ui.program=p;fx_ui.pad=0;fx_disarm();}
  else if(kind==12&&data==0){if(i)for(unsigned k=0;k<3;k++)pc_mix_set_send(p,i,k,0);fx_disarm();}
  else if(kind==12&&data==1)fx_open(1);
  else if(kind==12&&data==2)fx_back();
  else if(kind==21&&i){unsigned knob=(data>>16)&3,position=data&65535;if(knob<3){if(takeover(knob,position,pc_mix_send(i,knob))){pc_mix_set_send(p,i,knob,position);host.ui.message=0;}else host.ui.message="Turn knob through current value";}}
 }
 return 1;
}
static int mirror(int slot){
 if(slot<0)return 0;
 if(!__atomic_load_n(&host.ui.loaded_valid,AQ)||host.ui.loaded_slot!=(unsigned)slot){
  host.ui.save_confirm=0;Slot *s=&host.slots[slot];if(!pc_mirror_use(s->engine)||!pc_backend_panel_load(&host.mirror,s->engine,s->preset,s->patch))return 0;
  host.ui.loaded_slot=(unsigned)slot;__atomic_store_n(&host.ui.loaded_valid,1,RL);
 }
 pc_synth_filter_bind((unsigned)slot);
 return 1;
}
static int preset_step(unsigned engine,unsigned count,int index,int direction){
 for(index+=direction;index>=0&&(unsigned)index<count;index+=direction)
  if(!pc_preset_hidden(engine,(unsigned)index))return index;
 return -1;
}
static void factory_move(Slot *s,MpcPanelView *v,int delta){
 if(!delta)return;
 int next=(int)v->preset_index,direction=delta<0?-1:1;
 for(int64_t steps=delta<0?-(int64_t)delta:delta;steps;steps--){
  int candidate=preset_step(s->engine,v->preset_count,next,direction);
  if(candidate<0)break;
  next=candidate;
 }
 if(next!=(int)v->preset_index)host.mirror.encoder(next-(int)v->preset_index);
}
static void factory_normalize(Slot *s,MpcPanelView *v){
 if(!v->browser||!pc_preset_hidden(s->engine,v->preset_index))return;
 int next=preset_step(s->engine,v->preset_count,(int)v->preset_index,1);
 if(next<0)next=preset_step(s->engine,v->preset_count,(int)v->preset_index,-1);
 if(next>=0){host.mirror.encoder(next-(int)v->preset_index);host.mirror.view(v);}
}
static int factory_confirming(Slot *s,const MpcPanelView *v){
 if(!factory_delete.choice)return 0;
 if(!v->browser||factory_delete.instrument!=s->instrument||factory_delete.epoch!=host.project_epoch||
    factory_delete.engine!=s->engine||factory_delete.index!=v->preset_index){
  factory_delete.choice=0;return 0;
 }
 return 1;
}
static void publish_sequence_length(void){
 uintptr_t p=Q(pc_state_base(),0x1d08);if(!p||Q(p,0)!=host.base+0x6ecc648)return;
 uintptr_t t=Q(p,0x140),seq=Q(p,0x1c8);
 if(seq&&Q(seq,0)==host.base+0x6ecdff0&&
  (__atomic_load_n((uint64_t *)(pc_state_base()+0x1e10),AQ)||
   t&&Q(t,0)==host.base+0x6ecf118&&I(t,0x950)==1&&*(uint8_t *)(t+0x960))){
  int64_t length=*(int64_t *)(seq+0x348);if(length>0)__atomic_store_n((uint64_t *)(pc_state_base()+0x1e10),(uint64_t)length,RL);
 }
}
static void refresh_scope(void){
 publish_sequence_length();
 int id=mode();if(id!=host.ui.screen_mode)host.ui.screen=0;
 if(id!=0x20a7&&id!=0x20a9){__atomic_store_n(&host.ui.catalog,0,RL);host.ui.screen=0;}
 unsigned scope=host.ui.catalog||editor_scope();if(!scope){factory_delete.choice=0;__atomic_store_n(&factory_browser,0,RL);host.ui.save_confirm=0;pc_preview_stop();pc_ms_editor_reset();}__atomic_store_n(&host.ui.scope,scope,RL);
 __atomic_store_n(&host.debug->mode,(unsigned)id,RX);__atomic_store_n(&host.debug->source,host.ui.source,RX);
 __atomic_store_n(&host.debug->ui_scope,scope,RX);__atomic_store_n(&host.debug->catalog,host.ui.catalog,RX);
}
int pc_ui_event(uint64_t event){
 unsigned kind=(unsigned)(event>>1)&0x7fffffff,down=(unsigned)event&1,data=(unsigned)(event>>32);
 if(kind<11||kind>66)return 0;
 __atomic_fetch_add(&host.debug->controls,1,RX);
 if(!down)return 1;
 pc_project_new_sync_ui();
 if(kind==58||(pc_ms_active()&&(kind==12||kind==13||kind==14||kind==35))){
  if(pc_meta()){pc_ms_event(kind,data);pc_unmeta();}repaint();return 1;
 }
 if(kind==59){pc_dj_event(data);return 1;}
 if(kind==60){pc_dj_rotate((int32_t)data);return 1;}
 if(kind==66){
  unsigned k=data>>16;
  if(k<PC_SLOTS&&host.slots[k].instrument==current_instrument()){
   if(pc_meta()){pc_synth_filter_knob(host.slots[k].instrument,1,data&16383);pc_unmeta();repaint();}
   else enqueue(66,1,data);
  }return 1;
 }
 if(kind==65){pc_dj_fx_shift(data&1);return 1;}
 if(kind==61){pc_dj_fx_shift((data>>18)&1);pc_dj_knob((data>>16)&3,data&65535);return 1;}
 if(kind==62){pc_dj_pad(data&15,!(data&16));return 1;}
 if(kind==64){pc_dj_transport(data);return 1;}
 if(kind==63){
  if(pc_meta()){pc_ms_clear_queued(data);pc_unmeta();repaint();}
  else enqueue(63,1,data);
  return 1;
 }
 if(kind>=55){pc_limiter_event(kind,data);return 1;}
 if(pc_drumkit_active()&&(kind==11||kind==12||kind==13||kind==14||kind==35)){
  if(pc_meta()){
   pc_drumkit_event(kind,data);
   unsigned closed=!pc_drumkit_active();pc_unmeta();
   if(closed){uintptr_t b=behaviour(),manager=b?Q(b,0x30):0;if(manager)FN(0x1c0e5c0,void(*)(uintptr_t,int))(manager,0x20a7);}
  }repaint();return 1;
 }
 if(kind==54){if(pc_meta()){pc_chord_browser_open(behaviour());pc_unmeta();}repaint();return 1;}
 if(kind==50||kind==52){
  uintptr_t sequence=__atomic_load_n(&groove_sequence,AQ);
  __atomic_store_n(&groove_queued,0,RL);
  if(pc_groove_active())pc_groove_close();
  else if(groove_scope()&&pc_meta()){
   uintptr_t project=Q(pc_state_base(),0x1d08),program=current_program();
   unsigned epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
   unsigned index=data&255;
   if(project&&Q(project,0)==host.base+0x6ecc648&&sequence&&sequence==Q(project,0x1c8)&&
      (data>>8)==(epoch&0xffffffu)&&index<128&&program){
    for(unsigned source=0;source<128;source++){
     int key=I(program,0x12a8+4*source);
     if(key>=0&&key<128&&I(program,0x14a8+4*key)==(int)index){
      pc_preview_stop();if(kind==52)pc_groove_save_open(behaviour(),program,source,index);else pc_groove_open(behaviour(),program,source,index);break;
     }
    }
   }
   pc_unmeta();
  }
  repaint();return 1;
 }
 if(pc_groove_active()&&(kind==12||kind==14||kind==35)){
  if(pc_meta()){pc_groove_event(kind,data);pc_unmeta();}
  repaint();return 1;
 }
 if(kind==53){if(groove_scope()&&pc_meta()){pc_step_erase_current();pc_unmeta();}repaint();return 1;}
 if(kind==51){if(midi_roll_context()&&!I(pc_state_base(),0x5000))pc_roll_octave_event((int32_t)data);repaint();return 1;}
 if(kind==48){pc_roll_knob_event(data);return 1;}
 if(kind==49){pc_light_refresh_ui();if(pc_drumkit_active())repaint();return 1;}
 if(kind==47){pc_shutdown_missing_continue();return 1;}
 if(kind==41){if(pc_meta()){
  pc_user_close();pc_syx_close();pc_preview_stop();__atomic_store_n(&host.ui.catalog,0,RL);
  __atomic_store_n(&fx_overlay,0,RL);fx_native_close();pc_audio_close();
  uintptr_t b=behaviour(),m=b?Q(b,0x30):0;if(m)FN(0x1c0e5c0,void(*)(uintptr_t,int))(m,0x20a9);
  pc_audio_event(28,0);pc_unmeta();repaint();}return 1;
 }
 if(kind==33||(!fx_active()&&pc_user_active()&&(kind==11||kind==12||kind==13||kind==14||kind==21||kind==35||kind==36))){
  if(pc_meta()){
   uintptr_t p=current_program(),i=current_instrument();
   if(kind==33){pc_syx_close();int k=pc_find(i);if(!pc_audio_page()&&!pc_bounce_modal()&&k>=0&&host.slots[k].engine!=PC_MS_ENGINE){__atomic_store_n(&host.ui.catalog,0,RL);host.ui.save_confirm=0;pc_user_open(p,i,0);}}
   else pc_user_event(kind,data,p,i);
   pc_unmeta();repaint();
  }
  return 1;
 }
 if(!fx_active()&&pc_syx_active()){
  if(pc_meta()){pc_syx_event(kind,data,current_program(),current_instrument());pc_unmeta();repaint();}return 1;
 }
 if(!pc_audio_page()&&(kind==13||kind==17)&&fx_scope())return 1;

 if(kind==44)return 1; /* Withdraw automatic native mode restoration. */
 if(kind==43){if(pc_import_knob_event(data))enqueue(41,1,0);return 1;}
 if(kind==42)return 1;
 if(kind==40){pc_preview_stop();return 1;}
 if(kind==39){
  uintptr_t midi_project=Q(pc_state_base(),0x1d08);if(!midi_project||Q(midi_project,0)!=host.base+0x6ecc648||!Q(midi_project,0x12c0))return 1;
  /* Native browser only requests the operation. Event processing runs after
   * physical controls release their notification/dispatch mutexes. The native
   * commit revalidates project, sequence, pad, transport and held notes. */
  if(data>1||mode()!=0x20ad||pc_audio_config_scope()||pc_audio_page()||pc_bounce_modal())return 1;
  if(FN(0x7410018,int(*)(void))()){
   FN(0x7435020,int(*)(unsigned))(data);FN(0x7410098,void(*)(void))();repaint();
  }else enqueue(39,1,data);
  return 1;
 }
 if(kind==38){
  if(mode()!=0x20ad||pc_audio_config_scope()||pc_audio_page()||pc_bounce_modal()||fx_scope()||I(pc_state_base(),0x860)||I(pc_state_base(),0x5000))return 1;
  if(pc_meta()){
   uintptr_t project=Q(pc_state_base(),0x1d08),p=current_program(),selected=project?Q(project,0x668):0;
   if(project&&Q(project,0)==host.base+0x6ecc648&&p&&Q(project,0xb8)==p){
    int from=-1;for(unsigned k=0;k<128;k++)if(mapped_instrument(p,k)==selected){from=k;break;}
    int delta=(int32_t)data;if(from>=0&&(delta==-1||delta==1))for(int next=from+delta;next>=0&&next<128;next+=delta){
     if(!pc_editorial_step_populated(p,(unsigned)next))continue;
     int key=I(p,0x12a8+4*(unsigned)next),index=key>=0&&key<128?I(p,0x14a8+4*(unsigned)key):-1;
     if(index<0)continue;
     /* Project's typed current-InstrumentIndex property at4b0, value+50.
      * Native initialization at28faa68 uses this same setter. */
     FN(0x13b3740,void(*)(uintptr_t,int))(project+0x4b0,index);
     if(I(project,0x500)==index){host.ui.source=next;PcRollPrefix*r=(PcRollPrefix*)(pc_state_base()+0x800);
      uintptr_t b=behaviour(),ctrl=b?Q(b,0x150):0;
      if(!r->active&&r->last_valid&&r->last_controller==ctrl&&r->last_program==p)r->last_source=next;
     }break;
    }
   }pc_unmeta();repaint();
  }return 1;
 }
 if(kind==32){
  /* The queued request may arrive after the user changes mode or pad. Never
   * enter the chord browser using an obsolete Piano Roll button press. */
  if(!pc_audio_config_scope()&&!pc_bounce_modal()&&midi_roll_context()){
   if(pc_meta()){pc_chord_browser_open(behaviour());pc_unmeta();}repaint();
  }return 1;
 }
 if(kind==31){if(pc_meta()){pc_bounce_poll();pc_unmeta();repaint();uintptr_t b=behaviour(),root=b?Q(b,0x58):0;if(root)FN(0x1149d70,void(*)(uintptr_t))(root);}else pc_bounce_retry();return 1;}
 if(kind==30||pc_bounce_modal()){if(pc_meta()){int action=pc_bounce_event(kind,data);pc_unmeta();if(action==2)pc_bounce_start();repaint();}return 1;}
 if(kind==20){pc_preview_poll();return 1;}
 if(kind==18){pc_project_poll();refresh_scope();return 1;}
 pc_project_restore();
 if(kind==16){pc_roll_transport_sync();return 1;}
 if(kind==29){if(pc_meta()){pc_audio_state_poll();pc_unmeta();repaint();}return 1;}
 if(kind==27){if(pc_meta()){pc_audio_poll();pc_unmeta();repaint();}return 1;}
 if(kind==23){pc_diag_poll();pc_input_config_frame(0);pc_input_config_refresh();pc_padfx_ui_frame(0);return FN(PC_CH_LIVE_POLL,int(*)(void))();}
 if(kind==25){__atomic_store_n(&host.ui.catalog,0,RL);host.ui.replace=0;repaint();return 1;}
 /* Legacy entry is an idempotent OPEN, not the B3/shortcut toggle: several
  * queued knob updates must not alternately open and close the new menu. */
 if(kind==37){pc_diag_add(38);__atomic_store_n(&fx_stock_pending,0,RL);if(!pc_dj_open()&&!pc_dj_import()&&!pc_bounce_modal()&&!fx_active()){fx_open(data&1);fx_repaint();}return 1;}
 if(kind==26){if(pc_dj_open()||pc_dj_import())return 1;pc_diag_add(37);if(data==2){fx_disarm();fx_native_close();fx_repaint();return 1;}if(fx_active()&&fx_global_page==(data&1))fx_back();else fx_open(data&1);fx_repaint();uintptr_t b=behaviour(),root=b?Q(b,0x58):0;if(root)FN(0x1149d70,void(*)(uintptr_t))(root);return 1;}
 if(kind==24&&pc_audio_config_scope()&&!fx_scope()){pc_input_config_refresh();repaint();}
 if(kind==15)return FN(PC_CH_HISTORY,int(*)(unsigned))(data);
 if(!pc_meta()){host.ui.message="Project busy: try again";repaint();return 1;}
 refresh_scope();uintptr_t b=behaviour();
 if(fx_scope()&&fx_event(kind,data)){pc_unmeta();fx_repaint();if(b&&Q(b,0x58))FN(0x1149d70,void(*)(uintptr_t))(Q(b,0x58));return 1;}
 if(kind==12&&(data==1||data==2)&&pc_audio_config_scope()&&!pc_audio_page()){pc_audio_open(data==1?2:1);pc_unmeta();repaint();return 1;}
 if(pc_audio_page()&&pc_audio_event(kind,data)){pc_unmeta();repaint();return 1;}
 if(kind==12&&data==0&&mode()==0x20a9&&!host.ui.catalog){pc_unmeta();return 0;}
 if(kind==12&&data==2&&!factory_delete.choice&&!pc_audio_page()&&!pc_audio_config_scope()&&editor_scope()&&!host.ui.catalog){
  int sk=pc_find(current_instrument());if(sk>=0&&(host.slots[sk].engine==4||host.slots[sk].engine==7||host.slots[sk].engine==9)){
   MpcPanelView view;if(mirror(sk)&&host.mirror.view(&view)&&!view.browser){int opened=pc_syx_open(current_program(),current_instrument());pc_unmeta();if(!opened)host.ui.message="Cannot open SysEx browser";repaint();return 1;}
  }
 }
 if(fx_event(kind,data)){pc_unmeta();fx_repaint();return 1;}
 if(kind==17&&sample_mix()){
  unsigned role=data*3/16384;if(role>2)role=2;
  if(!pc_sc_set(current_program(),current_instrument(),role))host.ui.message="Sidechain allocation failed";
 }
 else if(kind==11&&data<128){
  pc_preview_stop();
  if(host.ui.source!=data)__atomic_store_n(&host.ui.loaded_valid,0,RL);
  if(fx_scope())fx_sync_entry();
  host.ui.source=data;fx_ui.source=data;fx_ui.source_valid=1;fx_ui.program=current_program();fx_disarm();host.ui.replace=0;host.ui.save_confirm=0;host.ui.message=host.ui.catalog?"Select engine, press encoder":0;
 }
 else if(kind==12&&data==2&&mode()==0x20a9){
  __atomic_store_n(&host.ui.catalog,!__atomic_load_n(&host.ui.catalog,AQ),RL);host.ui.replace=0;host.ui.program=current_program();host.ui.message="Touch target pad / encoder loads";
 }
 else if(host.ui.catalog){
  if(host.ui.program!=current_program()){__atomic_store_n(&host.ui.catalog,0,RL);host.ui.message="Program changed: reopen browser";}
  else if(kind==14){int64_t next=(int64_t)host.ui.candidate+(int32_t)data;if(next<0)next=0;if(next>9)next=9;host.ui.candidate=(unsigned)next;host.ui.replace=0;}
  else if(kind==12&&data==0){__atomic_store_n(&host.ui.catalog,0,RL);host.ui.replace=0;}
  else if(kind==12&&data==1){host.ui.candidate=9;host.ui.replace=0;}
  else if(kind==12&&data==3){
   if(host.ui.candidate==7){
    if(pc_drumkit_open(current_program(),host.ui.source)){pc_preview_stop();__atomic_store_n(&host.ui.catalog,0,RL);host.ui.replace=0;host.ui.message=0;}
    pc_unmeta();repaint();return 1;
   }
   uintptr_t i=current_instrument();int old=pc_find(i);
   if(host.ui.candidate==8){
    if(pc_ms_open(current_program(),i)){pc_preview_stop();__atomic_store_n(&host.ui.catalog,0,RL);host.ui.replace=0;}
    pc_unmeta();repaint();return 1;
   }
   if(!i)host.ui.message="Select a normal Drum program";
   else if(old>=0&&!host.ui.replace){host.ui.replace=1;host.ui.message="Replace engine? Press again";}
   else{
    static const unsigned engines[]={0,1,2,4,7,8,9};unsigned selected=host.ui.candidate<7?engines[host.ui.candidate]:6;int ok=host.ui.candidate==9?pc_remove(i):pc_assign(current_program(),i,selected,selected?0:1,0);
    if(ok){__atomic_store_n(&host.ui.catalog,0,RL);host.ui.replace=0;host.ui.message=0;
     host.ui.screen=0;uintptr_t manager=b?Q(b,0x30):0;if(manager)FN(0x1c0e5c0,void (*)(uintptr_t,int))(manager,0x20a7);
    }else host.ui.message=__atomic_load_n(&host.debug->error,AQ)==40?"SYNTH LIMIT REACHED":"Release notes / engine busy";
   }
  }
 }else if(editor_scope()){
  if(!host.ui.save_confirm)host.ui.message=0;
  int k=pc_find(current_instrument());Slot *s=&host.slots[k];
  if(s->engine==PC_MS_ENGINE)pc_ms_editor_event(current_instrument(),kind,data);
  else if(mirror(k)){
   MpcPanelView before,after;host.mirror.view(&before);
   if(factory_confirming(s,&before)){
    if(kind==14)factory_delete.choice=pc_delete_choice(factory_delete.choice,(int32_t)data);
    else if(kind==12&&(data==2||data==3)){
     if(data==3&&factory_delete.choice==PC_DELETE){
      if(pc_preset_delete(s->engine,factory_delete.index)){
       factory_normalize(s,&before);host.ui.message="Preset deleted";
      }else host.ui.message="Cannot delete preset";
     }
     factory_delete.choice=0;
    }
   }else if(kind==12&&data==PC_PRESET_ERASE&&before.browser){
    if(before.preset_count&&!pc_preset_hidden(s->engine,before.preset_index)){
     factory_delete.instrument=s->instrument;factory_delete.epoch=host.project_epoch;
     factory_delete.engine=s->engine;factory_delete.index=before.preset_index;
     factory_delete.choice=PC_KEEP;pc_preview_stop();
    }
   }else if(host.ui.save_confirm){
    if(kind==12&&data==2){host.ui.save_confirm=0;host.ui.message=0;}
    else if(kind==12&&data==0){
     if(pc_preset_write(s->engine,host.ui.save_target,s->patch)){
      s->preset=host.ui.save_target;host.mirror.saved(s->preset);
      host.ui.save_confirm=0;host.ui.message="Preset saved on SD";
     }else host.ui.message="Save failed: check SD / retry B1";
    }
   }
   else if(kind==12&&data==1&&before.browser){
    pc_preview_stop();pc_user_open(current_program(),current_instrument(),1);
   }
   else if(kind==12&&data<2&&!before.browser){
    unsigned total=host.mirror.count(s->engine);
    int next=preset_step(s->engine,total,(int)s->preset,data?1:-1);
    if(next>=0&&(unsigned)next<total){
     if(pc_assign(s->program,s->instrument,s->engine,(unsigned)next,0)){
      pc_synth_filter_bind((unsigned)k);host.mirror.encoder((int)before.page_index);pc_preview_stop();fx_disarm();host.ui.message=0;
     }else host.ui.message="Release notes / preset busy";
    }
   }
   else if(kind==14){if(before.browser)factory_move(s,&before,(int32_t)data);else host.mirror.encoder((int32_t)data);}
   else if(kind==12&&data<3){if(before.browser&&data==0)factory_move(s,&before,-1);else host.mirror.button(data);}
   else if(kind==12&&data==3){
    if(before.browser&&(!before.preset_count||pc_preset_hidden(s->engine,before.preset_index)))host.ui.message="No presets available";
    else if(before.browser&&__atomic_load_n(&host.debug->held[k],AQ))host.ui.message="Release all notes before loading";
    else if(!pc_room(s))host.ui.message="Audio command queue busy";
    else{
     int result=host.mirror.confirm();if(result==1&&before.browser){
      Command c={.kind=1,.index=s->engine};host.mirror.view(&after);
      int stored=pc_preset_read(s->engine,after.preset_index,c.patch);
      if(stored<0||(stored>0&&!pc_backend_panel_load(&host.mirror,s->engine,after.preset_index,c.patch))){
       pc_backend_panel_load(&host.mirror,s->engine,s->preset,s->patch);host.ui.message="Invalid saved preset: kept patch";
      }else{
       if(stored>0)host.mirror.saved(after.preset_index);
       pc_backend_save(&host.mirror,c.patch);for(unsigned g=0;g<4;g++)__atomic_store_n(&s->pending[g],0,RL);
       c.reserved=++s->generation;pc_push(s,&c);memcpy(s->patch,c.patch,512);s->preset=after.preset_index;
      }
     }
    }
   }else if(kind==13&&!before.browser){
    unsigned knob=(data>>16)&3,position=data&65535;
    if(pc_synth_filter_page(&before)){
     if(knob<3&&takeover(knob,position,pc_synth_filter_position(s->instrument,knob)))pc_synth_filter_knob(s->instrument,knob,position);
    }else if(output_page(&before)&&knob==0){
     unsigned target=pc_mix_volume_position(s->instrument);
     if(takeover(0,position,target)&&!pc_mix_set_volume(s->program,s->instrument,-240+(int)((position*480u+8191)/16383u)))host.ui.message="Volume storage full";
    }else if((int)knob==sidechain_knob(&before)){
     unsigned role=position*3/16384;if(role>2)role=2;
     if(!pc_sc_set(s->program,s->instrument,role))host.ui.message="Sidechain allocation failed";
    }else if(knob<3){
     if((s->engine==4||before.slots[knob].index>=128)&&!pc_room(s)){host.ui.message="Control queue busy: retry";pc_unmeta();return 1;}
     int result=host.mirror.knob(knob,position);host.mirror.view(&after);
     if(result==1&&after.slots[knob].current!=before.slots[knob].current){
      unsigned index=(unsigned)after.slots[knob].index;
      if(s->engine==4){
       Command c={.kind=4,.reserved=s->generation};
       if(pc_backend_save(&host.mirror,c.patch)){pc_push(s,&c);memcpy(s->patch,c.patch,512);}
      }else if(index<128){__atomic_store_n(&s->values[index],((uint64_t)s->generation<<32)|(uint32_t)after.slots[knob].current,RL);__atomic_fetch_or(&s->pending[index/32],1u<<(index%32),RL);}
      else if(index<192){Command c={.kind=2,.index=index,.value=after.slots[knob].current};pc_push(s,&c);}
      if(s->engine!=4)pc_backend_save(&host.mirror,s->patch);
     }
    }
   }
   host.mirror.view(&after);
   if(after.browser&&!before.browser)pc_preset_refresh_hidden(s->engine);
   factory_normalize(s,&after);
   __atomic_store_n(&factory_browser,after.browser?s->instrument:0,RL);
   if(before.page_index!=after.page_index||before.browser!=after.browser)fx_disarm();
   if(after.browser&&(!before.browser||after.preset_index!=before.preset_index))pc_preview_stop();
   else if(before.browser&&!after.browser)pc_preview_stop();
  }
 }
 refresh_scope();pc_unmeta();repaint();return 1;
}
static int fx_paint(uintptr_t,uintptr_t);
typedef struct {uintptr_t graphics;int width,height;} Canvas;
static void rect(Canvas *c,int x,int y,int w,int h,unsigned color){
 if(x<0||y<0||w<1||h<1||x>=c->width||y>=c->height)return;
 if(w>c->width-x)w=c->width-x;if(h>c->height-y)h=c->height-y;
 FN(0x102d5e0,void (*)(uintptr_t,unsigned))(c->graphics,pc_theme_colour(color));
 FN(0x102e000,void (*)(uintptr_t,int,int,int,int))(c->graphics,x,y,w,h);
}
static void glyph_rect(void *context,int x,int y,int w,int h,unsigned color){rect((Canvas *)context,x,y,w,h,color);}
static void text(Canvas *c,int x,int y,const char *s,unsigned color){pc_theme_text(c,glyph_rect,x,y,s,39,color);}
static void volume_text(char *out,int db){
 if(db<=-601){const char *m="MUTE";unsigned n=0;do{out[n]=m[n];}while(m[n++]);return;}
 unsigned n=0;out[n++]=db<0?'-':'+';unsigned v=(unsigned)(db<0?-db:db);if(v>=100)out[n++]=(char)('0'+v/100);out[n++]=(char)('0'+v/10%10);out[n++]='.';out[n++]=(char)('0'+v%10);out[n++]=' ';out[n++]='d';out[n++]='B';out[n]=0;
}
static void percent(char *out,unsigned p){unsigned v=(p*100+8191)/16383,n=0;if(v>=100)out[n++]='1';if(v>=10)out[n++]=(char)('0'+v/10%10);out[n++]=(char)('0'+v%10);out[n++]='%';out[n]=0;}
static void pad_text(char *out,unsigned source){
 const char prefix[]="TARGET PAD ";unsigned n=0;for(;prefix[n];n++)out[n]=prefix[n];
 unsigned bank=source/16,pad=source%16+1;out[n++]=(char)('A'+bank);out[n++]='-';
 if(pad>=10)out[n++]='1';out[n++]=(char)('0'+pad%10);out[n]=0;
}
static int voice_warning(void){return pc_cpu_warning();}
static void paint_voice_warning(uintptr_t screen,uintptr_t graphics,int type){
 typedef struct {uint64_t xy,wh;} Bounds;
 Bounds bounds=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);
 int w=(int)(uint32_t)bounds.wh,h=(int)(bounds.wh>>32);
 if(w<240||w>1024||h<120||h>1024)return;
 Canvas c={graphics,w,h};
 rect(&c,8,24,224,17,MPC_THEME_BG);
 rect(&c,8,24,2,17,MPC_THEME_ACCENT);
 text(&c,14,27,"HIGH CPU USAGE",MPC_THEME_TEXT);
}
#include "editorial_panel.h"
int pc_ui_paint(uintptr_t screen,uintptr_t graphics){
 if(host.ready){pc_dj_poll();pc_limiter_scope();publish_sequence_length();pc_cpu_poll();pc_project_new_sync_ui();pc_flex_clock_poll();pc_sample_playback_poll();pc_record_controls_poll();}
 if(host.ready&&pc_ms_active()&&pc_meta()){pc_ms_collect();pc_unmeta();}
 if(host.ready&&screen&&graphics&&pc_ms_paint(screen,graphics))return 1;
 if(host.ready&&screen&&graphics&&pc_drumkit_paint(screen,graphics))return 1;
 if(host.ready&&screen&&graphics&&pc_groove_paint(screen,graphics))return 1;
 if(host.ready&&screen&&Q(screen,0)==host.base+0x6e17160&&pc_bounce_busy())pc_bounce_schedule();
 pc_diag_poll();pc_padfx_ui_frame(screen);if(host.ready)pc_import_frame(screen);
 /* r22 keeps the native BPM and ERASE widgets unchanged. */
 if(host.ready&&screen&&Q(screen,0)==host.base+0x6e1e258){
  fx_suppress_stock(screen);return 1; /* No second popup painter on the stock child. */
 }
 if(host.ready&&screen&&graphics&&Q(screen,0)==host.base+0x6e1d890){
  /* Publish the same visible context used by the painter to the raw controls.
   * These stock overlays are children of AC50Display, not behaviour.root. */
  uintptr_t owner=behaviour();__atomic_store_n(&fx_visible_root,0,RL);
  __atomic_store_n(&fx_visible_mode,mode(),RL);__atomic_store_n(&fx_visible_epoch,__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ),RL);
  __atomic_store_n(&fx_visible_root,owner?Q(owner,0x58):0,RL);
  return pc_dj_open()||pc_dj_import()?1:fx_paint(screen,graphics);
 }
 if(host.ready)
 if(host.ready&&screen&&graphics&&pc_syx_active()){
  if(pc_meta()){pc_syx_event(0,0,current_program(),current_instrument());pc_unmeta();}
  if(pc_syx_active()){typedef struct{uint64_t xy,wh;}Bounds;Bounds a=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(int)(uint32_t)a.wh,h=(int)(a.wh>>32);if(w>=200&&w<=1024&&h>=130&&h<=1024)return pc_syx_paint(graphics,w,h);}
 }

 if(host.ready&&screen&&graphics&&pc_user_active()){
  if(pc_meta()){pc_user_event(0,0,current_program(),current_instrument());pc_unmeta();}
  if(pc_user_active()){typedef struct{uint64_t xy,wh;}Bounds;Bounds a=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(int)(uint32_t)a.wh,h=(int)(a.wh>>32);if(w>=200&&w<=1024&&h>=80&&h<=1024)return pc_user_paint(graphics,w,h);}
 }
 if(host.ready&&screen){pc_input_config_frame(screen);if(Q(screen,0)==host.base+0x6e17160)pc_new_tempo_poll();}
 static uintptr_t input_seen;static unsigned input_active,input_refreshing,input_flag;
 if(!pc_audio_config_scope())input_active=0;
 if(host.ready&&screen&&graphics&&pc_bounce_modal()){typedef struct{uint64_t xy,wh;}Bounds;Bounds a=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(int)(uint32_t)a.wh,h=(int)(a.wh>>32);if(w>=200&&w<=1024&&h>=80&&h<=1024)return pc_bounce_paint(graphics,w,h);}

 if(!host.ready)return 0;
 if(screen&&Q(screen,0)==host.base+0x6e18180)return pc_editorial_native_fx_tile(screen,graphics);
 if(screen&&(Q(screen,0)==host.base+0x6e1f400||Q(screen,0)==host.base+0x6e1d3f0))return pc_editorial_native_fx(screen,graphics);
 if(screen&&Q(screen,0)==host.base+0x6e17160){
  fx_display=screen;fx_display_owner=behaviour();
  dj_playhead_frame(screen);
  fx_visible_frame(screen);
  pc_input_config_background(screen);
  if(fx_active()&&fx_global())return fx_paint(screen,graphics);
  /* The frame hook is also used by global FX. Render the active roll/browser
   * there so native Step Edit children cannot leave only pad logic active. */
  if(mode()==0x20ad&&!pc_audio_config_scope()&&(I(pc_state_base(),0x860)||I(pc_state_base(),0x5000))){
   if(!pc_meta()){FN(0x1149d70,void(*)(uintptr_t))(screen);return 1;}
   if(FN(0x7410018,int(*)(void))()){
    pc_roll_prepare_locked();
    FN(0x7403db4,void(*)(uintptr_t,uintptr_t))(screen,graphics);
    pc_roll_view_paint_locked(screen,graphics);FN(0x7410098,void(*)(void))();
   }
   pc_unmeta();
   int handled=fx_active()?fx_paint(screen,graphics):1;
   int warning=graphics?voice_warning():0;if(warning)paint_voice_warning(screen,graphics,warning);
   return handled;
  }
  if(fx_active())return fx_paint(screen,graphics);
  int warning=graphics&&(mode()==0x20a7||mode()==0x20ad||mode()==0x20a9)?voice_warning():0;
  if(warning){
   FN(0x7403db4,void(*)(uintptr_t,uintptr_t))(screen,graphics);
   paint_voice_warning(screen,graphics,warning);return 1;
  }
  return 0;
 } /* Display frame hook: never cover its children with an underlying synth. */
 if(screen&&Q(screen,0)==host.base+0x6e1dd80){
  pc_input_config_children(screen,pc_audio_page()==1||pc_audio_page()==2);
  if(pc_audio_page())input_active=0;
  uintptr_t input_props=Q(screen,0x128);unsigned flag=input_props?*(unsigned char*)(input_props+0x2f3):0;
  if(!pc_audio_page()&&!input_refreshing&&(input_seen!=screen||!input_active||flag!=input_flag)){
   input_seen=screen;input_active=1;input_refreshing=1;input_flag=flag;
   uintptr_t editor=Q(screen,0x2028);
   if(editor&&input_props){/* Stock input-effect selector intentionally removed. */}
   input_refreshing=0;
  }
  if(!pc_audio_page()){pc_input_config_layout(screen);typedef struct{uint64_t xy,wh;}Bounds;Bounds a=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(unsigned)a.wh,h=(unsigned)(a.wh>>32);if(w>=200&&h>=80){/* Overlay footer only; stock controls remain native. */
   extern void pc_input_config_footer(uintptr_t,int,int);pc_input_config_footer(graphics,w,h);}
   host.ui.screen=screen;host.ui.screen_mode=mode();return 1;}
 }
 if(pc_audio_page()){if(pc_audio_page()<3&&Q(screen,0)!=host.base+0x6e1dd80)return 0;host.ui.screen=screen;host.ui.screen_mode=mode();typedef struct{uint64_t xy,wh;}AudioBounds;AudioBounds a=FN(0x10f8ec0,AudioBounds(*)(uintptr_t))(screen);int w=(int)(uint32_t)a.wh,h=(int)(a.wh>>32);if(w>=200&&h>=80)return pc_audio_paint(graphics,w,h);}
 /* Discover native input dialogs before any underlying StepEdit overlay. */
 if(screen&&Q(screen,0)==host.base+0x6e24f38){uintptr_t b=behaviour(),root=b?Q(b,0x58):0;if(root)pc_input_config_frame(root);if(pc_audio_config_scope())return 0;}
 if(!fx_scope())__atomic_store_n(&fx_entry_pending,1,RL);pc_project_restore();pc_mix_restore_poll();
 if(fx_active()&&fx_global())return 0;
 /* For sends, allow the current native/mod page to paint normally underneath. */
 if(fx_scope()&&Q(screen,0)==host.base+0x6e1d890)return fx_paint(screen,graphics);
 if(mode()==0x20a7&&screen>=0x10000&&Q(screen,0)==host.base+0x6e212a0)host.ui.sample_screen=screen;
 refresh_scope();
 /* Sequencer views change paint only. Native controls and their signals are
  * never captured or synthesized by these views. */
 if(screen&&Q(screen,0)==host.base+0x6e24f38){
  if(pc_audio_config_scope())return 0;
  if(mode()!=0x20ad)return pc_editorial_step_reuse(screen,graphics);
  if(!pc_meta())return pc_editorial_step_cached(screen,graphics);
  uintptr_t p=current_program();(void)current_instrument();
  int drawn=pc_editorial_step_paint(screen,graphics,p,host.ui.source);pc_unmeta();return drawn;
 }
 if(screen&&Q(screen,0)==host.base+0x6e212a0&&mode()==0x20a7&&!pc_audio_config_scope()&&FN(PC_CH_SCOPE,int(*)(void))()){
  FN(PC_CH_SAMPLE_PAINT,void(*)(uintptr_t,uintptr_t))(screen,graphics);
  return pc_editorial_chord_paint(screen,graphics);
 }

 /* Paint-over-children may be called with only a small dirty clip. A changed
  * target needs one full native repaint, including the underlying Sample UI
  * when leaving an engine. Never repaint unconditionally inside paint. */
 if(!pc_meta())return 0;
 int id=mode();uintptr_t instrument=current_instrument();int slot=pc_find(instrument);
 pc_ms_collect();
 unsigned mix=sample_mix();
 sample_mix_caption(screen,mix&&!host.ui.catalog,instrument);
 unsigned visual=host.ui.catalog?2:host.ui.scope?1:mix?3:0;
 unsigned engine=slot>=0?host.slots[slot].engine+1:0;
 int target_changed=host.ui.paint_instrument!=instrument||host.ui.paint_engine!=engine;
 if(host.ui.paint_screen&&(host.ui.paint_screen!=screen||host.ui.paint_mode!=id||host.ui.paint_scope!=visual||target_changed)){
  if(target_changed){__atomic_store_n(&host.ui.loaded_valid,0,RL);host.ui.save_confirm=0;fx_disarm();}
  FN(0x1149d70,void(*)(uintptr_t))(screen);
 }
 host.ui.paint_screen=screen;host.ui.paint_mode=id;host.ui.paint_scope=visual;
 host.ui.paint_instrument=instrument;host.ui.paint_engine=engine;
 pc_unmeta();
 if(!host.ui.scope&&id!=0x20a9&&!mix)return 0;
 __atomic_fetch_add(&host.debug->paint_calls,1,RX);
 if(!pc_meta())return 0;host.ui.screen=screen;host.ui.screen_mode=mode();
 typedef struct {uint64_t xy,wh;} Bounds;Bounds b=FN(0x10f8ec0,Bounds (*)(uintptr_t))(screen);
 Canvas c={graphics,(int)(uint32_t)b.wh,(int)(b.wh>>32)};
 if(c.width<200||c.height<40){pc_unmeta();return 0;}
 int handled=0;
 if(!host.ui.scope){pc_unmeta();return 0;}
 if(host.ui.catalog){
  rect(&c,0,0,c.width,c.height,0xff10151c);pc_theme_title(&c,glyph_rect,5,0,"synths.",c.width-10,MPC_THEME_TEXT);char label[32];pad_text(label,host.ui.source);if(c.height>=120)text(&c,5,22,label,0xff65e5c0);
  const char *names[]={"PROFET   | poly analog","CLOUD    | granular","KR-106   | DCO / chorus","FM6      | six-operator FM","CZ-1     | native phase dist.","CS-1     | dual channel","RS-01    | 8-note paraphonic","DRUMKIT  | random sample kit","MULTISAMPLES | MIDI capture","SAMPLE   | remove engine"};
  int top=c.height>=120?40:20;
  unsigned rows=c.height>top+32?(unsigned)(c.height-top-32)/19:1;if(!rows)rows=1;if(rows>7)rows=7;
  unsigned first=host.ui.candidate>=rows?host.ui.candidate-rows+1:0;
  for(unsigned row=0;row<rows&&first+row<10;row++){unsigned k=first+row;int y=top+19*(int)row;if(k==host.ui.candidate)rect(&c,2,y,c.width-4,18,0xff293f50);text(&c,6,y+4,names[k],k==host.ui.candidate?0xffffffff:0xffadb7c4);}

  text(&c,5,c.height-32,host.ui.message,0xff65e5c0);text(&c,5,c.height-15,__atomic_load_n(&host.debug->error,AQ)==40?"Maximum 16 synth pads per project.":"B1 BACK  B2 SAMPLE  ENC LOAD",0xffadb7c4);handled=1;
 }else{
  int k=pc_find(current_instrument());
  /* Cover the complete editor even if a mirror temporarily cannot draw. */
  rect(&c,0,0,c.width,c.height,0xff10151c);handled=1;
  if(k>=0&&host.slots[k].engine==PC_MS_ENGINE){pc_ms_editor(current_instrument(),graphics,c.width,c.height);}
  else if(mirror(k)){MpcPanelView view;if(host.mirror.view(&view))handled=editorial_panel(&c,&view,&host.slots[k]);}

 }
 if(handled&&!host.ui.catalog&&I(pc_state_base(),0x1c10))
  FN(PC_CH_SAMPLE_PAINT,void(*)(uintptr_t,uintptr_t))(screen,graphics);
 pc_unmeta();return handled;
}

static int fx_paint(uintptr_t screen,uintptr_t graphics){
 pc_diag_add(41);pc_diag_value(43,fx_active()!=0);
 if(!pc_meta())return 1;host.ui.screen=screen;host.ui.screen_mode=mode();
 typedef struct{uint64_t xy,wh;} Bounds;Bounds bounds=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);
 Canvas c={graphics,(int)(uint32_t)bounds.wh,(int)(bounds.wh>>32)};
 if(c.width<200||c.height<40){pc_unmeta();return 1;}
 if(fx_global())rect(&c,0,0,c.width,c.height,0xff10151c);
 if(fx_ui.paint_mode!=(unsigned)mode()){fx_ui.paint_mode=(unsigned)mode();fx_ui.browser=0;fx_disarm();}
 if(!pc_mix_ensure()){int top=fx_global()?0:c.height-(c.height>=200?104:90);if(top<0)top=0;rect(&c,0,top,c.width,c.height-top,MPC_THEME_BG);text(&c,6,top+5,"FX preparing...",MPC_THEME_WARNING);pc_unmeta();return 1;}
 if(fx_global()){
  unsigned page=fx_shift();if(fx_ui.page!=(int)page){fx_ui.page=(int)page;fx_disarm();}
  text(&c,5,3,fx_ui.browser?"FX TYPE - ENC LOAD":page?"GLOBAL FX - SHIFT PAGE 2/2":"GLOBAL FX - PAGE 1/2",0xffffffff);
  if(fx_ui.browser){
   unsigned rows=(unsigned)(c.height-36)/17;if(rows>7)rows=7;if(!rows)rows=1;
   unsigned first=fx_ui.candidate>=rows?fx_ui.candidate-rows+1:0;
   for(unsigned j=0;j<rows&&j+first<=pc_fx_count();j++){unsigned index=first+j;int y=22+(int)j*17;
    if(index==fx_ui.candidate)rect(&c,2,y,c.width-4,16,0xff293f50);
    text(&c,6,y+2,pc_fx_name(pc_fx_catalog_type(index)),index==fx_ui.candidate?0xffffffff:0xffadb7c4);
   }
   text(&c,5,c.height-14,"B1 CANCEL  B3 CANCEL  ENC LOAD",0xffadb7c4);
  }else{
   for(unsigned k=0;k<3;k++){int y=21+17*(int)k;char label[4]={(char)('1'+k),':',' ',0};
    if(k==fx_ui.slot){rect(&c,2,y,c.width-4,16,0xff293f50);rect(&c,2,y,1,16,MPC_THEME_ACCENT);}text(&c,5,y+2,label,0xff65e5c0);text(&c,31,y+2,pc_fx_name(pc_fx_type(k)),0xffffffff);
   }
   for(unsigned k=0;k<3;k++){int x=(int)(k*c.width/3)+4;char label[13],value[8];const char *name=pc_fx_label(fx_ui.slot,k+page*3);unsigned j=0;for(;j<12&&name&&name[j];j++)label[j]=name[j];label[j]=0;
    text(&c,x,c.height-64,label,0xffadb7c4);percent(value,pc_fx_position(fx_ui.slot,k+page*3));const char *option=pc_fx_option(fx_ui.slot,k+page*3);text(&c,x,c.height-45,name&&name[0]=='-'?"--":option?option:value,0xffffffff);
    if(k)rect(&c,x-4,c.height-65,1,42,MPC_THEME_GRID);
    rect(&c,x,c.height-28,c.width/3-10,2,MPC_THEME_GRID);rect(&c,x,c.height-28,(int)((c.width/3-10)*pc_fx_position(fx_ui.slot,k+page*3)/MIX_POSITION),2,MPC_THEME_ACCENT);
   }
   text(&c,5,c.height-14,"B1 BACK  B2 TYPE  B3 SLOT | SHIFT",0xffadb7c4);
  }
 }else{
  uintptr_t i=fx_target();if(fx_ui.pad!=i){fx_ui.pad=i;fx_disarm();}
  /* Final display paint is paintOverChildren: the current page is already drawn.
   * Only cover the lower panel; never clear or recapture the upper screen. */
  int height=c.height>=200?104:90;if(height>c.height)height=c.height;
  int top=c.height-height;
  rect(&c,0,top,c.width,height,MPC_THEME_BG);
  rect(&c,0,top,c.width,1,MPC_THEME_ACCENT);
  char title[32];pad_text(title,fx_ui.source);
  text(&c,6,top+5,host.ui.message?host.ui.message:title,host.ui.message?MPC_THEME_MUTED:MPC_THEME_ACCENT);
  for(unsigned k=0;k<3;k++){int x=(int)(k*c.width/3)+6;char label[12]={'K',(char)('1'+k),' ','S','E','N','D',' ',(char)('1'+k),0},value[8],name[13];
   unsigned position=pc_mix_send(i,k);text(&c,x,top+23,label,MPC_THEME_MUTED);
   const char *full=pc_fx_name(pc_fx_type(k));unsigned j=0;for(;j<12&&full[j];j++)name[j]=full[j];name[j]=0;
   text(&c,x,top+37,name,MPC_THEME_TEXT);percent(value,position);
   text(&c,x,top+53,i?value:"--",MPC_THEME_TEXT);
   if(k)rect(&c,x-6,top+23,1,height-43,MPC_THEME_GRID);
   int bar=c.width/3-12;rect(&c,x,top+height-24,bar,2,MPC_THEME_GRID);
   rect(&c,x,top+height-24,(int)(bar*position/MIX_POSITION),2,MPC_THEME_ACCENT);
  }
  text(&c,6,c.height-14,"B1 RESET  B2 FX SETUP  B3 CLOSE",MPC_THEME_MUTED);
 }
 pc_unmeta();return 1;
}

int pc_ui_native_fx_guard(void){return pc_mix_guard();}

