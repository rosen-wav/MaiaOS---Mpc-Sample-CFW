/* Offline 48 -> 44.1 kHz conversion. The only stretch processor remains Akai
 * Warp. A polyphase 128-tap Blackman sinc preserves the audible high band;
 * source files are never modified. Cache writes publish atomically. */
#include "dj_analysis.h"
extern long pc_sys(long,long,long,long,long,long,long);
extern int pc_sd_folder(char*,unsigned,const char*);
extern void *memcpy(void*,const void*,size_t);
extern int memcmp(const void*,const void*,size_t);
#define CACHE_TAPS 128u
#define CACHE_PHASES 147u
extern double sin(double),cos(double);
static int cache_write(int fd,const void *data,unsigned bytes){
 const char *p=data;
 while(bytes){
  long n=pc_sys(64,fd,(long)p,bytes,0,0,0);
  if(n==-4)continue;if(n<=0)return 0;p+=n;bytes-=n;
 }
 return 1;
}
static void cache_u16(uint8_t *p,unsigned v){p[0]=v;p[1]=v>>8;}
static void cache_u32(uint8_t *p,unsigned v){for(unsigned i=0;i<4;i++)p[i]=v>>(8*i);}
static unsigned cache_len(const char *s){unsigned n=0;while(s[n])n++;return n;}
static int cache_path(char *out,unsigned cap,const char *root,const char *name){
 unsigned a=cache_len(root),b=cache_len(name);
 if(a+b+2>cap)return 0;
 memcpy(out,root,a);if(a&&root[a-1]!='/')out[a++]='/';memcpy(out+a,name,b+1);return 1;
}
static uint64_t cache_hash(uint64_t h,const void *bytes,unsigned n){
 const uint8_t *p=bytes;for(unsigned i=0;i<n;i++){h^=p[i];h*=UINT64_C(1099511628211);}return h;
}
static void cache_hex(char *out,uint64_t v){
 for(unsigned i=0;i<16;i++)out[i]="0123456789abcdef"[(v>>(60-4*i))&15];
}
static int cache_valid(int dir,const char *name,unsigned channels,uint64_t frames){
 long fd=pc_sys(56,dir,(long)name,0xa0000,0,0,0);if(fd<0)return 0;
 long bytes=pc_sys(62,fd,0,2,0,0,0);DjWav w={0};
 int valid=bytes>0&&pc_dj_wav_header(fd,bytes,&w)&&w.rate==44100&&
    w.channels==channels&&w.format==3&&w.bits==32&&w.frames==frames;
 pc_sys(57,fd,0,0,0,0,0);return valid;
}
int pc_dj_prepare_track(const char *source,char *out,unsigned cap){
 unsigned length=cache_len(source);if(length+1>cap)return DJ_CACHE_ERROR;
 out[0]=0;DjReader reader={0};
 int error=pc_dj_reader_open(&reader,source);if(error)return error;
 const DjWav *w=&reader.format;
 if(w->rate!=48000){memcpy(out,source,length+1);pc_dj_reader_close(&reader);return DJ_OK;}
 if(w->frames>(uint64_t)w->rate*1800){pc_dj_reader_close(&reader);return DJ_TOO_LONG;}
 error=DJ_CACHE_ERROR;
 long source_fd=-1,root_fd=-1,dir=-1,dest=-1,coefficients=-1;
 char root[1024],folder[1024],name[40]="v1-",temporary[64]="v1-";
 uint64_t stat_before[16]={0},stat_after[16]={0};
 unsigned temporary_created=0;
 source_fd=pc_sys(56,-100,(long)source,0xa0000,0,0,0);
 if(source_fd<0||pc_sys(80,source_fd,(long)stat_before,0,0,0,0)<0)goto done;
 if(!pc_sd_folder(root,sizeof root,""))goto done;
 root_fd=pc_sys(56,-100,(long)root,0xa4000,0,0,0);if(root_fd<0)goto done;
 long made=pc_sys(34,root_fd,(long)"MaiaDJ-Cache",0755,0,0,0);
 if(made<0&&made!=-17)goto done;
 dir=pc_sys(56,root_fd,(long)"MaiaDJ-Cache",0xa4000,0,0,0);if(dir<0)goto done;
 uint64_t hash=cache_hash(UINT64_C(14695981039346656037),source,length);
 /* Linux AArch64 stat: device/inode, size, mtime and ctime; no atime. */
 hash=cache_hash(hash,stat_before,16);
 hash=cache_hash(hash,stat_before+6,8);
 hash=cache_hash(hash,stat_before+11,32);
 cache_hex(name+3,hash);memcpy(name+19,"-44100.wav",11);
 if(!cache_path(folder,sizeof folder,root,"MaiaDJ-Cache")||!cache_path(out,cap,folder,name))goto done;
 uint64_t frames=(w->frames*147+80)/160;
 if(cache_valid(dir,name,w->channels,frames)){error=DJ_OK;goto done;}
 static unsigned serial;
 unsigned sequence=__atomic_add_fetch(&serial,1,__ATOMIC_RELAXED);
 uint64_t clock[2]={0};pc_sys(113,1,(long)clock,0,0,0,0);
 memcpy(temporary,name,19);temporary[19]='-';
 cache_hex(temporary+20,clock[0]^clock[1]<<32^sequence);memcpy(temporary+36,".tmp",5);
 dest=pc_sys(56,dir,(long)temporary,0xa00c1,0600,0,0);if(dest<0)goto done;
 temporary_created=1;
 coefficients=pc_sys(222,0,CACHE_PHASES*CACHE_TAPS*4,3,0x22,-1,0);
 if(coefficients<=0){error=DJ_MEMORY_ERROR;goto done;}
 float (*table)[CACHE_TAPS]=(float (*)[CACHE_TAPS])coefficients;
 for(unsigned phase=0;phase<CACHE_PHASES;phase++){
  double total=0;
  for(unsigned tap=0;tap<CACHE_TAPS;tap++){
   double distance=(int)tap-63-(double)phase/CACHE_PHASES;
   double window=.42-.5*cos(6.283185307179586*tap/127)+.08*cos(12.566370614359172*tap/127);
   double value=(distance==0?.875:sin(2.748893571891069*distance)/(3.141592653589793*distance))*window;
   table[phase][tap]=value;total+=value;
  }
  for(unsigned tap=0;tap<CACHE_TAPS;tap++)table[phase][tap]/=total;
 }
 uint8_t header[44]={0};memcpy(header,"RIFF",4);memcpy(header+8,"WAVEfmt ",8);
 unsigned block=w->channels*4,bytes=(unsigned)(frames*block);
 cache_u32(header+4,36+bytes);cache_u32(header+16,16);cache_u16(header+20,3);
 cache_u16(header+22,w->channels);cache_u32(header+24,44100);cache_u32(header+28,44100*block);
 cache_u16(header+32,block);cache_u16(header+34,32);memcpy(header+36,"data",4);cache_u32(header+40,bytes);
 if(!cache_write(dest,header,sizeof header))goto done;
 float ring[256][2]={{0}},buffer[1024];unsigned buffered=0;uint64_t loaded=0;
 for(uint64_t frame=0;frame<frames;frame++){
  uint64_t phase=frame*160,centre=phase/147;
  unsigned fraction=phase%147;
  uint64_t newest=centre+64;if(newest>=w->frames)newest=w->frames-1;
  while(loaded<=newest){
   if(!pc_dj_reader_frame(&reader,loaded,&ring[loaded&255][0],&ring[loaded&255][1])){error=DJ_READ_ERROR;goto done;}
   loaded++;
  }
  float l=0,r=0;
  for(unsigned tap=0;tap<CACHE_TAPS;tap++){
   int64_t at=(int64_t)centre+(int)tap-63;
   if(at<0)at=0;if((uint64_t)at>=w->frames)at=w->frames-1;
   float weight=table[fraction][tap];l+=weight*ring[at&255][0];r+=weight*ring[at&255][1];
  }
  buffer[buffered++]=l;if(w->channels==2)buffer[buffered++]=r;
  if(buffered==1024){if(!cache_write(dest,buffer,sizeof buffer))goto done;buffered=0;}
 }
 if(buffered&&!cache_write(dest,buffer,buffered*4))goto done;
 if(pc_sys(82,dest,0,0,0,0,0)<0)goto done;
 if(pc_sys(57,dest,0,0,0,0,0)<0){dest=-1;goto done;}dest=-1;
 if(pc_sys(80,source_fd,(long)stat_after,0,0,0,0)<0||
    memcmp(stat_before,stat_after,16)||memcmp(stat_before+6,stat_after+6,8)||
    memcmp(stat_before+11,stat_after+11,32))goto done;
 if(!cache_valid(dir,temporary,w->channels,frames))goto done;
 if(pc_sys(38,dir,(long)temporary,dir,(long)name,0,0)<0)goto done;
 temporary_created=0;error=DJ_OK;
done:
 if(coefficients>0)pc_sys(215,coefficients,CACHE_PHASES*CACHE_TAPS*4,0,0,0,0);
 if(dest>=0)pc_sys(57,dest,0,0,0,0,0);
 if(temporary_created&&dir>=0)pc_sys(35,dir,(long)temporary,0,0,0,0);
 if(dir>=0)pc_sys(57,dir,0,0,0,0,0);
 if(root_fd>=0)pc_sys(57,root_fd,0,0,0,0,0);
 if(source_fd>=0)pc_sys(57,source_fd,0,0,0,0,0);
 pc_dj_reader_close(&reader);if(error)out[0]=0;return error;
}
