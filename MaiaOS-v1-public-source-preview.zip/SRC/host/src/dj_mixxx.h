/* SPDX-License-Identifier: GPL-2.0-or-later
 * Copyright 2008-2009 Matthew Davies and QMUL.
 * Copyright 2001-2026 Mixxx Development Team.
 * Adapted from the Mixxx archive. See LICENSES/dj-mixxx-NOTICE.txt.
 */
#ifndef PC_DJ_MIXXX_H
#define PC_DJ_MIXXX_H

/* TempoTrackV2::get_rcf. Lag-normalized autocorrelation and harmonic
 * comb. The caller supplies a rectified onset envelope and valid lags. */
static double dj_qm_acf(const float *onsets,unsigned size,unsigned lag){
 double sum=0;
 for(unsigned i=0;i<size-lag;i++)sum+=(double)onsets[i]*onsets[i+lag];
 return sum/(size-lag);
}
static double dj_qm_comb(const double *acf,int lag){
 double score=0;
 for(int harmonic=1;harmonic<=4;harmonic++)
  for(int offset=1-harmonic;offset<=harmonic-1;offset++)
   score+=acf[harmonic*lag+offset]/(2*harmonic-1);
 return score;
}

/* Mixxx Beats::lowerBound's constant-period branch. Return the first
 * beat index at or beyond the requested source position. */
static int dj_mixxx_beat_at_or_after(double position,double first,double period){
 double fraction=(position-first)/period;
 int index=(int)fraction;
 if(index*period+first<position)index++;
 return index;
}

#endif
