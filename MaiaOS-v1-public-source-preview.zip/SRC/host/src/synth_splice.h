#ifndef PC_SYNTH_SPLICE_H
#define PC_SYNTH_SPLICE_H

/* 3 ms at the MPC synth render rate of 44.1 kHz. */
#define PC_SYNTH_SPLICE_FRAMES 132u
typedef struct {
 float last[2],delta[2];
 unsigned remaining,transition;
} PcSynthSplice;

static inline void pc_synth_splice(PcSynthSplice *s,float *left,float *right,unsigned frames){
 if(s->transition){
  s->transition=0;
  float l=s->last[0]-left[0],r=s->last[1]-right[0];
  s->delta[0]=(l>=-16.f&&l<=16.f)?l:0;
  s->delta[1]=(r>=-16.f&&r<=16.f)?r:0;
  s->remaining=PC_SYNTH_SPLICE_FRAMES;
 }
 unsigned count=frames<s->remaining?frames:s->remaining;
 for(unsigned n=0;n<count;n++){
  float x=(float)(s->remaining-n)/PC_SYNTH_SPLICE_FRAMES;
  float weight=x*x*(3.f-2.f*x);
  left[n]+=s->delta[0]*weight;
  right[n]+=s->delta[1]*weight;
 }
 s->remaining-=count;
 s->last[0]=left[frames-1];
 s->last[1]=right[frames-1];
}
#endif
