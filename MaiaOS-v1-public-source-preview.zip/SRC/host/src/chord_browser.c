/* Browse progression MIDI files and native banks at the SD root. */
#include "internal.h"
#include "chord_files.h"
#include "../theme/layout.h"
static struct {unsigned active,index,count,epoch;uintptr_t project,behaviour;char root[320],relative[512],names[256][256];uint8_t directories[256];const char*message;} browser;
static uint8_t file_bytes[1048577];
unsigned pc_chord_browser_active(void){return __atomic_load_n(&browser.active,AQ);}
void pc_chord_browser_close(void){__atomic_store_n(&browser.active,0,RL);}
static unsigned length(const char*s){unsigned n=0;while(s[n])n++;return n;}
static int append(char*p,unsigned cap,const char*s){unsigned n=length(p),k=length(s);if(k>=cap-n)return 0;memcpy(p+n,s,k+1);return 1;}
static int path(char*p,const char*name){
 p[0]=0;if(!append(p,1100,browser.root)||!append(p,1100,browser.relative))return 0;
 for(unsigned n=0;name[n];n++)if(name[n]=='/'||name[n]=='\\')return 0;
 return append(p,1100,name);
}
static int bank_read(const char*name,ChordBank*out){
 char p[1100];if(!path(p,name))return 0;long fd=pc_sys(56,-100,(long)p,0x88800,0,0,0);if(fd<0)return 0;
 unsigned n=0;while(n<sizeof file_bytes){long got=pc_sys(63,fd,(long)(file_bytes+n),sizeof file_bytes-n,0,0,0);if(got==-4)continue;if(got<0){n=sizeof file_bytes;break;}if(!got)break;n+=got;}pc_sys(57,fd,0,0,0,0,0);
 if(n==sizeof file_bytes)return 0;ChordBank bank;int valid=pc_chord_file_parse(file_bytes,n,&bank);
 if(valid&&out){memcpy(out,&bank,sizeof bank);unsigned len=length(name);if(len>31)len=31;memset(out->name,0,32);memcpy(out->name,name,len);}
 return valid;
}
static int candidate(const char*name){
 unsigned n=length(name);const char*extensions[]={".progression",".mid",".midi",".chb",".chordbank"};
 for(unsigned i=0;i<5;i++){unsigned k=length(extensions[i]);if(k>n)continue;unsigned j=0;for(;j<k;j++){unsigned c=(unsigned char)name[n-k+j];if(c>='A'&&c<='Z')c+=32;if(c!=(unsigned char)extensions[i][j])break;}if(j==k)return 1;}return 0;
}
static void scan(void){
 browser.count=browser.index=0;browser.message=0;char dir[1100];if(!path(dir,""))return;
 long fd=pc_sys(56,-100,(long)dir,0x8c000,0,0,0);if(fd<0){browser.message="Progressions folder unavailable";return;}
 uint8_t entries[4096];long size;
 while(browser.count<256&&(size=pc_sys(61,fd,(long)entries,sizeof entries,0,0,0))>0){
  for(unsigned pos=0;pos+19<=(unsigned)size;){
   unsigned len=entries[pos+16]|(unsigned)entries[pos+17]<<8;if(len<20||pos+len>(unsigned)size)break;
   const char*name=(const char*)(entries+pos+19);unsigned bytes=len-19,n=0;while(n<bytes&&name[n])n++;
   if(n&&n<bytes&&n<256&&name[0]!='.'&&browser.count<256){
    int directory=entries[pos+18]==4;
    if(!entries[pos+18]){char p[1100];if(path(p,name)){long check=pc_sys(56,-100,(long)p,0x8c000,0,0,0);if(check>=0){directory=1;pc_sys(57,check,0,0,0,0,0);}}}
    if(directory||candidate(name)||bank_read(name,0)){
     unsigned at=browser.count++;
     while(at){char*before=browser.names[at-1];unsigned j=0;while(j<n&&before[j]&&before[j]==name[j])j++;
      if(browser.directories[at-1]>directory||(browser.directories[at-1]==directory&&(unsigned char)before[j]<=(unsigned char)name[j]))break;
      memcpy(browser.names[at],before,256);browser.directories[at]=browser.directories[at-1];at--;
     }memcpy(browser.names[at],name,n+1);browser.directories[at]=directory;
    }
   }pos+=len;
  }
 }pc_sys(57,fd,0,0,0,0,0);
 if(!browser.count)browser.message="No progression, MIDI or chord banks";
}
static void root_path(const char*s){browser.root[0]=0;append(browser.root,sizeof browser.root,s);browser.relative[0]=0;scan();}
static void find_root(void){
 char root[320];
 if(pc_sd_folder(root,sizeof root,"progressions/"))root_path(root);
 else {browser.root[0]=browser.relative[0]=0;browser.count=browser.index=0;browser.message="SD Root/progressions unavailable";}
}

int pc_chord_browser_open(uintptr_t b){
 uintptr_t p=Q(pc_state_base(),0x1d08);if(!b||!p||Q(p,0)!=host.base+0x6ecc648)return 0;
 browser.project=p;browser.behaviour=b;browser.epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 find_root();__atomic_store_n(&browser.active,1,RL);return 1;
}
static int current(void){return Q(pc_state_base(),0x20)==browser.behaviour&&Q(pc_state_base(),0x1d08)==browser.project&&__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)==browser.epoch;}
void pc_chord_browser_event(unsigned kind,unsigned data){
 if(!current()){pc_chord_browser_close();return;}
 if(kind==12&&data==2){pc_chord_browser_close();return;}
 if(kind==12&&data==0){
  if(!browser.relative[0])pc_chord_browser_close();
  else {unsigned n=length(browser.relative);if(n)n--;while(n&&browser.relative[n-1]!='/')n--;browser.relative[n]=0;scan();}return;
 }
 if(kind==14){int64_t i=(int64_t)browser.index+(int32_t)data;browser.index=i<0?0:i>browser.count?browser.count:i;browser.message=0;return;}
 if(kind!=12||data!=3)return;
 if(!browser.root[0]){find_root();return;}
 unsigned index=browser.index;
 if(index&&browser.directories[index-1]){
  unsigned n=length(browser.relative);if(!append(browser.relative,sizeof browser.relative,browser.names[index-1])||!append(browser.relative,sizeof browser.relative,"/")){browser.relative[n]=0;browser.message="Folder path too long";return;}scan();return;
 }
 if(!index){
  static uint64_t seed;int64_t now[2]={0};pc_sys(113,1,(long)now,0,0,0,0);seed^=(uint64_t)now[0]*1000000000+now[1]+0x9e3779b97f4a7c15ull;
  unsigned valid=0;
  for(unsigned n=0;n<browser.count;n++)if(!browser.directories[n]&&bank_read(browser.names[n],0)){
   seed^=seed<<13;seed^=seed>>7;seed^=seed<<17;if(seed%++valid==0)index=n+1;
  }
  if(!valid){browser.message="No valid chord banks in this folder";return;}

 }
 ChordBank bank;if(!index||!bank_read(browser.names[index-1],&bank)){browser.message="Invalid or unavailable chord bank";return;}
 if(!FN(0x7410018,int(*)(void))()){browser.message="Project busy / try again";return;}
 ChordProject project;int ok=FN(PC_CH_EXPORT,unsigned(*)(uintptr_t,void*,unsigned))(browser.project,&project,sizeof project)==sizeof project;
 unsigned added=0,total=0,next=0;
 for(unsigned n=0;n<16;n++)total+=bank.pads[n].count!=0;
 if(ok&&project.page<CH_PAGES){
  for(unsigned page=0;page<CH_PAGES&&added<total;page++){
   unsigned index=(project.page+page)%CH_PAGES;
   ChordBank*destination=&project.banks[index];
   unsigned occupied=0;
   for(unsigned pad=0;pad<16;pad++)occupied+=destination->pads[pad].count!=0;
   if(!occupied){
    memcpy(destination,&bank,offsetof(ChordBank,pads));
    project.transpose[index]=0;
   }
   for(unsigned pad=0;pad<16&&added<total;pad++){
    if(destination->pads[pad].count)continue;
    while(!bank.pads[next].count)next++;
    destination->pads[pad]=bank.pads[next++];
    added++;
   }
  }
  if(added)ok=FN(PC_CH_IMPORT,int(*)(uintptr_t,const void*,unsigned))(browser.project,&project,sizeof project);
 }else ok=0;
 FN(0x7410098,void(*)(void))();
 if(!ok)browser.message="Chord bank import failed";
 else if(!added)browser.message="No free chord slots";
 else if(added<total)browser.message="Bank partially added / chord slots full";
 else pc_chord_browser_close();
}
static void rect(void*g,int x,int y,int w,int h,unsigned c){FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,pc_theme_colour(c));FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);}
int pc_chord_browser_paint(uintptr_t screen,uintptr_t graphics){
 if(!pc_chord_browser_active())return 0;if(!current()){pc_chord_browser_close();return 0;}
 typedef struct{uint64_t xy,wh;}Bounds;Bounds b=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(uint32_t)b.wh,h=b.wh>>32;if(w<200||h<130||w>1024||h>1024)return 0;
 EiCanvas c={(void*)graphics,rect,w,h};ei_rect(&c,0,0,w,h,MPC_THEME_BG);ei_header(&c,"CHORD IMPORT","PROGRESSIONS");ei_text(&c,8,26,browser.relative[0]?browser.relative:browser.root,w-16,MPC_THEME_ACCENT);
 unsigned rows=(h-83)/20,first=browser.index>=rows?browser.index-rows+1:0;
 for(unsigned i=first;i<=browser.count&&i-first<rows;i++){int y=46+20*(i-first);if(i==browser.index)ei_rect(&c,5,y-3,w-10,19,MPC_THEME_SELECTED);ei_text(&c,10,y,i?browser.names[i-1]:"random",w-20,MPC_THEME_TEXT);}
 if(browser.message)ei_text(&c,8,h-36,browser.message,w-16,MPC_THEME_ACCENT);
 ei_text(&c,8,h-17,"B1 BACK   ENC LOAD   B3 CLOSE",w-16,MPC_THEME_MUTED);return 1;
}
