/* UI polls Linux per-core utilization. Audio reads only the atomic flag. */
#include "internal.h"
static struct {uint64_t total,idle;} prior[16];
static unsigned high,primed;
static int64_t polled=-1,warning_until,hot_since=-1;
int pc_cpu_overloaded(void){return __atomic_load_n(&high,AQ)!=0;}
static int64_t milliseconds(void){
 int64_t t[2];if(pc_sys(113,1,(long)t,0,0,0,0))return -1;
 return t[0]*1000+t[1]/1000000;
}
int pc_cpu_warning(void){int64_t t=milliseconds();return t>=0&&t<warning_until;}
void pc_cpu_poll(void){
 int64_t t=milliseconds();if(t<0)return;
 if(warning_until){
  uintptr_t b=Q(pc_state_base(),0x20),root=b?Q(b,0x58):0;
  if(root)FN(0x1149d70,void(*)(uintptr_t))(root);
  if(t>=warning_until)warning_until=0;
 }
 if(polled>=0&&t-polled<500)return;
 if(polled<0||t-polled>1500)hot_since=-1;polled=t;
 long fd=pc_sys(56,-100,(long)"/proc/stat",0x80000,0,0,0);if(fd<0)return;
 char b[4096];long size=pc_sys(63,fd,(long)b,sizeof b-1,0,0,0);pc_sys(57,fd,0,0,0,0,0);
 if(size<=0)return;b[size]=0;
 unsigned overloaded=0,cores=0;char*p=b;
 while(*p){
  char*end=p;while(*end&&*end!='\n')end++;
  if(end-p>4&&p[0]=='c'&&p[1]=='p'&&p[2]=='u'&&p[3]>='0'&&p[3]<='9'){
   char*q=p+3;unsigned core=0;
   while(q<end&&*q>='0'&&*q<='9'){core=core*10+*q-'0';q++;}
   uint64_t values[8]={0};
   for(unsigned k=0;k<8;k++){
    while(q<end&&*q==' ')q++;
    while(q<end&&*q>='0'&&*q<='9'){values[k]=values[k]*10+*q-'0';q++;}
   }
   if(core<16){
    uint64_t total=0;for(unsigned k=0;k<8;k++)total+=values[k];
    uint64_t idle=values[3]+values[4];
    if(primed&&total>=prior[core].total&&idle>=prior[core].idle){
     uint64_t dt=total-prior[core].total,di=idle-prior[core].idle;
     if(dt&&di<=dt&&(dt-di)*100>=dt*98)overloaded=1;
    }
    prior[core].total=total;prior[core].idle=idle;cores++;
   }
  }
  p=*end?end+1:end;
 }
 if(!cores)return;
 if(overloaded){if(hot_since<0)hot_since=t;overloaded=t-hot_since>=5000;}
 else hot_since=-1;
 if(overloaded&&!pc_cpu_overloaded())warning_until=t+2000;
 __atomic_store_n(&high,overloaded,RL);pc_diag_value(62,overloaded);primed=1;
}
