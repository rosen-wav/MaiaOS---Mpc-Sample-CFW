#ifndef PC_HARMONY_GROOVE_H
#define PC_HARMONY_GROOVE_H
#include <stdint.h>
typedef struct {int64_t tick,duration;float velocity;unsigned pitch;} PcHarmonyNote;
typedef int (*PcHarmonyEmit)(void*,int64_t,int64_t,unsigned,float);
unsigned pc_arp_count(void);
const char*pc_arp_name(unsigned);
int pc_harmony_generate(const PcHarmonyNote*,unsigned,int64_t,unsigned,unsigned,uint32_t,PcHarmonyEmit,void*);
#endif
