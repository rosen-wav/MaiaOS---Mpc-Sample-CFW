/* SPDX-License-Identifier: GPL-3.0-only
 * Mixxx Queen Mary analyzer adapter. Algorithms: vendor/qm-dsp and
 * mixxx_beatutils.cpp. Analysis runs on the offline worker, never audio.
 */
#include "dj_qm.h"
#include "mixxx_beatutils.h"
#include "dsp/onsets/DetectionFunction.h"
#include "dsp/tempotracking/TempoTrackV2.h"
#include <new>
struct Qm {
 unsigned rate,step,window,used;bool failed=false;
 DetectionFunction detector;
 std::vector<double> buffer,df;
 Qm(unsigned r):rate(r),step((unsigned)(r*.01161f)),window(MathUtilities::nextPowerOfTwo(r/50)),used(0),
 detector(DFConfig{(int)step,(int)window,DF_COMPLEXSD,3,false,-1,-1}),buffer(window,0){used=window/2;}
 void emit(){df.push_back(detector.processTimeDomain(buffer.data()));
  for(unsigned i=0;i<window-step;i++)buffer[i]=buffer[i+step];used=window-step;}
};
extern "C" void *pc_dj_qm_create(unsigned r){try{return new Qm(r);}catch(...){return nullptr;}}
extern "C" void pc_dj_qm_feed(void *v,float f){Qm*q=(Qm*)v;if(q->failed)return;try{q->buffer[q->used++]=f;if(q->used==q->window)q->emit();}catch(...){q->failed=true;}}
extern "C" void pc_dj_qm_destroy(void*v){delete (Qm*)v;}
static int finish_inner(void*v,double tagged,double*period,double*first,DjProgress*progress){
 Qm*q=(Qm*)v;if(q->failed)return 0;
 // Same trailing-window flush and first-two-results removal as Mixxx.
 unsigned fill=std::max(q->window-q->used,q->window/2-1);
 for(unsigned i=0;i<fill;i++)pc_dj_qm_feed(q,0);
 while(!q->df.empty()&&q->df.back()<=0)q->df.pop_back();
 if(q->df.size()<256)return 0;
 std::vector<double> df(q->df.begin()+2,q->df.end()),beats;
 const size_t windows=(df.size()+127)/128;
 std::vector<int> periods(windows);
 TempoTrackV2 tracker(q->rate,q->step);
 pc_dj_progress_report(progress,760);
 if(tagged>0){
  // A filename tempo is authoritative: skip tempo estimation altogether.
  // calculateBeats expects one period per detection-function hop.
  periods.assign(windows,(int)std::round(q->rate*60.0/tagged/q->step));
 }else tracker.calculateBeatPeriod(df,periods);
 for(int p:periods)if(p<1||p>(int)df.size())return 0;
 pc_dj_progress_report(progress,870);
 tracker.calculateBeats(df,periods,beats);
 if(beats.size()<3)return 0;
 QVector<double> frames;frames.reserve(beats.size());
 for(double beat:beats)frames.append(beat*q->step+q->step/2);
 pc_dj_progress_report(progress,940);
 double phase=frames.first();mixxx::Bpm bpm(tagged);
 if(!tagged){auto regions=BeatUtils::retrieveConstRegions(frames,q->rate);
  if(regions.isEmpty())return 0;
  bpm=BeatUtils::makeConstBpm(regions,q->rate,&phase);
 }
 if(!bpm.isValid())return 0;
 phase=BeatUtils::adjustPhase(phase,bpm,q->rate,frames);
 *period=q->rate*60.0/bpm.value();*first=std::fmod(phase,*period);
 if(*first<0)*first+=*period;
 return 1;
}

extern "C" int pc_dj_qm_finish(void*v,double tagged,double*period,double*first,DjProgress*progress){
 try{return finish_inner(v,tagged,period,first,progress);}catch(...){return 0;}
}
// GCC 14 vector headers reference this newer helper even with the old ABI.
// Supply it locally, using stock's longstanding bad_alloc exception ABI.
namespace std {void __throw_bad_array_new_length(){throw bad_alloc();}}
