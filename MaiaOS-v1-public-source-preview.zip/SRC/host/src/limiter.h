#ifndef PC_LIMITER_H
#define PC_LIMITER_H
#include <stdint.h>
unsigned pc_limiter_enabled(void);
void pc_limiter_process(float*,float*,const float*,const float*,unsigned,unsigned);
int pc_limiter_scope(void);
int pc_limiter_compressor(void);
void pc_limiter_event(unsigned,unsigned);
void pc_limiter_paint(uintptr_t,uintptr_t);
void pc_limiter_visibility(uintptr_t,unsigned);
#endif
