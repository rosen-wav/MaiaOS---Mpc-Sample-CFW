/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_DJ_CONTROLS_H
#define PC_DJ_CONTROLS_H

#define DJ_KNOB_MAX 16383u
#define DJ_KNOB_CENTRE 8192u
#define DJ_PICKUP_WINDOW 128u
enum {DJ_VOLUME,DJ_EQ,DJ_SENDS};
typedef struct {
 unsigned page,filter_deck,send_deck;
 unsigned volume[2],low[2],filter,send[2][3];
 unsigned armed,known,last[3];
} DjControls;
#define DJ_CONTROLS_DEFAULT { .volume={DJ_KNOB_MAX,DJ_KNOB_MAX}, \
 .low={DJ_KNOB_CENTRE,DJ_KNOB_CENTRE}, .filter=DJ_KNOB_CENTRE }

static unsigned *dj_control_value(DjControls *c,unsigned knob){
 if(c->page==DJ_SENDS)return &c->send[c->send_deck][knob];
 if(knob==1)return &c->filter;
 return c->page==DJ_EQ?&c->low[knob/2]:&c->volume[knob/2];
}
static void dj_disarm(DjControls *c,unsigned mask){
 c->armed&=~mask;c->known&=~mask;
}
static int dj_page_button(DjControls *c,unsigned button){
 unsigned page=c->page;
 if(button==0)c->page=page==DJ_EQ?DJ_VOLUME:DJ_EQ;
 else if(button==1){
  if(page==DJ_SENDS){c->send_deck^=1;dj_disarm(c,7);}
  else{c->filter_deck^=1;c->filter=DJ_KNOB_CENTRE;dj_disarm(c,2);}
 }else if(button==2)c->page=page==DJ_SENDS?DJ_VOLUME:DJ_SENDS;
 else return 0;
 if(c->page!=page)dj_disarm(c,7);
 return 1;
}
static int dj_pickup_value(DjControls *c,unsigned knob,unsigned position,unsigned *value){
 if(position>DJ_KNOB_MAX)return 0;
 unsigned bit=1u<<knob,last=c->last[knob];
 unsigned distance=position>*value?position-*value:*value-position;
 if(distance<=DJ_PICKUP_WINDOW||((c->known&bit)&&
    ((last<=*value&&position>=*value)||(last>=*value&&position<=*value))))c->armed|=bit;
 c->known|=bit;c->last[knob]=position;
 if(!(c->armed&bit)||*value==position)return 0;
 *value=position;return 1;
}
static int dj_pickup(DjControls *c,unsigned knob,unsigned position){
 return knob<3&&dj_pickup_value(c,knob,position,dj_control_value(c,knob));
}
static double dj_sync_target(double master,double follower){
 /* The midpoints are the absolute BPM tie boundaries. Prefer the
  * unscaled master on a tie. */
 if(follower<master*.75)return master*.5;
 if(follower>master*1.5)return master*2;
 return master;
}
static unsigned dj_filter_position(unsigned position){
 const unsigned low=7373,high=9010;
 if(position<low)return position*DJ_KNOB_CENTRE/low;
 if(position<=high)return DJ_KNOB_CENTRE;
 return DJ_KNOB_CENTRE+(position-high)*(DJ_KNOB_MAX-DJ_KNOB_CENTRE)/(DJ_KNOB_MAX-high);
}
static int dj_low_db(unsigned position){
 return position<DJ_KNOB_CENTRE
     ? -(int)(((DJ_KNOB_CENTRE-position)*24+DJ_KNOB_CENTRE/2)/DJ_KNOB_CENTRE)
     : (int)(((position-DJ_KNOB_CENTRE)*6+(DJ_KNOB_MAX-DJ_KNOB_CENTRE)/2)/(DJ_KNOB_MAX-DJ_KNOB_CENTRE));
}
#endif
