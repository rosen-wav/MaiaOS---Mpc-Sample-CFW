/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "bounce.h"
typedef struct {
 uint8_t native[0x50];PcBouncePlan plan;uint64_t controls;unsigned role,engine,preset,had_engine;uint8_t patch[512];
} MetaCommand;
typedef struct {uintptr_t vtable;uint32_t strong,weak;MetaCommand*command;} Control;
static uintptr_t command_vtable[13],control_vtable[7],typeinfo[3];
static int take(int*owned){if(pc_meta_owned()){*owned=0;return 1;}*owned=pc_meta();return *owned;}
static int apply(MetaCommand*c,unsigned undo){
 int owned;if(!take(&owned))return 2;int result=2;
 if(c->plan.epoch==__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)&&pc_valid(c->plan.program,c->plan.instrument)){
  if(undo){int ok=!c->had_engine||pc_assign(c->plan.program,c->plan.instrument,c->engine,c->preset,c->patch);if(ok&&pc_mix_set_controls(c->plan.program,c->plan.instrument,c->controls)&&pc_sc_set(c->plan.program,c->plan.instrument,c->role))result=0;}
  else{pc_bounce_detach(c->plan.instrument);if(pc_mix_set_controls(c->plan.program,c->plan.instrument,(uint64_t)601<<42)&&pc_sc_set(c->plan.program,c->plan.instrument,0))result=0;}
 }
 if(owned)pc_unmeta();return result;
}
static int execute(MetaCommand*c){return apply(c,0);}static int undo(MetaCommand*c){return apply(c,1);}
static void destroy(MetaCommand*c){FN(0x236f110,void(*)(uintptr_t))((uintptr_t)c+8);FN(0xf0a290,void(*)(uintptr_t))((uintptr_t)c+0x30);FN(0xf0a290,void(*)(uintptr_t))((uintptr_t)c+0x38);}
static void deleting(MetaCommand*c){destroy(c);FN(0xb51408,void(*)(void*,unsigned))(c,sizeof *c);}
static void dispose(Control*c){if(c->command){deleting(c->command);c->command=0;}}
static void delete_control(Control*c){FN(0xb51408,void(*)(void*,unsigned))(c,sizeof *c);}
static void*no_deleter(Control*c,void*t){(void)c;(void)t;return 0;}
int pc_bounce_history(uintptr_t factory,const PcBouncePlan*p){
 if(!command_vtable[2]){
  memcpy(command_vtable,(void*)(host.base+0x6e43990),sizeof command_vtable);
  typeinfo[0]=Q(host.base+0x6e07400,0);typeinfo[1]=(uintptr_t)"PcBounceMetadataCommand";typeinfo[2]=host.base+0x6e43980;command_vtable[1]=(uintptr_t)typeinfo;
  command_vtable[2]=(uintptr_t)destroy;command_vtable[3]=(uintptr_t)deleting;command_vtable[10]=(uintptr_t)execute;command_vtable[11]=(uintptr_t)undo;
  control_vtable[2]=(uintptr_t)delete_control;control_vtable[3]=(uintptr_t)delete_control;control_vtable[4]=(uintptr_t)dispose;control_vtable[5]=(uintptr_t)delete_control;control_vtable[6]=(uintptr_t)no_deleter;
 }
 MetaCommand*c=FN(0xb51418,void*(*)(unsigned))(sizeof *c);Control*ctrl=FN(0xb51418,void*(*)(unsigned))(sizeof *ctrl);if(!c||!ctrl){if(c)FN(0xb51408,void(*)(void*,unsigned))(c,sizeof *c);if(ctrl)FN(0xb51408,void(*)(void*,unsigned))(ctrl,sizeof *ctrl);return 0;}
 memset(c,0,sizeof *c);uintptr_t title=0;FN(0xf535c0,void(*)(void*,const char*))(&title,"Bounce pad routing and engine");FN(0x19c9850,void(*)(void*,void*,unsigned,unsigned))(c,&title,1,0);FN(0xf0a290,void(*)(void*))(&title);
 *(uintptr_t*)c=(uintptr_t)(command_vtable+2);c->plan=*p;c->controls=pc_mix_controls(p->instrument);c->role=pc_sc_role(p->instrument);int k=pc_find(p->instrument);if(k>=0){c->had_engine=1;c->engine=host.slots[k].engine;c->preset=host.slots[k].preset;memcpy(c->patch,host.slots[k].patch,512);}
 ctrl->vtable=(uintptr_t)(control_vtable+2);ctrl->strong=ctrl->weak=1;ctrl->command=c;uintptr_t shared[2]={(uintptr_t)c,(uintptr_t)ctrl};int result=FN(0x19d0a00,int(*)(uintptr_t,void*))(Q(factory,0x60),shared);FN(0x123bca0,void(*)(uintptr_t))((uintptr_t)ctrl);return result==0;
}
