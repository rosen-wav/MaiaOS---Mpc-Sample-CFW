/* SPDX-License-Identifier: GPL-3.0-only
 * One trigger bus per project, Off/Send/Receive per Instrument.
 * No allocations, filesystem calls or locks on the audio thread.
 */
#include "internal.h"
#define SC_PADS 256
#define SC_BUSES 1
typedef struct {uintptr_t instrument,program;unsigned role,bus,gain;uint64_t trigger;} ScPad;
typedef struct {uintptr_t program;uint64_t trigger;} ScBus;
static ScPad pads[SC_PADS];static ScBus buses[SC_BUSES];
static uint64_t now_ns(void){
 uint64_t bounce=pc_bounce_time_ns();if(bounce)return bounce;
 struct {int64_t sec,nsec;} ts;
 register long x8 __asm__("x8")=113,x0 __asm__("x0")=1,x1 __asm__("x1")=(long)&ts;
 __asm__ volatile("svc #0":"+r"(x0):"r"(x8),"r"(x1):"memory","cc");
 return x0==0?(uint64_t)ts.sec*1000000000ull+(uint64_t)ts.nsec:0;
}
static ScPad *find(uintptr_t i){for(unsigned n=0;n<SC_PADS;n++)if(__atomic_load_n(&pads[n].instrument,AQ)==i&&i)return &pads[n];return 0;}
unsigned pc_sc_role(uintptr_t i){ScPad *p=find(i);return p?__atomic_load_n(&p->role,AQ):0;}
/* Caller holds metadata ownership, never audio ownership. */
int pc_sc_set(uintptr_t program,uintptr_t i,unsigned role){
 if(role>2||!pc_valid(program,i))return 0;ScPad *p=find(i);
 if(!p){if(!role)return 1;for(unsigned n=0;n<SC_PADS;n++)if(!__atomic_load_n(&pads[n].instrument,AQ)){p=&pads[n];break;}}
 if(!p)return 0;
 unsigned b=0;
 __atomic_store_n(&p->trigger,0,RL);__atomic_store_n(&p->bus,b,RL);__atomic_store_n(&p->program,program,RL);__atomic_store_n(&p->gain,0x3f800000u,RL);
 __atomic_store_n(&p->role,role,RL);__atomic_store_n(&p->instrument,i,RL);return 1;
}
void pc_sc_forget(uintptr_t i,uintptr_t program){
 for(unsigned n=0;n<SC_PADS;n++)if((i&&__atomic_load_n(&pads[n].instrument,AQ)==i)||(program&&__atomic_load_n(&pads[n].program,AQ)==program)){
  __atomic_store_n(&pads[n].trigger,0,RL);__atomic_store_n(&pads[n].role,0,RL);__atomic_store_n(&pads[n].instrument,0,RL);
 }
 unsigned any=0;for(unsigned n=0;n<SC_PADS;n++)any|=__atomic_load_n(&pads[n].role,AQ);
 if(!any)__atomic_store_n(&buses[0].trigger,0,RL);
}
void pc_sc_note(uintptr_t program,uintptr_t i,const uint8_t *d){
 ScPad *p=find(i);if(!p||__atomic_load_n(&p->program,AQ)!=program||__atomic_load_n(&p->role,AQ)!=1||!d)return;
 if(__atomic_load_n((uint8_t*)(i+0x78),AQ)&1)return;
 float v;memcpy(&v,d+8,4);if(!(v>0&&v<=1))return;
 uint64_t t=now_ns();if(t)__atomic_store_n(&p->trigger,t,RL);if(t)__atomic_store_n(&buses[__atomic_load_n(&p->bus,AQ)].trigger,t,RL);
}
/* About -36 dB immediately after a send note, with 260ms recovery.
 * All project receivers follow the same monotonic timestamp: render order, voice
 * count and silent/idle send pads cannot stall or stretch the envelope. */
void pc_sc_process(uintptr_t i,uintptr_t buffer,unsigned frames,unsigned phase){
 (void)phase;pc_mix_native_gain(i,buffer,frames);pc_tune_audible_sample(i,buffer,frames);ScPad *p=find(i);if(!p||__atomic_load_n(&p->role,AQ)!=2)return;
 if(!buffer||I(buffer,0)<2||I(buffer,0)>32||!frames||frames>4096||I(buffer,4)<(int)frames)return;
 uintptr_t channels=Q(buffer,0x10);if(!channels||!Q(channels,0)||!Q(channels,8)||Q(channels,0)==Q(channels,8))return;
 uint64_t trigger=0;
 for(unsigned k=0;k<SC_PADS;k++){
  ScPad*sender=&pads[k];uintptr_t instrument=__atomic_load_n(&sender->instrument,AQ);
  if(!instrument||__atomic_load_n(&sender->role,AQ)!=1||
     (__atomic_load_n((uint8_t*)(instrument+0x78),AQ)&1))continue;
  uint64_t time=__atomic_load_n(&sender->trigger,AQ);if(time>trigger)trigger=time;
 }
 uint64_t now=trigger?now_ns():0;
 uint64_t elapsed=now>=trigger?now-trigger:260000000ull;
 unsigned gain_bits=__atomic_load_n(&p->gain,AQ);float gain;memcpy(&gain,&gain_bits,4);
 for(unsigned n=0;n<frames;n++){
  uint64_t age=elapsed+(uint64_t)n*1000000000ull/44100;
  float target=trigger&&now&&age<260000000ull?.01584893f+.98415107f*(float)(age>18000000ull?age-18000000ull:0)/242000000.f:1.f;
  /* 0.3ms attack slew avoids discontinuities; release follows the time envelope. */
  float delta=target-gain;if(delta<-.08f)delta=-.08f;if(delta>.02f)delta=.02f;gain+=delta;
  ((float *)Q(channels,0))[n]*=gain;((float *)Q(channels,8))[n]*=gain;
 }
 memcpy(&gain_bits,&gain,4);__atomic_store_n(&p->gain,gain_bits,RL);
}

void pc_sc_bounce_reset(void){__atomic_store_n(&buses[0].trigger,0,RL);for(unsigned n=0;n<SC_PADS;n++){__atomic_store_n(&pads[n].trigger,0,RL);__atomic_store_n(&pads[n].gain,0x3f800000u,RL);}}
