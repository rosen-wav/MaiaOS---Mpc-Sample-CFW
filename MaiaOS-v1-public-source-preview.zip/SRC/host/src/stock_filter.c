/* Stock FilterS80 stereo kernel with audio-owned state for each synth pad. */
#include "internal.h"
#include "stock_filter.h"

enum { STOCK_OFF=0, STOCK_LP12=2 };
enum { FILTER_ABSOLUTE=0x100, FILTER_RELATIVE=0x200 };
typedef struct {void *native;float cutoff,resonance;} StockFilterRef;
static unsigned enabled;

void pc_stock_filter_init(void){
 enabled=(uint32_t)I(host.base,0x2232750)==0xd503233f &&
         (uint32_t)I(host.base,0x2232850)==0xd503245f &&
         (uint32_t)I(host.base,0x2232990)==0xd503245f &&
         Q(host.base,0x7166a78)==host.base+0x71f4ed0 &&
         Q(host.base,0x6ec6a28)==host.base+0x2866bb0;
}
unsigned pc_stock_filter_note(uintptr_t program,const uint8_t*d){
 /* The stock filter override is parameter 2 of the packed note locks. */
 if(!(d[12]&4))return 0;
 unsigned raw=d[16];if(raw>254)raw=254;
 uintptr_t engine=Q(program,0x1fb8),locks=engine?Q(engine,0xf0):0;
 return (locks&&I(locks,0x9c)==1?FILTER_RELATIVE:FILTER_ABSOLUTE)|raw;
}
static float normalized(float value,float fallback){
 if(!(value>=0.f))return value<0.f?0.f:fallback;
 return value>1.f?1.f:value;
}
#define FILTER_FADE_FRAMES 352u /* About 8 ms at 44.1 kHz. */

static void configure_filter(uint8_t *state,unsigned mode,float cutoff,float resonance,int changed){
 StockFilterRef ref={state,cutoff,resonance};
 if(changed){
  memset(state,0,0xc0);
  FN(0x2232850,void(*)(StockFilterRef*,unsigned,unsigned,float,float))(&ref,mode,1,cutoff,resonance);
  return;
 }
 ref.cutoff=F(state,0xa0);
 ref.resonance=F(state,0xa8);
 FN(0x22328f0,void(*)(StockFilterRef*,float))(&ref,cutoff);
 FN(0x2232920,void(*)(StockFilterRef*,float))(&ref,resonance);
 FN(0x2232950,void(*)(StockFilterRef*))(&ref);
}
static void run_filter(uint8_t *state,float *stereo,unsigned frames){
 StockFilterRef ref={state,F(state,0xa0),F(state,0xa8)};
 FN(0x2232990,void(*)(StockFilterRef*,float*,unsigned))(&ref,stereo,frames);
}
int pc_stock_filter_render(PcStockFilter*filter,uintptr_t instrument,unsigned note_filter,
                           float*l,float*r,unsigned frames){
 /* DrumProgram::GetSynthSection supplies the audio-side parameter image
  * updated by the sample editor, Q-Link and assignable fader. */
 uintptr_t section=Q(instrument,0x2340);
 if(!section)return 0;
 unsigned mode=I(section,0x420);
 float cutoff=normalized(F(section,0x498),1.f);
 float resonance=normalized(F(section,0x4f0),0.f);
 if(note_filter){
  float value=(note_filter&255)/254.f;
  cutoff=(note_filter&FILTER_RELATIVE)?normalized(cutoff+2.f*value-1.f,1.f):value;
 }
 if(mode>29)mode=STOCK_OFF;
 if(mode==STOCK_OFF&&note_filter)mode=STOCK_LP12;
 return pc_stock_filter_process(filter,mode,cutoff,resonance,l,r,frames);
}
int pc_stock_filter_process(PcStockFilter*filter,unsigned mode,float cutoff,float resonance,
                            float*l,float*r,unsigned frames){
 if(!enabled||!(F(host.base,0x71f4ed0)>0.f))return 0;
 /* Finish the current fade before accepting another type change. This
  * keeps fast encoder sweeps continuous without a third filter path. */
 unsigned changed=mode!=filter->mode&&!filter->fade_left;
 if(changed){
  filter->previous_mode=filter->mode;
  if(filter->mode)memcpy(filter->previous,filter->native,sizeof filter->native);
  filter->mode=mode;
  filter->fade_left=FILTER_FADE_FRAMES;
 }
 if(filter->mode)configure_filter(filter->native,filter->mode,cutoff,resonance,changed);
 if(!filter->mode&&!filter->fade_left)return 0;

 for(unsigned start=0;start<frames;start+=128){
  _Alignas(32) float stereo[256],previous[256];
  unsigned count=frames-start;if(count>128)count=128;
  unsigned fading=filter->fade_left<count?filter->fade_left:count;
  for(unsigned n=0;n<count;n++){
   float left=l[start+n],right=r[start+n];
   stereo[2*n]=left>=-64.f&&left<=64.f?left:0.f;
   stereo[2*n+1]=right>=-64.f&&right<=64.f?right:0.f;
  }
  if(fading){
   memcpy(previous,stereo,2*fading*sizeof(float));
   if(filter->previous_mode)run_filter(filter->previous,previous,fading);
  }
  if(filter->mode)run_filter(filter->native,stereo,count);
  for(unsigned n=0;n<fading;n++){
   float x=(FILTER_FADE_FRAMES-filter->fade_left+n)*(1.f/(FILTER_FADE_FRAMES-1));
   float mix=x*x*(3.f-2.f*x);
   stereo[2*n]=previous[2*n]+mix*(stereo[2*n]-previous[2*n]);
   stereo[2*n+1]=previous[2*n+1]+mix*(stereo[2*n+1]-previous[2*n+1]);
  }
  filter->fade_left-=fading;
  for(unsigned n=0;n<count;n++){l[start+n]=stereo[2*n];r[start+n]=stereo[2*n+1];}
 }
 return changed;
}
