/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
const char *pc_synth_filter_name(unsigned);
unsigned pc_synth_filter_type(unsigned);
unsigned pc_synth_filter_type_position(unsigned);
unsigned pc_synth_filter_position(uintptr_t,unsigned);
void pc_synth_filter_knob(uintptr_t,unsigned,unsigned);
void pc_synth_filter_view(uintptr_t,MpcPanelView*);
void pc_synth_filter_bind(unsigned);
int pc_synth_filter_page(const MpcPanelView*);
unsigned pc_synth_fader_default(uintptr_t);
void pc_synth_fader_custom(uintptr_t);
void pc_synth_fader_reset(uintptr_t);
int pc_synth_fader_input(uintptr_t,float);
void pc_synth_fader_mapping_changed(void);
