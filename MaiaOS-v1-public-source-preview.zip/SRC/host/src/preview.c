/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
static struct{unsigned pending,queued,engine,preset,serial,owned;char file[160];}preview;
static uintptr_t owner(void){uintptr_t p=__atomic_load_n((uintptr_t *)(pc_state_base()+0x1ea0),AQ);return p&&Q(p,0)==host.base+0x6da3d18?p:0;}
void pc_preview_stop(void){__atomic_store_n(&preview.pending,0,RL);if(preview.owned){uintptr_t p=owner();if(p)FN(0x20be150,void(*)(uintptr_t))(p);preview.owned=0;}if(preview.file[0]){pc_sys(35,-100,(long)preview.file,0,0,0,0);preview.file[0]=0;}}
/* Selection is already serialized by the UI dispatcher. Queue the audition
 * here: pad lighting callbacks are not a periodic timer while browsing. */
void pc_preview_schedule(void){if(__atomic_load_n(&preview.pending,AQ)&&!__atomic_exchange_n(&preview.queued,1,__ATOMIC_ACQ_REL))FN(0x6d43500,void(*)(uint64_t))(41);}
void pc_preview_request(unsigned e,unsigned p){pc_preview_stop();if(e==3||(e==6||e>9))return;preview.engine=e;preview.preset=p;__atomic_store_n(&preview.pending,1,RL);pc_preview_schedule();}
static int write_all(long fd,const void*p,unsigned n){const char*b=p;while(n){long k=pc_sys(64,fd,(long)b,n,0,0,0);if(k<=0)return 0;b+=k;n-=k;}return 1;}
static void put16(uint8_t*p,unsigned v){p[0]=v;p[1]=v>>8;}static void put32(uint8_t*p,unsigned v){for(unsigned i=0;i<4;i++)p[i]=v>>(8*i);}
static float preview_samples[52920];
int pc_preview_wav(void){const unsigned frames=26460,hold=11025;uint8_t h[44]={0};memcpy(h,"RIFF",4);put32(h+4,36+frames*4);memcpy(h+8,"WAVEfmt ",8);put32(h+16,16);put16(h+20,1);put16(h+22,2);put32(h+24,44100);put32(h+28,176400);put16(h+32,4);put16(h+34,16);memcpy(h+36,"data",4);put32(h+40,frames*4);
char file[160]="/run/mpc-pc-integrated-v040/preview-";unsigned len=0;while(file[len])len++;unsigned serial=++preview.serial;char digits[16];unsigned n=0;do{digits[n++]=(char)('0'+serial%10);serial/=10;}while(serial);while(n)file[len++]=digits[--n];memcpy(file+len,".wav",5);
long fd=pc_sys(56,-100,(long)file,0x80000|0x40|0x200|1,0600,0,0);if(fd<0){pc_error(65);return 0;}int ok=write_all(fd,h,44);float l[128],r[128];int16_t pcm[256];if(preview.engine==4)pc_fm6_on(PC_FM6_PREVIEW,48,100);else host.preview.on(48,100);
float peak=0;unsigned done=0;while(ok&&done<frames){unsigned block=frames-done;if(block>128)block=128;if(done<hold&&done+block>hold)block=hold-done;if(done==hold){if(preview.engine==4)pc_fm6_off(PC_FM6_PREVIEW,48);else host.preview.off(48);}if(preview.engine==4)pc_fm6_render(PC_FM6_PREVIEW,l,r,block);else host.preview.render(l,r,block);for(unsigned i=0;i<block;i++)for(unsigned c=0;c<2;c++){float f=(c?r[i]:l[i])*.6f*(preview.engine>=4?1.7782794100f:1.0f);float limit=preview.engine>=4?1000000.0f:16.0f;if(!(f>=-limit&&f<=limit))f=0;float magnitude=f<0?-f:f;if(magnitude>peak)peak=magnitude;preview_samples[2*(done+i)+c]=f;}done+=block;}float scale=peak>.95f?.95f/peak:1.0f;
for(unsigned at=0;ok&&at<frames;){unsigned block=frames-at;if(block>128)block=128;for(unsigned i=0;i<block*2;i++)pcm[i]=(int16_t)(preview_samples[at*2+i]*scale*32767);ok=write_all(fd,pcm,block*4);at+=block;}
if(preview.engine!=4)for(unsigned i=0;i<128;i++)host.preview.off(i);pc_sys(57,fd,0,0,0,0,0);uintptr_t p=ok?owner():0;if(!p){pc_sys(35,-100,(long)file,0,0,0,0);pc_error(ok?63:65);return 0;}uintptr_t path=0;FN(0xf535c0,void(*)(uintptr_t,const char*))((uintptr_t)&path,file);FN(0x20be8c0,void(*)(uintptr_t,uintptr_t,unsigned))(p,(uintptr_t)&path,7);FN(0xf0a290,void(*)(uintptr_t))((uintptr_t)&path);if(!Q(p,0x3e0)){pc_sys(35,-100,(long)file,0,0,0,0);pc_error(65);return 0;}memcpy(preview.file,file,len+5);preview.owned=1;Q(pc_state_base(),0x1ea8)++;return 1;}
void pc_preview_poll(void){__atomic_store_n(&preview.queued,0,RL);
uintptr_t b=Q(pc_state_base(),0x20),m=b?Q(b,0x30):0;int id=m?I(m,0xd8):0;if(id==0x3080)id=I(m,0x80);
if(id!=0x20a7||host.ui.catalog){pc_preview_stop();return;}
if(!__atomic_load_n(&preview.pending,AQ))return;if(!pc_meta()){pc_preview_schedule();return;}
__atomic_store_n(&preview.pending,0,RL);
if(!pc_preview_backend(preview.engine)){pc_error(64);pc_unmeta();return;}
if(host.preview.select(preview.engine,preview.preset)){uint8_t patch[512];int r=pc_preset_read(preview.engine,preview.preset,patch);if(r>=0&&(!r||pc_backend_load(&host.preview,patch))){if((preview.engine!=4||(pc_backend_save(&host.preview,patch)&&pc_fm6_load(PC_FM6_PREVIEW,patch,0)))&&pc_preview_wav())pc_error(0);else host.ui.message="Preview unavailable: run status";}}
pc_unmeta();}
