/* Airwindows Pressure6 (MIT): pressure/response law adapted for a clean
 * master bus. Original plugin sources and license are shipped alongside. */
#include <stdint.h>
#include "pressure6.h"
extern "C" double sqrt(double);
static float min(float a,float b){return a<b?a:b;}
static float max(float a,float b){return a>b?a:b;}
static float absf(float x){return x<0?-x:x;}
static float unit(float f){return !(f>=0)?0:min(f,1);}
struct Context{
 uintptr_t owner;unsigned epoch,hold=0;
 float amount=0,colour=0,boost=1,meter=1,pressure=1,speed=100,peak=0,gain=1;
};
static Context contexts[8];static unsigned replacement;
static float pole(float rate,float ms){return 1.f/(1.f+rate*ms*.001f);}
extern "C" float pc_pressure6_process(uintptr_t owner,unsigned epoch,float*l,float*r,unsigned n,const PcPressure6*p){
 Context*c=nullptr;
 for(auto &ctx:contexts)if(ctx.owner==owner&&ctx.epoch==epoch){c=&ctx;break;}
 if(!c){c=&contexts[replacement++%8];*c=Context{};c->owner=owner;c->epoch=epoch;}
 float rate=p->rate>=8000&&p->rate<=192000?p->rate:44100;
 float attack=p->attack_ms>=0&&p->attack_ms<=10000?p->attack_ms:4;
 float release=p->release_ms>=0&&p->release_ms<=60000?p->release_ms:700;
 float target=unit(p->amount),colour=p->colour?1.f:0.f;
 float boost=p->boost>=1&&p->boost<=8?p->boost:1;
 float controls=pole(rate,12),gain_pole=pole(rate,2.5f);
 // A peak hold across waveform cycles keeps the detector from following
 // individual lobes of bass at short attack / high Amount.
 float peak_fall=pole(rate,max(18,min(release,65)));
 unsigned hold_frames=(unsigned)(rate*.016f);
 float attack_scale=max(attack,1.2f)/4.f;
 float release_scale=max(release,25)/700.f;
 double in_energy=0,out_energy=0;
 for(unsigned i=0;i<n;i++){
  c->amount+=(target-c->amount)*controls;
  c->colour+=(colour-c->colour)*controls;
  c->boost+=(boost-c->boost)*controls;
  float left=l[i]*c->boost,right=r[i]*c->boost;
  float peak=max(absf(left),absf(right));
  if(peak>=c->peak){c->peak=peak;c->hold=hold_frames;}
  else if(c->hold)c->hold--;
  else c->peak=max(peak,c->peak*(1-peak_fall));
  float a=c->amount*.9f,threshold=1-a*a*a;
  float nominal=(92+92*c->amount)*rate/44100;
  float sensed=c->peak*c->pressure/threshold;
  // Keep Pressure6's adaptive mu response. Apply its cubic gain as
  // a smoothed, normalized reduction instead of the driven sine stage.
  float equilibrium=c->peak>threshold*threshold?max(threshold,threshold*threshold/c->peak):1;
  float response=equilibrium<c->pressure?c->speed*attack_scale:c->speed*c->speed*release_scale;
  c->pressure+=(equilibrium-c->pressure)/max(1,response);
  c->pressure=max(threshold,min(1,c->pressure));
  float cube=c->pressure*c->pressure*c->pressure;
  c->speed=max(nominal,min(2*nominal,c->speed-1+sensed*c->pressure*c->pressure*nominal/c->speed));
  float mix=min(1,c->amount*20),depth=(.88f+.12f*c->colour)*mix;
  c->gain+=(1-(1-cube)*depth-c->gain)*gain_pole;
  float gain=c->gain;
  // Smooth stereo-linked overload knee, only while processing. Unity at
  // Amount zero, no per-channel hard clipping or unbounded makeup gain.
  float level=c->peak*gain;
  if(level>.95f&&mix>0){
   float excess=level-.95f;
   gain*=1-mix*(1-(.95f+excess/(1+20*excess))/level);
  }
  l[i]=left*gain;r[i]=right*gain;
  in_energy+=left*left+right*right;out_energy+=l[i]*l[i]+r[i]*r[i];
 }
 float gain=in_energy>1e-15?unit((float)sqrt(out_energy/in_energy)):1;
 c->meter+=(gain-c->meter)*.25f;
 return c->meter;
}
