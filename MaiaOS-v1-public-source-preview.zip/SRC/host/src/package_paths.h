#define PC_PACKAGE_ROOT "/media/MPCSSH/mpc-editorial-r1"
