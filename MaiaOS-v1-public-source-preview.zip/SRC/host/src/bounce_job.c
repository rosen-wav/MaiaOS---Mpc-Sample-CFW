/* SPDX-License-Identifier: GPL-3.0-only
 * Native offline renderer owns EngineMode. UI commits only after it releases it.
 * Never perform file access, model edits, allocation or blocking locks in audio.
 */
#include "internal.h"
#include "bounce.h"
/* Private post-FX block snapshot: native graph buffers are transient and may
 * be repurposed before the mixdown collector runs. Owned by the bounce worker. */
#define BOUNCE_BLOCK_MAX 4096u
typedef struct{int32_t channels,capacity;uintptr_t allocated_size;float**data;uintptr_t allocated;float*stack[33];uint8_t cleared,pad[7];}BounceBuffer;
_Static_assert(sizeof(BounceBuffer)==0x130,"native buffer ABI");
static struct{BounceBuffer buffer;float pcm[2][BOUNCE_BLOCK_MAX];}post_fx;
static struct {
 unsigned modal,choice,active,cancel,queued,status,error,seen,committing,synth_notes,synth_rendered,fallback_on,fallback_off;
 float peak;
 uintptr_t generator,mixdown,worker,fx_buffer;unsigned fx_frames;
 uint64_t frames,total,body,quiet;PcBouncePlan plan;
 char directory[192],path[256];
} bjob;
static unsigned serial;
static int worker(void);
void pc_bounce_note_seen(uintptr_t i){if(worker()&&i==bjob.plan.instrument)__atomic_fetch_add(&bjob.synth_notes,1,RX);}
void pc_bounce_synth_rendered(uintptr_t i){if(worker()&&i==bjob.plan.instrument)__atomic_store_n(&bjob.synth_rendered,1,RL);}

static unsigned load(unsigned*p){return __atomic_load_n(p,AQ);}
unsigned pc_bounce_busy(void){return load(&bjob.active);}
unsigned pc_bounce_modal(void){return load(&bjob.modal)||pc_bounce_busy();}
static uintptr_t thread(void){return pc_sys(178,0,0,0,0,0,0);}
static int worker(void){return pc_bounce_busy()&&__atomic_load_n(&bjob.worker,AQ)==thread();}
unsigned pc_bounce_synth_gate(uintptr_t i,unsigned*source,unsigned held){
 if(!worker()||i!=bjob.plan.instrument||bjob.plan.mode)return 0;
 *source=(unsigned)I(bjob.plan.program,0x12a8+4*bjob.plan.source);
 if(!bjob.fallback_on&&!__atomic_load_n(&bjob.synth_notes,AQ)&&!held&&!bjob.frames){bjob.fallback_on=1;pc_diag_flag(1,0x1000);return 1;}
 if(bjob.fallback_on&&!bjob.fallback_off&&bjob.body&&bjob.frames>=bjob.body){bjob.fallback_off=1;return 2;}return 0;
}
int pc_bounce_synth_done(void){return worker()&&__atomic_load_n(&bjob.synth_rendered,AQ);}
int pc_bounce_ensure_synth(uintptr_t b,unsigned n){
 if(!worker()||pc_find(bjob.plan.instrument)<0||__atomic_load_n(&bjob.synth_rendered,AQ))return 0;
 return pc_synth_bounce_render(bjob.plan.instrument,b,n);
}
void pc_bounce_synth_route(uintptr_t b,unsigned n){
 if(!worker())return;struct{uint64_t unused;uint32_t type,channels;float gain;uint32_t pad;}route={0,0,1,1.f,0};
 pc_mix_input(bjob.plan.instrument,b,(uintptr_t)&route,n);
}
uint64_t pc_bounce_time_ns(void){return worker()?1000000000ull+__atomic_load_n(&bjob.frames,AQ)*1000000000ull/44100:0;}
uintptr_t pc_bounce_service(uintptr_t type){
 /* Read-only unordered_map traversal. Never use operator[] for missing services. */
 uintptr_t locator=Q(pc_state_base(),0x1e98);if(!locator)return 0;
 uintptr_t node=Q(locator,0x10);for(unsigned n=0;node&&n<4096;n++,node=Q(node,0))if(Q(node,8)==type)return Q(node,0x10);return 0;
}
static void queue(void){if(!__atomic_exchange_n(&bjob.queued,1,__ATOMIC_ACQ_REL))FN(0x6d43500,void(*)(uint64_t))((31<<1)|1);}
void pc_bounce_retry(void){__atomic_store_n(&bjob.queued,0,RL);if(pc_bounce_busy())queue();}
void pc_bounce_schedule(void){if(pc_bounce_busy())queue();}
int pc_bounce_current(const PcBouncePlan*p){
 if(!p||p->epoch!=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)||p->project!=Q(pc_state_base(),0x1d08))return 0;
 if(Q(p->project,0)!=host.base+0x6ecc648||Q(p->project,0x1c8)!=p->sequence||Q(p->project,0x140)!=p->track||Q(p->project,0xb8)!=p->program)return 0;
 if(p->source>=128||!pc_valid(p->program,p->instrument)||Q(p->project,0x668)!=p->instrument||I(p->project,0x500)!=(int)p->index)return 0;
 int key=I(p->program,0x12a8+4*p->source);if(key<0||key>127||I(p->program,0x14a8+4*key)!=(int)p->index)return 0;
 uintptr_t b=Q(p->program,0x2808),e=Q(p->program,0x2810);return b&&e>=b&&(e-b)%8==0&&e-b<=128*8&&p->index<(e-b)/8&&Q(b,8*p->index)==p->instrument;
}
static int plan(void){
 PcBouncePlan*p=&bjob.plan;memset(p,0,sizeof *p);p->project=Q(pc_state_base(),0x1d08);p->source=host.ui.source;p->mode=bjob.choice;p->epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 if(!p->project||Q(p->project,0)!=host.base+0x6ecc648||p->source>127)return 0;
 p->program=Q(p->project,0xb8);p->instrument=Q(p->project,0x668);p->sequence=Q(p->project,0x1c8);p->track=Q(p->project,0x140);
 if(!pc_valid(p->program,p->instrument)||!p->sequence||Q(p->sequence,0)!=host.base+0x6ecdff0)return 0;
 uintptr_t b=Q(p->program,0x2808),e=Q(p->program,0x2810);int idx=I(p->project,0x500);
 if(idx<0||!b||e<b||e-b>128*8||(e-b)%8||(unsigned)idx>=(e-b)/8||Q(b,8*idx)!=p->instrument)return 0;
 int key=I(p->program,0x12a8+4*p->source),mapped=key>=0&&key<128?I(p->program,0x14a8+4*key):-1;
 if(mapped!=idx){unsigned source;for(source=0;source<128;source++){int k=I(p->program,0x12a8+4*source);if(k>=0&&k<128&&I(p->program,0x14a8+4*k)==idx)break;}if(source==128)return 0;p->source=source;}
 p->index=idx;p->seqindex=I(p->sequence,0x480);p->ticks=*(int64_t*)(p->sequence+0x348);
 uintptr_t tempo=pc_bounce_service(host.base+0x6e08fe0);if(!tempo)return 0;p->bpm=I(tempo,0x208)==1?F(tempo,0x1b0):F(tempo,0x158);if(!(p->bpm>=20&&p->bpm<=999))return 0;
 if(p->ticks<=0||p->ticks>960LL*4*1024)return 0;return pc_bounce_current(p);
}
static unsigned append(char*s,unsigned at,uint64_t v){char b[24];unsigned n=0;do{b[n++]='0'+v%10;v/=10;}while(v);while(n)s[at++]=b[--n];s[at]=0;return at;}
static void string(uintptr_t*s,const char*t){FN(0xf535c0,void(*)(void*,const char*))(s,t);}
static void strfree(uintptr_t*s){FN(0xf0a290,void(*)(void*))(s);}
static void cleanup(void){pc_bounce_sequence_clear();pc_bounce_voices_reset();__atomic_store_n(&bjob.active,0,RL);__atomic_store_n(&bjob.worker,0,RL);bjob.modal=0;bjob.generator=bjob.mixdown=0;host.ui.loaded_valid=0;pc_light_refresh();}
static void failed(const char*message){
 pc_diag_flag(1,0x80000000u);pc_diag_poll();
 host.ui.message=message;if(!bjob.committing&&bjob.path[0]){pc_sys(35,-100,(long)bjob.path,0,0,0,0);if(bjob.directory[0])pc_sys(35,-100,(long)bjob.directory,0x200,0,0,0);}cleanup();
}
static int prepare_job(void){
 pc_diag_flag(1,1);if(!plan()){host.ui.message="Select a Drum pad and valid sequence/tempo";return 0;}
 if(pc_find(bjob.plan.instrument)>=0&&(__atomic_load_n((uint8_t*)(bjob.plan.instrument+0x78),AQ)&1)){host.ui.message="Selected synth pad is muted";return 0;}
 bjob.generator=pc_bounce_service(host.base+0x6e107a0);if(!bjob.generator){host.ui.message="Native export service unavailable";return 0;}
 uintptr_t mode=Q(bjob.generator,0xc8);if(!mode||(*(uint8_t*)(mode+0x10)&1)){host.ui.message="Native engine busy";return 0;}
 if((unsigned)I(bjob.plan.project,0x500)!=bjob.plan.index||!pc_mix_ensure()||!pc_mix_bounce_prepare()){host.ui.message="Pad or FX not ready";return 0;}
 /* Export to an empty pad does not replace source note events. Native export
  * mode5 owns the sequence; do not require Step Edit's UI note-list cache. */
 pc_bounce_sequence_clear();
 const char root[]="/media/MPCSSH/mpc-bounces";long mk=pc_sys(34,-100,(long)root,0755,0,0,0);if(mk<0&&mk!=-17){host.ui.message="Cannot create bounce folder";pc_bounce_sequence_clear();return 0;}
 int64_t ts[2];if(pc_sys(113,0,(long)ts,0,0,0,0)){pc_bounce_sequence_clear();return 0;}
 memcpy(bjob.directory,root,sizeof root);unsigned a=sizeof root-1;bjob.directory[a++]='/';a=append(bjob.directory,a,ts[0]);bjob.directory[a++]='-';a=append(bjob.directory,a,ts[1]);bjob.directory[a++]='-';a=append(bjob.directory,a,++serial);
 if(pc_sys(34,-100,(long)bjob.directory,0755,0,0,0)){host.ui.message="Cannot create unique bounce folder";pc_bounce_sequence_clear();return 0;}
 memcpy(bjob.path,bjob.directory,a);bjob.path[a++]='/';memcpy(bjob.path+a,"BNC-",4);a+=4;bjob.path[a++]='A'+bjob.plan.source/16;a=append(bjob.path,a,1+bjob.plan.source%16);memcpy(bjob.path+a,bjob.choice?"-seq-":"-sound-",bjob.choice?5:7);a+=bjob.choice?5:7;a=append(bjob.path,a,ts[0]);bjob.path[a++]='-';a=append(bjob.path,a,ts[1]);bjob.path[a++]='-';a=append(bjob.path,a,serial);memcpy(bjob.path+a,".wav",5);
 bjob.cancel=bjob.error=bjob.frames=bjob.total=bjob.quiet=bjob.seen=bjob.status=bjob.committing=0;bjob.worker=bjob.mixdown=0;bjob.modal=0;bjob.synth_notes=bjob.synth_rendered=bjob.fallback_on=bjob.fallback_off=0;bjob.peak=0;
 __atomic_store_n(&bjob.active,1,RL);pc_preview_stop();pc_mix_route_program(bjob.plan.program);
 return 1;
}
int pc_bounce_start(void){
 pc_diag_flag(1,2);
 if(!pc_meta()){host.ui.message="Project busy: retry bounce";return 0;}
 int ready=prepare_job();pc_unmeta();if(!ready)return 0;
 /* Release extension metadata before the native worker can render its first
  * note. Native Export owns EngineMode and all offline graph synchronization. */
 uintptr_t file=0;uint8_t completion[32]={0};string(&file,bjob.path);
 FN(0x18c5a00,void(*)(uintptr_t,uintptr_t*,uintptr_t,unsigned,unsigned,unsigned,unsigned,unsigned,unsigned,void*))(bjob.generator,&file,bjob.plan.project,bjob.choice?5:3,120,1,1,3,1,completion);strfree(&file);
 uintptr_t mode=bjob.generator?Q(bjob.generator,0xc8):0;
 if(!bjob.mixdown&&(!Q(bjob.generator,0xb8)||!mode||!(*(uint8_t*)(mode+0x10)&1))){failed("Native export did not start");return 0;}return 1;
}

void pc_bounce_export(uintptr_t generator,uintptr_t props,unsigned index){
 if(!pc_bounce_busy()||generator!=bjob.generator||index!=bjob.plan.seqindex)return;
 if(!pc_bounce_current(&bjob.plan)){bjob.error=1;return;}
 FN(0x13bf290,void(*)(uintptr_t,uintptr_t))(props+0x538,bjob.plan.program);FN(0x13bb770,void(*)(uintptr_t,uintptr_t))(props+0x590,bjob.plan.track);FN(0x13b16a0,void(*)(uintptr_t,unsigned))(props+0x640,bjob.plan.index);
 FN(0x13b16a0,void(*)(uintptr_t,unsigned))(props+0x220,44100);
 FN(0x13904f0,void(*)(uintptr_t,unsigned))(props+0x3d8,1);FN(0x13904f0,void(*)(uintptr_t,unsigned))(props+0x430,1);
 FN(0x13bb930,void(*)(uintptr_t,float))(props+0x7f8,bjob.plan.bpm);
 uintptr_t meter=FN(0x29becf0,uintptr_t(*)(uintptr_t))(bjob.plan.sequence+0xe0);
 typedef struct {uint64_t a;unsigned b,pad;} BBP;
 BBP first={0};FN(0x13bc0a0,void(*)(uintptr_t,const void*))(props,&first);
 if(bjob.plan.mode||pc_find(bjob.plan.instrument)>=0||(!Q(props,0xb0)&&!I(props,0xb8))){int64_t ticks=bjob.plan.mode?bjob.plan.ticks:3840;BBP last=FN(0x29bf230,BBP(*)(uintptr_t,int64_t))(meter,ticks);FN(0x13bc0a0,void(*)(uintptr_t,const void*))(props+0x60,&last);}
 BBP last;memcpy(&last,(void*)(props+0xb0),12);int64_t ticks=FN(0x29bf150,int64_t(*)(uintptr_t,const void*))(meter,&last);if(ticks<=0)bjob.error=1;
 bjob.body=(uint64_t)((double)ticks*60.*44100./(960.*bjob.plan.bpm));bjob.total=bjob.body+120*44100;
}
void pc_bounce_enter(uintptr_t mixdown){
 if(!pc_bounce_busy()||!bjob.generator||mixdown!=Q(bjob.generator,0xb8))return;
 pc_diag_flag(1,4);bjob.mixdown=mixdown;__atomic_store_n(&bjob.worker,thread(),RL);pc_bounce_voices_reset();pc_mix_bounce_reset();pc_sc_bounce_reset();
}
void pc_bounce_block(uintptr_t mixdown){
 if(!pc_bounce_busy()||mixdown!=bjob.mixdown)return;
 uintptr_t tid=thread();if(__atomic_load_n(&bjob.worker,AQ)!=tid){__atomic_store_n(&bjob.worker,tid,RL);pc_bounce_voices_reset();pc_mix_bounce_reset();pc_sc_bounce_reset();}
 pc_diag_flag(1,8);__atomic_store_n(&bjob.synth_rendered,0,RL);pc_mix_bounce_begin();bjob.seen=0;bjob.fx_buffer=0;bjob.total=Q(mixdown,0xa00);
 if(bjob.plan.epoch!=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)||bjob.plan.project!=Q(pc_state_base(),0x1d08))__atomic_store_n(&bjob.cancel,1,RL);
 if(load(&bjob.cancel)||bjob.error)FN(0x18b5a50,void(*)(uintptr_t))(mixdown);
}
int pc_bounce_input(uintptr_t channels,unsigned n,unsigned offset){if(!worker())return 0;if(channels&&n<=4096){for(unsigned k=0;k<2;k++){float*p=(float*)Q(channels,8*k);if(p)memset(p+offset,0,n*4);}}return 1;}
void pc_bounce_fx(uintptr_t b,unsigned n){
 if(!worker()||!b||!n||n>BOUNCE_BLOCK_MAX||I(b,0)!=2||I(b,4)<(int)n)return;
 uintptr_t channels=Q(b,0x10);if(!channels)return;float*l=(float*)Q(channels,0),*r=(float*)Q(channels,8);if(!l||!r||l==r)return;
 BounceBuffer*out=&post_fx.buffer;memset(out,0,sizeof*out);out->channels=2;out->capacity=n;out->data=out->stack;out->stack[0]=post_fx.pcm[0];out->stack[1]=post_fx.pcm[1];out->cleared=*(uint8_t*)(b+0x128)&1;
 if(out->cleared){memset(post_fx.pcm,0,sizeof post_fx.pcm);}else{memcpy(post_fx.pcm[0],l,n*4);memcpy(post_fx.pcm[1],r,n*4);}
 pc_diag_flag(1,16);bjob.fx_buffer=(uintptr_t)out;bjob.fx_frames=n;bjob.seen=1;
}
void pc_bounce_collect(uintptr_t mixdown,unsigned n){
 if(!worker()||mixdown!=bjob.mixdown||!n||n>4096)return;
 uint64_t remaining=Q(mixdown,0x9f8);if(remaining<n)n=(unsigned)remaining;if(!n)return;
 if(bjob.plan.epoch!=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)||bjob.plan.project!=Q(pc_state_base(),0x1d08)){__atomic_store_n(&bjob.cancel,1,RL);FN(0x18b5a50,void(*)(uintptr_t))(mixdown);return;}
 pc_diag_flag(1,32);uintptr_t destination=Q(mixdown,0xa08);
 if(destination!=bjob.plan.program&&destination!=bjob.plan.instrument)destination=Q(mixdown,0xa10);
 /* Render and copy the exact object consumed by the native writer. */
 if(!bjob.seen&&!pc_mix_bounce_render(bjob.plan.program,bjob.plan.instrument,destination,n)){bjob.error=1;FN(0x18b5a50,void(*)(uintptr_t))(mixdown);return;}
 if((destination!=bjob.plan.program&&destination!=bjob.plan.instrument)||!destination||
    !bjob.seen||bjob.fx_frames<n||!pc_mix_bounce_copy(destination,bjob.fx_buffer,n)){bjob.error=1;FN(0x18b5a50,void(*)(uintptr_t))(mixdown);return;}
 pc_diag_flag(1,64);
 /* Register a writer even for a pure wet block whose dry source is empty. */
 FN(0x18bd730,void(*)(uintptr_t,uintptr_t))(mixdown,destination);
 uintptr_t b=bjob.fx_buffer;float*l=(float*)Q(Q(b,0x10),0),*r=(float*)Q(Q(b,0x10),8);unsigned quiet=1;
 for(unsigned i=0;i<n;i++){float a=l[i]<0?-l[i]:l[i],b=r[i]<0?-r[i]:r[i];if(a>bjob.peak)bjob.peak=a;if(b>bjob.peak)bjob.peak=b;if(a>.00001f||b>.00001f)quiet=0;}
 uint64_t frames=__atomic_load_n(&bjob.frames,AQ)+n;__atomic_store_n(&bjob.frames,frames,RL);
 if(frames>=bjob.body){bjob.quiet=quiet?bjob.quiet+n:0;if(bjob.quiet>=2*44100)Q(mixdown,0x9f8)=0;}
 queue();
}
void pc_bounce_status(uintptr_t gen,unsigned kind){if(pc_bounce_busy()&&gen==bjob.generator&&kind){__atomic_store_n(&bjob.status,kind,RL);queue();}}
static int read_exact(long fd,void*p,unsigned n){unsigned done=0;while(done<n){long k=pc_sys(63,fd,(long)p+done,n-done,0,0,0);if(k<=0)return 0;done+=k;}return 1;}
static uint32_t u32(uint8_t*b){return b[0]|(uint32_t)b[1]<<8|(uint32_t)b[2]<<16|(uint32_t)b[3]<<24;}
static int valid_wav(void){
 long fd=pc_sys(56,-100,(long)bjob.path,0x80000,0,0,0);if(fd<0)return 0;uint8_t h[40];int ok=read_exact(fd,h,12)&&!memcmp(h,"RIFF",4)&&!memcmp(h+8,"WAVE",4);uint64_t bytes=0,data_at=0;unsigned align=0,rate=0,channels=0,format=0,bits=0;
 for(unsigned c=0;ok&&c<128;c++){
  if(!read_exact(fd,h,8)){ok=0;break;}unsigned len=u32(h+4);if(!memcmp(h,"fmt ",4)){if(len<16||len>4096||!read_exact(fd,h,16)){ok=0;break;}format=h[0]|h[1]<<8;bits=h[14]|h[15]<<8;channels=h[2]|h[3]<<8;rate=u32(h+4);align=h[12]|h[13]<<8;len-=16;}
  else if(!memcmp(h,"data",4)){bytes=len;data_at=pc_sys(62,fd,0,1,0,0,0);break;}
  if(pc_sys(62,fd,len+(len&1),1,0,0,0)<0){ok=0;break;}
 }
 long size=pc_sys(62,fd,0,2,0,0,0);pc_sys(57,fd,0,0,0,0,0);
 uint64_t frames=__atomic_load_n(&bjob.frames,AQ);return ok&&size>0&&bytes&&data_at&&data_at+bytes<=(uint64_t)size&&(format==1||format==3||format==65534)&&(bits==16||bits==24||bits==32)&&align==2*(bits/8)&&channels==2&&rate==44100&&align>=4&&align<=8&&bytes%align==0&&bytes/align<=frames+BOUNCE_BLOCK_MAX&&frames>=bjob.body&&load(&bjob.status)==1;
}
/* Native export can choose a filename within its output directory. Resolve
 * exactly one WAV in this job's unique directory; never import a prior job. */
static int resolve_wav(void){
 if(valid_wav())return 1;
 char candidate[256]={0};unsigned found=0;
 const char*folders[2]={bjob.directory,bjob.path};
 for(unsigned which=0;which<2;which++){
  long fd=pc_sys(56,-100,(long)folders[which],0x90000,0,0,0);if(fd<0)continue;
  uint8_t entries[4096];unsigned checked=0;
  for(unsigned batch=0;batch<32;batch++){
   long bytes=pc_sys(61,fd,(long)entries,sizeof entries,0,0,0);if(bytes<=0)break;
   unsigned at=0;while(at<(unsigned)bytes){
    uint8_t*d=entries+at;if((unsigned)bytes-at<20)break;unsigned size=d[16]|(unsigned)d[17]<<8;
    if(size<20||size>(unsigned)bytes-at)break;
    char*name=(char*)d+19;unsigned n=0;while(n<size-19&&name[n])n++;
    if(++checked>512){found=2;break;}
    if(n>4&&n<size-19&&name[0]!='.'&&d[18]!=4&&name[n-4]=='.'&&(name[n-3]=='w'||name[n-3]=='W')&&(name[n-2]=='a'||name[n-2]=='A')&&(name[n-1]=='v'||name[n-1]=='V')){
     unsigned a=0;while(folders[which][a])a++;
     if(a+n+2<=sizeof candidate){if(found++){break;}memcpy(candidate,folders[which],a);candidate[a++]='/';memcpy(candidate+a,name,n+1);}
    }at+=size;
   }if(found>1||checked>512)break;
  }
  pc_sys(57,fd,0,0,0,0,0);if(found)break;
 }
 if(found!=1)return 0;
 memcpy(bjob.path,candidate,sizeof candidate);bjob.path[sizeof bjob.path-1]=0;
 return valid_wav();
}
static int empty_target(PcBouncePlan *p){
 uintptr_t begin=Q(p->program,0x2808),end=Q(p->program,0x2810);
 if(!begin||end<begin||(end-begin)%8||end-begin>1024)return 0;
 uintptr_t vt=Q(p->program,0);if(vt!=host.base+0x6ec6860)return 0;
 for(unsigned pad=0;pad<128;pad++){
  int key=I(p->program,0x12a8+4*pad);if(key<0||key>127)continue;
  int idx=I(p->program,0x14a8+4*key);if(idx<0||idx>=128)continue;
  uintptr_t ins=(unsigned)idx<(end-begin)/8?Q(begin,8*idx):0;
  if(ins&&(Q(ins,0)!=host.base+0x6ec3ca0||Q(ins,0x2310)!=p->program||pc_find(ins)>=0))continue;
  if(((unsigned(*)(uintptr_t,unsigned))Q(vt,0xd0))(p->program,pad))continue;
  p->source=pad;p->index=idx;p->instrument=ins;return 1;
 }return 0;
}
static void finish(void){
 pc_diag_flag(1,128);
 if(load(&bjob.cancel)||load(&bjob.status)==2){failed("Bounce cancelled; pad unchanged");return;}
 if(bjob.error){failed("Bounce render failed; pad unchanged");return;}
 if(!pc_bounce_current(&bjob.plan)){failed("Bounce target changed; pad unchanged");return;}
 if(pc_find(bjob.plan.instrument)>=0&&!(bjob.peak>0.f)){bjob.committing=1;failed("Synth rendered silence; WAV kept, pad unchanged");return;}
 if(!resolve_wav()){bjob.committing=1;failed("No complete WAV; check mpc-bounces");return;}
 pc_diag_flag(1,256);PcBouncePlan target=bjob.plan;if(!empty_target(&target)){bjob.committing=1;failed("No empty pad; WAV kept in mpc-bounces");return;}
 pc_diag_flag(1,512);uintptr_t loader=pc_bounce_service(host.base+0x6e08dd0),factory=pc_bounce_service(Q(host.base,0x7165828));if(!loader||!factory||Q(factory,0x28)!=bjob.plan.project||!Q(factory,0x60)){failed("Native sample import service unavailable");return;}
 uintptr_t file=0;string(&file,bjob.path);PcNativeReturn sample=FN(0x1df3db0,PcNativeReturn(*)(uintptr_t,uintptr_t*,float))(loader,&file,44100.f);strfree(&file);
 if(!sample.object){if(sample.owner)FN(0x123bca0,void(*)(uintptr_t))(sample.owner);failed("Cannot load bounce WAV");return;}
 pc_diag_flag(1,1024);FN(0x2946d30,void(*)(uintptr_t,float))(sample.object,bjob.plan.bpm);
 uintptr_t title=0,empty=0;string(&title,"Bounce to empty pad");FN(0xf1c620,void(*)(void*))(&empty);
 PcNativeTransaction tx=FN(0x19d0520,PcNativeTransaction(*)(uintptr_t,uintptr_t*,uintptr_t*))(Q(factory,0x60),&title,&empty);strfree(&empty);strfree(&title);
 pc_diag_value(8,tx.group?I(tx.group,0x28):0xffffffffu);
 int success=tx.group!=0;bjob.committing=1; /* Keep WAV if any command may reference it. */
 if(success&&I(tx.group,0x28)<=1){uint64_t lo=target.index<64?1ull<<target.index:0,hi=target.index>=64?1ull<<(target.index-64):0;
  if(target.instrument)FN(0x1950720,void(*)(uintptr_t,uintptr_t,uint64_t,uint64_t))(factory,bjob.plan.program,lo,hi);
  if(I(tx.group,0x28)<=1)FN(0x195bbb0,void(*)(uintptr_t,void*))(factory,&sample);
  pc_diag_value(9,I(tx.group,0x28));
  if(I(tx.group,0x28)==0)FN(0x195e940,void(*)(uintptr_t,uintptr_t,void*,unsigned,int))(factory,bjob.plan.program,&sample,target.index,-1);
 }
 if(success&&I(tx.group,0x28)==0){
  /* AssignSample's native constructor calls Program::getOrCreateInstrument
   * (2870e90); the previously empty slot need not have existed before export. */
  uintptr_t begin=Q(target.program,0x2808),end=Q(target.program,0x2810);
  target.instrument=begin&&end>=begin&&(end-begin)%8==0&&end-begin<=1024&&target.index<(end-begin)/8?Q(begin,8*target.index):0;
  success=target.instrument!=0;
 }
 pc_diag_value(10,tx.group?I(tx.group,0x28):0xffffffffu);
 success=success&&tx.group&&I(tx.group,0x28)==0;
 if(success){uintptr_t b=Q(tx.group,0x68),e=Q(tx.group,0x70);if(!b||e<b||(e-b)%16||(e-b)/16<1||(e-b)/16>4096)success=0;
  else for(uintptr_t n=b;n<e;n+=16){uintptr_t c=Q(n,0);if(!c||I(c,0x28)!=0){success=0;break;}}
  uintptr_t layers=Q(target.instrument,0x22e8);pc_diag_value(11,layers&&Q(layers,0x4a8)==sample.object);if(!layers||Q(layers,0x4a8)!=sample.object)success=0;
 }
 if(!success&&tx.processor){
  /* Native child failure may already have undone prior children. Group undo
   * skips those children; then close with discard so no failed undo entry remains. */
  if(tx.group)FN(0x19c9c40,int(*)(uintptr_t))(tx.group);
  FN(0x19cea40,void(*)(uintptr_t,unsigned))(tx.processor,1);tx.processor=0;
 }
 if(tx.processor)FN(0x19cc6b0,void(*)(void*))(&tx);
 if(!tx.processor&&tx.owner)FN(0x123bca0,void(*)(uintptr_t))(tx.owner);
 if(sample.owner)FN(0x123bca0,void(*)(uintptr_t))(sample.owner);
 pc_mix_route_program(bjob.plan.program);
 if(success){pc_diag_flag(1,2048);
  /* Empty destination has no synth to detach. Native sample assignment owns
   * undo; use the same UI-owned setters as the sends menu after commit. */
  unsigned routed=pc_mix_set_controls(target.program,target.instrument,(uint64_t)601<<42)&&pc_sc_set(target.program,target.instrument,0);
  pc_diag_value(12,routed);
  /* Select the newly assigned pad through the native typed property so the
   * waveform/selection and pad lamps show the result immediately. */
  FN(0x13b3740,void(*)(uintptr_t,unsigned))(target.project+0x4b0,target.index);
  host.ui.source=target.source;
  static char loaded[]="Bounce loaded: A01";unsigned pad=target.source%16+1;
  loaded[15]='A'+target.source/16;loaded[16]='0'+pad/10;loaded[17]='0'+pad%10;
  host.ui.message=loaded;cleanup();
 }else failed("Commit failed; WAV retained in mpc-bounces");
}
void pc_bounce_poll(void){
 pc_diag_add(4);
 __atomic_store_n(&bjob.queued,0,RL);if(!pc_bounce_busy())return;
 uintptr_t m=bjob.generator?Q(bjob.generator,0xc8):0;
 if(!pc_bounce_current(&bjob.plan))__atomic_store_n(&bjob.cancel,1,RL);
 pc_diag_value(5,m?(*(uint8_t*)(m+0x10)&1):2);pc_diag_value(6,load(&bjob.status));
 if(bjob.mixdown&&m&&!(*(uint8_t*)(m+0x10)&1)){
  if(!load(&bjob.status))__atomic_store_n(&bjob.status,load(&bjob.cancel)?2:1,RL);
  finish();
 }
}
int pc_bounce_event(unsigned kind,unsigned data){
 if(kind==30&&!pc_bounce_busy()){bjob.modal=1;bjob.choice=0;host.ui.message=0;return 1;}
 if(!pc_bounce_modal())return 0;
 if(pc_bounce_busy()){if(kind==12&&(data==0||data==2))__atomic_store_n(&bjob.cancel,1,RL);return 1;}
 if(kind==14){int64_t v=(int64_t)bjob.choice+(int32_t)data;bjob.choice=v<=0?0:1;}
 else if(kind==12){if(data==0||data==2)bjob.modal=0;else if(data==3)return 2;}
 return 1;
}

void pc_bounce_progress(uint64_t*f,uint64_t*t,unsigned*c,unsigned*x){*f=__atomic_load_n(&bjob.frames,AQ);*t=__atomic_load_n(&bjob.total,AQ);*c=bjob.choice;*x=load(&bjob.cancel);}
