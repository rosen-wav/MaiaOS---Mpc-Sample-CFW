/* SPDX-License-Identifier: GPL-3.0-only */
#include "groove.h"

const char *const pc_groove_folders[GROOVE_FOLDERS] = {
    "Kick", "Snare", "Hi-Hat", "Perc", "Bass", "Lead", "Arp Chords"
};

/* Native resolution is 960 PPQ. Hat offsets are measured from the four
 * eighth-note offbeats. They stay in the bar and retain individual accents. */
#define HIT(step, velocity) { (step) * 240, (velocity) }
#define OFF(beat, offset, velocity) { (beat) * 960 + 480 + (offset), (velocity) }

static const PcGroovePattern kicks[] = {
    {"4 on the Floor", {HIT(0,116), HIT(4,108), HIT(8,112), HIT(12,108)}},
    {"Detroit Techno Drive", {HIT(0,120), HIT(4,111), HIT(7,75), HIT(8,116), HIT(12,110), HIT(14,83)}},
    {"UK Garage Two-Step", {HIT(0,115), HIT(6,102), HIT(10,109), HIT(15,86)}},
    {"Trap 808 Bounce", {HIT(0,122), HIT(3,102), HIT(7,112), HIT(10,118), HIT(14,106)}},
    {"R&B Pocket", {HIT(0,115), HIT(6,84), HIT(8,108), HIT(11,93)}},
    {"IDM Broken Grid", {HIT(0,119), HIT(3,76), HIT(5,105), HIT(9,113), HIT(13,99), HIT(15,64)}},
    {"Boom Bap Push", {HIT(0,119), HIT(2,92), HIT(7,83), HIT(8,114), HIT(10,101)}},
    {"Dancehall Bounce", {HIT(0,116), HIT(7,101), HIT(8,109), HIT(14,97)}},
};

static const PcGroovePattern snares[] = {
    {"Classic 2 & 4", {HIT(4,112), HIT(12,116)}},
    {"Halftime Beat 3", {HIT(8,116)}},
    {"Classic Boom Bap Ghosts", {HIT(3,36), HIT(4,117), HIT(9,42), HIT(12,113), HIT(15,29)}},
    {"Classic R&B Drag", {{900,34}, HIT(4,108), HIT(7,39), {2808,31}, HIT(12,114)}},
    {"Classic Funk Push", {HIT(2,45), HIT(4,116), HIT(6,35), HIT(10,48), HIT(12,112), HIT(14,38)}},
    {"Classic IDM Stutter", {HIT(4,112), HIT(5,56), {2700,45}, HIT(12,119), {2980,67}, HIT(15,42)}},
    {"Halftime Trap Rolls", {HIT(6,38), HIT(7,56), HIT(8,121), {3360,35}, {3480,46}, {3600,63}}},
    {"Halftime R&B Ghosts", {HIT(2,32), {1740,42}, HIT(8,112), HIT(13,37)}},
    {"Halftime Dubstep Fill", {HIT(3,40), HIT(8,122), HIT(11,51), HIT(14,67), HIT(15,44)}},
};

static const PcGroovePattern hats[] = {
    {"Hi-Hat Octave / 8ths", {HIT(0,96), HIT(2,67), HIT(4,86), HIT(6,63), HIT(8,92), HIT(10,69), HIT(12,85), HIT(14,66)}},
    {"Offbeat Hi-Hat", {OFF(0,0,99), OFF(1,0,92), OFF(2,0,97), OFF(3,0,94)}},
    {"Sloppy 01 - House", {OFF(0,42,101), OFF(1,68,84), OFF(2,44,96), OFF(3,76,87)}},
    {"Sloppy 02 - Garage", {OFF(0,112,99), OFF(1,134,81), OFF(2,87,108), OFF(3,140,91)}},
    {"Sloppy 03 - Neo Soul", {OFF(0,81,82), OFF(1,31,103), OFF(2,119,74), OFF(3,57,96)}},
    {"Sloppy 04 - Boom Bap", {OFF(0,145,92), OFF(1,55,72), OFF(2,155,98), OFF(3,71,81)}},
    {"Sloppy 05 - IDM", {OFF(0,19,106), OFF(1,177,61), OFF(2,93,92), OFF(3,210,74)}},
    {"Sloppy 06 - Trap", {OFF(0,53,84), OFF(1,115,110), OFF(2,34,77), OFF(3,172,96), {3590,45}, {3690,58}}},
    {"Sloppy 07 - Detroit", {OFF(0,60,113), OFF(1,39,85), OFF(2,98,105), OFF(3,28,91)}},
    {"Sloppy 08 - Broken Beat", {OFF(0,176,89), OFF(1,83,106), OFF(2,205,76), OFF(3,47,102)}},
    {"Sloppy 09 - R&B Drag", {OFF(0,88,98), OFF(1,121,73), OFF(2,143,93), OFF(3,187,81)}},
    {"Sloppy 10 - Deep House", {OFF(0,24,109), OFF(1,102,81), OFF(2,24,106), OFF(3,102,85)}},
    {"Trap Triplet Rolls", {HIT(0,90), HIT(2,64), HIT(4,86), {1440,73}, {1600,53}, {1760,64}, HIT(8,94), HIT(10,66), HIT(12,92), {3360,78}, {3520,53}, {3680,72}}},
    {"IDM Skip Hats", {HIT(0,84), {314,63}, {723,94}, {1360,70}, {1834,81}, {2180,64}, {2644,98}, {3270,72}, {3587,87}}},
};

static const PcGroovePattern percussion[] = {
    {"Latin 3-2 Clave", {HIT(0,103), HIT(3,83), HIT(6,94), HIT(10,90), HIT(12,98)}},
    {"Afro House Shaker", {HIT(0,84), HIT(1,45), HIT(3,70), HIT(6,90), HIT(7,52), HIT(8,79), HIT(10,55), HIT(11,72), HIT(14,92), HIT(15,52)}},
    {"R&B Rim Pocket", {{552,63}, {1188,100}, {1812,47}, {2480,70}, {3180,96}, {3650,46}}},
    {"Trap Rim Syncopation", {HIT(3,75), HIT(7,98), HIT(10,61), HIT(14,92), HIT(15,58)}},
    {"IDM Metallic Scatter", {{125,79}, {450,109}, {1030,54}, {1345,86}, {1760,63}, {2181,105}, {2700,54}, {3290,93}, {3730,76}}},
    {"Disco Tambourine", {HIT(2,78), HIT(4,103), HIT(6,81), HIT(10,81), HIT(12,106), HIT(14,83)}},
    {"Dub Woodblock", {HIT(2,100), HIT(7,77), HIT(10,94), HIT(15,68)}},
    {"Funk Conga Pocket", {HIT(0,79), HIT(3,102), HIT(5,53), HIT(7,84), HIT(10,99), HIT(11,52), HIT(14,91)}},
};

static const struct { const PcGroovePattern *patterns; unsigned count; } drums[] = {
    { kicks, sizeof kicks / sizeof *kicks },
    { snares, sizeof snares / sizeof *snares },
    { hats, sizeof hats / sizeof *hats },
    { percussion, sizeof percussion / sizeof *percussion }
};

const PcGroovePattern *pc_groove_pattern(unsigned folder, unsigned index)
{
    return index < pc_groove_pattern_count(folder) ? &drums[folder].patterns[index] : 0;
}

unsigned pc_groove_pattern_count(unsigned folder)
{
    return folder < GROOVE_BASS ? drums[folder].count : 0;
}

int pc_groove_chord_feed(PcChordLane *lane, int pitch, int64_t tick, int64_t end)
{
    unsigned index = 0;
    while (index < 3 && lane->end[index] > tick && lane->pitch[index] != pitch)
        index++;
    if (index == 3) {
        index = 2;
        if (lane->end[index] >= end)
            return 1;
    } else if (lane->end[index] > tick && lane->end[index] >= end) {
        return lane->end[2] > tick;
    }
    while (index && lane->end[index - 1] < end) {
        lane->end[index] = lane->end[index - 1];
        lane->pitch[index] = lane->pitch[index - 1];
        index--;
    }
    lane->end[index] = end;
    lane->pitch[index] = pitch;
    return lane->end[2] > tick;
}
