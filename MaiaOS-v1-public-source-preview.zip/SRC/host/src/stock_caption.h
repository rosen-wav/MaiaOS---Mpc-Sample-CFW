#ifndef PC_STOCK_CAPTION_H
#define PC_STOCK_CAPTION_H

/* Same JUCE caption component as the stock Compressor and File Select
 * actions. Each instance has one fixed title and may move between views. */
typedef uint64_t PcStockCaption[0x220/8];

static inline void pc_stock_caption_hide(PcStockCaption storage,uintptr_t parent){
 uintptr_t caption=(uintptr_t)storage;
 if(Q(caption,0x18)==parent&&(*(uint8_t*)(caption+0xa8)&2))
  FN(0x1172670,void(*)(uintptr_t,unsigned))(caption,0);
}
static inline void pc_stock_caption_init(uintptr_t caption,const char*text){
 if(!Q(caption,0)){
  uintptr_t title=0;
  int style=1;
  FN(0xf535c0,void(*)(uintptr_t*,const char*))(&title,text);
  FN(0x3b7e940,void(*)(uintptr_t,const uintptr_t*,const int*))(caption,&title,&style);
  FN(0xf0a290,void(*)(uintptr_t*))(&title);
 }
}
static inline void pc_stock_caption_bounds(uintptr_t caption,int x,int y,int w,int h){
 if(I(caption,0x20)!=x||I(caption,0x24)!=y||I(caption,0x28)!=w||I(caption,0x2c)!=h)
  FN(0x1160fc0,void(*)(uintptr_t,uint64_t,uint64_t))(caption,(uint32_t)x|((uint64_t)(uint32_t)y<<32),
     (uint32_t)w|((uint64_t)(uint32_t)h<<32));
}
static inline void pc_stock_caption_show(PcStockCaption storage,uintptr_t parent,
                                        const char*text,int x,int y,int w,int h){
 uintptr_t caption=(uintptr_t)storage;
 pc_stock_caption_init(caption,text);
 pc_stock_caption_bounds(caption,x,y,w,h);
 if(Q(caption,0x18)!=parent)
  FN(0x11790b0,void(*)(uintptr_t,uintptr_t,int))(parent,caption,-1);
 else if(!(*(uint8_t*)(caption+0xa8)&2))
  FN(0x1172670,void(*)(uintptr_t,unsigned))(caption,1);
}
/* Draw a stock caption in a paintOverChildren overlay. Keep the attached
 * component hidden from the ordinary child pass so the caption is drawn once. */
static inline void pc_stock_caption_paint(PcStockCaption storage,uintptr_t parent,uintptr_t graphics,
                                         const char *text,int x,int y,int w,int h){
 uintptr_t caption=(uintptr_t)storage;
 pc_stock_caption_init(caption,text);
 if(Q(caption,0)!=host.base+0x706e940)return;
 pc_stock_caption_bounds(caption,x,y,w,h);
 if(Q(caption,0x18)!=parent)
  FN(0x1178f00,void(*)(uintptr_t,uintptr_t,int))(parent,caption,-1);
 FN(0x102d360,void(*)(uintptr_t))(graphics);
 FN(0x102d470,void(*)(uintptr_t,int,int))(graphics,x,y);
 FN(0x10f99b0,void(*)(uintptr_t,uintptr_t))(caption,graphics);
 FN(0x102d3b0,void(*)(uintptr_t))(graphics);
}
#endif
