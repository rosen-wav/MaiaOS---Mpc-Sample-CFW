/* SPDX-License-Identifier: GPL-3.0-only
 * Use the persisted DrumProgram synth-section model, identical to samples.
 * Panel wrappers only insert a stock-filter page; DSP presets stay intact.
 */
#include "internal.h"
#include "synth_filter.h"
/* Native FilterS80 enum from the stock filter selector (0..28). */
static const char*const names[]={"OFF","LP6","LP12","LP24","LP36","LP48","HP6","HP12","HP24","HP36","HP48","BP12","BP24","BP36","BP48","NOTCH12","NOTCH24","NOTCH36","NOTCH48","BOOST12","BOOST24","BOOST36","BOOST48","MODEL1","MODEL2","MODEL3","VOCAL1","VOCAL2","VOCAL3"};
#include "stock_filter.h"
const char *pc_synth_filter_name(unsigned type){return type<PC_STOCK_FILTER_TYPES?names[type]:"STOCK29";}
unsigned pc_synth_filter_type(unsigned position){return position*PC_STOCK_FILTER_TYPES/16384;}
unsigned pc_synth_filter_type_position(unsigned type){
 return type>=PC_STOCK_FILTER_TYPES?16383:(type*16383+14)/(PC_STOCK_FILTER_TYPES-1);
}
static uintptr_t section(uintptr_t i){return i?Q(i,0x2340):0;}
unsigned pc_synth_filter_position(uintptr_t i,unsigned k){
 uintptr_t p=section(i);if(!p||k>=3)return 0;
 if(!k)return pc_synth_filter_type_position(I(p,0x420));
 float f=F(p,k==1?0x498:0x4f0);return !(f>=0)?0:f>=1?16383:(unsigned)(f*16383+.5f);
}
void pc_synth_filter_knob(uintptr_t i,unsigned k,unsigned pos){
 uintptr_t p=section(i);if(!p||k>2||pos>16383)return;
 if(!k){unsigned n=pc_synth_filter_type(pos);
  FN(0x282a4a0,void(*)(uintptr_t,unsigned))(p+0x3d0,n);
 }else {if(k==1&&pos<16383&&I(p,0x420)==0)FN(0x282a4a0,void(*)(uintptr_t,unsigned))(p+0x3d0,2);
 FN(0x13bb930,void(*)(uintptr_t,float))(p+(k==1?0x448:0x4a0),pos*(1.f/16383));}
}
static void percent(char*b,unsigned v){unsigned n=(v*100+8191)/16383;b[0]='0'+n/100;b[1]='0'+n/10%10;b[2]='0'+n%10;b[3]='%';b[4]=0;}
void pc_synth_filter_view(uintptr_t i,MpcPanelView*v){
 memcpy(v->page,"STOCK FILTER",13);
 static const char*const labels[]={"Type","Cutoff","Resonance"};
 for(unsigned k=0;k<3;k++){
  MpcPanelSlot*p=&v->slots[k];memset(p,0,sizeof*p);p->index=500+k;p->maximum=16383;p->current=pc_synth_filter_position(i,k);
  unsigned length=0;do{p->label[length]=labels[k][length];}while(labels[k][length++]);
  if(!k){uintptr_t s=section(i);unsigned mode=s?I(s,0x420):0;
   const char*name=pc_synth_filter_name(mode);unsigned c=0;do{p->value[c]=name[c];}while(name[c++]);
  }else percent(p->value,p->current);
 }
}
int pc_synth_filter_page(const MpcPanelView*v){return !v->browser&&v->slots[0].index==500;}
static struct {
 int (*view)(MpcPanelView*),(*encoder)(int);
 uintptr_t instrument;unsigned generation,slot,count,page,native_count;
 int map[66];
} proxy;
static int view(MpcPanelView*v){
 if(!proxy.view||!proxy.view(v))return 0;
 if(v->browser)return 1;
 v->page_count=proxy.count;v->page_index=proxy.page;
 if(proxy.map[proxy.page]<0)pc_synth_filter_view(proxy.instrument,v);
 return 1;
}
static int encoder(int delta){
 MpcPanelView v;if(!proxy.view(&v))return 0;
 if(v.browser)return proxy.encoder(delta);
 int64_t next=(int64_t)proxy.page+delta;next%=proxy.count;if(next<0)next+=proxy.count;proxy.page=(unsigned)next;
 int native=proxy.map[proxy.page];if(native<0)native=(int)proxy.native_count-1;
 return proxy.encoder(native-(int)v.page_index);
}
static int label_has(const char*s,const char*needle){
 for(unsigned i=0;i<24&&s[i];i++){
  unsigned j=0;while(needle[j]&&i+j<24&&((s[i+j]|32)==needle[j]))j++;
  if(!needle[j])return 1;
 }return 0;
}
void pc_synth_filter_bind(unsigned slot){
 if(slot>=PC_SLOTS)return;Slot*s=&host.slots[slot];
 if(host.mirror.view==view&&proxy.slot==slot&&proxy.instrument==s->instrument&&proxy.generation==s->generation)return;
 if(host.mirror.view==view){host.mirror.view=proxy.view;host.mirror.encoder=proxy.encoder;}
 proxy.view=host.mirror.view;proxy.encoder=host.mirror.encoder;
 MpcPanelView v;if(!proxy.view||!proxy.encoder||!proxy.view(&v)||v.browser||!v.page_count||v.page_count>64)return;
 proxy.slot=slot;proxy.instrument=s->instrument;proxy.generation=s->generation;proxy.count=0;proxy.native_count=v.page_count;
 unsigned original=v.page_index;int output=-1;
 for(unsigned n=0;n<proxy.native_count;n++){
  proxy.encoder((int)n-(int)v.page_index);proxy.view(&v);
  int cutoff=0,resonance=0,type=0;
  for(unsigned k=0;k<3;k++){
   if(label_has(v.slots[k].label,"cutoff"))cutoff=1;
   if(label_has(v.slots[k].label,"resonance"))resonance=1;
   if(label_has(v.slots[k].label,"filter type"))type=1;
  }
  if(s->engine==4&&((cutoff&&resonance)||type))continue;
  if(n+1==proxy.native_count){output=n;continue;}
  proxy.map[proxy.count++]=n;
 }
 proxy.map[proxy.count++]=-1;if(output>=0)proxy.map[proxy.count++]=output;
 proxy.page=0;for(unsigned n=0;n<proxy.count;n++)if(proxy.map[n]==(int)original){proxy.page=n;break;}
 int target=proxy.map[proxy.page];if(target<0)target=proxy.native_count-1;
 proxy.encoder(target-(int)v.page_index);
 host.mirror.view=view;host.mirror.encoder=encoder;
}
/* A synth's default is scoped here, so the saved native fader assignment
 * for ordinary sample pads is never overwritten. Explicit native mapping
 * selections disable the default on that synth pad. */
static struct {uintptr_t instrument;unsigned custom;} fader_pad[PC_SLOTS];
unsigned pc_synth_fader_default(uintptr_t i){
 int k=pc_find(i);if(k<0)return 0;
 if(fader_pad[k].instrument!=i){fader_pad[k].instrument=i;fader_pad[k].custom=0;}
 return !fader_pad[k].custom;
}
void pc_synth_fader_custom(uintptr_t i){int k=pc_find(i);if(k>=0){fader_pad[k].instrument=i;fader_pad[k].custom=1;}}
void pc_synth_fader_reset(uintptr_t i){int k=pc_find(i);if(k>=0){fader_pad[k].instrument=i;fader_pad[k].custom=0;}}
