/* SPDX-License-Identifier: GPL-3.0-only */
#include "audio_features.h"
#include <stddef.h>
extern void *memcpy(void *,const void *,size_t);
extern int memcmp(const void *,const void *,size_t);
static unsigned u16(const uint8_t*p){return p[0]|(unsigned)p[1]<<8;}
static uint32_t u32(const uint8_t*p){return u16(p)|u16(p+2)<<16;}
/* Decode on UI only. RIFF bounds, frame alignment and finite float samples are
 * checked before publishing the immutable buffer to the audio callback. */
int pc_click_decode(PcClick*out,const void*data,unsigned bytes){
 const uint8_t*p=data;if(!out||!p||bytes<12||memcmp(p,"RIFF",4)||memcmp(p+8,"WAVE",4))return 0;
 uint32_t riff=u32(p+4);if(riff<4||riff>bytes-8)return 0;unsigned end=riff+8,fmt=0,channels=0,rate=0,bits=0,align=0;const uint8_t*pcm=0;unsigned pcmbytes=0;
 for(unsigned at=12;at+8<=end;){unsigned n=u32(p+at+4);if(n>end-at-8)return 0;const uint8_t*c=p+at+8;
  if(!memcmp(p+at,"fmt ",4)){if(n<16)return 0;fmt=u16(c);channels=u16(c+2);rate=u32(c+4);align=u16(c+12);bits=u16(c+14);
   if(fmt==0xfffe){if(n<40||u16(c+16)<22||u16(c+18)!=bits)return 0;static const uint8_t tail[12]={0,0,0x10,0,0x80,0,0,0xaa,0,0x38,0x9b,0x71};if(memcmp(c+28,tail,12))return 0;fmt=u32(c+24);}
  }else if(!memcmp(p+at,"data",4)&&!pcm){pcm=c;pcmbytes=n;}
  unsigned step=8+n+(n&1);if(step>end-at){if(8+n==end-at)break;return 0;}at+=step;
 }
 if(!pcm||!pcmbytes||channels<1||channels>2||rate<8000||rate>192000||!(fmt==1&&(bits==8||bits==16||bits==24||bits==32)||fmt==3&&bits==32)||align!=channels*(bits/8)||pcmbytes%align)return 0;
 unsigned source=pcmbytes/align;if(!source||source>(uint64_t)rate*5)return 0;
 unsigned frames=(uint64_t)source*44100/rate;if(!frames||frames>PC_CLICK_FRAMES)return 0;
 /* Linear resampling uses bounded random access to the original immutable RIFF. */
 for(unsigned j=0;j<frames;j++){
  uint64_t pos=(uint64_t)j*rate;unsigned at=pos/44100;float frac=(pos%44100)/44100.f,values[2]={0,0};
  for(unsigned k=0;k<2;k++){unsigned index=at+k;if(index>=source)index=source-1;const uint8_t*s=pcm+index*align;
   for(unsigned ch=0;ch<channels;ch++,s+=bits/8){float x;
    if(fmt==3){uint32_t raw=u32(s);memcpy(&x,&raw,4);if(!(x>=-3.402823466e38f&&x<=3.402823466e38f))return 0;}
    else if(bits==8)x=((int)s[0]-128)/128.f;
    else if(bits==16)x=(int16_t)u16(s)/32768.f;
    else if(bits==24){int32_t v=s[0]|(unsigned)s[1]<<8|(unsigned)s[2]<<16;if(v&0x800000)v|=(int32_t)0xff000000;x=v/8388608.f;}
    else x=(int32_t)u32(s)/2147483648.f;
    if(x>1)x=1;if(x< -1)x=-1;values[k]+=x/channels;
   }
  }out->samples[j]=values[0]+(values[1]-values[0])*frac;
 }
 out->frames=frames;out->rate=44100;return 1;
}
