/* SPDX-License-Identifier: GPL-3.0-only
 * Preserve the stock master-compressor model, controls and meter sources.
 * Replace only ColourCompressor's stereo audio kernel.
 */
#include "internal.h"
#include "pressure6.h"
static void store_float(uintptr_t a,float f){uint32_t bits;memcpy(&bits,&f,4);__atomic_store_n((uint32_t*)a,bits,RL);}
void pc_pressure6_native(uintptr_t owner,const float**in,float**out,uintptr_t end,uintptr_t unused,uintptr_t first){
 if(!owner||Q(owner,0)!=host.base+0x70784a8||!in||!out||!in[0]||!in[1]||!out[0]||!out[1]||end<first||end>4096||Q(owner,0x28)!=6){
  FN(0x3c59c10,void(*)(uintptr_t,const float**,float**,uintptr_t,uintptr_t,uintptr_t))(owner,in,out,end,unused,first);return;
 }
 uintptr_t values=Q(owner,0x18),dsp=Q(owner,0x70),config=dsp?Q(dsp,0xb8):0;
 if(!values||!dsp||!config){FN(0x3c59c10,void(*)(uintptr_t,const float**,float**,uintptr_t,uintptr_t,uintptr_t))(owner,in,out,end,unused,first);return;}
 unsigned bypass=*(uint8_t*)(owner+0x69)&1;
 float input=0,output=0;
 for(unsigned j=first;j<end;j++){
  float l=in[0][j],r=in[1][j];if(!(l>=-64&&l<=64))l=0;if(!(r>=-64&&r<=64))r=0;
  float a=l<0?-l:l,b=r<0?-r:r;if(a>input)input=a;if(b>input)input=b;
  out[0][j]=l;out[1][j]=r;
 }
 float gain=1;
 if(!bypass){
  PcPressure6 p={.amount=F(values,8),.attack_ms=F(config,0),.release_ms=F(config,4),.boost=F(dsp,0x7c),.rate=F(host.base,0x71f4ed0),.colour=0};
  gain=pc_pressure6_process(owner,__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ),out[0]+first,out[1]+first,end-first,&p);
 }
 for(unsigned j=first;j<end;j++){
  float a=out[0][j]<0?-out[0][j]:out[0][j],b=out[1][j]<0?-out[1][j]:out[1][j];if(a>output)output=a;if(b>output)output=b;
 }
 store_float(owner+0xa0,input);store_float(owner+0xa8,output);store_float(dsp+0xc0,gain);
 if(bypass){store_float(owner+0xa4,0);store_float(owner+0xac,0);store_float(owner+0xb0,0);}
}
