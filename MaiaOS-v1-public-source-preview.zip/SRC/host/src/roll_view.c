/* Whole-bar chromatic roll view. Called on UI under host metadata AND the
 * native chord/roll guard, after the original painter updates its cursor.
 * View knobs never shorten playback. A deferred native undoable command repairs
 * an inherited short roll loop outside painting. */
#include "internal.h"
#include "bounce.h"
#include "../theme/layout.h"
#define ROLL_BEAT_TICKS 960u
#define ROLL_BAR_TICKS (4u*ROLL_BEAT_TICKS)
_Static_assert(ROLL_BAR_TICKS==3840u,"4/4 bar at native 960 PPQ");
_Static_assert(ROLL_BAR_TICKS*2u==7680u&&ROLL_BAR_TICKS*4u==15360u&&ROLL_BAR_TICKS*8u==30720u,"whole 4/4 zoom windows");
typedef struct {uintptr_t behaviour,controller,list,program,screen,recorder,last_controller,last_list,last_program,router;int32_t source,last_source,reference,key;uint32_t active,erase,last_valid,held_mask,reentrant,error,b2_owned,b3_owned;uint8_t held[16][64];uint32_t chord_mode,chord_owned,last_pad;uintptr_t loop_track;uint32_t loop_bars,loop_pending;int64_t loop_sequence;}RollView;
enum { ROLL_CLIP_LIMIT=128, ROLL_EVENT_BYTES=56 };
typedef struct {
 int64_t bar,whole,cursor,view,anchor,selection_start,selection_end;
 uint32_t bars,zoom,denominator;
 uint8_t selecting,clip_valid;
 uint32_t clip_count;
 int64_t clip_span;
 uint8_t clip_notes[ROLL_CLIP_LIMIT][ROLL_EVENT_BYTES];
} RollTime;
_Static_assert(offsetof(RollTime,clip_valid)==0x45&&offsetof(RollTime,clip_count)==0x48&&
               offsetof(RollTime,clip_span)==0x50&&offsetof(RollTime,clip_notes)==0x58,"native clipboard ABI");
static struct {
 uintptr_t project;
 unsigned epoch,count;
 int64_t span;
 uint8_t notes[ROLL_CLIP_LIMIT][ROLL_EVENT_BYTES];
} clipboard;
_Static_assert(offsetof(RollView,active)==0x60,"roll view active ABI");
_Static_assert(offsetof(RollView,chord_mode)==0x480,"roll view mode ABI");
_Static_assert(offsetof(RollView,loop_track)==0x490,"roll loop ABI");
_Static_assert(offsetof(RollTime,zoom)==0x3c,"timeline zoom ABI");
/* Shared by the native painter and the overlay, under metadata + roll guard. */
static struct{uintptr_t project,track,sequence,factory;unsigned epoch,pending,queued;}repair;
static int context(RollView**out,RollTime**time,uintptr_t*project,uintptr_t*track,uintptr_t*sequence){
 RollView*r=(RollView*)(pc_state_base()+0x800);uintptr_t b=Q(pc_state_base(),0x20),ctrl=b?Q(b,0x150):0,p=ctrl?Q(ctrl,0x248):0;
 if(!b||!ctrl||!p||Q(p,0)!=host.base+0x6ecc648||r->active!=1||r->behaviour!=b||r->controller!=ctrl||(!r->chord_mode&&(r->list!=Q(ctrl,0xc0)||r->program!=Q(p,0xb8))))return 0;
 uintptr_t seq=Q(p,0x1c8),tr=Q(p,0x140);if(!seq||Q(seq,0)!=host.base+0x6ecdff0||!tr||Q(tr,0)!=host.base+0x6ecf118)return 0;
 int64_t len=*(int64_t*)(seq+0x348);if(len<1||len>(int64_t)ROLL_BAR_TICKS*999)return 0;
 *out=r;*time=(RollTime*)(pc_state_base()+0x2000);*project=p;*track=tr;*sequence=seq;return 1;
}

/* The native encoder handler runs under the roll guard. Keep its copied
 * event values across roll sessions and let its undoable paste use the new
 * pad key and cursor. Never retain an event-list pointer in the clipboard. */
int pc_roll_encoder_click(uintptr_t behaviour,unsigned down){
 int(*native)(uintptr_t,unsigned)=FN(0x74140b8,int(*)(uintptr_t,unsigned));
 RollView*r;RollTime*t;uintptr_t project,track,seq;
 if(!down||I(pc_state_base(),0x5000)||!context(&r,&t,&project,&track,&seq)||
    r->chord_mode||r->behaviour!=behaviour||r->held_mask||!r->program||Q(r->program,0)!=host.base+0x6ec6860)
  return native(behaviour,down);
 unsigned epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 int copying=t->selecting;
 if(clipboard.project&&(clipboard.project!=project||clipboard.epoch!=epoch)){
  clipboard.project=0;
  t->clip_valid=0;
 }
 if(!copying&&clipboard.project){
  t->clip_count=clipboard.count;
  t->clip_span=clipboard.span;
  memcpy(t->clip_notes,clipboard.notes,clipboard.count*ROLL_EVENT_BYTES);
  t->clip_valid=1;
 }
 int handled=native(behaviour,down);
 if(handled&&copying&&!t->selecting&&t->clip_valid&&
    t->clip_span>0&&t->clip_count<=ROLL_CLIP_LIMIT){
  clipboard.project=project;
  clipboard.epoch=epoch;
  clipboard.count=t->clip_count;
  clipboard.span=t->clip_span;
  memcpy(clipboard.notes,t->clip_notes,t->clip_count*ROLL_EVENT_BYTES);
 }
 return handled;
}
int pc_roll_prepare_locked(void){
 RollView*r;RollTime*t;uintptr_t p,track,seq;if(!context(&r,&t,&p,&track,&seq))return 0;
 uint64_t length=*(int64_t*)(seq+0x348);unsigned bars=(unsigned)((length+ROLL_BAR_TICKS-1)/ROLL_BAR_TICKS);
 /* 0x200 is not used as a bar-count proxy. Real 4/4 duration owns the units. */
 if(!r->chord_mode&&r->loop_track==track&&r->loop_bars&&I(track,0x950)==1&&*(uint8_t*)(track+0x960)&&*(int64_t*)(track+0x958)<(int64_t)length&&!repair.pending){
  repair.project=p;repair.track=track;repair.sequence=seq;repair.factory=Q(r->controller,0x240);repair.epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);repair.pending=1;
 }
 if(repair.pending&&!repair.queued){repair.queued=1;FN(0x6d43500,void(*)(uint64_t))((16u<<1)|1u);}
 if(t->bar!=ROLL_BAR_TICKS||t->whole!=ROLL_BAR_TICKS)t->bars=bars;
 t->bar=ROLL_BAR_TICKS;t->whole=ROLL_BAR_TICKS;
 if(t->bars<bars)t->bars=bars;if(t->bars>999)t->bars=999;
 t->zoom=t->zoom>=8?8:t->zoom>=4?4:t->zoom>=2?2:1;
 if(!t->denominator||t->denominator>ROLL_BAR_TICKS)t->denominator=16;
 if(t->cursor<0)t->cursor=0;if((uint64_t)t->cursor>=length)t->cursor=(length-1)/(ROLL_BAR_TICKS/t->denominator)*(ROLL_BAR_TICKS/t->denominator);
 uint64_t span=(uint64_t)ROLL_BAR_TICKS*t->zoom;t->view=(uint64_t)t->cursor/span*span;
 /* View/workspace changes must never enqueue an independent Track loop. */
 r->loop_track=0;r->loop_bars=0;r->loop_pending=0;r->loop_sequence=length;
 return 1;
}
void pc_roll_transport_sync(void){
 repair.queued=0;
 if(!pc_meta()){uintptr_t b=Q(pc_state_base(),0x20),r=b?Q(b,0x58):0;if(r)FN(0x1149d70,void(*)(uintptr_t))(r);return;}if(!FN(0x7410018,int(*)(void))()){pc_unmeta();uintptr_t b=Q(pc_state_base(),0x20),root=b?Q(b,0x58):0;if(root)FN(0x1149d70,void(*)(uintptr_t))(root);return;}
 RollView*r;RollTime*t;uintptr_t p,track,seq;
 if(repair.pending&&context(&r,&t,&p,&track,&seq)&&p==repair.project&&track==repair.track&&seq==repair.sequence&&repair.factory&&Q(r->controller,0x240)==repair.factory&&repair.epoch==__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)){
  int64_t length=*(int64_t*)(seq+0x348);
  if(I(track,0x950)==1&&*(uint8_t*)(track+0x960)&&*(int64_t*)(track+0x958)<length)
   FN(0x195a580,void(*)(uintptr_t,uintptr_t,int64_t,uintptr_t,unsigned))(repair.factory,track,length,0,1);
 }
 repair.pending=0;FN(0x7410098,void(*)(void))();pc_unmeta();
}
void pc_roll_knob_event(unsigned data){
 if(!pc_meta())return;if(!FN(0x7410018,int(*)(void))()){pc_unmeta();return;}
 RollView*r;RollTime*t;uintptr_t p,tr,seq;
 if(context(&r,&t,&p,&tr,&seq)){
  unsigned knob=(data>>16)&3,position=data&16383;uint64_t length=*(int64_t*)(seq+0x348);
  if(knob==0){static const unsigned a[4]={8,4,2,1};unsigned n=position*4u/16384;t->zoom=a[n];}
  if(knob==1){static const unsigned a[5]={4,8,16,32,64};unsigned n=position*5u/16384;t->denominator=a[n];t->cursor=t->cursor/(ROLL_BAR_TICKS/a[n])*(ROLL_BAR_TICKS/a[n]);t->selecting=0;}
  if(knob==2){static const unsigned a[6]={1,2,4,8,16,32};unsigned n=position*6u/16384;t->bars=a[n];}
  pc_roll_prepare_locked();uintptr_t root=Q(r->behaviour,0x58);if(root)FN(0x1149d70,void(*)(uintptr_t))(root);
 }
 FN(0x7410098,void(*)(void))();pc_unmeta();
}

/* The native replacement command changes each old value to its new value
 * together. A note transposed onto another selected note's original pitch
 * stays a distinct event in this multimap. */
typedef struct {
 uintptr_t unused;
 unsigned color,padding;
 uintptr_t parent,left,right;
 uint64_t count;
} RollChanges;
typedef struct { uint64_t header[4]; uint8_t old[56],changed[56]; } RollChangeNode;
_Static_assert(sizeof(RollChanges)==48&&sizeof(RollChangeNode)==144,"native replacement map ABI");

int pc_roll_has_selection(void){
 const RollTime*t=(const RollTime*)(pc_state_base()+0x2000);
 return __atomic_load_n(&t->selecting,AQ)&&__atomic_load_n(&t->selection_start,AQ)>=0&&
        __atomic_load_n(&t->selection_end,AQ)>__atomic_load_n(&t->selection_start,AQ);
}
static void transpose_selection(RollView*r,const RollTime*t,uintptr_t seq,int delta){
 if(!r->list||!r->program||r->source<0||r->source>127||r->key<0||r->key>127||
    I(r->program,0x12a8+4*(unsigned)r->source)!=r->key||r->held_mask||
    !t->selecting||t->selection_start<0||t->selection_end<=t->selection_start)return;
 uintptr_t factory=Q(r->controller,0x240);
 if(!factory||!Q(factory,0x60))return;
 void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 RollChangeNode*(*allocate)(size_t,const void*)=symbol(0,"_ZnwmRKSt9nothrow_t");
 const void*nothrow=symbol(0,"_ZSt7nothrow");
 void(*rebalance)(_Bool,uintptr_t,uintptr_t,uintptr_t)=
     symbol(0,"_ZSt29_Rb_tree_insert_and_rebalancebPSt18_Rb_tree_node_baseS0_RS_");
 if(!allocate||!nothrow||!rebalance)return;
 RollChanges changes={0};uintptr_t header=(uintptr_t)&changes+8;
 changes.left=changes.right=header;
 int64_t limit=*(int64_t*)(seq+0x348);
 if(t->selection_end<limit)limit=t->selection_end;
 uintptr_t list=r->list,end=list+0x68;
 uintptr_t node=FN(0x27d00f0,uintptr_t(*)(uintptr_t,int64_t))(list+0x60,t->selection_start);
 unsigned scanned=0;
 int valid=1;
 for(;node&&node!=end;node=FN(0xb51738,uintptr_t(*)(uintptr_t))(node)){
  if(++scanned>65536){valid=0;break;}
  uintptr_t event=node+0x20;
  if(*(int64_t*)event>=limit)break;
  if(*(uint8_t*)(event+8)!=3||*(uint8_t*)(event+0x30)!=r->key)continue;
  int pitch=(*(uint8_t*)(event+0x14)&1)?(int)*(uint8_t*)(event+0x16)-120:0;
  pitch+=delta;
  /* Keep the whole selection unchanged when any note is out of range. */
  if(pitch< -60||pitch>67||changes.count>=16384){valid=0;break;}
  RollChangeNode *entry=allocate(sizeof *entry,nothrow);
  if(!entry){valid=0;break;}
  memcpy(entry->old,(const void*)event,sizeof entry->old);
  memcpy(entry->changed,entry->old,sizeof entry->changed);
  FN(0x27e4400,void(*)(void*,int,int,int))(entry->changed+0x14,0,0,pitch);
  uintptr_t parent=header,current=changes.parent;
  _Bool left=1;
  while(current){
   parent=current;
   left=FN(0x19d4d70,int(*)(const void*,const void*))(entry->old,(void*)(current+0x20))&1;
   current=Q(current,left?16:24);
  }
  rebalance(left,(uintptr_t)entry,parent,header);
  changes.count++;
 }
 if(valid&&node&&changes.count){
  uintptr_t title=0,merge=0;
  FN(0xf535c0,void(*)(void*,const char*))(&title,delta>0?"Octave Up":"Octave Down");
  FN(0xf1c620,void(*)(void*))(&merge);
  PcNativeReturn command=FN(0x194fd60,PcNativeReturn(*)(uintptr_t,uintptr_t,RollChanges*,void*,void*,uintptr_t,unsigned))
      (factory,list,&changes,&title,&merge,0,0);
  if(command.owner)FN(0x123bca0,void(*)(uintptr_t))(command.owner);
  FN(0xf0a290,void(*)(void*))(&merge);
  FN(0xf0a290,void(*)(void*))(&title);
 }
 if(changes.parent)FN(0x157e620,void(*)(uintptr_t))(changes.parent);
}

void pc_roll_octave_event(int delta){
 if((delta!=12&&delta!=-12)||!pc_meta())return;
 if(FN(0x7410018,int(*)(void))()){
  RollView*r;RollTime*t;uintptr_t project,track,seq;
  if(context(&r,&t,&project,&track,&seq)&&!r->chord_mode)transpose_selection(r,t,seq,delta);
  FN(0x7410098,void(*)(void))();
 }
 pc_unmeta();
}

static struct {uintptr_t screen,list;uint64_t signature;}cache[2];
static uint64_t hash(uint64_t h,uint64_t v){return (h^v)*1099511628211ULL;}
static unsigned number(char*out,unsigned at,uint64_t n){char r[24];unsigned j=0;do{r[j++]='0'+n%10;n/=10;}while(n);while(j)out[at++]=r[--j];out[at]=0;return at;}
static void rect(void*g,int x,int y,int w,int h,unsigned c){if(w<=0||h<=0)return;FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,pc_theme_colour(c));FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);}
static int x_tick(uint64_t tick,uint64_t begin,uint64_t span,int gx,int width){return gx+(int)((tick-begin)*(uint64_t)width/span);}
int pc_roll_view_paint_locked(uintptr_t screen,uintptr_t graphics){
 if(!screen||!graphics||I(pc_state_base(),0x5000))return 0;
 pc_roll_prepare_locked();
 uintptr_t vt=Q(screen,0);if(vt!=host.base+0x6e17160&&vt!=host.base+0x6e24f38)return 0;
 RollView*r=(RollView*)(pc_state_base()+0x800);RollTime*t=(RollTime*)(pc_state_base()+0x2000);
 uintptr_t b=Q(pc_state_base(),0x20),ctrl=b?Q(b,0x150):0,p=ctrl?Q(ctrl,0x248):0;
 if(r->active!=1||r->chord_mode||!b||r->behaviour!=b||r->controller!=ctrl||!p||Q(p,0)!=host.base+0x6ecc648||!r->list||!r->program||r->list!=Q(ctrl,0xc0)||r->program!=Q(p,0xb8)||r->source<0||r->source>=128||r->key<0||r->key>=128||I(r->program,0x12a8+4*(unsigned)r->source)!=r->key||r->reference<0||r->reference>=128)return 0;
 if(t->bar<1||t->bar>122880||t->whole<1||t->whole>122880||!t->bars||t->bars>999||t->cursor<0)return 0;
 uintptr_t seq=Q(p,0x1c8);if(!seq||Q(seq,0)!=host.base+0x6ecdff0)return 0;
 int64_t sequence_length=*(int64_t*)(seq+0x348);if(sequence_length<1)return 0;
 /* A displayed bar is always four quarter notes at the native 960 PPQ.
  * Never derive its width from sequence/workspace/independent loop length. */
 const uint64_t bar=ROLL_BAR_TICKS;
 unsigned zoom=t->zoom>=8?8:t->zoom>=4?4:t->zoom>=2?2:1;t->zoom=zoom;
 uint64_t span=bar*zoom,cursor=t->cursor,begin=cursor/span*span,end=begin+span;
 uint64_t limit=sequence_length,editor_limit=(uint64_t)t->bar*t->bars;if(editor_limit<limit)limit=editor_limit;
 typedef struct {uint64_t xy,wh;}Bounds;Bounds bounds=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(uint32_t)bounds.wh,h=bounds.wh>>32;
 if(w!=320||h!=240)return 0;
 EiCanvas e={(void*)graphics,rect,w,h};const int gx=26,gw=w-31,top=50,gh=144,bottom=top+gh;
 int bank=I(pc_state_base(),0);if(bank< -2)bank=-2;if(bank>2)bank=2;int low=12*bank-r->reference,high=low+15;
 uint64_t signature=hash(hash(hash(hash(1469598103934665603ULL,begin),span),cursor),r->held_mask);signature=hash(signature,bar);signature=hash(signature,zoom);signature=hash(signature,limit);signature=hash(signature,(unsigned)low);signature=hash(signature,t->selecting);signature=hash(signature,t->selection_start);signature=hash(signature,t->selection_end);
 /* Blank the entire old grid AND its labels; header and native actions stay. */
 ei_rect(&e,0,36,w,h-76,MPC_THEME_BG);
 for(unsigned row=0;row<16;row++){
  int y=top+row*gh/16,rh=gh/16,note=high-row+r->reference,pc=(note%12+12)%12;unsigned black=pc==1||pc==3||pc==6||pc==8||pc==10;
  ei_rect(&e,gx,y,gw,rh,black?MPC_THEME_SURFACE:MPC_THEME_BG);ei_rect(&e,gx,y,gw,1,MPC_THEME_GRID);
  if(!(row&1)){char label[16];int semi=high-row;unsigned a=0;if(semi<0){label[a++]='-';semi=-semi;}number(label,a,semi);pc_theme_text_face_width(&e,ei_rect,1,y,label,12,MPC_THEME_MUTED,0,8,23);}
 }
 if(t->selecting&&t->selection_start>=0&&t->selection_end>t->selection_start){uint64_t l=t->selection_start,rr=t->selection_end;if(l<begin)l=begin;if(rr>end)rr=end;if(rr>l)ei_rect(&e,x_tick(l,begin,span,gx,gw),top,x_tick(rr,begin,span,gx,gw)-x_tick(l,begin,span,gx,gw),gh,MPC_THEME_SELECTED);}
 uint64_t grid=t->denominator?ROLL_BAR_TICKS/t->denominator:0;if(!grid)grid=bar;
 if(grid*gw/span<4)grid=ROLL_BEAT_TICKS;if(!grid)grid=bar;if(grid*gw/span<4)grid=bar;
 for(uint64_t tick=begin;tick<end;tick+=grid)ei_rect(&e,x_tick(tick,begin,span,gx,gw),top,1,gh,MPC_THEME_GRID);
 /* Always show all four beats per bar, regardless of note quantization. */
 for(unsigned beat=1;beat<zoom*4;beat++)ei_rect(&e,x_tick(begin+(uint64_t)beat*ROLL_BEAT_TICKS,begin,span,gx,gw),top,1,gh,MPC_THEME_GRID);
 /* Draw every 4/4 bar boundary independently of quantization/triplet spacing. */
 for(unsigned j=0;j<=zoom;j++){
  int x=gx+j*gw/zoom;ei_rect(&e,x,top,1,gh,MPC_THEME_MUTED);
  if(j<zoom){char label[16];number(label,0,begin/bar+j+1);pc_theme_text_face_width(&e,ei_rect,x+2,38,label,12,MPC_THEME_TEXT,0,9,gw/zoom-3);}
 }
 uintptr_t sentinel=r->list+0x68,node=Q(r->list,0x78);unsigned scanned=0;
 while(node&&node!=sentinel&&scanned++<16384){
  uintptr_t event=node+0x20;int64_t tick=*(int64_t*)event,duration=*(int64_t*)(event+0x28);
  if(tick>=0&&(uint64_t)tick>=end)break;
  if(*(uint8_t*)(event+8)==3&&*(uint8_t*)(event+0x30)==r->key&&tick>=0&&(uint64_t)tick<limit&&duration>0){
   int semi=(*(uint8_t*)(event+0x14)&1)?(int)*(uint8_t*)(event+0x16)-120:0;
   if(semi>=low&&semi<=high){uint64_t left=tick,right=(uint64_t)duration>limit-left?limit:left+duration;
    if(right>begin){if(left<begin)left=begin;if(right>end)right=end;
     int x=x_tick(left,begin,span,gx,gw),x2=gx+(int)(((right-begin)*gw+span-1)/span);if(x2>gx+gw)x2=gx+gw;
     unsigned held=0;for(unsigned k=0;k<16;k++)if(r->held[k][0]&&!memcmp(r->held[k]+8,(void*)event,56)){held=1;break;}
     int nw=x2-x-1;if(nw<2)nw=2;if(x+nw>gx+gw)nw=gx+gw-x;
     ei_rect(&e,x,top+(high-semi)*gh/16+1,nw,gh/16-2,held?MPC_THEME_ACCENT:MPC_THEME_TEXT);
     signature=hash(hash(hash(signature,(uint64_t)tick),(uint64_t)duration),(unsigned)semi);
    }
   }
  }
  node=FN(0xb51738,uintptr_t(*)(uintptr_t))(node);
 }
 ei_rect(&e,gx,top,gw+1,1,MPC_THEME_MUTED);ei_rect(&e,gx,bottom,gw+1,1,MPC_THEME_MUTED);
 ei_rect(&e,x_tick(cursor,begin,span,gx,gw),top,1,gh,MPC_THEME_ACCENT);
 char label[64]="BARS ";unsigned at=number(label,5,begin/bar+1);label[at++]='-';at=number(label,at,begin/bar+zoom);label[at++]=' ';label[at++]='/';label[at++]=' ';at=number(label,at,zoom);label[at++]=' ';label[at++]='B';const char*meter=" / 4/4";while(*meter)label[at++]=*meter++;label[at]=0;
 pc_theme_text_face_width(&e,ei_rect,gx,198,label,40,MPC_THEME_MUTED,0,9,gw);
 char z[4];number(z,0,zoom);ei_rect(&e,0,h-29,44,15,MPC_THEME_BG);ei_text(&e,5,h-27,"Z",10,MPC_THEME_MUTED);ei_text(&e,17,h-27,z,24,MPC_THEME_TEXT);
 pc_diag_value(19,zoom);pc_diag_value(20,bar);pc_diag_value(21,begin);pc_diag_value(22,span);pc_diag_add(23);
 unsigned slot=vt==host.base+0x6e17160?0:1;
 if(cache[slot].screen!=screen||cache[slot].list!=r->list||cache[slot].signature!=signature){cache[slot].screen=screen;cache[slot].list=r->list;cache[slot].signature=signature;FN(0x1149d70,void(*)(uintptr_t))(screen);}
 return 1;
}
