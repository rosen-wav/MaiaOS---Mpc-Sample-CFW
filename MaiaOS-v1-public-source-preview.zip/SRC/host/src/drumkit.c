/* A page tool. Imported samples remain ordinary native pad samples. */
#include "internal.h"
#include "drumkit.h"
#include "drumkit_files.h"
#include "../theme/layout.h"
static char root[512];
#define KIT_LOCKED_MASK UINT64_C(0xffff)
#define KIT_HELD_SHIFT 16
#define KIT_SELECTED_SHIFT 32
#define KIT_SELECTED_MASK (UINT64_C(15)<<KIT_SELECTED_SHIFT)
#define KIT_EDIT (UINT64_C(1)<<36)
#define KIT_LOADED (UINT64_C(1)<<37)
#define KIT_OWNED_SHIFT 40
#define KIT_BUSY (UINT64_C(1)<<38)
typedef struct {uintptr_t instrument,sample;unsigned index;} KitPad;
static struct {
 unsigned active,page,epoch;
 /* Publish input changes and take the Randomize snapshot atomically. */
 uint64_t input;
 uintptr_t project,program,behaviour;
 uint64_t native_colour[16];
 KitPad pads[16];int gain[3];unsigned armed[3],known[3],last[3];
 char paths[16][PC_KIT_PATH],message[96];
} kit;
static unsigned length(const char*s){unsigned n=0;while(s[n])n++;return n;}
static void message(const char*s){unsigned n=length(s);if(n>=sizeof kit.message)n=sizeof kit.message-1;memcpy(kit.message,s,n);kit.message[n]=0;}
static int context(void){
 uintptr_t p=Q(pc_state_base(),0x1d08);
 return p==kit.project&&p&&Q(p,0)==host.base+0x6ecc648&&Q(p,0xb8)==kit.program&&
  Q(pc_state_base(),0x20)==kit.behaviour&&kit.epoch==__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
}
static uintptr_t sample(uintptr_t instrument){uintptr_t layers=instrument?Q(instrument,0x22e8):0;return layers?Q(layers,0x4a8):0;}
static int pad_at(unsigned local,KitPad*out){
 unsigned source=kit.page*16+local;uintptr_t p=kit.program;
 int key=I(p,0x12a8+4*source),index=key>=0&&key<128?I(p,0x14a8+4*(unsigned)key):-1;
 uintptr_t begin=Q(p,0x2808),end=Q(p,0x2810);
 if(index<0||index>=128||(!begin&&end)||end<begin||(end-begin)%8||end-begin>1024)return 0;
 uintptr_t instrument=begin&&(unsigned)index<(end-begin)/8?Q(begin,8*(unsigned)index):0;
 if(instrument&&!pc_valid(p,instrument))return 0;
 *out=(KitPad){instrument,sample(instrument),(unsigned)index};return 1;
}
static int empty(KitPad*p){
 if(!p->instrument)return 1;if(pc_find(p->instrument)>=0)return 0;
 uintptr_t layers=Q(p->instrument,0x22e8);if(layers)for(unsigned n=0;n<8;n++)if(Q(layers,n*0xb30+0x4a8))return 0;
 return 1;
}
unsigned pc_drumkit_active(void){return __atomic_load_n(&kit.active,AQ);}
static int empty_page(unsigned page){
 kit.page=page;
 for(unsigned n=0;n<16;n++){
  if(!pad_at(n,&kit.pads[n])||!empty(&kit.pads[n]))return 0;
  for(unsigned j=0;j<n;j++)if(kit.pads[j].index==kit.pads[n].index)return 0;
 }
 return 1;
}
static uintptr_t raw_pads(void){
 uintptr_t surface=kit.behaviour?Q(kit.behaviour,0x78):0;
 if(surface&&I(surface,0x29d0)==16&&Q(surface,0x29d8))return Q(surface,0x29d8);
 uintptr_t controller=kit.behaviour?Q(kit.behaviour,0x270):0;
 uintptr_t panel=controller&&Q(controller,0)==host.base+0x6d98388?Q(controller,0x198):0;
 return panel&&I(panel,0x20)==16?Q(panel,0x28):0;
}
static void refresh_colours(void);
static int select_native_bank(unsigned source){
 /* SurfaceBehaviour owns the native PadController at +0x270.
  * SelectBankForPad resolves the bank and notifies the hardware listeners. */
 if(Q(kit.behaviour,0)!=host.base+0x6d8bee8)return 0;
 uintptr_t controller=Q(kit.behaviour,0x270);
 if(!controller||Q(controller,0)!=host.base+0x6d98388||
    source>=(unsigned)I(controller,0x1c0))return 0;
 FN(0x1a395e0,void(*)(uintptr_t,unsigned))(controller,source);
 return 1;
}
int pc_drumkit_open(uintptr_t program,unsigned source){
 if(!program||source>=128||Q(program,0)!=host.base+0x6ec6860||I(program,0x1234))return 0;
 kit.project=Q(pc_state_base(),0x1d08);kit.program=program;kit.behaviour=Q(pc_state_base(),0x20);
 kit.epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 if(!kit.behaviour||!context())return 0;
 unsigned requested=source/16;
 if(!empty_page(requested)){
  unsigned page=0;
  while(page<8&&(page==requested||!empty_page(page)))page++;
  if(page==8){host.ui.message="No bank with 16 free pads";return 0;}
  source=page*16;
  if(!select_native_bank(source)){host.ui.message="Cannot select free pad bank";return 0;}
  host.ui.source=source;
 }
 __atomic_store_n(&kit.input,(uint64_t)(source%16)<<KIT_SELECTED_SHIFT,RL);
 memset(kit.gain,0,sizeof kit.gain);memset(kit.armed,0,sizeof kit.armed);memset(kit.known,0,sizeof kit.known);
 uintptr_t pads=raw_pads();
 for(unsigned n=0;n<16;n++){
  uint64_t value=0;
  if(pads)memcpy(&value,(const void*)(pads+n*0x128+0x3c),sizeof value);
  __atomic_store_n(&kit.native_colour[n],value,RL);
 }
 pc_diag_value(65,0);pc_diag_value(66,0);
 message("B3 loads a random kit");__atomic_store_n(&kit.active,1,RL);pc_light_refresh();return 1;
}
static void release(PcNativeReturn*loaded){for(unsigned n=0;n<16;n++)if(loaded[n].owner)FN(0x123bca0,void(*)(uintptr_t))(loaded[n].owner);}
static int targets_unchanged(void){
 if(!context())return 0;
 int loaded=!!(__atomic_load_n(&kit.input,AQ)&KIT_LOADED);
 for(unsigned n=0;n<16;n++){KitPad now;if(!pad_at(n,&now)||now.index!=kit.pads[n].index||now.instrument!=kit.pads[n].instrument)return 0;
  if(loaded){if(now.sample!=kit.pads[n].sample||pc_find(now.instrument)>=0)return 0;}else if(!empty(&now))return 0;
 }return 1;
}
static void randomize(void){
 uint64_t input=__atomic_fetch_or(&kit.input,KIT_BUSY,__ATOMIC_ACQ_REL);
 if(input&KIT_BUSY)return;
 unsigned locked=(unsigned)(input&KIT_LOCKED_MASK);
 if(locked==KIT_LOCKED_MASK||!targets_unchanged()){
  message(locked==KIT_LOCKED_MASK?"All pads are locked":"Page changed / exit and reopen DRUMKIT");
  __atomic_fetch_and(&kit.input,~KIT_BUSY,RL);
  return;
 }
 message("Loading random kit...");
 unsigned failed=0;int64_t now[2]={0};pc_sys(113,1,(long)now,0,0,0,0);
 if(!pc_sd_folder(root,sizeof root,"MPC-Sample/Samples/")){message("SD Root/MPC-Sample/Samples missing");__atomic_fetch_and(&kit.input,~KIT_BUSY,RL);return;}
 if(!pc_kit_pick(root,(uint16_t)locked,(uint32_t)(now[1]^now[0]),kit.paths,&failed)){
  message("Missing or unreadable sample folder: ");unsigned n=length(kit.message),m=length(pc_kit_folders[failed]);if(n+m<sizeof kit.message)memcpy(kit.message+n,pc_kit_folders[failed],m+1);__atomic_fetch_and(&kit.input,~KIT_BUSY,RL);return;
 }
 uintptr_t factory=pc_bounce_service(Q(host.base,0x7165828)),loader=pc_bounce_service(host.base+0x6e08dd0);
 if(!factory||Q(factory,0x28)!=kit.project||!Q(factory,0x60)||!loader){message("Sample import service unavailable");__atomic_fetch_and(&kit.input,~KIT_BUSY,RL);return;}
 PcNativeReturn loaded[16]={0};int ok=1;
 for(unsigned n=0;n<16&&ok;n++)if(!(locked&(1u<<n))){
  uintptr_t file=0;FN(0xf535c0,void(*)(void*,const char*))(&file,kit.paths[n]);
  loaded[n]=FN(0x1df3db0,PcNativeReturn(*)(uintptr_t,uintptr_t*,float))(loader,&file,44100.f);
  FN(0xf0a290,void(*)(void*))(&file);ok=loaded[n].object!=0;
 }
 if(!ok||!targets_unchanged()){release(loaded);message(ok?"Page changed during import":"Cannot decode sample / kit unchanged");__atomic_fetch_and(&kit.input,~KIT_BUSY,RL);return;}
 uint64_t before[16];unsigned roles[16],modes[16];
 for(unsigned n=0;n<16;n++){
  uintptr_t i=kit.pads[n].instrument;
  before[n]=i?pc_mix_controls(i):pc_mix_default();
  roles[n]=i?pc_sc_role(i):0;
  modes[n]=i?(unsigned)I(i,0x1690):0;
 }
 uintptr_t title=0,merge=0;FN(0xf535c0,void(*)(void*,const char*))(&title,"Random Drum Kit");FN(0xf1c620,void(*)(void*))(&merge);
 PcNativeTransaction tx=FN(0x19d0520,PcNativeTransaction(*)(uintptr_t,uintptr_t*,uintptr_t*))(Q(factory,0x60),&title,&merge);
 FN(0xf0a290,void(*)(void*))(&merge);FN(0xf0a290,void(*)(void*))(&title);
 ok=tx.group!=0;
 for(unsigned n=0;n<16&&ok;n++)if(!(locked&(1u<<n))){
  if(I(tx.group,0x28)>1){ok=0;break;}
  FN(0x195bbb0,void(*)(uintptr_t,void*))(factory,&loaded[n]);
  if(I(tx.group,0x28)<=1)FN(0x195e940,void(*)(uintptr_t,uintptr_t,void*,unsigned,int))(factory,kit.program,&loaded[n],kit.pads[n].index,-1);
  KitPad after;ok=I(tx.group,0x28)==0&&pad_at(n,&after)&&after.sample==loaded[n].object;
  if(ok){
   FN(0x2806c90,void(*)(uintptr_t,unsigned))(after.instrument,pc_sample_default_mode(after.sample));
   ok=pc_mix_set_volume(kit.program,after.instrument,kit.gain[pc_kit_gain_group(n)]);
   if(ok&&pc_kit_category[n]==0)ok=pc_sc_set(kit.program,after.instrument,1);
  }
 }
 if(!ok&&tx.processor){
  if(tx.group)FN(0x19c9c40,int(*)(uintptr_t))(tx.group);
  FN(0x19cea40,void(*)(uintptr_t,unsigned))(tx.processor,1);tx.processor=0;
  for(unsigned n=0;n<16;n++)if(!(locked&(1u<<n))){KitPad p;if(pad_at(n,&p)&&p.instrument){FN(0x2806c90,void(*)(uintptr_t,unsigned))(p.instrument,modes[n]);pc_mix_set_controls(kit.program,p.instrument,before[n]);if(roles[n])pc_sc_set(kit.program,p.instrument,roles[n]);else pc_sc_forget(p.instrument,0);}}
 }
 if(tx.processor)FN(0x19cc6b0,void(*)(void*))(&tx);else if(tx.owner)FN(0x123bca0,void(*)(uintptr_t))(tx.owner);
 release(loaded);
 if(ok){for(unsigned n=0;n<16;n++)pad_at(n,&kit.pads[n]);__atomic_fetch_or(&kit.input,KIT_LOADED,RL);pc_mix_route_program(kit.program);pc_light_refresh();message("Kit loaded / B3 randomizes unlocked pads");}
 else message("Import failed / previous kit restored");__atomic_fetch_and(&kit.input,~KIT_BUSY,RL);
}
void pc_drumkit_lock_edit(void){
 if(!pc_drumkit_active())return;
 uint64_t previous=__atomic_fetch_xor(&kit.input,KIT_EDIT,__ATOMIC_ACQ_REL);
 pc_diag_value(65,!(previous&KIT_EDIT));
 pc_light_refresh();
}
int pc_drumkit_pad(unsigned source,unsigned kind){
 if(!pc_drumkit_active()||!context()||source>=128||source/16!=kit.page||kind>2)return 0;
 unsigned pad=source%16;
 uint64_t bit=UINT64_C(1)<<pad,held=bit<<KIT_HELD_SHIFT,owned=bit<<KIT_OWNED_SHIFT;
 if(kind==2)return !!(__atomic_fetch_and(&kit.input,~(held|owned),__ATOMIC_ACQ_REL)&owned);
 uint64_t previous=__atomic_load_n(&kit.input,AQ),next;
 if(kind==1)return !!(previous&owned);
 do{
  if(previous&held)return !!(previous&owned);
  next=previous|held;
  if(previous&KIT_EDIT)next|=owned;
  if(!(previous&KIT_BUSY)){
   next=(next&~KIT_SELECTED_MASK)|((uint64_t)pad<<KIT_SELECTED_SHIFT);
   if((previous&(KIT_EDIT|KIT_LOADED))==(KIT_EDIT|KIT_LOADED))next^=bit;
  }
 }while(!__atomic_compare_exchange_n(&kit.input,&previous,next,1,__ATOMIC_ACQ_REL,AQ));
 if((next^previous)&KIT_LOCKED_MASK){
  pc_diag_value(66,(unsigned)(next&KIT_LOCKED_MASK));
  pc_light_refresh();
 }
 return !!(next&owned);
}
static int physical_index(uintptr_t property,unsigned offset){
 if(!pc_drumkit_active()||!context())return -1;
 uintptr_t pads=raw_pads();
 if(!pads||property<pads+offset)return -1;
 uintptr_t delta=property-pads-offset;
 return delta<16*0x128&&delta%0x128==0?(int)(delta/0x128):-1;
}
int pc_drumkit_pressure(uintptr_t property,float pressure){
 int pad=physical_index(property,0);
 if(pad<0)return 0;
 pc_diag_add(67);
 return pc_drumkit_pad(kit.page*16+(unsigned)pad,pressure>0.f?0:2);
}
int pc_drumkit_panel_pad(uintptr_t panel,unsigned pad,float pressure){
 if(pad>=16||!pc_drumkit_active()||!context()||I(panel,0x48)!=16)return 0;
 uintptr_t physical=raw_pads();
 if(!physical||Q(panel,0x50)!=physical)return 0;
 pc_diag_add(68);
 return pc_drumkit_pad(kit.page*16+pad,pressure>0.f?0:2);
}
void pc_drumkit_close(void){
 if(!__atomic_exchange_n(&kit.active,0,__ATOMIC_ACQ_REL))return;
 if(context())refresh_colours();
 pc_light_refresh();
}
void pc_drumkit_event(unsigned kind,unsigned data){
 if(!pc_drumkit_active())return;
 if(!context()){__atomic_store_n(&kit.active,0,RL);return;}
 uint64_t input=__atomic_load_n(&kit.input,AQ);
 if(input&KIT_BUSY)return;
 if(kind==12){
  if(data==0){
   unsigned selected=(unsigned)((input&KIT_SELECTED_MASK)>>KIT_SELECTED_SHIFT);
   if(input&KIT_LOADED)FN(0x13b3740,void(*)(uintptr_t,int))(kit.project+0x4b0,kit.pads[selected].index);
   pc_drumkit_close();
  }else if(data==2){
   randomize();
  }
 }
 else if(kind==13){unsigned k=data>>16,p=data&65535;if(k>=3||p>16383)return;
  unsigned target=(unsigned)((kit.gain[k]+240)*16383/360),old=kit.last[k];int delta=(int)p-(int)target;
  if(!kit.armed[k]&&((delta>=-128&&delta<=128)||(kit.known[k]&&((old<=target&&p>=target)||(old>=target&&p<=target)))))kit.armed[k]=1;
  kit.last[k]=p;kit.known[k]=1;if(!kit.armed[k]){message("Turn knob through current group gain");return;}
  int gain=-240+(int)((p*360u+8191)/16383);kit.gain[k]=gain;
  for(unsigned n=0;n<16;n++)if(pc_kit_gain_group(n)==k&&kit.pads[n].instrument)pc_mix_set_volume(kit.program,kit.pads[n].instrument,gain);
  message("Group gain stored on the native sample pads");
 }
}
#define KIT_YELLOW UINT64_C(0x3f80000000ffff00)
uint64_t pc_drumkit_hw_colour(uintptr_t property,uint64_t colour){
 int pad=physical_index(property,0x20);
 if(pad<0)return colour;
 __atomic_store_n(&kit.native_colour[pad],colour,RL);
 return (__atomic_load_n(&kit.input,AQ)&(1u<<pad))?KIT_YELLOW:colour;
}
static void refresh_colours(void){
 uintptr_t pads=raw_pads();
 if(!pads)return;
 for(unsigned n=0;n<16;n++){
  uintptr_t property=pads+n*0x128+0x20;
  uint64_t base=__atomic_load_n(&kit.native_colour[n],AQ);
  FN(0x13be8b0,void(*)(uintptr_t,const uint64_t*))(property,&base);
 }

}
void pc_drumkit_refresh_lights(void){
 if(pc_drumkit_active()&&context())refresh_colours();
}
static void rect(void*g,int x,int y,int w,int h,unsigned color){FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,pc_theme_colour(color));FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);}
static void gain_label(char*out,int value){unsigned at=0;out[at++]=value<0?'-':'+';unsigned n=value<0?-value:value;out[at++]='0'+n/100;out[at++]='0'+n/10%10;out[at++]='.';out[at++]='0'+n%10;memcpy(out+at," dB",4);}
int pc_drumkit_paint(uintptr_t screen,uintptr_t graphics){
 if(!pc_drumkit_active())return 0;if(!context()){__atomic_store_n(&kit.active,0,RL);return 0;}
 typedef struct{uint64_t xy,wh;}Bounds;Bounds b=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(uint32_t)b.wh,h=b.wh>>32;if(w<200||h<130||w>1024||h>1024)return 0;
 EiCanvas c={(void*)graphics,rect,w,h};char page[]="PAGE A";page[5]='A'+kit.page;ei_rect(&c,0,0,w,h,MPC_THEME_BG);ei_header(&c,"DRUMKIT",page);
 const char*shorts[]={"KICK","SNARE","CLAP","HAT","PERC","CYMB"};int top=28,bottom=h-83,cellw=(w-16)/4,cellh=(bottom-top)/4;if(cellh<12)cellh=12;
 uint64_t input=__atomic_load_n(&kit.input,AQ);
 for(unsigned n=0;n<16;n++){int x=8+(n%4)*cellw,y=top+(3-n/4)*cellh;unsigned locked=(unsigned)(input&(1u<<n));ei_rect(&c,x,y,cellw-3,cellh-2,locked?0xffffff00u:MPC_THEME_GRID);ei_text(&c,x+3,y+2,shorts[pc_kit_category[n]],cellw-8,locked?0xff000000u:MPC_THEME_TEXT);if(locked)ei_text(&c,x+cellw-13,y+2,"L",10,0xff000000u);}
 const char*groups[]={"KICK","SNARE/CLAP","HAT/PERC/CYMB"};for(unsigned n=0;n<3;n++){int x=8+n*(w-16)/3;char gain[16];gain_label(gain,kit.gain[n]);ei_text(&c,x,h-76,groups[n],(w-24)/3,MPC_THEME_MUTED);ei_text(&c,x,h-60,gain,(w-24)/3,MPC_THEME_TEXT);}
 ei_text(&c,8,h-38,kit.message,w-16,MPC_THEME_ACCENT);ei_rule(&c,h-23);ei_text(&c,8,h-18,(input&KIT_EDIT)?"B1 EXIT  B2 EDIT LOCK ON  B3 RANDOM":"B1 EXIT  B2 EDIT LOCK OFF  B3 RANDOM",w-16,MPC_THEME_MUTED);return 1;
}
