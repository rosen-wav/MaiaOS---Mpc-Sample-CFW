/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_PRESET_DELETE_H
#define PC_PRESET_DELETE_H
#include "../theme/layout.h"

enum {PC_PRESET_ERASE=4, PC_KEEP=1, PC_DELETE=2};

static inline unsigned pc_delete_choice(unsigned choice,int delta){
 return delta<0?PC_KEEP:delta>0?PC_DELETE:choice;
}
static inline void pc_delete_paint(EiCanvas *c,const char *name,unsigned choice){
 ei_header(c,"PRESETS","CONFIRM");
 ei_heading(c,8,29,"delete preset?",c->w-16);
 int y=c->h>=175?85:56;
 ei_text(c,12,y,name,c->w-24,MPC_THEME_MUTED);
 y+=16;
 for(unsigned i=0;i<2;i++){
  if(choice==i+PC_KEEP)ei_selection(c,y,19);
  ei_text(c,15,y+3,i?"Delete":"Keep",c->w-30,i?MPC_THEME_WARNING:MPC_THEME_TEXT);
  y+=20;
 }
 if(c->h>=175)ei_actions(c,"CANCEL","","ENC CONFIRM");
}
#endif
