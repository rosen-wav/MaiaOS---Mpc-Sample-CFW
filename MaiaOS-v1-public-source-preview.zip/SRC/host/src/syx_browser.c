/* SPDX-License-Identifier: GPL-3.0-only. UI-owned SysEx file/voice browser.
 * No file, bank or import ever changes a live DSP directly. pc_assign uses
 * the existing bounded owner queue and persists the complete 512-byte patch.
 */
#include "internal.h"
#include "syx.h"
#include "../theme/layout.h"
extern void*pc_read_file(const char*,unsigned*);extern void pc_free_file(void*);
static struct{unsigned active,engine,epoch,mode,index,count,voices,voice;uintptr_t program,instrument;char path[512],file[256];struct{char name[256];unsigned dir;}entries[256];PcSyxVoice bank[PC_SYX_MAX];uint8_t dents[4096];const char*message;}sx;
static unsigned len(const char*s){unsigned n=0;while(s&&s[n])n++;return n;}
static int copy(char*d,unsigned n,const char*s){unsigned k=len(s);if(k>=n)return 0;memcpy(d,s,k+1);return 1;}
static int extension(const char*s,const char*ext){unsigned n=len(s),k=len(ext);if(n<k)return 0;for(unsigned j=0;j<k;j++){char c=s[n-k+j];if(c>='A'&&c<='Z')c+=32;if(c!=ext[j])return 0;}return 1;}
static int suffix(const char*s){return sx.engine==9?(extension(s,".bassline")||extension(s,".vstpreset")):extension(s,".syx");}
static unsigned mode(void){uintptr_t b=Q(pc_state_base(),0x20),m=b?Q(b,0x30):0;if(!m)return 0;unsigned id=I(m,0xd8);return id==0x3080?(unsigned)I(m,0x80):id;}
static void scan(void){
 sx.count=sx.index=0;sx.message=0;long fd=pc_sys(56,-100,(long)sx.path,0x8c000,0,0,0);
 if(fd<0){sx.message="Cannot open folder";return;}
 for(unsigned pass=0;pass<4096;pass++){
  long n=pc_sys(61,fd,(long)sx.dents,sizeof sx.dents,0,0,0);if(n<0){sx.message="Cannot read folder";break;}if(!n)break;
  unsigned at=0;while(at<(unsigned)n){uint8_t*d=sx.dents+at;if((unsigned)n-at<20){sx.message="Invalid directory entry";break;}unsigned size=d[16]|(unsigned)d[17]<<8;if(size<20||size>(unsigned)n-at){sx.message="Invalid directory entry";break;}
   char*name=(char*)d+19;unsigned k=0;while(k<size-19&&name[k])k++;
   if(k&&k<size-19&&k<256&&name[0]!='.'&&sx.count<256){unsigned dir=d[18]==4,regular=d[18]==8;
    if(!d[18]){long child=pc_sys(56,fd,(long)name,0x8c000,0,0,0);if(child>=0){dir=1;pc_sys(57,child,0,0,0,0,0);}else regular=1;}
    if(dir||regular&&suffix(name)){copy(sx.entries[sx.count].name,256,name);sx.entries[sx.count++].dir=dir;}
   }at+=size;
  }if(sx.message)break;
 }
 pc_sys(57,fd,0,0,0,0,0);
 for(unsigned i=1;i<sx.count;i++)for(unsigned j=i;j;j--){unsigned less=sx.entries[j].dir>sx.entries[j-1].dir;if(sx.entries[j].dir==sx.entries[j-1].dir){unsigned k=0;const char*a=sx.entries[j].name,*b=sx.entries[j-1].name;while(a[k]&&a[k]==b[k])k++;less=(unsigned char)a[k]<(unsigned char)b[k];}if(!less)break;char t[260];memcpy(t,&sx.entries[j],260);memcpy(&sx.entries[j],&sx.entries[j-1],260);memcpy(&sx.entries[j-1],t,260);}
}
unsigned pc_syx_active(void){return __atomic_load_n(&sx.active,AQ);}
void pc_syx_close(void){__atomic_store_n(&sx.active,0,RL);sx.voices=0;}
int pc_syx_open(uintptr_t p,uintptr_t i){
 int k=pc_find(i);if(k<0||host.slots[k].program!=p||(host.slots[k].engine!=4&&host.slots[k].engine!=7&&host.slots[k].engine!=9)||pc_audio_config_scope()||mode()!=0x20a7)return 0;
 Slot*s=&host.slots[k];if(!pc_mirror_use(s->engine)||!pc_backend_panel_load(&host.mirror,s->engine,s->preset,s->patch))return 0;
 host.ui.loaded_slot=(unsigned)k;host.ui.loaded_valid=1;pc_preview_stop();unsigned previous=sx.engine;sx.program=p;sx.instrument=i;sx.engine=s->engine;sx.epoch=host.project_epoch;sx.mode=mode();sx.voices=sx.voice=0;if(previous!=sx.engine||!sx.path[0])copy(sx.path,sizeof sx.path,"/media/MPCSSH");scan();__atomic_store_n(&sx.active,1,RL);return 1;
}
static void back(void){
 if(sx.active==2){sx.voices=0;__atomic_store_n(&sx.active,1,RL);sx.message=0;return;}
 unsigned n=len(sx.path);if(n<=13)return;while(n>13&&sx.path[n-1]!='/')n--;if(n>13)n--;sx.path[n]=0;scan();
}
static void choose(uintptr_t p,uintptr_t i){
 if(sx.active==2){uint8_t patch[512];if(!sx.voices||sx.voice>=sx.voices)return;
  if(!pc_syx_make_patch(&sx.bank[sx.voice],patch)||!pc_assign(p,i,sx.engine,0,patch)){sx.message="Release notes / engine busy";return;}
  pc_syx_close();host.ui.message=sx.engine==9?"TAL loaded / SHIFT+SELECT save":"SysEx loaded / SHIFT+SELECT save";return;
 }
 if(!sx.count)return;char path[512];unsigned n=len(sx.path),k=len(sx.entries[sx.index].name);if(n+k+2>sizeof path){sx.message="Path too long";return;}
 memcpy(path,sx.path,n);path[n++]='/';memcpy(path+n,sx.entries[sx.index].name,k+1);
 if(sx.entries[sx.index].dir){copy(sx.path,sizeof sx.path,path);scan();return;}
 unsigned bytes=0;void*data=pc_read_file(path,&bytes);if(!data){sx.message=sx.engine==9?"Cannot read TAL preset":"Cannot read .syx file";return;}
 int count=pc_syx_parse(data,bytes,sx.engine,sx.bank,PC_SYX_MAX);pc_free_file(data);
 if(count<0){sx.voices=0;sx.message=sx.engine==9?"Invalid or unsupported TAL preset":count==-2?"Wrong synth or unsupported SysEx":count==-3?"Bank limit: 128 voices":count==-4?"SysEx checksum mismatch":"Invalid or truncated SysEx";return;}
 sx.voices=count;sx.voice=0;copy(sx.file,sizeof sx.file,sx.entries[sx.index].name);sx.message=sx.engine==9?(sx.bank[0].raw[143]?"FM / ARP / SEQ omitted; ENC load":"8 OSC / shared filter; ENC load"):0;__atomic_store_n(&sx.active,2,RL);
}
int pc_syx_event(unsigned kind,unsigned data,uintptr_t p,uintptr_t i){
 if(!pc_syx_active())return 0;int k=pc_find(i);
 if(mode()!=sx.mode||pc_audio_config_scope()||host.project_epoch!=sx.epoch||p!=sx.program||i!=sx.instrument||k<0||host.slots[k].engine!=sx.engine){pc_syx_close();return 1;}
 if(kind==33||kind==36||kind==11){pc_syx_close();return 1;}
 if(kind==14||kind==35){unsigned count=sx.active==2?sx.voices:sx.count;int64_t pos=(sx.active==2?sx.voice:sx.index)+(int64_t)(int32_t)data;if(pos<0)pos=0;if(pos>=(int64_t)count)pos=count?count-1:0;if(sx.active==2)sx.voice=pos;else sx.index=pos;if(sx.engine!=9||sx.active!=2)sx.message=0;}
 else if(kind==12){if(data==0)back();else if(data==2)pc_syx_close();else if(data==3)choose(p,i);else if(data==1){if(sx.active==2){back();}else{pc_syx_close();host.mirror.button(2);}}}
 return 1;
}
static void rect(void*g,int x,int y,int w,int h,unsigned c){FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,c);FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);}
static void visible(char*out,const char*name,unsigned limit){unsigned n=len(name);if(n<=limit){copy(out,limit+1,name);return;}unsigned first=limit-15;memcpy(out,name,first);memcpy(out+first,"...",3);memcpy(out+first+3,name+n-12,12);out[limit]=0;}
static unsigned number(char*out,unsigned at,unsigned n){char b[12];unsigned k=0;do{b[k++]='0'+n%10;n/=10;}while(n);while(k)out[at++]=b[--k];out[at]=0;return at;}
int pc_syx_paint(uintptr_t g,int w,int h){
 if(!pc_syx_active()||w<200||h<130)return 0;EiCanvas e={(void*)g,rect,w,h};char counter[24];unsigned at=number(counter,0,sx.voice+1);counter[at++]='/';number(counter,at,sx.voices);ei_header(&e,sx.engine==9?"RS-01 / TAL PRESETS":sx.engine==4?"FM6 / SYSEX":"CZ-1 / SYSEX",sx.active==2?counter:sx.engine==9?"TAL FILES":".SYX");ei_heading(&e,8,30,sx.engine==9?(sx.active==2?"load preset.":"import tal."):sx.active==2?"choose tone.":"import syx.",w-16);
 char path[40];visible(path,sx.active==2?sx.file:sx.path,38);ei_text(&e,8,64,path,w-16,MPC_THEME_MUTED);
 unsigned rows=h>128?(h-128)/18:1;if(!rows)rows=1;unsigned index=sx.active==2?sx.voice:sx.index,count=sx.active==2?sx.voices:sx.count,first=index>=rows?index-rows+1:0;
 for(unsigned row=0;row<rows&&first+row<count;row++){unsigned n=first+row;int y=83+18*row;if(n==index)ei_selection(&e,y,17);char label[40];visible(label,sx.active==2?sx.bank[n].name:sx.entries[n].name,35);if(sx.active==1&&sx.entries[n].dir){unsigned z=len(label);if(z<36){label[z++]='/';label[z]=0;}}ei_text(&e,15,y+2,label,w-30,MPC_THEME_TEXT);}
 if(!count)ei_text(&e,8,85,sx.engine==9?"No .bassline / .vstpreset here":"No .syx files in this folder",w-16,MPC_THEME_MUTED);
 ei_actions(&e,"BACK",sx.active==2?"FILES":"FACTORY","CANCEL");ei_notice(&e,sx.message?sx.message:"ENC open / select / load");return 1;
}
