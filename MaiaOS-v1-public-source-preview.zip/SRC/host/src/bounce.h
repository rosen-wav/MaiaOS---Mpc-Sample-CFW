/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_BOUNCE_H
#define PC_BOUNCE_H
#include <stdint.h>
typedef struct {uintptr_t project,program,instrument,sequence,track;unsigned epoch,source,index,seqindex,mode;int64_t ticks;float bpm;} PcBouncePlan;
uint64_t pc_bounce_time_ns(void);void pc_sc_bounce_reset(void);
unsigned pc_bounce_busy(void);unsigned pc_bounce_modal(void);
int pc_mix_bounce_render(uintptr_t,uintptr_t,uintptr_t,unsigned);
void pc_mix_bounce_begin(void);
int pc_bounce_start(void);int pc_bounce_event(unsigned,unsigned);void pc_bounce_poll(void);void pc_bounce_schedule(void);void pc_bounce_retry(void);
int pc_bounce_paint(uintptr_t,int,int);void pc_bounce_lcd(uintptr_t,uintptr_t);
void pc_bounce_export(uintptr_t,uintptr_t,unsigned);void pc_bounce_enter(uintptr_t);void pc_bounce_block(uintptr_t);void pc_bounce_collect(uintptr_t,unsigned);void pc_bounce_status(uintptr_t,unsigned);
int pc_bounce_input(uintptr_t,unsigned,unsigned);void pc_bounce_fx(uintptr_t,unsigned);
uintptr_t pc_bounce_service(uintptr_t);int pc_bounce_current(const PcBouncePlan*);
int pc_bounce_sequence_prepare(const PcBouncePlan*);int pc_bounce_sequence_apply(uintptr_t);void pc_bounce_sequence_clear(void);
int pc_bounce_history(uintptr_t,const PcBouncePlan*);void pc_bounce_detach(uintptr_t);void pc_bounce_voices_reset(void);
/* These C aggregates deliberately exceed 16 bytes: native C++ returns use x8. */
typedef struct {uintptr_t object,owner,padding[6];} PcNativeReturn;
typedef struct {uintptr_t processor,group,owner,padding[5];} PcNativeTransaction;
#endif
