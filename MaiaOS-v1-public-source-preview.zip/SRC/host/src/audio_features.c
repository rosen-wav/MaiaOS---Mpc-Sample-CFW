/* SPDX-License-Identifier: GPL-3.0-only
 * UI owns imports, loading and project serialization. Audio sees immutable
 * click banks and atomic numeric controls; it never performs file operations. */
#include "internal.h"
#include "audio_features.h"
#include "stock_filter.h"
#include "synth_filter.h"
#include "../theme/layout.h"
#define INPUT_FILTER_DEFAULT (PC_STOCK_FILTER_VOCAL1 | (16383ull<<5))
static uint64_t input_filter_settings=INPUT_FILTER_DEFAULT;
static PcStockFilter input_filter;
static unsigned input_filter_epoch;
static unsigned filter_value(uint64_t settings,unsigned knob){
 if(!knob)return (unsigned)settings&31;
 return (unsigned)(settings>>(knob==1?5:19))&16383;
}
#define PC_TUNE_SPEED_DEFAULT ((120u*16383u+200u)/400u)
static struct {
 unsigned page,queued,sends[3],controls[6],enabled,hold,hold_fired;uint64_t began;
 uintptr_t input_object;void *tune;void*(*create)(double);void(*process)(void*,float*,float*,unsigned);void(*enable)(void*,unsigned);void(*set)(void*,unsigned,unsigned);void(*harmony)(void*,unsigned);
 PcClick clicks[3];unsigned published,reader,cursor;float click_gain;
 char click_path[160],path[512];unsigned count,index,error;
 struct {char name[256];unsigned dir;} entries[256];uint8_t dents[4096];
 unsigned armed[3],known[3],last[3],knob_page;
}audio={.controls={0,0,PC_TUNE_SPEED_DEFAULT,0,0,8192},.published=3,.reader=3};
static unsigned state_epoch,pending_audio,chord_mask;
void pc_audio_chord(unsigned key,unsigned down){(void)key;(void)down;}
static unsigned length(const char*s){unsigned n=0;while(s&&s[n])n++;return n;}
static int copy(char*d,unsigned cap,const char*s){unsigned n=length(s);if(n>=cap)return 0;memcpy(d,s,n+1);return 1;}
static uint64_t millis(void){int64_t t[2];if(pc_sys(113,1,(long)t,0,0,0,0))return 0;return (uint64_t)t[0]*1000+t[1]/1000000;}
static unsigned pos(unsigned*p){return __atomic_load_n(p,AQ);}
int pc_audio_config_scope(void){
 uintptr_t b=Q(pc_state_base(),0x20),root=b?Q(b,0x58):0;
 return root&&__atomic_load_n((uintptr_t*)(pc_state_base()+0x1f90),AQ)==root&&__atomic_load_n((unsigned*)(pc_state_base()+0x1f88),AQ);
}
unsigned pc_audio_page(void){
 unsigned page=pos(&audio.page);if(!page)return 0;
 uintptr_t b=Q(pc_state_base(),0x20),m=b?Q(b,0x30):0;int id=m?I(m,0xd8):0;if(id==0x3080)id=I(m,0x80);
 if(page==3?id!=0x20a9:!pc_audio_config_scope()){__atomic_store_n(&audio.page,0,RL);return 0;}return page;
}
unsigned pc_input_send(unsigned k){return k<3?pos(&audio.sends[k]):0;}
static void disarm(void){memset(audio.armed,0,sizeof audio.armed);memset(audio.known,0,sizeof audio.known);}
static int pickup(unsigned k,unsigned value,unsigned target){int d=(int)value-(int)target;unsigned old=audio.last[k];if(!audio.armed[k]&&((d>=-128&&d<=128)||(audio.known[k]&&((old<=target&&value>=target)||(old>=target&&value<=target)))))audio.armed[k]=1;audio.known[k]=1;audio.last[k]=value;return audio.armed[k];}
static int tune_ready(void){
 if(audio.tune)return 1;
 void*h=FN(0xb518a8,void*(*)(const char*,int))("/run/mpc-pc-integrated-v040/libmpc-autotune.aarch64.so",2);if(!h)return 0;
 void*(*sym)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 audio.create=sym(h,"mpc_autotune_create");audio.process=sym(h,"mpc_autotune_process");audio.enable=sym(h,"mpc_autotune_enable");audio.set=sym(h,"mpc_autotune_set_control");audio.harmony=sym(h,"mpc_autotune_set_harmony");
 unsigned(*version)(void)=sym(h,"mpc_autotune_harmony_version");if(!audio.harmony||!version||version()!=1)return 0;
 if(!audio.create||!audio.process||!audio.enable||!audio.set)return 0;
 void*t=audio.create(44100);if(!t)return 0;for(unsigned k=0;k<6;k++)audio.set(t,k,pos(&audio.controls[k]));audio.enable(t,pos(&audio.enabled));__atomic_store_n(&audio.tune,t,RL);return 1;
}
/* Called from the final native input-render point, before the native graph's
 * input inserts. Capture taps keep the original input. */
typedef struct{void*context;void(*process)(void*,float*,float*,unsigned);float*l,*r;unsigned n;}TuneTask;
static void tune_task_run(void*arg){TuneTask*t=arg;audio.harmony(t->context,pc_tune_follow_render(t->n)|(pc_tune_follow_mode()?512u:0u));t->process(t->context,t->l,t->r,t->n);}
void pc_audio_input(uintptr_t object,uintptr_t channels,unsigned n,unsigned offset){
 if(!object||!channels||!n||n>4096)return;if(pc_bounce_input(channels,n,offset))return;
 pc_ms_input(object,channels,n,offset);
 pc_padfx_record_input(object);
 unsigned sends=pc_input_send(0)|pc_input_send(1)|pc_input_send(2);void*t=__atomic_load_n(&audio.tune,AQ);

 uintptr_t first=__atomic_load_n(&audio.input_object,AQ);
 if(!first){uintptr_t expected=0;__atomic_compare_exchange_n(&audio.input_object,&expected,object,0,__ATOMIC_ACQ_REL,AQ);first=__atomic_load_n(&audio.input_object,AQ);}
 if(first!=object)return;float*l=(float*)Q(channels,0),*r=(float*)Q(channels,8);if(!l||!r||l==r)return;l+=offset;r+=offset;
 if(t&&(sends||pos(&audio.enabled))){
  TuneTask task={t,audio.process,l,r,n};PcFxWork work={tune_task_run,&task};
  if(!pc_fx_worker_tune(work,n))tune_task_run(&task);
 }
 unsigned epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 if(epoch!=input_filter_epoch){memset(&input_filter,0,sizeof input_filter);input_filter_epoch=epoch;}
 uint64_t filter=__atomic_load_n(&input_filter_settings,AQ);
 pc_stock_filter_process(&input_filter,filter_value(filter,0),
    filter_value(filter,1)*(1.f/16383),filter_value(filter,2)*(1.f/16383),l,r,n);
 if(sends)pc_mix_external(l,r,n);
}
/* Native beat scheduler calls this immediately after setting its accent gain. */
void pc_audio_tick(uintptr_t object){
 unsigned bank;
 do{bank=__atomic_load_n(&audio.published,__ATOMIC_SEQ_CST);if(bank>=3)return;__atomic_store_n(&audio.reader,bank,__ATOMIC_SEQ_CST);}while(bank!=__atomic_load_n(&audio.published,__ATOMIC_SEQ_CST));
 audio.cursor=0;audio.click_gain=F(object,0x7c);
}
/* Native scheduler splits the block at the exact beat. This replaces only its
 * oscillator segment; native timing, gain, output selection and mask remain. */
int pc_audio_click(uintptr_t object,uintptr_t channels,unsigned n,unsigned offset){
 if(pos(&audio.published)>=3)return 0;
 unsigned bank=pos(&audio.reader);if(bank>=3)return 1;
 PcClick*c=&audio.clicks[bank];float*l=(float*)Q(channels,0),*r=(float*)Q(channels,8);if(!l||!r)return 0;
 for(unsigned j=0;j<n;j++){float x=audio.cursor<c->frames?c->samples[audio.cursor++]*audio.click_gain:0;l[offset+j]+=x;r[offset+j]+=x;}
 F(object,0x7c)=audio.cursor<c->frames?.001f:0.f;return 1;
}
static char lower(char c){return c>='A'&&c<='Z'?c+32:c;}
static int wav(const char*s){unsigned n=length(s);return n>=4&&s[n-4]=='.'&&lower(s[n-3])=='w'&&lower(s[n-2])=='a'&&lower(s[n-1])=='v';}
static int join(char*d,const char*p,const char*n){unsigned a=length(p),b=length(n);if(a+b+2>512)return 0;copy(d,512,p);if(a&&d[a-1]!='/')d[a++]='/';copy(d+a,512-a,n);return 1;}
static void scan(void){
 audio.count=audio.index=audio.error=0;long fd=pc_sys(56,-100,(long)audio.path,0x8c000,0,0,0);if(fd<0){audio.error=1;return;}
 for(;;){long bytes=pc_sys(61,fd,(long)audio.dents,sizeof audio.dents,0,0,0);if(bytes<=0){if(bytes<0)audio.error=1;break;}
  unsigned at=0;while(at<(unsigned)bytes){uint8_t*d=audio.dents+at;if((unsigned)bytes-at<20){audio.error=1;break;}unsigned size=d[16]|(unsigned)d[17]<<8;if(size<20||size>(unsigned)bytes-at){audio.error=1;break;}
   char*name=(char*)d+19;unsigned n=0;while(n<size-19&&name[n])n++;unsigned dir=d[18]==4,regular=d[18]==8;
   if(!d[18]){long child=pc_sys(56,fd,(long)name,0x8c000,0,0,0);if(child>=0){dir=1;pc_sys(57,child,0,0,0,0,0);}else regular=1;}
   if(n&&n<size-19&&n<256&&name[0]!='.'&&(dir||regular&&wav(name))&&audio.count<256){copy(audio.entries[audio.count].name,256,name);audio.entries[audio.count++].dir=dir;}at+=size;
  }if(audio.error)break;
 }pc_sys(57,fd,0,0,0,0,0);
 for(unsigned i=1;i<audio.count;i++)for(unsigned j=i;j;j--){unsigned a=audio.entries[j].dir,b=audio.entries[j-1].dir,less=a>b;if(a==b){unsigned k=0;char*x=audio.entries[j].name,*y=audio.entries[j-1].name;while(x[k]&&y[k]&&lower(x[k])==lower(y[k]))k++;less=(uint8_t)lower(x[k])<(uint8_t)lower(y[k]);}if(!less)break;char temp[260];memcpy(temp,&audio.entries[j],260);memcpy(&audio.entries[j],&audio.entries[j-1],260);memcpy(&audio.entries[j-1],temp,260);}
}
static uint32_t crc(const void*data,unsigned n){const uint8_t*p=data;uint32_t c=~0u;while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=c>>1^(0xedb88320u&-(c&1));}return~c;}
static void hex8(char*out,unsigned v){const char*h="0123456789abcdef";for(unsigned n=0;n<8;n++)out[n]=h[v>>(28-4*n)&15];}
static int import_click(const char*path,int retain){
 unsigned size;void*data=pc_read_file(path,&size);if(!data){host.ui.message="Cannot read WAV (max 8 MiB)";return 0;}
 unsigned published=__atomic_load_n(&audio.published,__ATOMIC_SEQ_CST),reader=__atomic_load_n(&audio.reader,__ATOMIC_SEQ_CST),bank=0;while(bank==published||bank==reader)bank++;
 if(bank>=3||!pc_click_decode(&audio.clicks[bank],data,size)){pc_free_file(data);host.ui.message="Use PCM/float WAV, mono/stereo, max 5 sec";return 0;}
 char stored[160];copy(stored,sizeof stored,path);
 if(retain){const char root[]="/media/MPCSSH/mpc-project-audio";pc_sys(34,-100,(long)root,0755,0,0,0);copy(stored,sizeof stored,root);unsigned at=length(stored);stored[at++]='/';hex8(stored+at,crc(data,size));at+=8;stored[at++]='-';hex8(stored+at,size);at+=8;memcpy(stored+at,".wav",5);
  unsigned oldsize=0;void*old=pc_read_file(stored,&oldsize);int same=old&&size==oldsize&&!memcmp(old,data,size);if(old)pc_free_file(old);
  if(!same){long fd=pc_sys(56,-100,(long)stored,0x80000|0x40|0x80|1,0644,0,0);unsigned done=0;if(fd>=0){while(done<size){long k=pc_sys(64,fd,(long)data+done,size-done,0,0,0);if(k<=0)break;done+=k;}int ok=done==size&&!pc_sys(82,fd,0,0,0,0,0);pc_sys(57,fd,0,0,0,0,0);if(!ok){pc_sys(35,-100,(long)stored,0,0,0,0);done=0;}}
   if(done!=size){pc_free_file(data);host.ui.message="Cannot save custom click on SD";return 0;}
  }
 }pc_free_file(data);if(!pc_native_click_load(stored))return 0;copy(audio.click_path,sizeof audio.click_path,stored);__atomic_store_n(&audio.published,bank,__ATOMIC_SEQ_CST);host.ui.message="Project metronome sample loaded";return 1;
}
void pc_audio_schedule(void){
 pc_bounce_schedule();if(pc_bounce_busy())return;
 unsigned epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 if((epoch!=pos(&state_epoch)||pos(&pending_audio)&&!pc_mix_needs_poll())&&!__atomic_exchange_n(&audio.queued,1,__ATOMIC_ACQ_REL))FN(0x6d43500,void(*)(uint64_t))((29<<1)|1);
 }
void pc_audio_poll(void){__atomic_store_n(&audio.queued,0,RL);}
void pc_audio_close(void){__atomic_store_n(&audio.page,0,RL);disarm();}
int pc_audio_open(unsigned page){
 if(!pc_audio_config_scope()||(page!=1&&page!=2))return 0;
 if(page==1&&!pc_mix_ready()&&!pc_mix_ensure()){host.ui.message="Input sends: FX not ready";return 1;}
 if(page==2&&!tune_ready()){host.ui.message="Autotune library unavailable";return 1;}
 audio.knob_page=0;disarm();host.ui.message=0;__atomic_store_n(&audio.page,page,RL);return 1;
}
int pc_audio_event(unsigned kind,unsigned data){
 unsigned page=pc_audio_page();if(!page){if(kind==28){if(!audio.path[0])copy(audio.path,sizeof audio.path,"/media/MPCSSH");scan();__atomic_store_n(&audio.page,3,RL);host.ui.message=0;return 1;}return 0;}
 if(kind==12){
  if(page==1){if(data==0){
   if(audio.knob_page)__atomic_store_n(&input_filter_settings,INPUT_FILTER_DEFAULT,RL);
   else for(unsigned k=0;k<3;k++)__atomic_store_n(&audio.sends[k],0,RL);
   disarm();
  }else if(data==1){if(tune_ready()){__atomic_store_n(&audio.page,2,RL);audio.knob_page=0;disarm();}else host.ui.message="Autotune library unavailable";}else if(data==2)__atomic_store_n(&audio.page,0,RL);}
  else if(page==2){if(data==0){unsigned enabled=!pos(&audio.enabled);if(enabled&&pc_tune_follow_mode())pc_tune_follow_set(1);audio.enable(audio.tune,enabled);__atomic_store_n(&audio.enabled,enabled,RL);}else if(data==2){__atomic_store_n(&audio.page,0,RL);disarm();}else if(data==3){pc_tune_follow_set(!pc_tune_follow_mode());disarm();host.ui.message=0;}}
  else if(page==3){if(data==2)__atomic_store_n(&audio.page,0,RL);else if(data==1){pc_native_click_restore();__atomic_store_n(&audio.published,3,RL);audio.click_path[0]=0;host.ui.message="Stock metronome restored";}else if(data==0){unsigned n=length(audio.path);while(n>13&&audio.path[n-1]!='/')n--;if(n>13)n--;audio.path[n]=0;scan();}else if(data==3&&audio.count){char p[512];if(join(p,audio.path,audio.entries[audio.index].name)){if(audio.entries[audio.index].dir){copy(audio.path,sizeof audio.path,p);scan();}else if(import_click(p,1))__atomic_store_n(&audio.page,0,RL);}}}
 }else if(kind==14&&page==3&&audio.count){int64_t v=(int64_t)audio.index+(int32_t)data;if(v<0)v=0;if(v>=(int64_t)audio.count)v=audio.count-1;audio.index=v;}
 else if(kind==21&&page<3){unsigned k=(data>>16)&3,shift=(data>>18)&1,p=data&65535;if(k>=3||p>16383)return 1;
  if(audio.knob_page!=shift){audio.knob_page=shift;disarm();}
  if(page==1){
   if(!shift){
    if(pickup(k,p,pc_input_send(k)))__atomic_store_n(&audio.sends[k],p,RL);
   }else{
    uint64_t settings=__atomic_load_n(&input_filter_settings,AQ);
    unsigned old=filter_value(settings,k),target=k?old:pc_synth_filter_type_position(old);
    if(pickup(k,p,target)){
     unsigned bit=k==0?0:k==1?5:19;
     uint64_t mask=(uint64_t)(k?16383:31)<<bit;
     unsigned value=k?p:pc_synth_filter_type(p);
     __atomic_store_n(&input_filter_settings,(settings&~mask)|((uint64_t)value<<bit),RL);
    }
   }
  }
  else{unsigned control=k+3*shift;if(pc_tune_follow_mode()&&control<2){host.ui.message="ENC: switch to MANUAL to edit key";return 1;}if(pickup(k,p,pos(&audio.controls[control]))){audio.set(audio.tune,control,p);__atomic_store_n(&audio.controls[control],p,RL);}}
 }else if(kind==24&&page<3&&audio.knob_page!=(data&1)){audio.knob_page=data&1;disarm();}
 return 1;
}
static int audio_width=320,audio_height=160;
static void rect(uintptr_t g,int x,int y,int w,int h,unsigned c){if(x<0||y<0||w<=0||h<=0||x>=audio_width||y>=audio_height)return;if(w>audio_width-x)w=audio_width-x;if(h>audio_height-y)h=audio_height-y;FN(0x102d5e0,void(*)(uintptr_t,unsigned))(g,pc_theme_colour(c));FN(0x102e000,void(*)(uintptr_t,int,int,int,int))(g,x,y,w,h);}
static void tr(void*g,int x,int y,int w,int h,unsigned c){rect((uintptr_t)g,x,y,w,h,c);}
static void text(uintptr_t g,int x,int y,const char*s,unsigned c){pc_theme_text_fit((void*)g,tr,x,y,s,x<audio_width?(unsigned)(audio_width-x-3):0,c);}
static void number(char*out,unsigned v,const char*unit){unsigned k=0;char b[12];do{b[k++]='0'+v%10;v/=10;}while(v);unsigned at=0;while(k)out[at++]=b[--k];copy(out+at,24-at,unit);}
void pc_input_config_footer(uintptr_t g,int w,int h){
 audio_width=w;audio_height=h;
 /* Header strip only: native input-FX rows and B1 action stay untouched. */
 if(w>=280){EiCanvas e={(void*)g,tr,w,h};int x=w/3;
  ei_rect(&e,x,0,w-x,21,MPC_THEME_BG);
  ei_rect(&e,x,3,1,15,MPC_THEME_GRID);ei_rect(&e,2*w/3,3,1,15,MPC_THEME_GRID);
  ei_text(&e,x+6,5,"B2",18,MPC_THEME_TEXT);ei_text(&e,x+28,5,"AUTO TUNE",w/3-33,MPC_THEME_TEXT);
  ei_text(&e,2*w/3+6,5,"B3",18,MPC_THEME_TEXT);ei_text(&e,2*w/3+28,5,"SENDS",w/3-33,MPC_THEME_TEXT);
 }
}
int pc_audio_paint(uintptr_t g,int w,int h){
 unsigned page=pc_audio_page();if(!page||w<200||h<80)return 0;audio_width=w;audio_height=h;
 EiCanvas e={(void*)g,tr,w,h};
 if(page==3){
  ei_header(&e,"RECORD / METRONOME","WAV");ei_heading(&e,8,30,"metronome.",w-16);ei_text(&e,8,55,audio.path,w-16,MPC_THEME_MUTED);
  unsigned rows=h>120?(h-119)/18:1,first=audio.index>=rows?audio.index-rows+1:0;
  for(unsigned row=0;row<rows&&first+row<audio.count;row++){unsigned n=first+row;int y=74+row*18;if(n==audio.index)ei_selection(&e,y,17);ei_text(&e,15,y+2,audio.entries[n].name,w-30,MPC_THEME_TEXT);}
  if(!audio.count)ei_text(&e,8,78,audio.error?"Cannot open folder":"No WAV samples here",w-16,MPC_THEME_WARNING);
  ei_actions(&e,"BACK","STOCK","EXIT");
 }else{
  unsigned filter_page=page==1&&audio.knob_page;
  uint64_t filter=__atomic_load_n(&input_filter_settings,AQ);
  ei_header(&e,page==1?(filter_page?"INPUT FX / FILTER":"INPUT FX / SENDS"):"INPUT FX / AUTO TUNE",page==1?"LIVE INPUT":pc_tune_follow_mode()?pos(&audio.enabled)?"ON AUTO":"OFF AUTO":pos(&audio.enabled)?"ON MANUAL":"OFF MANUAL");
  ei_heading(&e,8,30,page==1?(filter_page?"stock filter.":"sends."):"auto tune.",w-16);
  ei_text(&e,8,64,page==1?(filter_page?"Release SHIFT for sends":"SHIFT: stock filter"):pc_tune_follow_mode()?"ENC: AUTO MIDI > MANUAL":"ENC: MANUAL > AUTO MIDI",w-16,MPC_THEME_MUTED);
  static const char*labels[]={"ROOT","SCALE","SPEED","TRANSITION","DOUBLE +12","BLEND"},*notes[]={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"},*scales[]={"MAJOR","MINOR","CHROMATIC","PENTA MAJ"};
  int label_y=h>=190?100:77,value_y=label_y+20,bar_y=h>=190?h-66:h-29;unsigned value_h=h>=190?26:18;
  unsigned columns=3;
  for(unsigned k=0;k<columns;k++){
   int x=8+k*w/columns,width=w/columns-16;char label[48]={'K',(char)('1'+k),' ',0},value[24];unsigned posi;const char*v=value,*unit="";const char*l;
   if(filter_page){
    static const char *const filter_labels[]={"TYPE","CUTOFF","RESONANCE"};
    l=filter_labels[k];posi=filter_value(filter,k);
    if(k)number(value,(posi*100+8191)/16383,"%");
    else {v=pc_synth_filter_name(posi);posi=pc_synth_filter_type_position(posi);}
   }else if(page==1){posi=pc_input_send(k);l=pc_fx_name(pc_fx_type(k));number(value,(posi*100+8191)/16383,"%");}
   else{unsigned c=k+3*audio.knob_page;posi=pos(&audio.controls[c]);l=labels[c];if(c==0)v=notes[posi*12/16384];else if(c==1)v=scales[posi*4/16384];else if(c==4)v=posi>=8192?"ON":"OFF";else if(c==5)number(value,(posi*100+8191)/16383,"%");else{number(value,(posi*400+8191)/16383,"");unit="ms";}}
   if(page==2&&pc_tune_follow_mode()&&!audio.knob_page){unsigned harmony=pc_tune_follow_result();if(k==0){l=(harmony&1024)?"KEY / SAMPLE":"KEY / AUTO";v=(harmony&256)?notes[harmony&15]:"WAIT MIDI";}else if(k==1){l="SCALE / AUTO";v=(harmony&256)?((harmony&16)?"MINOR":"MAJOR"):"---";}}
   unsigned n=0;while(n<40&&l&&l[n]){label[3+n]=l[n];n++;}label[3+n]=0;
   if(k)ei_rect(&e,k*w/columns,label_y-3,1,bar_y-label_y+7,MPC_THEME_GRID);
   ei_text(&e,x,label_y,label,width,MPC_THEME_MUTED);ei_value(&e,x,value_y,v,width,value_h,MPC_THEME_TEXT);
   if(unit[0])ei_text(&e,x,value_y+value_h+1,unit,width,MPC_THEME_MUTED);
   ei_bar(&e,x,bar_y,width,posi);
  }
  if(page==1)ei_actions(&e,"RESET","TUNE","CONFIG");else{if(h>=190)ei_text(&e,8,h-49,"SHIFT: controls page 2",w-16,MPC_THEME_MUTED);ei_actions(&e,pos(&audio.enabled)?"BYPASS":"ENABLE","","CONFIG");}
 }
 ei_notice(&e,host.ui.message);return 1;
}
/* Small independent versioned note section. Existing engine/mix sections and
 * user notes survive byte-for-byte. Paths name immutable copied resources. */
typedef struct {uint32_t version,crc,sends[3],controls[6],enabled;char click[160];uint32_t filter[3];} AudioSaved;
static const char tag[]="\n[MPC-PC-AUDIO:1]\n",endtag[]="\n[/MPC-PC-AUDIO]\n";
static char saved_notes[1048576];
static AudioSaved pending_state;
static unsigned bounded(const char*s,unsigned limit){unsigned n=0;if(s)while(n<limit&&s[n])n++;return n;}
static unsigned locate(const char*s,unsigned n,const char*p,unsigned k){for(unsigned j=0;j+k<=n;j++)if(!memcmp(s+j,p,k))return j;return n;}
void pc_audio_info_write(uintptr_t info){
 if(!host.ready||!info)return;if(pos(&pending_audio)){return;}AudioSaved s={0};s.version=3;
 uint64_t filter=__atomic_load_n(&input_filter_settings,AQ);
 for(unsigned k=0;k<3;k++){s.sends[k]=pc_input_send(k);s.filter[k]=filter_value(filter,k);}for(unsigned k=0;k<6;k++)s.controls[k]=pos(&audio.controls[k]);s.enabled=pos(&audio.enabled)|(pc_tune_follow_mode()<<1);copy(s.click,sizeof s.click,audio.click_path);s.crc=crc((char*)&s+8,sizeof s-8);
 const char*old=(const char*)Q(info,0x60);unsigned n=bounded(old,sizeof saved_notes),left=locate(old,n,tag,sizeof tag-1),right=n;
 if(n==sizeof saved_notes){pc_error(81);return;}
 if(left<n){unsigned at=left+sizeof tag-1,k=locate(old+at,n-at,endtag,sizeof endtag-1);if(k==n-at){pc_error(81);return;}right=at+k+sizeof endtag-1;}
 unsigned total=left+sizeof tag-1+2*sizeof s+sizeof endtag-1+n-right;if(total>=sizeof saved_notes){pc_error(81);return;}
 unsigned at=left;if(left)memcpy(saved_notes,old,left);memcpy(saved_notes+at,tag,sizeof tag-1);at+=sizeof tag-1;const uint8_t*p=(const uint8_t*)&s;const char*digits="0123456789abcdef";for(unsigned k=0;k<sizeof s;k++){saved_notes[at++]=digits[p[k]>>4];saved_notes[at++]=digits[p[k]&15];}memcpy(saved_notes+at,endtag,sizeof endtag-1);at+=sizeof endtag-1;if(right<n){memcpy(saved_notes+at,old+right,n-right);at+=n-right;}saved_notes[at]=0;
 FN(0xf0a290,void(*)(uintptr_t))(info+0x60);FN(0xf535c0,void(*)(uintptr_t,const char*))(info+0x60,saved_notes);
}
static int hexval(char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:-1;}
static void audio_defaults(void){
 pc_native_click_restore();pc_tune_follow_set(1);
 __atomic_store_n(&input_filter_settings,INPUT_FILTER_DEFAULT,RL);
 __atomic_store_n(&audio.page,0,RL);__atomic_store_n(&audio.published,3,__ATOMIC_SEQ_CST);__atomic_store_n(&audio.enabled,0,RL);audio.click_path[0]=0;
 for(unsigned k=0;k<3;k++)__atomic_store_n(&audio.sends[k],0,RL);const unsigned defaults[6]={0,0,PC_TUNE_SPEED_DEFAULT,0,0,8192};for(unsigned k=0;k<6;k++)__atomic_store_n(&audio.controls[k],defaults[k],RL);if(audio.tune){audio.enable(audio.tune,0);for(unsigned k=0;k<6;k++)audio.set(audio.tune,k,defaults[k]);}
 __atomic_store_n(&audio.input_object,0,RL);disarm();
}
void pc_audio_info_read(uintptr_t info){
 if(!host.ready||!info)return;
 audio_defaults();__atomic_store_n(&pending_audio,0,RL);__atomic_store_n(&state_epoch,__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ),RL);
 const char*old=(const char*)Q(info,0x60);unsigned n=bounded(old,sizeof saved_notes),at=locate(old,n,tag,sizeof tag-1);if(at==n||n==sizeof saved_notes){return;}at+=sizeof tag-1;
 AudioSaved s={0};
 unsigned legacy_size=sizeof s-sizeof s.filter;
 unsigned bytes=sizeof s;
 if(n-at<bytes*2+sizeof endtag-1||memcmp(old+at+bytes*2,endtag,sizeof endtag-1))bytes=legacy_size;
 if(n-at<bytes*2+sizeof endtag-1||memcmp(old+at+bytes*2,endtag,sizeof endtag-1)){pc_error(82);return;}
 uint8_t*p=(uint8_t*)&s;
 for(unsigned k=0;k<bytes;k++){int a=hexval(old[at+2*k]),b=hexval(old[at+2*k+1]);if(a<0||b<0){pc_error(82);return;}p[k]=a*16+b;}
 int valid=(bytes==legacy_size?(s.version==1||s.version==2):s.version==3)&&
    s.crc==crc(p+8,bytes-8)&&s.enabled<=(s.version==1?1u:3u)&&bounded(s.click,sizeof s.click)<sizeof s.click;
 if(s.version==3)valid&=s.filter[0]<PC_STOCK_FILTER_TYPES&&s.filter[1]<=16383&&s.filter[2]<=16383;
 for(unsigned k=0;k<3;k++)valid&=s.sends[k]<=16383;for(unsigned k=0;k<6;k++)valid&=s.controls[k]<=16383;
 static const char root[]="/media/MPCSSH/mpc-project-audio/";
 if(s.click[0]){if(memcmp(s.click,root,sizeof root-1)||length(s.click)!=sizeof root-1+21)valid=0;
  else{const char*name=s.click+sizeof root-1;if(name[8]!='-'||memcmp(name+17,".wav",5))valid=0;for(unsigned k=0;k<17;k++)if(k!=8&&hexval(name[k])<0)valid=0;}
 }
 if(!valid){pc_error(82);return;}
 if(s.version==1){static const unsigned legacy[3]={2048,6144,14336};s.controls[1]=legacy[s.controls[1]*3/16384];s.version=2;}pending_state=s;__atomic_store_n(&pending_audio,1,RL);
}
void pc_audio_state_poll(void){
 __atomic_store_n(&audio.queued,0,RL);unsigned epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 if(epoch!=pos(&state_epoch)){audio_defaults();__atomic_store_n(&state_epoch,epoch,RL);}
 if(!pos(&pending_audio)||pc_mix_needs_poll())return;
 AudioSaved s=pending_state;__atomic_store_n(&pending_audio,0,RL);
 if(s.version==3){
  uint64_t filter=s.filter[0]|((uint64_t)s.filter[1]<<5)|((uint64_t)s.filter[2]<<19);
  __atomic_store_n(&input_filter_settings,filter,RL);
 }
 for(unsigned k=0;k<3;k++)__atomic_store_n(&audio.sends[k],s.sends[k],RL);for(unsigned k=0;k<6;k++)__atomic_store_n(&audio.controls[k],s.controls[k],RL);
 if(s.click[0]&&!import_click(s.click,0))host.ui.message="Custom metronome missing: using stock";
 pc_tune_follow_set((s.enabled>>1)&1);if((s.enabled&1)||audio.tune){if(tune_ready()){for(unsigned k=0;k<6;k++)audio.set(audio.tune,k,s.controls[k]);audio.enable(audio.tune,s.enabled&1);__atomic_store_n(&audio.enabled,s.enabled&1,RL);}else host.ui.message="Autotune unavailable: bypassed";}

}
