/* UI-thread discovery of the visible native Input Config child.
 * The main mode manager deliberately keeps Step Edit/Sample beneath this view.
 * Input callbacks read only the published scalar/root, never the Component tree.
 */
#include "internal.h"
static uintptr_t current_view;
uintptr_t pc_input_config_view(void){return current_view;}
static uintptr_t find(uintptr_t component,unsigned depth,unsigned *budget){
 if(!component||!depth||!*budget)return 0;--*budget;
 if(!(Q(component,0xa8)&2))return 0;
 if(Q(component,0)==host.base+0x6e1dd80)return component;
 uintptr_t children=Q(component,0x40);int count=I(component,0x4c);
 /* Actual Component::addChildComponent uses +0x40/+0x4c; +0x80 is listener list. */
 if(count<0||count>256||(!children&&count))return 0;
 for(int i=count;i>0;i--){uintptr_t found=find(Q(children,8*(i-1)),depth-1,budget);if(found)return found;}
 return 0;
}
void pc_input_config_frame(uintptr_t screen){
 uintptr_t b=Q(pc_state_base(),0x20),root=b?Q(b,0x58):0;if(!root){current_view=0;__atomic_store_n((unsigned*)(pc_state_base()+0x1f88),0,RL);__atomic_store_n((uintptr_t*)(pc_state_base()+0x1f90),0,RL);return;}
 uintptr_t scan_root=root,ancestor=root;
 for(unsigned j=0;j<12&&ancestor;j++,ancestor=Q(ancestor,0x18))if(Q(ancestor,0)==host.base+0x6e17160){scan_root=ancestor;break;}
 unsigned budget=512;uintptr_t view=find(scan_root,16,&budget);
 if(screen&&Q(screen,0)==host.base+0x6e1dd80&&(Q(screen,0xa8)&2))view=screen;
 current_view=view;
 __atomic_store_n((uintptr_t*)(pc_state_base()+0x1f90),root,RL);
 __atomic_store_n((unsigned*)(pc_state_base()+0x1f88),view?1:0,RL);
}

static void fit_rows(uintptr_t c,unsigned depth,unsigned *budget){
 if(!c||!depth||!*budget||!(Q(c,0xa8)&2))return;--*budget;
 uintptr_t list=Q(c,0x40);int count=I(c,0x4c);
 if(count<0||count>64||(!list&&count))return;
 if(Q(c,0)==host.base+0x6d799b0&&count>=2&&count<=32){
  int bottom=0,rows=0;
  for(int k=0;k<count;k++){
   uintptr_t row=Q(list,8*k);if(!row||Q(row,0)!=host.base+0x6d84cf0||!(Q(row,0xa8)&2))continue;rows=1;
   int y=I(row,0x24),h=I(row,0x2c);if(y<0||h<1||h>64||y>1024-h){rows=0;break;}if(y+h>bottom)bottom=y+h;
  }
  int w=I(c,0x28),h=I(c,0x2c);
  if(rows&&w>0&&w<=1024&&h>0&&bottom>h&&bottom<=1024){
   uint64_t xy=*(uint64_t*)(c+0x20),wh=(uint64_t)(unsigned)w|((uint64_t)(unsigned)bottom<<32);
   FN(0x1160fc0,void(*)(uintptr_t,uint64_t,uint64_t))(c,xy,wh);
  }
 }
 for(int k=0;k<count;k++)fit_rows(Q(list,8*k),depth-1,budget);
}
static void hide(uintptr_t c){if(c){
 ((void(*)(uintptr_t,unsigned))Q(Q(c,0),0x60))(c,0);
 /* Removed Input Config controls must stay empty even when native Shift
  * publishes visible=true before the next paint hook. Target instances only. */
 FN(0x1160fc0,void(*)(uintptr_t,uint64_t,uint64_t))(c,*(uint64_t*)(c+0x20),0);
 }}
/* Hide the actual menu row as well as the secondary editor groups. */
static void hide_stock_row(uintptr_t c,unsigned depth,unsigned *budget){
 if(!c||!depth||!*budget)return;--*budget;
 if(Q(c,0)==host.base+0x6d849e8){
  const char *name=(const char*)Q(c,0x150);char normalized[129];unsigned n=0;
  if(name){for(unsigned j=0;j<128&&name[j];j++){char x=name[j];if(x>='a'&&x<='z')x-=32;if((x>='A'&&x<='Z')||(x>='0'&&x<='9'))normalized[n++]=x;}normalized[n]=0;
   if(n==10&&!memcmp(normalized,"RECINPUTFX",10)||n==14&&!memcmp(normalized,"RECINPUTEFFECT",14)||n==15&&!memcmp(normalized,"RECINPUTEFFECTS",15)){
    uintptr_t row=c;for(unsigned j=0;j<4&&row;j++,row=Q(row,0x18))if(Q(row,0)==host.base+0x6d84cf0){hide(row);return;}
   }
  }
 }
 uintptr_t list=Q(c,0x40);int count=I(c,0x4c);if(count<0||count>128||(!list&&count))return;
 for(int j=0;j<count;j++)hide_stock_row(Q(list,8*j),depth-1,budget);
}
void pc_input_config_layout(uintptr_t screen){
 if(!screen||Q(screen,0)!=host.base+0x6e1dd80)return;
 unsigned row_budget=512;hide_stock_row(screen,12,&row_budget);
 uintptr_t editor=Q(screen,0x2028);if(!editor)return;
 /* Native 0x1614a30 owns these three visibility groups. Suppress the complete
  * stock input-effect selector/editor, retaining the surrounding input setup. */
 for(unsigned off=0x50;off<=0x58;off+=8){uintptr_t v=Q(editor,off);if(!v)continue;uintptr_t b=Q(v,0),e=Q(v,8);if(!b||e<b||(e-b)%8||e-b>128*8)continue;for(uintptr_t n=b;n<e;n+=8)hide(Q(n,0));}
 hide(Q(editor,0x60));unsigned budget=128;fit_rows(screen,8,&budget);
}

/* Custom Input FX pages paint the full content. Hide stock children while
 * they are shown, restoring only live children when returning to setup. */
void pc_input_config_children(uintptr_t screen,unsigned custom){
 static uintptr_t owner,children[128];static unsigned visible[128],saved;
 if(!screen||Q(screen,0)!=host.base+0x6e1dd80)return;
 uintptr_t list=Q(screen,0x40);int count=I(screen,0x4c);if(count<0||count>128||(!list&&count))return;
 if(owner!=screen){owner=screen;saved=0;}
 if(custom){for(int i=0;i<count;i++){
  uintptr_t c=Q(list,8*i);if(!c)continue;unsigned j;for(j=0;j<saved&&children[j]!=c;j++);
  if(j==saved&&saved<128){children[saved]=c;visible[saved++]=(*(unsigned char*)(c+0xa8)&2)!=0;}
  if(*(unsigned char*)(c+0xa8)&2)FN(0x1172670,void(*)(uintptr_t,unsigned))(c,0);
 }}else if(saved){for(int i=0;i<count;i++){
  uintptr_t c=Q(list,8*i);for(unsigned j=0;j<saved;j++)if(c&&c==children[j]&&visible[j])FN(0x1172670,void(*)(uintptr_t,unsigned))(c,1);
 }saved=0;}
}

static struct{uintptr_t c;} background[128];
static int knob_component(uintptr_t c){
 uintptr_t vt=Q(c,0),ti=vt?Q(vt,-8):0;const char*s=ti?(const char*)Q(ti,8):0;if(!s)return 0;
 unsigned length=0;while(length<96&&s[length])length++;for(unsigned n=0;n<length;n++){if(n+4<=length&&!memcmp(s+n,"Knob",4))return 1;if(n+9<=length&&!memcmp(s+n,"Parameter",9))return 1;}return 0;
}
static void background_walk(uintptr_t c,uintptr_t view,int y,unsigned inside,unsigned knob,unsigned underlying,unsigned active,unsigned depth,unsigned*budget){
 if(!c||!depth||!*budget)return;--*budget;y+=I(c,0x24);inside|=c==view;
 uintptr_t b=Q(pc_state_base(),0x20),root=b?Q(b,0x58):0;underlying|=c==root;
 if(active&&!(*(unsigned char*)(c+0xa8)&2))return;
 if(active&&!inside)knob|=knob_component(c)||(underlying&&Q(c,0)==host.base+0x6d849e8);
 if(!active){for(unsigned j=0;j<128;j++)if(background[j].c==c){FN(0x1172670,void(*)(uintptr_t,unsigned))(c,1);background[j].c=0;}}
 else if(!inside&&knob&&y>=176&&I(c,0x2c)>0&&I(c,0x2c)<=64&&(*(unsigned char*)(c+0xa8)&2)){
  unsigned j;for(j=0;j<128&&background[j].c&&background[j].c!=c;j++);
  if(j<128){background[j].c=c;FN(0x1172670,void(*)(uintptr_t,unsigned))(c,0);}
 }
 uintptr_t a=Q(c,0x40);int n=I(c,0x4c);if(n<0||n>256||(!a&&n))return;
 for(int j=0;j<n;j++)background_walk(Q(a,8*j),view,y,inside,knob,underlying,active,depth-1,budget);
}
void pc_input_config_background(uintptr_t screen){
 if(!screen||Q(screen,0)!=host.base+0x6e17160)return;
 unsigned active=pc_audio_config_scope()&&current_view!=0,budget=1024;
 if(active){pc_input_config_layout(current_view);pc_input_config_children(current_view,pc_audio_page()==1||pc_audio_page()==2);}
 background_walk(screen,current_view,-I(screen,0x24),0,0,0,active,16,&budget);
 if(!active)for(unsigned j=0;j<128;j++)background[j].c=0;
}

/* Native Shift redraws only its own controls. Refresh the whole visible dialog
 * after the signal dispatcher returns, so hidden old captions are erased. */
void pc_input_config_refresh(void){
 static uintptr_t last;static unsigned shift,page;
 uintptr_t view=current_view,b=Q(pc_state_base(),0x20),surface=b?Q(b,0x78):0;
 if(!view||!pc_audio_config_scope()){last=0;return;}
 unsigned value=surface?*(uint8_t*)(surface+0x22a0)&1:0,now=pc_audio_page();
 if(last==view&&shift==value&&page==now)return;
 last=view;shift=value;page=now;
 pc_input_config_layout(view);pc_input_config_children(view,now==1||now==2);
 FN(0x1149d70,void(*)(uintptr_t))(view);
 uintptr_t ancestor=view;for(unsigned k=0;k<12&&ancestor;k++,ancestor=Q(ancestor,0x18))if(Q(ancestor,0)==host.base+0x6e17160){pc_input_config_background(ancestor);FN(0x1149d70,void(*)(uintptr_t))(ancestor);break;}
}
