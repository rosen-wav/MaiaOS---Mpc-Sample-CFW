#ifndef PC_EDITORIAL_CHORD_LAYOUT_H
#define PC_EDITORIAL_CHORD_LAYOUT_H
/* Read-only ABI definitions for the existing native chord painter. */
typedef struct {char name[32];uint32_t count;uint8_t notes[8],velocities[8],reserved[12];} ChordPad;
typedef struct {uint8_t magic[8];uint32_t version,reference,count,reserved[3];char name[32];ChordPad pads[16];} ChordBank;
/* Four project-local pages. Pure state transitions, shared by ARM/native tests. */
#define CH_PAGES 4
#define CH_HISTORY 32
#define CH_CACHE 4
typedef struct {
 uint32_t version,page,fixed,reserved;int32_t transpose[4];ChordBank banks[4];
} ChordProject;
typedef struct {
 uintptr_t project;uint32_t stamp,cursor,length,erase;
 ChordProject data,history[CH_HISTORY+1];
 unsigned imported,discarded,error;
} ChordProjectState;
typedef struct {uint32_t down[4],pending,queued,pending_epoch,active_epoch,active;int source,active_source,target;float velocity;uintptr_t interaction,program,pending_router;ChordBank view;uint32_t view_page,view_fixed;int view_transpose;} ChordLive;
typedef struct {uint32_t magic,clock;uintptr_t guard;uint32_t depth,reserved;ChordProjectState slots[CH_CACHE];ChordLive live;} ChordProjects;

#endif
