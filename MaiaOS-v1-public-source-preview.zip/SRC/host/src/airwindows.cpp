/* Airwindows Galactic3 and Highpass2, Copyright (c) Airwindows, MIT license.
 * Adapted from the supplied VST sources. Float DSP bodies are preserved;
 * Plugin plumbing is removed and reset seeds made deterministic. The dither
 * coefficient uses double precision to avoid software quad arithmetic on ARM64.
 */
#include <stdint.h>
extern "C" {
 double sin(double); double cos(double); double pow(double,double); double sqrt(double);
 float frexpf(float,int*); void *memset(void*,int,__SIZE_TYPE__);
}
#define fabs __builtin_fabs
#define floor __builtin_floor

class Galactic3 {
public:
 void reset(unsigned seed=0);
 void processReplacing(float**,float**,int);
 double getSampleRate(){return 44100.;}
 void set(const float *p){A=p[0];B=p[1];C=p[2];D=p[3];E=p[4];F=p[5];}
private:
	double iirAL;
	double iirBL;
	
	double aIL[6480];
	double aJL[3660];
	double aKL[1720];
	double aLL[680];
	
	double aAL[9700];
	double aBL[6000];
	double aCL[2320];
	double aDL[940];
	
	double aEL[15220];
	double aFL[8460];
	double aGL[4540];
	double aHL[3200];
	
	double aML[3111];
	double aMR[3111];
	double vibML, vibMR, depthM, oldfpd;
	
	double feedbackAL;
	double feedbackBL;
	double feedbackCL;
	double feedbackDL;
		
	double iirAR;
	double iirBR;
	
	double aIR[6480];
	double aJR[3660];
	double aKR[1720];
	double aLR[680];
	
	double aAR[9700];
	double aBR[6000];
	double aCR[2320];
	double aDR[940];
	
	double aER[15220];
	double aFR[8460];
	double aGR[4540];
	double aHR[3200];
	
	double feedbackAR;
	double feedbackBR;
	double feedbackCR;
	double feedbackDR;
		
	int countA, delayA;
	int countB, delayB;
	int countC, delayC;
	int countD, delayD;
	int countE, delayE;
	int countF, delayF;
	int countG, delayG;
	int countH, delayH;
	int countI, delayI;
	int countJ, delayJ;
	int countK, delayK;
	int countL, delayL;
	int countM, delayM;//all these ints are shared across channels, not duplicated
	
	double vibM;
	
	enum {
		bez_AL,
		bez_AR,
		bez_BL,
		bez_BR,
		bez_CL,
		bez_CR,	
		bez_InL,
		bez_InR,
		bez_UnInL,
		bez_UnInR,
		bez_SampL,
		bez_SampR,
		bez_cycle,
		bez_total
	}; //the new undersampling. bez signifies the bezier curve reconstruction
	double bez[bez_total];	
	
	uint32_t fpdL;
	uint32_t fpdR;
	//default stuff
	
    float A;
    float B;
    float C;
    float D;
    float E;
	float F;//parameters. Always 0-1, and we scale/alter them elsewhere.
};

void Galactic3::reset(unsigned seed){memset(this,0,sizeof *this);
	A = 0.5;
	B = 0.5;
	C = 0.5;
	D = 1.0;
	E = 1.0;
	F = 1.0;
	
	iirAL = 0.0; iirAR = 0.0;
	iirBL = 0.0; iirBR = 0.0;
	
	for(int count = 0; count < 6479; count++) {aIL[count] = 0.0;aIR[count] = 0.0;}
	for(int count = 0; count < 3659; count++) {aJL[count] = 0.0;aJR[count] = 0.0;}
	for(int count = 0; count < 1719; count++) {aKL[count] = 0.0;aKR[count] = 0.0;}
	for(int count = 0; count < 679; count++) {aLL[count] = 0.0;aLR[count] = 0.0;}
	
	for(int count = 0; count < 9699; count++) {aAL[count] = 0.0;aAR[count] = 0.0;}
	for(int count = 0; count < 5999; count++) {aBL[count] = 0.0;aBR[count] = 0.0;}
	for(int count = 0; count < 2319; count++) {aCL[count] = 0.0;aCR[count] = 0.0;}
	for(int count = 0; count < 939; count++) {aDL[count] = 0.0;aDR[count] = 0.0;}
	
	for(int count = 0; count < 15219; count++) {aEL[count] = 0.0;aER[count] = 0.0;}
	for(int count = 0; count < 8459; count++) {aFL[count] = 0.0;aFR[count] = 0.0;}
	for(int count = 0; count < 4539; count++) {aGL[count] = 0.0;aGR[count] = 0.0;}
	for(int count = 0; count < 3199; count++) {aHL[count] = 0.0;aHR[count] = 0.0;}
	
	for(int count = 0; count < 3110; count++) {aML[count] = aMR[count] = 0.0;}	
	
	feedbackAL = 0.0; feedbackAR = 0.0;
	feedbackBL = 0.0; feedbackBR = 0.0;
	feedbackCL = 0.0; feedbackCR = 0.0;
	feedbackDL = 0.0; feedbackDR = 0.0;
		
	countI = 1;
	countJ = 1;
	countK = 1;
	countL = 1;
	
	countA = 1;
	countB = 1;
	countC = 1;
	countD = 1;	
	
	countE = 1;
	countF = 1;
	countG = 1;
	countH = 1;
	countM = 1;
	//the predelay
	
	vibM = 3.0;
	
	oldfpd = 429496.7295;
	
	for (int x = 0; x < bez_total; x++) bez[x] = 0.0;
	bez[bez_cycle] = 1.0;
		
	fpdL = 0x12345678u ^ seed;
	fpdR = 0x87654321u ^ (seed<<1);
	//this is reset: values being initialized only once. Startup values, whatever they are.
	
}

void Galactic3::processReplacing(float **inputs, float **outputs, int sampleFrames) 
{
    float* in1  =  inputs[0];
    float* in2  =  inputs[1];
    float* out1 = outputs[0];
    float* out2 = outputs[1];

	double overallscale = 1.0;
	overallscale /= 44100.0;
	overallscale *= getSampleRate();
		
	double regen = 0.0625+((1.0-A)*0.0625);
	double attenuate = (1.0 - (regen / 0.125))*1.333;
	double lowpass = pow(1.00001-(1.0-B),2.0)/sqrt(overallscale);
	double drift = pow(C,3)*0.001;
	double derez = D/overallscale;
	if (derez < 0.0005) derez = 0.0005; if (derez > 1.0) derez = 1.0;
	derez = 1.0 / ((int)(1.0/derez));
	//this hard-locks derez to exact subdivisions of 1.0
	double size = (E*1.77)+0.1;
	double wet = 1.0-(pow(1.0-F,3));
	
	delayI = 3407.0*size;
	delayJ = 1823.0*size;
	delayK = 859.0*size;
	delayL = 331.0*size;
	delayA = 4801.0*size;
	delayB = 2909.0*size;
	delayC = 1153.0*size;
	delayD = 461.0*size;
	delayE = 7607.0*size;
	delayF = 4217.0*size;
	delayG = 2269.0*size;
	delayH = 1597.0*size;
	delayM = 256;
	
    while (--sampleFrames >= 0)
    {
		double inputSampleL = *in1;
		double inputSampleR = *in2;
		if (fabs(inputSampleL)<1.18e-23) inputSampleL = fpdL * 1.18e-17;
		if (fabs(inputSampleR)<1.18e-23) inputSampleR = fpdR * 1.18e-17;
		double drySampleL = inputSampleL;
		double drySampleR = inputSampleR;
		
		vibM += (oldfpd*drift);
		if (vibM > (3.141592653589793238*2.0)) {
			vibM = 0.0;
			oldfpd = 0.4294967295+(fpdL*0.0000000000618);
		}
		
		aML[countM] = inputSampleL * attenuate;
		aMR[countM] = inputSampleR * attenuate;
		countM++; if (countM < 0 || countM > delayM) countM = 0;
		
		double offsetML = (sin(vibM)+1.0)*127;
		double offsetMR = (sin(vibM+(3.141592653589793238/2.0))+1.0)*127;
		int workingML = countM + offsetML;
		int workingMR = countM + offsetMR;
		double interpolML = (aML[workingML-((workingML > delayM)?delayM+1:0)] * (1-(offsetML-floor(offsetML))));
		interpolML += (aML[workingML+1-((workingML+1 > delayM)?delayM+1:0)] * ((offsetML-floor(offsetML))) );
		double interpolMR = (aMR[workingMR-((workingMR > delayM)?delayM+1:0)] * (1-(offsetMR-floor(offsetMR))));
		interpolMR += (aMR[workingMR+1-((workingMR+1 > delayM)?delayM+1:0)] * ((offsetMR-floor(offsetMR))) );
		inputSampleL = interpolML;
		inputSampleR = interpolMR;
		//predelay that applies vibrato
		//want vibrato speed AND depth like in MatrixVerb
		
		iirAL = (iirAL*(1.0-lowpass))+(inputSampleL*lowpass); inputSampleL = iirAL;
		iirAR = (iirAR*(1.0-lowpass))+(inputSampleR*lowpass); inputSampleR = iirAR;
		//initial filter
		
		bez[bez_cycle] += derez;
		bez[bez_SampL] += ((inputSampleL+bez[bez_InL]) * derez);
		bez[bez_SampR] += ((inputSampleR+bez[bez_InR]) * derez);
		bez[bez_InL] = inputSampleL; bez[bez_InR] = inputSampleR;
		if (bez[bez_cycle] > 1.0) { //hit the end point and we do a reverb sample
			bez[bez_cycle] = 0.0;
			
			aIL[countI] = (bez[bez_SampL]+bez[bez_UnInL]) + (feedbackAR * regen);
			aJL[countJ] = (bez[bez_SampL]+bez[bez_UnInL]) + (feedbackBR * regen);
			aKL[countK] = (bez[bez_SampL]+bez[bez_UnInL]) + (feedbackCR * regen);
			aLL[countL] = (bez[bez_SampL]+bez[bez_UnInL]) + (feedbackDR * regen);
			bez[bez_UnInL] = bez[bez_SampL];
			
			aIR[countI] = (bez[bez_SampR]+bez[bez_UnInR]) + (feedbackAL * regen);
			aJR[countJ] = (bez[bez_SampR]+bez[bez_UnInR]) + (feedbackBL * regen);
			aKR[countK] = (bez[bez_SampR]+bez[bez_UnInR]) + (feedbackCL * regen);
			aLR[countL] = (bez[bez_SampR]+bez[bez_UnInR]) + (feedbackDL * regen);
			bez[bez_UnInR] = bez[bez_SampR];
			
			countI++; if (countI < 0 || countI > delayI) countI = 0;
			countJ++; if (countJ < 0 || countJ > delayJ) countJ = 0;
			countK++; if (countK < 0 || countK > delayK) countK = 0;
			countL++; if (countL < 0 || countL > delayL) countL = 0;
			
			double outIL = aIL[countI-((countI > delayI)?delayI+1:0)];
			double outJL = aJL[countJ-((countJ > delayJ)?delayJ+1:0)];
			double outKL = aKL[countK-((countK > delayK)?delayK+1:0)];
			double outLL = aLL[countL-((countL > delayL)?delayL+1:0)];
			double outIR = aIR[countI-((countI > delayI)?delayI+1:0)];
			double outJR = aJR[countJ-((countJ > delayJ)?delayJ+1:0)];
			double outKR = aKR[countK-((countK > delayK)?delayK+1:0)];
			double outLR = aLR[countL-((countL > delayL)?delayL+1:0)];
			//first block: now we have four outputs
			
			aAL[countA] = (outIL - (outJL + outKL + outLL));
			aBL[countB] = (outJL - (outIL + outKL + outLL));
			aCL[countC] = (outKL - (outIL + outJL + outLL));
			aDL[countD] = (outLL - (outIL + outJL + outKL));
			aAR[countA] = (outIR - (outJR + outKR + outLR));
			aBR[countB] = (outJR - (outIR + outKR + outLR));
			aCR[countC] = (outKR - (outIR + outJR + outLR));
			aDR[countD] = (outLR - (outIR + outJR + outKR));
			
			countA++; if (countA < 0 || countA > delayA) countA = 0;
			countB++; if (countB < 0 || countB > delayB) countB = 0;
			countC++; if (countC < 0 || countC > delayC) countC = 0;
			countD++; if (countD < 0 || countD > delayD) countD = 0;
			
			double outAL = aAL[countA-((countA > delayA)?delayA+1:0)];
			double outBL = aBL[countB-((countB > delayB)?delayB+1:0)];
			double outCL = aCL[countC-((countC > delayC)?delayC+1:0)];
			double outDL = aDL[countD-((countD > delayD)?delayD+1:0)];
			double outAR = aAR[countA-((countA > delayA)?delayA+1:0)];
			double outBR = aBR[countB-((countB > delayB)?delayB+1:0)];
			double outCR = aCR[countC-((countC > delayC)?delayC+1:0)];
			double outDR = aDR[countD-((countD > delayD)?delayD+1:0)];
			//second block: four more outputs
			
			aEL[countE] = (outAL - (outBL + outCL + outDL));
			aFL[countF] = (outBL - (outAL + outCL + outDL));
			aGL[countG] = (outCL - (outAL + outBL + outDL));
			aHL[countH] = (outDL - (outAL + outBL + outCL));
			aER[countE] = (outAR - (outBR + outCR + outDR));
			aFR[countF] = (outBR - (outAR + outCR + outDR));
			aGR[countG] = (outCR - (outAR + outBR + outDR));
			aHR[countH] = (outDR - (outAR + outBR + outCR));
			
			countE++; if (countE < 0 || countE > delayE) countE = 0;
			countF++; if (countF < 0 || countF > delayF) countF = 0;
			countG++; if (countG < 0 || countG > delayG) countG = 0;
			countH++; if (countH < 0 || countH > delayH) countH = 0;
			
			double outEL = aEL[countE-((countE > delayE)?delayE+1:0)];
			double outFL = aFL[countF-((countF > delayF)?delayF+1:0)];
			double outGL = aGL[countG-((countG > delayG)?delayG+1:0)];
			double outHL = aHL[countH-((countH > delayH)?delayH+1:0)];
			double outER = aER[countE-((countE > delayE)?delayE+1:0)];
			double outFR = aFR[countF-((countF > delayF)?delayF+1:0)];
			double outGR = aGR[countG-((countG > delayG)?delayG+1:0)];
			double outHR = aHR[countH-((countH > delayH)?delayH+1:0)];
			//third block: final outputs
			
			feedbackAL = (outEL - (outFL + outGL + outHL));
			feedbackBL = (outFL - (outEL + outGL + outHL));
			feedbackCL = (outGL - (outEL + outFL + outHL));
			feedbackDL = (outHL - (outEL + outFL + outGL));
			feedbackAR = (outER - (outFR + outGR + outHR));
			feedbackBR = (outFR - (outER + outGR + outHR));
			feedbackCR = (outGR - (outER + outFR + outHR));
			feedbackDR = (outHR - (outER + outFR + outGR));
			//which we need to feed back into the input again, a bit
			
			inputSampleL = (outEL + outFL + outGL + outHL)/8.0;
			inputSampleR = (outER + outFR + outGR + outHR)/8.0;
			//and take the final combined sum of outputs
			
			bez[bez_CL] = bez[bez_BL];
			bez[bez_BL] = bez[bez_AL];
			bez[bez_AL] = inputSampleL;
			bez[bez_SampL] = 0.0;
			
			bez[bez_CR] = bez[bez_BR];
			bez[bez_BR] = bez[bez_AR];
			bez[bez_AR] = inputSampleR;
			bez[bez_SampR] = 0.0;
		}
		double CBL = (bez[bez_CL]*(1.0-bez[bez_cycle]))+(bez[bez_BL]*bez[bez_cycle]);
		double CBR = (bez[bez_CR]*(1.0-bez[bez_cycle]))+(bez[bez_BR]*bez[bez_cycle]);
		double BAL = (bez[bez_BL]*(1.0-bez[bez_cycle]))+(bez[bez_AL]*bez[bez_cycle]);
		double BAR = (bez[bez_BR]*(1.0-bez[bez_cycle]))+(bez[bez_AR]*bez[bez_cycle]);
		double CBAL = (bez[bez_BL]+(CBL*(1.0-bez[bez_cycle]))+(BAL*bez[bez_cycle]))*0.125;
		double CBAR = (bez[bez_BR]+(CBR*(1.0-bez[bez_cycle]))+(BAR*bez[bez_cycle]))*0.125;
		inputSampleL = CBAL;
		inputSampleR = CBAR;		
		
		iirBL = (iirBL*(1.0-lowpass))+(inputSampleL*lowpass); inputSampleL = iirBL;
		iirBR = (iirBR*(1.0-lowpass))+(inputSampleR*lowpass); inputSampleR = iirBR;
		//end filter
		
		if (wet < 1.0) {
			inputSampleL = (inputSampleL * wet) + (drySampleL * (1.0-wet));
			inputSampleR = (inputSampleR * wet) + (drySampleR * (1.0-wet));
		}
		
		//begin 32 bit stereo floating point dither
		int expon; frexpf((float)inputSampleL, &expon);
		fpdL ^= fpdL << 13; fpdL ^= fpdL >> 17; fpdL ^= fpdL << 5;
		inputSampleL += ((double(fpdL)-uint32_t(0x7fffffff)) * 5.5e-36 * pow(2,expon+62));
		frexpf((float)inputSampleR, &expon);
		fpdR ^= fpdR << 13; fpdR ^= fpdR >> 17; fpdR ^= fpdR << 5;
		inputSampleR += ((double(fpdR)-uint32_t(0x7fffffff)) * 5.5e-36 * pow(2,expon+62));
		//end 32 bit stereo floating point dither
		
		*out1 = inputSampleL;
		*out2 = inputSampleR;

		in1++;
		in2++;
		out1++;
		out2++;
    }
}


class Highpass2 {
public:
 void reset(unsigned seed=0);
 void processReplacing(float**,float**,int);
 double getSampleRate(){return 44100.;}
 void set(const float *p){A=p[0];B=p[1];C=p[2];D=p[3];}
private:
	uint32_t fpdL;
	uint32_t fpdR;
	//default stuff

	double iirSampleAL;
	double iirSampleBL;
	double iirSampleCL;
	double iirSampleDL;
	double iirSampleEL;
	double iirSampleFL;
	double iirSampleGL;
	double iirSampleHL;
	
	double iirSampleAR;
	double iirSampleBR;
	double iirSampleCR;
	double iirSampleDR;
	double iirSampleER;
	double iirSampleFR;
	double iirSampleGR;
	double iirSampleHR;
	
	bool fpFlip;
		
    float A;
    float B;
    float C;
    float D;
};

void Highpass2::reset(unsigned seed){memset(this,0,sizeof *this);
	A = 0.0;
	B = 0.5; //-1.0 to 1.0
	C = 0.25; // 0.0 to 4.0
	D = 1.0;
	fpdL = 0x12345678u ^ seed;
	fpdR = 0x87654321u ^ (seed<<1);
	
	iirSampleAL = 0.0;
	iirSampleBL = 0.0;
	iirSampleCL = 0.0;
	iirSampleDL = 0.0;
	iirSampleEL = 0.0;
	iirSampleFL = 0.0;
	iirSampleGL = 0.0;
	iirSampleHL = 0.0;
	
	iirSampleAR = 0.0;
	iirSampleBR = 0.0;
	iirSampleCR = 0.0;
	iirSampleDR = 0.0;
	iirSampleER = 0.0;
	iirSampleFR = 0.0;
	iirSampleGR = 0.0;
	iirSampleHR = 0.0;
	
	fpFlip = true;	
	//this is reset: values being initialized only once. Startup values, whatever they are.
	
}

void Highpass2::processReplacing(float **inputs, float **outputs, int sampleFrames) 
{
    float* in1  =  inputs[0];
    float* in2  =  inputs[1];
    float* out1 = outputs[0];
    float* out2 = outputs[1];
	
	double iirAmount = A;
	double tight = (B*2.0)-1.0;
	if (iirAmount < 0.0000001) iirAmount = 0.0000001;
	if (iirAmount > 1) iirAmount = 1;
	if (tight < 0.0) tight *= 0.5;
	double offsetL;
	double offsetR;
	double aWet = 1.0;
	double bWet = 1.0;
	double cWet = 1.0;
	double dWet = C*4.0;
	//four-stage wet/dry control using progressive stages that bypass when not engaged
	if (dWet < 1.0) {aWet = dWet; bWet = 0.0; cWet = 0.0; dWet = 0.0;}
	else if (dWet < 2.0) {bWet = dWet - 1.0; cWet = 0.0; dWet = 0.0;}
	else if (dWet < 3.0) {cWet = dWet - 2.0; dWet = 0.0;}
	else {dWet -= 3.0;}
	//this is one way to make a little set of dry/wet stages that are successively added to the
	//output as the control is turned up. Each one independently goes from 0-1 and stays at 1
	//beyond that point: this is a way to progressively add a 'black box' sound processing
	//which lets you fall through to simpler processing at lower settings.
	double wet = D;
	
    while (--sampleFrames >= 0)
    {
		double inputSampleL = *in1;
		double inputSampleR = *in2;

		if (fabs(inputSampleL)<1.18e-23) inputSampleL = fpdL * 1.18e-17;
		if (fabs(inputSampleR)<1.18e-23) inputSampleR = fpdR * 1.18e-17;
		double drySampleL = inputSampleL;
		double drySampleR = inputSampleR;
		
		if (tight > 0) offsetL = (1 - tight) + (fabs(inputSampleL)*tight);
		else offsetL = (1 + tight) + ((1-fabs(inputSampleL))*tight);
		if (offsetL < 0.0000001) offsetL = 0.0000001; if (offsetL > 1) offsetL = 1;
		
		if (tight > 0) offsetR = (1 - tight) + (fabs(inputSampleR)*tight);
		else offsetR = (1 + tight) + ((1-fabs(inputSampleR))*tight);
		if (offsetR < 0.0000001) offsetR = 0.0000001; if (offsetR > 1) offsetR = 1;
		
		if (fpFlip)
		{
			if (aWet > 0.0) {
				iirSampleAL = (iirSampleAL * (1 - (offsetL * iirAmount))) + (inputSampleL * (offsetL * iirAmount));
				inputSampleL = ((inputSampleL-iirSampleAL) * aWet) + (inputSampleL * (1.0-aWet));
				
				iirSampleAR = (iirSampleAR * (1 - (offsetR * iirAmount))) + (inputSampleR * (offsetR * iirAmount));
				inputSampleR = ((inputSampleR-iirSampleAR) * aWet) + (inputSampleR * (1.0-aWet));
			}
			if (bWet > 0.0) {
				iirSampleCL = (iirSampleCL * (1 - (offsetL * iirAmount))) + (inputSampleL * (offsetL * iirAmount));
				inputSampleL = ((inputSampleL-iirSampleCL) * bWet) + (inputSampleL * (1.0-bWet));
				
				iirSampleCR = (iirSampleCR * (1 - (offsetR * iirAmount))) + (inputSampleR * (offsetR * iirAmount));
				inputSampleR = ((inputSampleR-iirSampleCR) * bWet) + (inputSampleR * (1.0-bWet));
			}
			if (cWet > 0.0) {
				iirSampleEL = (iirSampleEL * (1 - (offsetL * iirAmount))) + (inputSampleL * (offsetL * iirAmount));
				inputSampleL = ((inputSampleL-iirSampleEL) * cWet) + (inputSampleL * (1.0-cWet));
				
				iirSampleER = (iirSampleER * (1 - (offsetR * iirAmount))) + (inputSampleR * (offsetR * iirAmount));
				inputSampleR = ((inputSampleR-iirSampleER) * cWet) + (inputSampleR * (1.0-cWet));
			}
			if (dWet > 0.0) {
				iirSampleGL = (iirSampleGL * (1 - (offsetL * iirAmount))) + (inputSampleL * (offsetL * iirAmount));
				inputSampleL = ((inputSampleL-iirSampleGL) * dWet) + (inputSampleL * (1.0-dWet));
				
				iirSampleGR = (iirSampleGR * (1 - (offsetR * iirAmount))) + (inputSampleR * (offsetR * iirAmount));
				inputSampleR = ((inputSampleR-iirSampleGR) * dWet) + (inputSampleR * (1.0-dWet));
			}
		}
		else
		{
			if (aWet > 0.0) {
				iirSampleBL = (iirSampleBL * (1 - (offsetL * iirAmount))) + (inputSampleL * (offsetL * iirAmount));
				inputSampleL = ((inputSampleL-iirSampleBL) * aWet) + (inputSampleL * (1.0-aWet));
				
				iirSampleBR = (iirSampleBR * (1 - (offsetR * iirAmount))) + (inputSampleR * (offsetR * iirAmount));
				inputSampleR = ((inputSampleR-iirSampleBR) * aWet) + (inputSampleR * (1.0-aWet));
			}
			if (bWet > 0.0) {
				iirSampleDL = (iirSampleDL * (1 - (offsetL * iirAmount))) + (inputSampleL * (offsetL * iirAmount));
				inputSampleL = ((inputSampleL-iirSampleDL) * bWet) + (inputSampleL * (1.0-bWet));
				
				iirSampleDR = (iirSampleDR * (1 - (offsetR * iirAmount))) + (inputSampleR * (offsetR * iirAmount));
				inputSampleR = ((inputSampleR-iirSampleDR) * bWet) + (inputSampleR * (1.0-bWet));
			}
			if (cWet > 0.0) {
				iirSampleFL = (iirSampleFL * (1 - (offsetL * iirAmount))) + (inputSampleL * (offsetL * iirAmount));
				inputSampleL = ((inputSampleL-iirSampleFL) * cWet) + (inputSampleL * (1.0-cWet));
				
				iirSampleFR = (iirSampleFR * (1 - (offsetR * iirAmount))) + (inputSampleR * (offsetR * iirAmount));
				inputSampleR = ((inputSampleR-iirSampleFR) * cWet) + (inputSampleR * (1.0-cWet));
			}
			if (dWet > 0.0) {
				iirSampleHL = (iirSampleHL * (1 - (offsetL * iirAmount))) + (inputSampleL * (offsetL * iirAmount));
				inputSampleL = ((inputSampleL-iirSampleHL) * dWet) + (inputSampleL * (1.0-dWet));
				
				iirSampleHR = (iirSampleHR * (1 - (offsetR * iirAmount))) + (inputSampleR * (offsetR * iirAmount));
				inputSampleR = ((inputSampleR-iirSampleHR) * dWet) + (inputSampleR * (1.0-dWet));
			}
		}
		
		if (wet !=1.0) {
			inputSampleL = (inputSampleL * wet) + (drySampleL * (1.0-wet));
			inputSampleR = (inputSampleR * wet) + (drySampleR * (1.0-wet));
		}
		//Dry/Wet control, defaults to the last slider
		fpFlip = !fpFlip;
		
		//begin 32 bit stereo floating point dither
		int expon; frexpf((float)inputSampleL, &expon);
		fpdL ^= fpdL << 13; fpdL ^= fpdL >> 17; fpdL ^= fpdL << 5;
		inputSampleL += ((double(fpdL)-uint32_t(0x7fffffff)) * 5.5e-36 * pow(2,expon+62));
		frexpf((float)inputSampleR, &expon);
		fpdR ^= fpdR << 13; fpdR ^= fpdR >> 17; fpdR ^= fpdR << 5;
		inputSampleR += ((double(fpdR)-uint32_t(0x7fffffff)) * 5.5e-36 * pow(2,expon+62));
		//end 32 bit stereo floating point dither
		
		*out1 = inputSampleL;
		*out2 = inputSampleR;

		in1++;
		in2++;
		out1++;
		out2++;
    }
}



static Galactic3 reverbs[4];
static Highpass2 dj_highpass;
static unsigned generation[3],initialized[4];
extern "C" void pc_galactic_prepare(unsigned slot){
 if(slot<4&&!__atomic_load_n(&initialized[slot],__ATOMIC_ACQUIRE)){reverbs[slot].reset(slot+1);__atomic_store_n(&initialized[slot],1,__ATOMIC_RELEASE);}
}
extern "C" void pc_galactic_process(unsigned slot,float *l,float *r,unsigned n,const float *p,unsigned epoch){
 if(slot>=3||!n||n>4096)return;
 if(!__atomic_load_n(&initialized[slot],__ATOMIC_ACQUIRE)||generation[slot]!=epoch){
  reverbs[slot].reset(slot+1);__atomic_store_n(&initialized[slot],1,__ATOMIC_RELEASE);generation[slot]=epoch;
 }
 float values[6];for(unsigned k=0;k<6;k++)values[k]=p[k]<0?0:p[k]>1?1:p[k];
 values[0]=1.f-.95f*values[0]; // UI Decay: more clockwise means longer.
 reverbs[slot].set(values);float *planes[]={l,r};
 reverbs[slot].processReplacing(planes,planes,(int)n);
}
static unsigned dj_generation;
static float dj_amount;
static unsigned dj_clear;
static float wet_l[4096],wet_r[4096];
static float dj_wet_gain=1,dj_hp_position;
extern "C" unsigned pc_dj_space_active(void){return dj_amount>0;}
extern "C" void pc_dj_space_process(float *l,float *r,unsigned n,unsigned position,unsigned epoch){
 if(!n||n>4096)return;
 if(!__atomic_load_n(&initialized[3],__ATOMIC_ACQUIRE)||dj_generation!=epoch){
  reverbs[3].reset(4);dj_highpass.reset(5);__atomic_store_n(&initialized[3],1,__ATOMIC_RELEASE);
  dj_generation=epoch;dj_amount=0;dj_clear=0;dj_wet_gain=1;dj_hp_position=0;
 }
 float target=position>=16383?1.f:position*(1.f/16383.f);
 if(target==0&&dj_amount==0){dj_clear=1;return;} // exact dry bypass
 if(dj_clear){reverbs[3].reset(4);dj_highpass.reset(5);dj_clear=0;dj_wet_gain=1;dj_hp_position=0;}
 for(unsigned i=0;i<n;i++){wet_l[i]=l[i];wet_r[i]=r[i];}
 // Long decay, bright diffuse tail, modest drift, full-resolution processing.
 const float long_reverb[]={.10f,.85f,.20f,1.f,1.f,1.f};
 reverbs[3].set(long_reverb);float *wet[]={wet_l,wet_r};
 reverbs[3].processReplacing(wet,wet,(int)n);
 // Cap filter travel at half of r101; filter the reverb branch so the
 // dry attack is preserved through the crossfade. One gain estimate/block.
 for(unsigned offset=0;offset<n;offset+=16){
  unsigned count=n-offset;if(count>16)count=16;
  float delta=target-dj_hp_position;if(delta>.008f)delta=.008f;if(delta<-.008f)delta=-.008f;
  dj_hp_position+=delta;
  float hp[]={.340062f*dj_hp_position*dj_hp_position,.5f,.5f,dj_hp_position<.1f?dj_hp_position*10:1.f};
  dj_highpass.set(hp);float *planes[]={wet_l+offset,wet_r+offset};dj_highpass.processReplacing(planes,planes,(int)count);
 }
 double dry_energy=0,wet_energy=0;
 for(unsigned i=0;i<n;i++){dry_energy+=l[i]*l[i]+r[i]*r[i];wet_energy+=wet_l[i]*wet_l[i]+wet_r[i]*wet_r[i];}
 float gain_target=dj_wet_gain;
 if(dry_energy>1e-8&&wet_energy>1e-10){
  double gain=sqrt(dry_energy/wet_energy);gain_target=gain<1?1:gain>16?16:(float)gain;
 }
 for(unsigned i=0;i<n;i++){
  float delta=target-dj_amount;
  if(delta>.0005f)delta=.0005f;if(delta<-.0005f)delta=-.0005f;
  dj_amount+=delta;if(dj_amount<0)dj_amount=0;if(dj_amount>1)dj_amount=1;
  dj_wet_gain+=(gain_target-dj_wet_gain)*.0001f;
  // Equal-power approximation; exact 0% dry and 100% wet endpoints.
  float dry=(1-dj_amount)*(1+.82842712f*dj_amount);
  float wet_mix=dj_amount*(1+.82842712f*(1-dj_amount))*dj_wet_gain;
  l[i]=l[i]*dry+wet_l[i]*wet_mix;r[i]=r[i]*dry+wet_r[i]*wet_mix;
 }
 if(target==0&&dj_amount==0)dj_clear=1;
}
