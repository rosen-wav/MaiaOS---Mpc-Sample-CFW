/* Mixxx BeatUtils, GPL-2.0-or-later. Qt/frame adapters only; see vendor/mixxx. */
#pragma once
#include <vector>
#include <optional>
#include <cmath>
#include <algorithm>
#define DEBUG_ASSERT(x) ((void)0)
#define math_max std::max
#define math_min std::min
template<class T> struct QVector:std::vector<T>{
 using std::vector<T>::vector;
 int size()const{return (int)std::vector<T>::size();}
 bool isEmpty()const{return this->empty();}
 void append(const T& t){this->push_back(t);}
 const T& first()const{return this->front();}
 const T& last()const{return this->back();}
};
namespace mixxx {struct Bpm{
 double n;Bpm(double v=0):n(v){} double value()const{return n;}
 bool isValid()const{return n>0&&std::isfinite(n);}
 bool operator<(Bpm b)const{return n<b.n;} bool operator>(Bpm b)const{return n>b.n;}
};}
class BeatUtils {
  public:
    struct ConstRegion {
        double firstBeat;
        double beatLength;
    };

    static mixxx::Bpm calculateBpm(const QVector<double>& beats,
            double sampleRate);

    static QVector<ConstRegion> retrieveConstRegions(
            const QVector<double>& coarseBeats,
            double sampleRate);

    static mixxx::Bpm calculateAverageBpm(int numberOfBeats,
            double sampleRate,
            double lowerFrame,
            double upperFrame);

    static mixxx::Bpm makeConstBpm(
            const QVector<ConstRegion>& constantRegions,
            double sampleRate,
            double* pFirstBeat);

    static double adjustPhase(
            double firstBeat,
            mixxx::Bpm bpm,
            double sampleRate,
            const QVector<double>& beats);

    static QVector<double> getBeats(const QVector<ConstRegion>& constantRegions);

    static std::optional<mixxx::Bpm> trySnap(mixxx::Bpm minBpm,
            mixxx::Bpm centerBpm,
            mixxx::Bpm maxBpm,
            double fraction);

    static mixxx::Bpm roundBpmWithinRange(
            mixxx::Bpm minBpm, mixxx::Bpm centerBpm, mixxx::Bpm maxBpm);
};

