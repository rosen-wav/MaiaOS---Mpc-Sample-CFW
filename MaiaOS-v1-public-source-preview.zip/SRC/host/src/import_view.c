/* SPDX-License-Identifier: GPL-3.0-only
 * FileSelectScreen remains the native navigator/loader. Only its sample-page
 * Back/Preview widgets and preview trigger change. No MIDI browser changes. */
#include "internal.h"
#include "stock_caption.h"
#include "dj_mode.h"
static unsigned preview_on=1,metro_armed=1,available,native_import_mode;
static PcStockCaption import_synths,import_metro,import_preview[2];
static void import_captions(uintptr_t view,unsigned visible){
 if(!visible){
  pc_stock_caption_hide(import_synths,view);pc_stock_caption_hide(import_metro,view);
  for(unsigned n=0;n<2;n++)pc_stock_caption_hide(import_preview[n],view);
  return;
 }
 pc_stock_caption_hide(import_preview[!preview_on],view);
 pc_stock_caption_show(import_synths,view,"Synths",215,0,104,38);
 pc_stock_caption_show(import_metro,view,"K1 100% Metro",0,216,154,22);
 pc_stock_caption_show(import_preview[preview_on],view,preview_on?"K3 Preview On":"K3 Preview Off",166,216,154,22);
}
static uintptr_t find(uintptr_t c,unsigned depth,unsigned *budget,int sample_only){
 if(!c||!depth||!*budget)return 0;--*budget;if(!(*(uint8_t*)(c+0xa8)&2))return 0;
 if(Q(c,0)==host.base+0x6e1cfb8&&(!sample_only||I(c,0x1388)==0))return c;
 uintptr_t a=Q(c,0x40);int n=I(c,0x4c);if(!a||n<0||n>128)return 0;
 for(int j=0;j<n;j++){uintptr_t hit=find(Q(a,8*j),depth-1,budget,sample_only);if(hit)return hit;}return 0;
}
uintptr_t pc_import_current(void){
 uintptr_t b=Q(pc_state_base(),0x20),m=b?Q(b,0x30):0;if(!m||host.ui.catalog)return 0;
 int mode=I(m,0xd8);if(mode==0x3080)mode=I(m,0x80);if(mode!=0x20a9)return 0;
 uintptr_t root=Q(b,0x58),ancestor=root;unsigned budget=512;
 for(unsigned j=0;j<12&&ancestor;j++,ancestor=Q(ancestor,0x18))if(Q(ancestor,0)==host.base+0x6e17160){root=ancestor;break;}
 return find(root,12,&budget,1);
}
void pc_import_frame(uintptr_t screen){
 if(!screen)return;
 uintptr_t vtable=Q(screen,0);
 if(vtable==host.base+0x6e17160||vtable==host.base+0x6e1cfb8){
  uintptr_t b=Q(pc_state_base(),0x20),m=b?Q(b,0x30):0;
  int id=m?I(m,0xd8):0;if(id==0x3080)id=I(m,0x80);
  unsigned budget=512;
  uintptr_t browser=find(screen,12,&budget,0);
  __atomic_store_n(&native_import_mode,browser?(unsigned)id:0,RL);
  if(vtable==host.base+0x6e17160)__atomic_store_n(&available,0,RL);
 }
 uintptr_t view=0;
 if(Q(screen,0)==host.base+0x6e1cfb8&&I(screen,0x1388)==0)view=screen;
 else if(Q(screen,0)==host.base+0x6e17160)view=pc_import_current();
 if(!view){
  if(vtable==host.base+0x6e1cfb8)import_captions(screen,0);
  return;
 }
 if(pc_dj_import()){
  import_captions(view,0);
  pc_dj_browser_frame(view);
  __atomic_store_n(&available,0,RL);
  return;
 }
 pc_dj_browser_frame(view);
 if(pc_audio_page()||host.ui.catalog||!pc_native_import_scope(0x20a9)){import_captions(view,0);return;}
 __atomic_store_n(&available,1,RL);I(view,0xa2c)=preview_on;
 /* Reserve the bottom24 pixels for K labels; retain the native path above. */
 uintptr_t path=view+0x11d0;
 if(Q(path,0x18)==view&&I(path,0x24)==198&&I(path,0x2c)>18)
  FN(0x1160fc0,void(*)(uintptr_t,uint64_t,uint64_t))(path,*(uint64_t*)(path+0x20),(uint64_t)(unsigned)I(path,0x28)|((uint64_t)18<<32));
 const unsigned offsets[]={0x638,0x858};int changed=0;
 for(unsigned j=0;j<sizeof offsets/sizeof *offsets;j++){uintptr_t c=view+offsets[j];if(*(uint8_t*)(c+0xa8)&2){FN(0x1172670,void(*)(uintptr_t,unsigned))(c,0);changed=1;}}
 import_captions(view,1);
 if(changed)FN(0x1149d70,void(*)(uintptr_t))(view);
}
int pc_import_preview(void){return 1;}

unsigned pc_native_import_scope(int id){
 return id>0&&__atomic_load_n(&native_import_mode,AQ)==(unsigned)id&&!host.ui.catalog;
}
unsigned pc_import_knob_scope(void){
 uintptr_t b=Q(pc_state_base(),0x20),m=b?Q(b,0x30):0;
 int mode=m?I(m,0xd8):0;if(mode==0x3080)mode=I(m,0x80);
 return mode==0x20a9&&!host.ui.catalog&&!pc_audio_page()&&__atomic_load_n(&available,AQ);
}
int pc_import_knob_event(unsigned data){
 if(!pc_import_knob_scope())return 0;uintptr_t view=pc_import_current();if(!view)return 0;
 unsigned knob=data>>16,value=data&65535;
 if(knob==0){if(value<15500)metro_armed=1;if(value>=16300&&metro_armed){metro_armed=0;return 1;}}
 if(knob==2){unsigned on=preview_on;if(value<=6553)on=0;else if(value>=9830)on=1;
  if(on!=preview_on){preview_on=on;I(view,0xa2c)=on;import_captions(view,1);
   if(!on){uintptr_t player=Q(pc_state_base(),0x1ea0);if(player&&Q(player,0)==host.base+0x6da3d18)FN(0x20be150,void(*)(uintptr_t))(player);pc_preview_stop();}
   FN(0x1149d70,void(*)(uintptr_t))(view);
  }
 }return 0;
}

int pc_import_selected_path(uintptr_t view,char *path,unsigned cap){
 if(!view||Q(view,0)!=host.base+0x6e1cfb8||I(view,0x1388)!=0||cap<2)return 0;
 /* The non-trivial optional<juce::File> is returned indirectly in X8.
  * A large aggregate requests the same ABI from the C compiler. */
 typedef struct {uintptr_t file;uint64_t present;uintptr_t padding;} FileResult;
 FileResult selection=FN(0x15b7090,FileResult(*)(uintptr_t))(view+0xff0);
 if(!(selection.present&1))return 0;
 const char *native=(const char*)selection.file;
 unsigned n=0;
 if(native&&native[0]=='/'){
  while(n<cap&&native[n])n++;
  if(n<cap)memcpy(path,native,n+1);
  else n=0;
 }
 FN(0xf0a290,void(*)(uintptr_t*))(&selection.file);
 return n!=0;
}
