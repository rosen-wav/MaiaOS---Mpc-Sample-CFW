/* Pure note generation, shared by the browser and regression fixtures. */
#include "harmony_groove.h"
typedef struct {const char*name;unsigned step,direction,swing,gate,mask;uint8_t accents[8];} Arp;
static const Arp arps[]={
 {"Up / 8ths",480,0,0,85,255,{127,90,106,86,120,88,104,86}},
 {"Down / 8ths",480,1,0,85,255,{127,92,108,88,120,88,104,86}},
 {"Up-Down / 16ths",240,2,0,75,255,{127,76,98,82,112,74,96,84}},
 {"Down-Up / 16ths",240,3,0,75,255,{122,78,100,80,115,75,98,84}},
 {"Random / 16ths",240,4,0,70,255,{120,72,100,84,114,78,96,88}},
 {"Random / Triplets",320,4,0,72,255,{127,78,94,112,76,100,118,84}},
 {"Up / Velocity Rise",240,0,0,80,255,{56,66,76,86,96,106,116,127}},
 {"Down / Velocity Fall",240,1,0,80,255,{127,116,106,96,86,76,66,56}},
 {"R&B Swing / Up-Down",240,2,48,78,255,{116,62,98,74,120,68,104,76}},
 {"Trap / Random Rolls",120,4,0,58,221,{122,55,94,62,114,60,100,72}},
 {"IDM / Outside-In",240,5,31,65,183,{124,60,96,72,112,54,102,82}},
 {"Inside-Out / Pulses",480,6,0,65,219,{120,78,100,68,114,82,104,72}},
 {"Up / 16ths Even",240,0,0,88,255,{104,104,104,104,104,104,104,104}},
 {"Down / Triplets",320,1,0,80,255,{124,82,96,120,78,98,116,84}},
};
unsigned pc_arp_count(void){return sizeof arps/sizeof *arps;}
const char*pc_arp_name(unsigned p){return p<pc_arp_count()?arps[p].name:"";}
typedef struct {int64_t start,end,emitted;float velocity;} Voice;
static uint32_t random_next(uint32_t*seed){uint32_t s=*seed?*seed:0x9e3779b9;s^=s<<13;s^=s>>17;s^=s<<5;return *seed=s;}
static unsigned choose(unsigned direction,unsigned phase,unsigned n,uint32_t*seed){
 unsigned p=phase%n;
 if(direction==1)return n-1-p;
 if(direction==2||direction==3){unsigned span=2*n-2,pos=phase%span;unsigned index=pos<n?pos:span-pos;return direction==3?n-1-index:index;}
 if(direction==4)return random_next(seed)%n;
 if(direction==5)return p&1?n-1-p/2:p/2;
 if(direction==6){unsigned index=p&1?(n-1)/2+1+p/2:(n-1)/2-p/2;return index;}
 return p;
}
int pc_harmony_generate(const PcHarmonyNote*notes,unsigned count,int64_t ticks,unsigned mode,unsigned pattern,uint32_t seed,PcHarmonyEmit emit,void*context){
 if(!notes||!count||count>65536||ticks<=0||mode>2||!emit||(mode==2&&pattern>=pc_arp_count()))return 0;
 for(unsigned i=0;i<count;i++)if(notes[i].tick<0||notes[i].tick>=ticks||notes[i].duration<=0||notes[i].pitch>=256||!(notes[i].velocity>0&&notes[i].velocity<=1)||(i&&notes[i].tick<notes[i-1].tick))return 0;
 Voice voices[256]={0};unsigned at=0,emitted=0,phase=0,iterations=0;int64_t time=notes[0].tick;
 const Arp*arp=mode==2?&arps[pattern]:0;
 while(time<ticks&&iterations++<131072){
  unsigned changed=0;
  while(at<count&&notes[at].tick<=time){
   const PcHarmonyNote*n=&notes[at++];Voice*v=&voices[n->pitch];int64_t end=n->duration>ticks-n->tick?ticks:n->tick+n->duration;
   if(v->start!=n->tick||v->end<end){v->start=n->tick;v->end=end;v->velocity=n->velocity;}changed=1;
  }
  unsigned pitches[256],held=0;for(unsigned p=0;p<256;p++)if(voices[p].end>time)pitches[held++]=p;
  if(mode<2){
   if(changed&&held>=3){unsigned pitch=pitches[mode==1?held-1:0];Voice*v=&voices[pitch];
    if(v->emitted!=v->start+1){if(!emit(context,v->start,v->end-v->start,pitch,v->velocity))return 0;v->emitted=v->start+1;emitted++;}
   }
   if(at==count)break;time=notes[at].tick;continue;
  }
  if(changed)phase=0;
  if(held<3){if(at==count)break;time=notes[at].tick;continue;}
  unsigned pitch=pitches[choose(arp->direction,phase,held,&seed)];Voice*v=&voices[pitch];
  int64_t duration=(int64_t)arp->step*arp->gate/100;if(duration>v->end-time)duration=v->end-time;if(duration>ticks-time)duration=ticks-time;
  if(duration>0&&(arp->mask&(1u<<(phase&7)))){
   float velocity=v->velocity*arp->accents[phase&7]/127.f;
   if(emitted==65536||!emit(context,time,duration,pitch,velocity))return 0;emitted++;
  }
  int64_t next=time+arp->step+(phase&1?-(int64_t)arp->swing:arp->swing);
  if(at<count&&notes[at].tick<next)next=notes[at].tick;
  if(next<=time)return 0;time=next;phase++;
 }
 return iterations<131072?(int)emitted:0;
}
