/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_HOST_H
#define PC_HOST_H
#include <stdint.h>
#include <stddef.h>
#include "panel.h"
#define PC_MAGIC 0x3230435043504dULL
#define PC_SLOTS 16
#define PC_LEGACY_STATE_OFFSET 0x72a4cb0u
#define PC_SHARED_STATE_SIZE 0xf0000u
#define PC_SHARED_DEBUG_OFFSET 0x1d10u
typedef struct {
 uint64_t magic;uint32_t state,error;
 uint64_t assigned,notes,offs,frames,contention,panics,saves,loads;
 uint32_t held[PC_SLOTS];
 uint64_t track_vtable,program_vtable;uint32_t mode,source,ui_scope,catalog;
 uint64_t controls,paint_calls;uint32_t reserved[4];
} PcDebug;
_Static_assert(sizeof(PcDebug)==208,"debug ABI");
typedef struct {
 uint64_t magic,version;
 int (*note_on)(uintptr_t,uintptr_t,uintptr_t,uintptr_t,const uint8_t *,unsigned);
 void (*note_off)(uintptr_t,uintptr_t,unsigned,unsigned,unsigned);
 int (*active)(uintptr_t);
 void (*render)(uintptr_t,uintptr_t,unsigned,unsigned);
 void (*stop)(uintptr_t,uintptr_t,unsigned,unsigned);
 void (*destroy)(uintptr_t);
 int (*physical)(uintptr_t,unsigned);
 int (*knob)(uintptr_t,uint32_t); /* 0: v064; 1: consumed; 2: native FX */
 int (*rotation)(uintptr_t,int);
 int (*capture)(int,int);
 int (*event)(uint64_t);
 int (*paint)(uintptr_t,uintptr_t);
 int (*write_xml)(uintptr_t,uintptr_t);
 int (*read_xml)(uintptr_t,uintptr_t);
 void (*destroy_instrument)(uintptr_t);
 int (*light_has)(uintptr_t,unsigned,uintptr_t);
 int (*light_playing)(uintptr_t,uintptr_t,unsigned);
 void (*sidechain)(uintptr_t,uintptr_t,unsigned,unsigned);
 void (*info_write)(uintptr_t,uintptr_t);void (*info_read)(uintptr_t);
 void (*fx_input)(uintptr_t,uintptr_t,uintptr_t,unsigned);
 int (*fx_chain)(uintptr_t,uintptr_t,unsigned);int (*fx_guard)(void);
 unsigned (*pad_enter)(unsigned,uintptr_t,unsigned);void (*pad_leave)(unsigned);
 void (*audio_input)(uintptr_t,uintptr_t,unsigned,unsigned);
 void (*audio_tick)(uintptr_t);int (*audio_click)(uintptr_t,uintptr_t,unsigned,unsigned);
 uint64_t audio_extension_magic,audio_extension_size;
 void (*bounce_export)(uintptr_t,uintptr_t,unsigned);void (*bounce_enter)(uintptr_t);void (*bounce_block)(uintptr_t);void (*bounce_collect)(uintptr_t,unsigned);void (*bounce_status)(uintptr_t,unsigned);void (*bounce_paint)(uintptr_t,uintptr_t);
} PcApi;
const PcApi *pc_init(uintptr_t,PcDebug *);
/* The caller owns an aligned, zeroed state region for the process lifetime.
 * Native bridges and the host must use the same region. */
const PcApi *pc_init_with_state(uintptr_t,void *,size_t);
#endif
