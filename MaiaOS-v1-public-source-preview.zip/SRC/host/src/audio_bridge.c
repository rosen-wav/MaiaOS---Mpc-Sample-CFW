#include "host.h"
#ifdef PC_RELOCATABLE_BRIDGE
extern uintptr_t pc_loader_statebase(void);
#else
extern uintptr_t pc_feature_base(void);
static uintptr_t pc_loader_statebase(void){return pc_feature_base()+PC_LEGACY_STATE_OFFSET;}
#endif
static const PcApi*get(void){const PcApi*a=__atomic_load_n((const PcApi**)(pc_loader_statebase()+0x1d00),__ATOMIC_ACQUIRE);return a&&a->magic==PC_MAGIC&&a->version==6&&a->audio_extension_magic==0x303730415544494fULL&&a->audio_extension_size>=sizeof(PcApi)?a:0;}
void pc_bridge_input(uintptr_t o,uintptr_t b,unsigned n,unsigned p){const PcApi*a=get();if(a&&a->audio_input)a->audio_input(o,b,n,p);}
void pc_bridge_tick(uintptr_t o){const PcApi*a=get();if(a&&a->audio_tick)a->audio_tick(o);}
int pc_bridge_click(uintptr_t o,uintptr_t b,unsigned n,unsigned p){const PcApi*a=get();return a&&a->audio_click?a->audio_click(o,b,n,p):0;}
void pc_bridge_bounce_export(uintptr_t g,uintptr_t p,unsigned i){const PcApi*a=get();if(a&&a->bounce_export)a->bounce_export(g,p,i);}
void pc_bridge_bounce_enter(uintptr_t m){const PcApi*a=get();if(a&&a->bounce_enter)a->bounce_enter(m);}
void pc_bridge_bounce_block(uintptr_t m){const PcApi*a=get();if(a&&a->bounce_block)a->bounce_block(m);}
void pc_bridge_bounce_collect(uintptr_t m,unsigned n){const PcApi*a=get();if(a&&a->bounce_collect)a->bounce_collect(m,n);}
void pc_bridge_bounce_status(uintptr_t g,unsigned k){const PcApi*a=get();if(a&&a->bounce_status)a->bounce_status(g,k);}
void pc_bridge_bounce_paint(uintptr_t c,uintptr_t g){const PcApi*a=get();if(a&&a->bounce_paint)a->bounce_paint(c,g);}
