/* SPDX-License-Identifier: GPL-3.0-only
 * UI-thread-only Linux AArch64 I/O. Factory presets remain recoverable;
 * confirmed saves create durable, version-independent SD overrides.
 */
#include "internal.h"
static long sys(long number,long a,long b,long c,long d,long e){
 return pc_sys(number,a,b,c,d,e,0);
}
static const char directory[]="/media/MPCSSH/mpc-pc-presets";
static void path(char *out,unsigned engine,unsigned preset,int temporary){
 unsigned n=0;while(directory[n]){out[n]=directory[n];n++;}
 out[n++]='/';out[n++]=(char)('0'+engine);out[n++]='-';
 out[n++]=(char)('0'+preset/100);out[n++]=(char)('0'+preset/10%10);out[n++]=(char)('0'+preset%10);
 const char *suffix=temporary?".tmp":".pcp";for(unsigned k=0;suffix[k];k++)out[n++]=suffix[k];out[n]=0;
}
static int transfer(long fd,uint8_t *p,unsigned count,int write){
 for(unsigned done=0;done<count;){long n=sys(write?64:63,fd,(long)(p+done),count-done,0,0);if(n==-4)continue;if(n<=0||n>(long)(count-done))return 0;done+=(unsigned)n;}return 1;
}
int pc_preset_read(unsigned engine,unsigned preset,uint8_t *patch){
 if((engine==3||(engine==6||engine>9))||preset>=pc_engine_count(engine))return -1;
 char name[80];path(name,engine,preset,0);long fd=sys(56,-100,(long)name,0x8000,0,0);
 if(fd==-2)return 0;if(fd<0)return -1;
 uint8_t blob[529];int ok=transfer(fd,blob,528,0);long extra=ok?sys(63,fd,(long)(blob+528),1,0,0):-1;sys(57,fd,0,0,0,0);
 if(!ok||extra!=0||memcmp(blob,"MPCPRE01",8)||blob[8]!=engine||blob[9]!=preset||blob[10]!=preset/256)return -1;
 for(unsigned n=11;n<16;n++)if(blob[n])return -1;
 memcpy(patch,blob+16,512);return 1;
}
int pc_preset_write(unsigned engine,unsigned preset,const uint8_t *patch){
 if((engine==3||(engine==6||engine>9))||preset>=pc_engine_count(engine))return 0;
 long mk=sys(34,-100,(long)directory,0770,0,0);if(mk<0&&mk!=-17)return 0;
 char name[80],temp[80];path(name,engine,preset,0);path(temp,engine,preset,1);
 uint8_t blob[528]={0};memcpy(blob,"MPCPRE01",8);blob[8]=(uint8_t)engine;blob[9]=(uint8_t)preset;blob[10]=(uint8_t)(preset/256);memcpy(blob+16,patch,512);
 /* O_NOFOLLOW avoids following a substituted temporary symlink. */
 long fd=sys(56,-100,(long)temp,1|64|512|0x8000,0660,0);if(fd<0)return 0;
 int ok=transfer(fd,blob,sizeof blob,1);if(ok)ok=sys(82,fd,0,0,0,0)==0;
 if(sys(57,fd,0,0,0,0)<0)ok=0;
 if(ok)ok=sys(38,-100,(long)temp,-100,(long)name,0)==0;
 if(!ok){sys(35,-100,(long)temp,0,0,0);return 0;}
 long dir=sys(56,-100,(long)directory,0x4000,0,0);if(dir<0)return 0;
 ok=sys(82,dir,0,0,0,0)==0;sys(57,dir,0,0,0,0);return ok;
}

/* Keep the factory IDs stable for projects and named presets. Deletion
 * removes the browser entry using an atomically replaced visibility map. */
#define HIDDEN_BYTES 128
static uint8_t hidden[HIDDEN_BYTES];
static unsigned hidden_engine=~0u;

static void hidden_path(char *out,unsigned engine,int temporary){
 unsigned n=sizeof directory-1;memcpy(out,directory,n);
 memcpy(out+n,"/hidden-0",10);out[n+8]='0'+engine;
 if(temporary)memcpy(out+n+9,".tmp",5);
}
void pc_preset_refresh_hidden(unsigned engine){
 char name[80];hidden_path(name,engine,0);
 memset(hidden,0,sizeof hidden);
 long fd=sys(56,-100,(long)name,0x88000,0,0);
 if(fd>=0){
  if(!transfer(fd,hidden,sizeof hidden,0))memset(hidden,0,sizeof hidden);
  sys(57,fd,0,0,0,0);
 }
 hidden_engine=engine;
}
int pc_preset_hidden(unsigned engine,unsigned index){
 if(engine!=hidden_engine)pc_preset_refresh_hidden(engine);
 return index<8*HIDDEN_BYTES&&(hidden[index/8]&(1u<<(index%8)))!=0;
}
int pc_preset_delete(unsigned engine,unsigned index){
 if(engine>9||index>=8*HIDDEN_BYTES||index>=pc_engine_count(engine))return 0;
 pc_preset_refresh_hidden(engine);
 long mk=sys(34,-100,(long)directory,0770,0,0);
 if(mk<0&&mk!=-17)return 0;
 char name[80],temp[80];hidden_path(name,engine,0);hidden_path(temp,engine,1);
 long fd=sys(56,-100,(long)temp,0x88000|1|64|512,0660,0);
 if(fd<0)return 0;
 uint8_t next[HIDDEN_BYTES];memcpy(next,hidden,sizeof next);
 next[index/8]|=1u<<(index%8);
 int ok=transfer(fd,next,sizeof next,1)&&sys(82,fd,0,0,0,0)==0;
 if(sys(57,fd,0,0,0,0)<0)ok=0;
 if(ok)ok=sys(38,-100,(long)temp,-100,(long)name,0)==0;
 if(!ok){sys(35,-100,(long)temp,0,0,0);return 0;}
 memcpy(hidden,next,sizeof hidden);
 if(engine!=3&&engine!=6&&index<1000){
  path(name,engine,index,0);
  sys(35,-100,(long)name,0,0,0);
 }
 fd=sys(56,-100,(long)directory,0x4000,0,0);
 if(fd>=0){sys(82,fd,0,0,0,0);sys(57,fd,0,0,0,0);}
 return 1;
}
