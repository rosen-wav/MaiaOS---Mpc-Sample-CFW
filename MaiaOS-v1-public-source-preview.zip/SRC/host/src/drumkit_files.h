#ifndef PC_DRUMKIT_FILES_H
#define PC_DRUMKIT_FILES_H
#include <stdint.h>
#define PC_KIT_PATH 768u
extern const uint8_t pc_kit_category[16];
extern const char*const pc_kit_folders[6];
unsigned pc_kit_gain_group(unsigned);
int pc_kit_pick(const char*root,uint16_t locked,uint32_t seed,char paths[16][PC_KIT_PATH],unsigned*failed_category);
#endif
