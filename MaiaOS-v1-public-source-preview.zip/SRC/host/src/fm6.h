/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_FM6_H
#define PC_FM6_H
#include <stdint.h>
#define PC_FM6_VOICES 256u
#define PC_FM6_PREVIEW 16u
int pc_fm6_load(unsigned owner,const uint8_t *patch,int edit);
int pc_fm6_on(unsigned owner,unsigned note,unsigned velocity);
void pc_fm6_off(unsigned owner,unsigned note);
unsigned pc_fm6_voices(unsigned owner);
void pc_fm6_render(unsigned owner,float *l,float *r,unsigned frames);
#endif
