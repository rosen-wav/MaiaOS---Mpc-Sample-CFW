/* SPDX-License-Identifier: GPL-3.0-only
 * XPJ uses cereal JSON, not the legacy Instrument XML writer. Preserve the
 * extension in native ProjectInfo.notes so stock load/recovery/save carries
 * it too. Existing notes are retained around a checked, versioned section.
 * Records use the serialized Track ID and Instrument index, never addresses.
 */
#include "internal.h"
#define RECORDS 272
#define NOTE_LIMIT 1048576
#define CHORD_BYTES 4384
#define HEADER_BYTES (16+CHORD_BYTES)
static const char begin[]="\n[MPC-PC-STATE:1]\n",end[]="\n[/MPC-PC-STATE]\n";
typedef struct {char track[128];uint16_t instrument,preset;uint8_t engine,role,reserved[2],patch[512];} Record;
_Static_assert(sizeof(Record)==648,"persistent record ABI");
static struct {uint32_t version,count,crc,chord_size;uint8_t chords[CHORD_BYTES];Record records[RECORDS];} snapshot,pending;
static char notes[NOTE_LIMIT];
static uintptr_t read_project,read_first;
static unsigned pending_valid,read_epoch,read_serial,restore_attempts,restore_queued;
static size_t length(const char *s,size_t limit){if(!s)return 0;size_t n=0;while(n<limit&&s[n])n++;return n;}
static int eq(const char *a,const char *b,size_t n){return memcmp(a,b,n)==0;}
static size_t find(const char *s,size_t n,const char *needle,size_t k){for(size_t i=0;i+k<=n;i++)if(eq(s+i,needle,k))return i;return n;}
static uint32_t crc(const void *data,size_t n){const uint8_t *p=data;uint32_t c=~0u;while(n--){c^=*p++;for(unsigned i=0;i<8;i++)c=(c>>1)^((0u-(c&1))&0xedb88320u);}return ~c;}
static uintptr_t project(void){
 uintptr_t holder=__atomic_load_n((uintptr_t *)(pc_state_base()+0x1e70),AQ);
 uintptr_t p=holder?Q(holder,0):__atomic_load_n((uintptr_t *)(pc_state_base()+0x1e40),AQ);
 if(!p||Q(p,0)!=host.base+0x6ecc648)p=Q(pc_state_base(),0x1d08);
 return p&&Q(p,0)==host.base+0x6ecc648?p:0;
}
/* The native Project object can be reused for New. A pointer comparison
 * alone cannot distinguish that from editing the same project. */
static unsigned applied_project_serial;
unsigned pc_project_new_serial(void){
 return __atomic_load_n((unsigned *)(pc_state_base()+PC_NEW_PROJECT_SERIAL),AQ);
}
int pc_project_new_pending(void){
 return pc_project_new_serial()!=__atomic_load_n(&applied_project_serial,AQ);
}
int pc_project_new_sync_locked(void){
 unsigned serial=pc_project_new_serial();
 if(serial==__atomic_load_n(&applied_project_serial,AQ))return 1;
 pc_diag_value(47,serial);
 uintptr_t target=__atomic_load_n((uintptr_t *)(pc_state_base()+PC_NEW_PROJECT_MODEL),AQ);
 if(!target||target!=project())return 0;

 /* Native ChordProject v1: 32 byte header, four 1088 byte banks. */
 uint32_t blank[CHORD_BYTES/4]={0};
 blank[0]=1;
 for(unsigned page=0;page<4;page++){
  uint32_t *bank=blank+8+page*272;
  memcpy(bank,"MPCCHD1",8);
  bank[2]=1;bank[3]=60;bank[4]=16;
  char *name=(char *)(bank+8);
  memcpy(name,"CHORD PAGE 1",13);
  name[11]=(char)('1'+page);
 }
 if(!FN(PC_CH_IMPORT,int(*)(uintptr_t,const void *,unsigned))(target,blank,sizeof blank))return 0;
 if(read_serial!=serial)__atomic_store_n(&pending_valid,0,RL);
 pc_mix_new_project(serial);
 /* Native already stopped the old project voices before publishing. */
 I(pc_state_base(),0x18d0)=0;
 __atomic_store_n(&applied_project_serial,serial,RL);
 pc_diag_value(48,serial);
 return 1;
}
void pc_project_new_sync_ui(void){
 if(!pc_project_new_pending()||!pc_meta())return;
 int applied=pc_project_new_sync_locked();
 pc_unmeta();
 if(applied)pc_project_schedule();
}
static int tracks(uintptr_t p,uintptr_t *first,unsigned *count){
 if(!p)return 0;uintptr_t pool=Q(p,0x1288);if(!pool)return 0;
 uintptr_t list=FN(0x2925db0,uintptr_t(*)(uintptr_t))(pool);
 uintptr_t b=Q(list,8),e=Q(list,16);
 if((!b&&e)||e<b||(e-b)%8||e-b>1024*8)return 0;*first=b;*count=(unsigned)((e-b)/8);return 1;
}
static const char *track_id(uintptr_t t){return (const char *)Q(t,0x820);}
/* Called immediately before native JSON output of ProjectInfoData. */
void pc_project_info_write(uintptr_t archive,uintptr_t info){
 (void)archive;if(!host.ready||!info)return;
 __atomic_fetch_add((uint64_t *)(pc_state_base()+0x1e60),1,RX);
 if(__atomic_load_n(&pending_valid,AQ)){return;}
 uintptr_t p=project(),ts;unsigned nt;
 __atomic_store_n((uintptr_t *)(pc_state_base()+0x1e68),p,RL);
 __atomic_store_n((uintptr_t *)(pc_state_base()+0x1e78),p?Q(p,0x1288):0,RL);
 __atomic_store_n((uint64_t *)(pc_state_base()+0x1e80),0,RL);
 __atomic_store_n((uint64_t *)(pc_state_base()+0x1e88),0,RL);
 if(!tracks(p,&ts,&nt)){pc_error(p?58:57);return;}
 __atomic_store_n((uint64_t *)(pc_state_base()+0x1e80),nt,RL);
 memset(&snapshot,0,sizeof snapshot);snapshot.version=2;snapshot.chord_size=CHORD_BYTES;
 if(FN(PC_CH_EXPORT,int(*)(uintptr_t,void *,unsigned))(p,snapshot.chords,CHORD_BYTES)!=CHORD_BYTES){pc_error(54);return;}
 int overflow=0;unsigned engine_records=0;uintptr_t seen[RECORDS];
 for(unsigned k=0;k<nt&&!overflow;k++){
  uintptr_t track=Q(ts,8*k);if(!track||Q(track,0)!=host.base+0x6ecf118)continue;
  uintptr_t program=Q(track,0xbb8);if(!program||Q(program,0)!=host.base+0x6ec6860||I(program,0x1234))continue;
  const char *id=track_id(track);size_t len=length(id,128);if(!len||len>=128)continue;
  uintptr_t b=Q(program,0x2808),e=Q(program,0x2810);if(!b||e<b||(e-b)%8||e-b>128*8)continue;
  for(unsigned j=0;j<(e-b)/8;j++){
   uintptr_t instrument=Q(b,8*j);int slot=pc_find(instrument);unsigned role=pc_sc_role(instrument);
   if(slot<0&&!role)continue;
   unsigned duplicate=0;for(unsigned prior=0;prior<snapshot.count;prior++)duplicate|=seen[prior]==instrument;
   if(duplicate)continue;
   if(snapshot.count==RECORDS){overflow=1;break;}
   seen[snapshot.count]=instrument;Record *r=&snapshot.records[snapshot.count++];memcpy(r->track,id,len);r->instrument=(uint16_t)j;r->role=(uint8_t)role;r->engine=255;
   if(slot>=0){engine_records++;Slot *s=&host.slots[slot];r->engine=(uint8_t)s->engine;r->preset=(uint16_t)s->preset;memcpy(r->patch,s->patch,512);}
  }
 }
 if(overflow){pc_error(54);return;}
 __atomic_store_n((uint64_t *)(pc_state_base()+0x1e88),engine_records,RL);
 if(engine_records!=__atomic_load_n(&host.debug->assigned,AQ)){pc_error(59);return;}
 const char *old=(const char *)Q(info,0x60);size_t n=length(old,NOTE_LIMIT),left=find(old,n,begin,sizeof begin-1),right=n;
 if(n==NOTE_LIMIT){pc_error(54);return;}
 if(left<n){size_t off=left+sizeof begin-1;right=find(old+off,n-off,end,sizeof end-1);if(right==n-off){pc_error(54);return;}right+=off+sizeof end-1;}
 size_t bytes=HEADER_BYTES+snapshot.count*sizeof(Record),tail=right<n?n-right:0;
 size_t encoded=(snapshot.count||snapshot.chord_size)?(sizeof begin-1)+bytes*2+(sizeof end-1):0;
 if(left+tail+encoded>=sizeof notes){pc_error(54);return;}
 if(left)memcpy(notes,old,left);size_t out=left;
 if(snapshot.count||snapshot.chord_size){
  snapshot.crc=crc(snapshot.chords,CHORD_BYTES+snapshot.count*sizeof(Record));
  memcpy(notes+out,begin,sizeof begin-1);out+=sizeof begin-1;
  const uint8_t *b=(const uint8_t *)&snapshot;static const char hex[]="0123456789abcdef";
  for(size_t j=0;j<bytes;j++){notes[out++]=hex[b[j]>>4];notes[out++]=hex[b[j]&15];}
  memcpy(notes+out,end,sizeof end-1);out+=sizeof end-1;
 }
 if(tail){memcpy(notes+out,old+right,tail);out+=tail;}notes[out]=0;
 /* Native notes is a Juce String. Replace its transient snapshot value using
  * native string ownership, retaining the user's prefix/suffix exactly. */
 FN(0xf0a290,void(*)(uintptr_t))(info+0x60);
 FN(0xf535c0,void(*)(uintptr_t,const char *))(info+0x60,notes);
 __atomic_fetch_add(&host.debug->saves,snapshot.count,RX);pc_error(0);
}
static int hex(char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:-1;}
/* Runs after the native JSON input fills info; model conversion follows. */
void pc_project_info_read(uintptr_t info){
 if(!host.ready||!info)return;__atomic_store_n(&pending_valid,0,RL);
 __atomic_store_n((uint64_t *)(pc_state_base()+0x1e10),0,RL);
 const char *s=(const char *)Q(info,0x60);size_t n=length(s,NOTE_LIMIT),at=find(s,n,begin,sizeof begin-1);
 if(at==n||n==NOTE_LIMIT){return;}at+=sizeof begin-1;
 size_t stop=find(s+at,n-at,end,sizeof end-1),bytes=stop/2;
 if(stop==n-at||stop%2||bytes<HEADER_BYTES||bytes>sizeof pending){pc_error(55);return;}
 uint8_t *b=(uint8_t *)&pending;memset(&pending,0,sizeof pending);
 for(size_t i=0;i<bytes;i++){int a=hex(s[at+2*i]),c=hex(s[at+2*i+1]);if(a<0||c<0){pc_error(55);return;}b[i]=(uint8_t)(16*a+c);}
 if(pending.version!=2||pending.chord_size!=CHORD_BYTES||pending.count>RECORDS||bytes!=HEADER_BYTES+pending.count*sizeof(Record)||crc(pending.chords,CHORD_BYTES+pending.count*sizeof(Record))!=pending.crc){pc_error(55);return;}
 for(unsigned k=0;k<pending.count;k++){
  Record *r=&pending.records[k];if(!r->track[0]||length(r->track,128)>=128||r->instrument>=128||r->role>2||r->reserved[0]||r->reserved[1]||(r->engine!=255&&(r->engine==6||r->engine>PC_MS_ENGINE))){pc_error(55);return;}
 }
 read_epoch=__atomic_load_n(&host.project_epoch,AQ);read_serial=pc_project_new_serial();restore_attempts=0;
 read_project=project();uintptr_t previous_tracks=0;unsigned previous_count=0;
 read_first=tracks(read_project,&previous_tracks,&previous_count)&&previous_count?Q(previous_tracks,0):0;
 __atomic_store_n(&pending_valid,1,RL);pc_project_schedule();
}
/* UI work only, once the loaded model replaces the previous Track objects. */
void pc_project_restore(void){
 if(!__atomic_load_n(&pending_valid,AQ)||!pc_meta())return;
 uintptr_t p=project(),ts;unsigned nt;
 if(!tracks(p,&ts,&nt)||!nt||(p==read_project&&Q(ts,0)==read_first&&__atomic_load_n(&host.project_epoch,AQ)==read_epoch)){pc_unmeta();return;}
 unsigned applied=0,missing=0;
 uintptr_t instruments[RECORDS],programs[RECORDS];
 for(unsigned k=0;k<pending.count;k++){
  Record *r=&pending.records[k];uintptr_t instrument=0,program=0;
  for(unsigned j=0;j<nt;j++){
   uintptr_t t=Q(ts,8*j);if(!t||Q(t,0)!=host.base+0x6ecf118)continue;
   const char *id=track_id(t);size_t len=length(id,128);if(!len||len>=128||len!=length(r->track,128)||memcmp(id,r->track,len))continue;
   program=Q(t,0xbb8);if(!program||Q(program,0)!=host.base+0x6ec6860||I(program,0x1234)){program=0;continue;}
   uintptr_t b=Q(program,0x2808),e=Q(program,0x2810);if(b&&e>=b&&(e-b)%8==0&&e-b<=128*8&&r->instrument<(e-b)/8)instrument=Q(b,8*r->instrument);
   break;
  }
  instruments[k]=instrument;programs[k]=program;
  if(!instrument||!pc_valid(program,instrument))missing++;
 }
 if(missing){if(++restore_attempts>=128){__atomic_store_n(&pending_valid,0,RL);pc_error(56);}pc_unmeta();return;}
 if(!FN(PC_CH_IMPORT,int(*)(uintptr_t,const void *,unsigned))(p,pending.chords,CHORD_BYTES)){pc_unmeta();return;}
 for(unsigned k=0;k<pending.count;k++){
  Record *r=&pending.records[k];
  if((r->engine==255||r->engine==3||r->engine==5||pc_assign(programs[k],instruments[k],r->engine,r->preset,r->patch))&&pc_sc_set(programs[k],instruments[k],r->role))applied++;else missing++;
 }
 __atomic_store_n(&pending_valid,0,RL);__atomic_store_n(&host.ui.loaded_valid,0,RL);
 __atomic_fetch_add(&host.debug->loads,applied,RX);if(missing)pc_error(56);pc_unmeta();
}

/* Native pad lighting ticks in Sequence/Step/Sample views, so restoration is
 * not conditional on visiting the engine editor. Queue one UI callback at a
 * time; loading may replace the model after the first callback has run. */
void pc_project_schedule(void){
 if(!__atomic_load_n(&pending_valid,AQ)&&!pc_mix_needs_poll()&&!pc_project_new_pending())return;
 uintptr_t b=Q(pc_state_base(),0x20);if(!b||!Q(b,0x78))return;
 if(!__atomic_exchange_n(&restore_queued,1,__ATOMIC_ACQ_REL))
  FN(0x6d43500,void(*)(uint64_t))(37); /* UI kind18 */
}
void pc_project_poll(void){
 __atomic_store_n(&restore_queued,0,RL);
 pc_project_new_sync_ui();
 if(pc_project_new_pending())return;
 pc_project_restore();pc_mix_restore_poll();
}
