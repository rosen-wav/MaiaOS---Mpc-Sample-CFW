/* SPDX-License-Identifier: GPL-3.0-only
 * MPC native InputProgram and sample-backed Metronome. UI loads Samples;
 * audio processing uses existing native insert scheduling and fixed buffers.
 */
#include "internal.h"
typedef struct {uintptr_t object,owner,pad[6];} SampleReturn;
struct {uintptr_t model,program,object,owner;unsigned installed,last_error;uint64_t installs,restores,input_blocks,input_frames,input_nonzero;} pc_native_audio_state;
#define state pc_native_audio_state
/* ServiceLocator's unordered map has a global node chain at +0x10.
 * Native 0x143ad50 confirms node.next +0, typeinfo +8, value +0x10.
 * Read-only lookup avoids inserting an absent service into the registry. */
static uintptr_t service(uintptr_t type){
 uintptr_t locator=Q(pc_state_base(),0x1e98);if(!locator)return 0;
 uintptr_t node=Q(locator,0x10);for(unsigned n=0;node&&n<4096;n++,node=Q(node,0))if(Q(node,8)==type)return Q(node,0x10);return 0;
}
void pc_native_sequence_stop(void){
 /* Same transport service and stop command used by the physical STOP
  * responder. Calling the command directly avoids its double-tap action. */
 uintptr_t transport=service(host.base+0x6e7faa8);
 if(transport)FN(0x21390f0,void(*)(uintptr_t,unsigned))(transport,0);
}
static void release(uintptr_t owner){if(owner)FN(0x123bca0,void(*)(uintptr_t))(owner);}
static uintptr_t metro(void){uintptr_t m=service(host.base+0x6e7e500);return m&&Q(m,0)==host.base+0x6da4328?m:0;}
static int program(uintptr_t m,uintptr_t*p){
 if(!m)return 0;uintptr_t v=Q(m,0x328);if(!v||Q(v,0)!=host.base+0x6e3abc8)return 0;
 uintptr_t b=Q(v,0x2808),e=Q(v,0x2810);if(!b||e<b||(e-b)%8||e-b<64||e-b>1024)return 0;
 for(unsigned k=0;k<8;k++){uintptr_t i=Q(b,k*8);if(!i||Q(i,0)!=host.base+0x6ec3ca0||Q(i,0x2310)!=v||!Q(i,0x22e8))return 0;}*p=v;return 1;
}
static int assign(uintptr_t p,uintptr_t m,uintptr_t object,uintptr_t owner,unsigned custom){
 uintptr_t b=Q(p,0x2808);
 for(unsigned k=0;k<8;k++){
  uintptr_t pair[2]={custom?object:Q(m,0x338+k*16),custom?owner:Q(m,0x340+k*16)};
  if(!pair[0]||!pair[1])return 0;
  uintptr_t i=Q(b,8*k);FN(0x280ba80,void(*)(uintptr_t,unsigned,void*,unsigned))(i,0,pair,1);
  uintptr_t layer=Q(i,0x22e8);if(!layer||Q(layer,0x4a8)!=pair[0])return 0;
 }return 1;
}
void pc_native_click_restore(void){
 if(state.installed){uintptr_t m=metro(),p=0;if(m==state.model&&program(m,&p)&&p==state.program)assign(p,m,0,0,0);state.restores++;}
 uintptr_t old=state.owner;state.installed=0;state.model=state.program=state.object=state.owner=0;release(old);
}
int pc_native_click_load(const char*path){
 uintptr_t m=metro(),p=0,loader=service(host.base+0x6e08dd0);
 if(!program(m,&p)||!loader){state.last_error=1;host.ui.message="Native MPC metronome not ready";return 0;}
 uintptr_t file=0;FN(0xf535c0,void(*)(void*,const char*))(&file,path);
 SampleReturn s=FN(0x1df3db0,SampleReturn(*)(uintptr_t,uintptr_t*,float))(loader,&file,44100.f);FN(0xf0a290,void(*)(void*))(&file);
 if(!s.object||!s.owner){release(s.owner);state.last_error=2;host.ui.message="Native MPC click WAV load failed";return 0;}
 if(!assign(p,m,s.object,s.owner,1)){assign(p,m,0,0,0);release(s.owner);state.last_error=3;host.ui.message="Native click publication failed";return 0;}
 uintptr_t old=state.owner;state.model=m;state.program=p;state.object=s.object;state.owner=s.owner;state.installed=1;state.last_error=0;state.installs++;release(old);return 1;
}
void pc_native_input_process(uintptr_t p,uintptr_t b,unsigned n){
 if(!p||!b||!n||n>4096||I(b,0)!=2||I(b,4)<(int)n)return;
 uintptr_t c=Q(b,0x10);float*l=c?(float*)Q(c,0):0,*r=c?(float*)Q(c,8):0;if(!l||!r||l==r)return;
 state.input_blocks++;state.input_frames+=n;
 if(*(uint8_t*)(b+0x128)&1){memset(l,0,n*4);memset(r,0,n*4);}
 pc_audio_input(p,c,n,0);
 for(unsigned j=0;j<n;j++)if(l[j]!=0||r[j]!=0){*(uint8_t*)(b+0x128)=0;state.input_nonzero++;break;}
}
