/* SPDX-License-Identifier: GPL-3.0-only
 * Three shared, parallel native FX buses. UI owns model edits and factory calls;
 * the audio thread owns all accumulation, ramps and native DSP processing.
 * The routing core uses fixed storage, no file I/O, allocation or locks.
 */
#include "internal.h"
#include "dj_playback.h"
#include "limiter.h"
#include "airwindows.h"
#include "gain_table.h"
#define FX_FRAMES 4096u
#define FX_CONTROLLER 0x6d8e1e0u
#define FX_SUBMIX 0x6ec91d0u
#define FX_INSERTS 0x6dbb378u
#define FX_INSTRUMENT 0x6ec3ca0u
typedef struct {uintptr_t instrument,program;uint64_t controls;unsigned generation,audio_generation,gain_generation;float sends[3],sample_gain;} MixPad;
typedef struct {int32_t channels,capacity;uintptr_t allocated_size;float **data;uintptr_t allocated;float *stack[33];uint8_t cleared,pad[7];} FxBuffer;
_Static_assert(sizeof(FxBuffer)==0x130,"native audio buffer ABI");
static struct {
 MixPad pads[MIX_PADS];unsigned count,ready,epoch,audio_epoch,frames,project_generation,limit_block;
 uintptr_t owner,input,inserts;int types[3];unsigned last_error;
 PcFxProject initial;unsigned restore;
 float exempt[2][FX_FRAMES];
 float dj_return[2][FX_FRAMES];
 float pcm[3][2][FX_FRAMES];FxBuffer buffers[3];
 uint64_t blocks,inputs,returns[3];
} mix;
/* Custom effects keep independent per-slot contexts. Construct on UI only;
 * parameters cross lock-free mailboxes and all live mutation is audio-owned.
 * Contexts stay allocated until process exit, so selection never frees live DSP. */
static struct {void *ctx[3][4];void *(*create)(unsigned);void (*process)(void*,float*,float*,unsigned,const float*,unsigned);uint32_t params[3][6],generation[3];} extra;
static const char *extra_names[4]={"OFF","Grain Cloud","OFF","Galactic Reverb"};
static const char *extra_labels[4][6]={{"Stretch","Blur","Freeze","Pitch","Tone","Width"},{"Effect","Activity","Repeats","Shape","Space","Filter"},{"Drive","Bass","Mid","Treble","Cabinet","Level"},{"Decay","Brightness","Detune","Derez","Size","Mix"}};
static const float extra_defaults[4][6]={{.33f,.35f,0.f,.5f,.8f,.5f},{.6f,.5f,.5f,.5f,.3f,.85f},{.25f,.5f,.5f,.5f,.75f,.5f},{.65f,.75f,.25f,1.f,.8f,1.f}};
static int extra_prepare(unsigned slot,unsigned kind){
 if(__atomic_load_n(&extra.ctx[slot][kind],AQ))return 1;
 if(kind==3){pc_galactic_prepare(slot);__atomic_store_n(&extra.ctx[slot][kind],(void*)1,RL);return 1;}
 if(kind==2){__atomic_store_n(&extra.ctx[slot][kind],(void*)1,RL);return 1;}
 if(!extra.create){void*h=FN(0xb518a8,void*(*)(const char*,int))("/run/mpc-pc-integrated-v040/libpc-fx.aarch64.so",2);if(!h)return 0;
 void*(*sym)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));extra.create=sym(h,"mpc_fx_create");extra.process=sym(h,"mpc_fx_process");if(!extra.create||!extra.process){extra.create=0;return 0;}}
 void *p=extra.create(kind);__atomic_store_n(&extra.ctx[slot][kind],p,RL);return p!=0;
}
static int custom_type(int t){return t==29||t==31;}
static int bus_active(unsigned n){int t=__atomic_load_n(&mix.types[n],AQ);return custom_type(t)?__atomic_load_n(&extra.ctx[n][t-28],AQ)!=0:t>=0;}
static uintptr_t controller(void){uintptr_t c=Q(pc_state_base(),0x1eb0);return c&&Q(c,0)==host.base+FX_CONTROLLER?c:0;}
static uint32_t float_bits(float v){uint32_t b;memcpy(&b,&v,4);return b;}
uint64_t pc_mix_default(void){return (uint64_t)601<<42;}
static MixPad *find(uintptr_t i){unsigned count=__atomic_load_n(&mix.count,AQ);for(unsigned n=0;n<count;n++)if(i&&__atomic_load_n(&mix.pads[n].instrument,AQ)==i)return &mix.pads[n];return 0;}
uint64_t pc_mix_controls(uintptr_t i){MixPad *p=find(i);return (p?__atomic_load_n(&p->controls,AQ):pc_mix_default());}
static int valid_controls(uint64_t c){return !(c>>52)&&((c>>42)&1023)<=841;}
int pc_mix_set_controls(uintptr_t program,uintptr_t i,uint64_t value){
 if(!valid_controls(value)||!pc_valid(program,i))return 0;MixPad *p=find(i);
 if(!p){if(value==pc_mix_default())return 1;unsigned count=__atomic_load_n(&mix.count,AQ),n;
  for(n=0;n<count;n++)if(!__atomic_load_n(&mix.pads[n].instrument,AQ))break;
  if(n==count){if(count==MIX_PADS){pc_error(76);return 0;}__atomic_store_n(&mix.count,count+1,RL);}
  p=&mix.pads[n];p->program=program;__atomic_store_n(&p->controls,value,RL);__atomic_add_fetch(&p->generation,1,RL);__atomic_store_n(&p->instrument,i,RL);return 1;
 }
 __atomic_store_n(&p->controls,value,RL);return 1;
}
int pc_mix_nondefault(uintptr_t i){return pc_mix_controls(i)!=pc_mix_default();}
unsigned pc_mix_send(uintptr_t i,unsigned n){return n<3?(unsigned)(pc_mix_controls(i)>>(14*n))&MIX_POSITION:0;}
int pc_mix_set_send(uintptr_t program,uintptr_t i,unsigned n,unsigned position){
 if(n>2||position>MIX_POSITION)return 0;uint64_t c=pc_mix_controls(i),mask=(uint64_t)MIX_POSITION<<(14*n);
 return pc_mix_set_controls(program,i,(c&~mask)|(uint64_t)position<<(14*n));
}
int pc_mix_volume(uintptr_t i){return (int)((pc_mix_controls(i)>>42)&1023)-601;}
int pc_mix_set_volume(uintptr_t program,uintptr_t i,int db){
 if(db<MIX_GAIN_MIN||db>MIX_GAIN_MAX)return 0;uint64_t c=pc_mix_controls(i);
 return pc_mix_set_controls(program,i,(c&(((uint64_t)1<<42)-1))|(uint64_t)(db+601)<<42);
}
float pc_mix_gain(uintptr_t i){return pc_output_gain[(pc_mix_controls(i)>>42)&1023];}
void pc_mix_forget(uintptr_t i,uintptr_t program){
 unsigned count=__atomic_load_n(&mix.count,AQ);for(unsigned n=0;n<count;n++)if((i&&__atomic_load_n(&mix.pads[n].instrument,AQ)==i)||(program&&mix.pads[n].program==program))__atomic_store_n(&mix.pads[n].instrument,0,RL);
}
void pc_mix_reset(void){
 __atomic_store_n(&mix.ready,0,RL);__atomic_store_n(&mix.project_generation,__atomic_load_n((unsigned *)(pc_state_base()+0x1ef4),AQ),RL);__atomic_add_fetch(&mix.epoch,1,RL);
 unsigned count=__atomic_load_n(&mix.count,AQ);for(unsigned n=0;n<count;n++)__atomic_store_n(&mix.pads[n].instrument,0,RL);
 mix.restore=0;for(unsigned n=0;n<3;n++)__atomic_store_n(&mix.types[n],-1,RL);
}
int pc_mix_guard(void){return __atomic_load_n(&mix.ready,AQ)!=0&&!pc_project_new_pending()&&Q(pc_state_base(),0x1eb0)&&__atomic_load_n(&mix.project_generation,AQ)==__atomic_load_n((unsigned *)(pc_state_base()+0x1ef4),AQ);}
int pc_mix_ready(void){return pc_mix_guard();}
/* Route every InstrumentProgram, including non-selected tracks, before the
 * native graph runs. Use its property setter for notifications/graph updates;
 * never write live routing properties from the audio callback. */
void pc_mix_route_program(uintptr_t program){
 if(!pc_mix_guard()||!program||Q(program,0)!=host.base+0x6ec6860||I(program,0x1234))return;
 uintptr_t b=Q(program,0x2808),e=Q(program,0x2810);if(!b||e<b||(e-b)%8||e-b>128*8)return;
 const uint64_t route[4]={1,3,0x100000000ull,0x3f800000ull};
 for(uintptr_t p=b;p<e;p+=8){uintptr_t i=Q(p,0);if(pc_valid(program,i)&&Q(i,0x560)!=1)FN(0x1561d00,void(*)(uintptr_t,const uint64_t *))(i+0x510,route);}
}

static int targets(uintptr_t *owner,uintptr_t *output){
 uintptr_t c=controller();if(!c)return 0;uintptr_t ctx=Q(c,0x130);if(!ctx)return 0;
 uintptr_t holder=Q(ctx,0x100),p=holder?Q(holder,0):0,o=Q(ctx,0xe0);
 if(!p||!o||Q(p,0)!=host.base+FX_SUBMIX||I(p,0x1234)!=8||Q(o,0)!=host.base+0x6ec8290||I(o,0x1234)!=10)return 0;
 uintptr_t ins=Q(p,0x988);if(!ins||Q(ins,0)!=host.base+FX_INSERTS)return 0;
 uintptr_t b=Q(ins,0xa0),e=Q(ins,0xa8);if(!b||e<b||(e-b)%8||e-b<3*8||e-b>16*8)return 0;
 *owner=p;*output=o;return 1;
}
static unsigned native_fx_count(void){uintptr_t c=controller();if(!c)return 0;uintptr_t b=Q(c,0x180),e=Q(c,0x188);return b&&e>b&&(e-b)%0x158==0&&(e-b)/0x158<=64?(unsigned)((e-b)/0x158):0;}
static int removed_fx(int type){
 if(type==30)return 1;
 if(type<0||type>=28||native_fx_count()!=28)return 0;
 uintptr_t c=controller();const char*name=c?(const char*)Q(Q(c,0x180)+(unsigned)type*0x158,8):0;
 if(!name)return 0;
 for(unsigned i=0;name[i]&&i<80;i++){
  const char*needle="guitar";unsigned j=0;for(;needle[j]&&name[i+j];j++){unsigned ch=(unsigned char)name[i+j];if(ch>='A'&&ch<='Z')ch+=32;if(ch!=(unsigned char)needle[j])break;}
  if(!needle[j])return 1;
 }return 0;
}
unsigned pc_fx_count(void){if(native_fx_count()!=28)return 0;unsigned n=2;for(int t=0;t<28;t++)if(!removed_fx(t))n++;return n;}
int pc_fx_catalog_type(unsigned choice){if(!choice)return -1;for(int t=0;t<28;t++)if(!removed_fx(t)&&!--choice)return t;return choice==1?29:choice==2?31:-1;}
unsigned pc_fx_catalog_index(int type){unsigned count=pc_fx_count();for(unsigned n=0;n<=count;n++)if(pc_fx_catalog_type(n)==type)return n;return 0;}
static uintptr_t row(int index){unsigned count=native_fx_count();return index>=0&&(unsigned)index<count?Q(controller(),0x180)+(unsigned)index*0x158:0;}
const char *pc_fx_name(int index){if(removed_fx(index))return "OFF";if(custom_type(index))return extra_names[index-28];uintptr_t r=row(index);return r?(const char *)Q(r,8):"OFF";}
const char *pc_fx_label(unsigned slot,unsigned knob){if(slot<3&&knob<6&&custom_type(mix.types[slot]))return extra_labels[mix.types[slot]-28][knob];uintptr_t r=slot<3?row(mix.types[slot]):0;return r&&knob<6&&I(r,0x20+0x30*knob)>=0?(const char *)Q(r,0x28+0x30*knob):"--";}
const char *pc_fx_option(unsigned slot,unsigned parameter){
 if(slot>2)return 0;int t=mix.types[slot];
 if(t==29&&parameter==0){static const char*names[]={"Arp","Cutup","Chop","Glide","Seq","Stack","Cloud","Drone","Chain","Taps","Warp"};unsigned v=(unsigned)(pc_fx_position(slot,0)*11u/(MIX_POSITION+1u));return names[v>10?10:v];}
 if(t==28&&parameter==2)return pc_fx_position(slot,2)>=8192?"ON":"OFF";
 return 0;
}
static uintptr_t ui_effect(unsigned slot){uintptr_t ins=__atomic_load_n(&mix.inserts,AQ);if(!ins||slot>2)return 0;uintptr_t b=Q(ins,0xa0),e=Q(ins,0xa8);return b&&e>=b+(slot+1)*8?Q(b,slot*8):0;}
static unsigned param_count(uintptr_t fx){return fx?FN(0x2754590,unsigned(*)(uintptr_t))(fx):0;}
static float get_param(uintptr_t fx,unsigned id){return fx?FN(0x2755fe0,float(*)(uintptr_t,unsigned))(fx,id):0.f;}
static void set_param(uintptr_t fx,unsigned id,float value){if(fx) ((void(*)(uintptr_t,unsigned,float))Q(Q(fx,0),0x148))(fx,id,value);}
static void set_raw(uintptr_t fx,unsigned id,float value){if(fx) ((void(*)(uintptr_t,unsigned,float))Q(Q(fx,0),0x140))(fx,id,value);}
unsigned pc_fx_position(unsigned slot,unsigned knob){
 if(slot<3&&knob<6&&custom_type(mix.types[slot])){uint32_t bits=__atomic_load_n(&extra.params[slot][knob],AQ);float f;memcpy(&f,&bits,4);return (unsigned)(f*MIX_POSITION+.5f);}
 uintptr_t r=slot<3?row(mix.types[slot]):0,fx=ui_effect(slot);if(!r||!fx||knob>5)return 0;
 int id=I(r,0x20+0x30*knob);if(id<0||(unsigned)id>=param_count(fx))return 0;
 float p=get_param(fx,(unsigned)id);return p>=0&&p<=1?(unsigned)(p*MIX_POSITION+.5f):0;
}
int pc_fx_type(unsigned slot){
 return slot<3&&pc_mix_guard()?__atomic_load_n(&mix.types[slot],AQ):-1;
}
static uintptr_t description(uintptr_t r){
 uintptr_t c=controller(),node=Q(c,0x160),end=c+0x158;unsigned id=(unsigned)I(r,0);
 for(unsigned depth=0;node&&node!=end&&depth<128;depth++){
  unsigned key=(unsigned)I(node,0x20);if(id==key)return node+0x28;node=Q(node,id<key?0x10:0x18);
 }return 0;
}
int pc_fx_select(unsigned slot,int index){
 if(slot>2||removed_fx(index)||index==28||index< -1||(index>=0&&!custom_type(index)&&!row(index)))return 0;uintptr_t owner=__atomic_load_n(&mix.owner,AQ),ins=__atomic_load_n(&mix.inserts,AQ);if(!owner||!ins)return 0;
 host.ui.message=0;
 if(index==29)for(unsigned other=0;other<3;other++)if(other!=slot&&__atomic_load_n(&mix.types[other],AQ)==29){host.ui.message="Grain Cloud: one send per project";return 0;}
 if(custom_type(index)){
  if(!extra_prepare(slot,(unsigned)index-28)){pc_error(80);return 0;}
  /* Turn native slot OFF while the custom context receives this bus. */
  FN(0x2761e20,void(*)(uintptr_t,unsigned,uintptr_t,unsigned))(ins,slot,0,0);
  for(unsigned k=0;k<6;k++)__atomic_store_n(&extra.params[slot][k],float_bits(extra_defaults[index-28][k]),RL);
  __atomic_add_fetch(&extra.generation[slot],1,RL);__atomic_store_n(&mix.types[slot],index,RL);pc_error(0);return 1;
 }
 if(index<0){FN(0x2761e20,void(*)(uintptr_t,unsigned,uintptr_t,unsigned))(ins,slot,0,0);__atomic_store_n(&mix.types[slot],-1,RL);return 1;}
 uintptr_t r=row(index),desc=description(r);if(!desc){pc_error(70);return 0;}
 uintptr_t empty=0;FN(0xf1c620,void(*)(uintptr_t *))(&empty);
 uintptr_t fx=FN(0x276af70,uintptr_t(*)(uintptr_t,unsigned,uintptr_t,unsigned,uintptr_t *,uintptr_t,unsigned))(owner+0x78,slot,desc,0,&empty,0,1);
 FN(0xf0a290,void(*)(uintptr_t *))(&empty);if(!fx){pc_error(71);return 0;}
 uintptr_t b=Q(r,0x140),e=Q(r,0x148);unsigned count=param_count(fx);
 if(e<b||(e-b)%8||e-b>256*8||count>MIX_MAX_PARAMS){pc_error(72);return 0;}
 for(uintptr_t p=b;p<e;p+=8){unsigned id=(unsigned)I(p,0);float value=F(p,4);if(id<count&&value==value)set_raw(fx,id,value);}
 /* The factory's final flag is the INSERT slot enable state. Its queued
  * publication re-applies this flag after graph updates. Enabling only the
  * Effect object is temporary and was overwritten by the old false flag. */
 // Native insert enable and per-slot enable are distinct from loading.
 // The DJ has no native sounding pad to wake/bypass this chain for us.
 FN(0x2760000,void(*)(uintptr_t,unsigned))(ins,1);
 FN(0x2760680,void(*)(uintptr_t,unsigned,unsigned))(ins,slot,1);
 __atomic_store_n(&mix.types[slot],index,RL);pc_error(0);return 1;
}
int pc_fx_knob(unsigned slot,unsigned knob,unsigned position){
 if(slot>2||knob>5||position>MIX_POSITION)return 0;
 if(custom_type(mix.types[slot])){__atomic_store_n(&extra.params[slot][knob],float_bits((float)position/MIX_POSITION),RL);return 1;}uintptr_t r=row(mix.types[slot]),fx=ui_effect(slot);if(!r||!fx)return 0;
 int id=I(r,0x20+0x30*knob);if(id<0||(unsigned)id>=param_count(fx))return 0;
 set_param(fx,(unsigned)id,(float)position/(float)MIX_POSITION);return 1;
}
static int capture_fx(uintptr_t fx,int type,PcFxState *out){
 memset(out,0,sizeof *out);out->type=type;if(type<0)return 1;if(!fx)return 0;
 out->count=param_count(fx);if(out->count>MIX_MAX_PARAMS)return 0;
 for(unsigned j=0;j<out->count;j++){float value=get_param(fx,j);if(!(value>=0&&value<=1))return 0;out->params[j]=value;}return 1;
}
int pc_fx_snapshot(PcFxProject *out){
 /* Serialization already owns metadata. Rebuilding native inserts here
  * can wait for the graph while the native archive owns its own locks. */
 if(!out||!pc_mix_guard())return 0;
 memset(out,0,sizeof *out);out->version=1;
 for(unsigned n=0;n<3;n++){
  if(custom_type(mix.types[n])){out->slots[n].type=mix.types[n];out->slots[n].count=6;for(unsigned k=0;k<6;k++){uint32_t b=__atomic_load_n(&extra.params[n][k],AQ);memcpy(&out->slots[n].params[k],&b,4);}}
  else if(!capture_fx(ui_effect(n),mix.types[n],&out->slots[n]))return 0;
 }return 1;
}
int pc_fx_restore(const PcFxProject *in){
 if(!in||in->version!=1)return 0;
 for(unsigned n=0;n<3;n++){const PcFxState *s=&in->slots[n];if(s->type< -1||s->type>=32||s->count>MIX_MAX_PARAMS||(s->type<0&&s->count)||(custom_type(s->type)&&s->count!=6))return 0;for(unsigned j=0;j<s->count;j++)if(!(s->params[j]>=0&&s->params[j]<=1))return 0;}
 if(__atomic_load_n(&mix.project_generation,AQ)!=__atomic_load_n((unsigned *)(pc_state_base()+0x1ef4),AQ))pc_mix_reset();mix.initial=*in;unsigned grain_seen=0;for(unsigned n=0;n<3;n++)if(mix.initial.slots[n].type==29){if(grain_seen){mix.initial.slots[n].type=-1;mix.initial.slots[n].count=0;}else grain_seen=1;}for(unsigned n=0;n<3;n++)if(mix.initial.slots[n].type==28||removed_fx(mix.initial.slots[n].type)){mix.initial.slots[n].type=-1;mix.initial.slots[n].count=0;}mix.restore=1;__atomic_store_n(&mix.ready,0,RL);__atomic_add_fetch(&mix.epoch,1,RL);return 1;
}
int pc_mix_ensure(void){
 if(!pc_project_new_sync_locked())return 0;
 if(__atomic_load_n(&mix.project_generation,AQ)!=__atomic_load_n((unsigned *)(pc_state_base()+0x1ef4),AQ))pc_mix_reset();
 uintptr_t owner,output;if(!targets(&owner,&output)||native_fx_count()!=28)return 0;
 const int same_project_ready=pc_mix_guard();
 if(same_project_ready&&owner==__atomic_load_n(&mix.owner,AQ))return 1;
 __atomic_store_n(&mix.ready,0,RL);__atomic_store_n(&mix.owner,owner,RL);__atomic_store_n(&mix.input,output,RL);__atomic_store_n(&mix.inserts,Q(owner,0x988),RL);
 PcFxProject state;if(mix.restore)state=mix.initial;else{
  memset(&state,0,sizeof state);state.version=1;state.slots[0].type=state.slots[1].type=state.slots[2].type=-1;
  /* No native insert is an authority for project-owned sends. */
 }
 /* Snapshot all old values before replacing slot zero. Native setters own
  * publication and retirement of effects; the extension never frees them. */
 for(unsigned n=0;n<3;n++)__atomic_store_n(&mix.types[n],-1,RL);
 for(unsigned order=0;order<3;order++){
  unsigned n=order;const PcFxState *s=&state.slots[n];if(!pc_fx_select(n,s->type))return 0;
  if(custom_type(s->type)){if(s->count!=6){pc_error(74);return 0;}for(unsigned j=0;j<6;j++)__atomic_store_n(&extra.params[n][j],float_bits(s->params[j]),RL);continue;}
  uintptr_t fx=ui_effect(n);if(s->type>=0){unsigned count=param_count(fx);if(s->count&&s->count!=count){pc_error(74);return 0;}
   for(unsigned j=0;j<s->count;j++)set_param(fx,j,s->params[j]);}
 }
 mix.restore=0;__atomic_add_fetch(&mix.epoch,1,RL);__atomic_store_n(&mix.ready,1,RL);
 /* The patched native routing callback includes every pad in this submix.
  * Three sends are controlled independently; only one may host Grain Cloud. */
 uintptr_t context=Q(controller(),0x128);if(context)pc_mix_route_program(Q(context,0xb8));pc_mix_route_project();return 1;
}
static int buffer_ok(uintptr_t b,unsigned n){return b&&I(b,0)==2&&n&&n<=FX_FRAMES&&I(b,4)>=(int)n&&Q(b,0x10)&&Q(Q(b,0x10),0)&&Q(Q(b,0x10),8)&&Q(Q(b,0x10),0)!=Q(Q(b,0x10),8);}
static uintptr_t audio_effect(unsigned n){uintptr_t ins=__atomic_load_n(&mix.inserts,AQ);if(!ins)return 0;uintptr_t b=Q(ins,0x108),e=Q(ins,0x110);return b&&e>=b+(n+1)*8?Q(b,n*8):0;}
static void audio_epoch(unsigned n){
 unsigned epoch=__atomic_load_n(&mix.epoch,AQ);if(epoch!=mix.audio_epoch){memset(mix.pcm,0,sizeof mix.pcm);memset(mix.exempt,0,sizeof mix.exempt);mix.audio_epoch=epoch;mix.frames=0;}
 if(!mix.frames){mix.frames=n;mix.limit_block=pc_limiter_enabled();}
}
/* Native sample pads use the same persisted trim gain as synth pads.
 * Their ordinary native Volume remains an independent, editable pad level. */
void pc_mix_native_gain(uintptr_t i,uintptr_t b,unsigned n){
 if(pc_find(i)>=0||!buffer_ok(b,n))return;
 MixPad*p=find(i);if(!p)return;
 unsigned generation=__atomic_load_n(&p->generation,AQ);
 uint64_t controls=__atomic_load_n(&p->controls,AQ);float target=pc_output_gain[(controls>>42)&1023],gain=p->gain_generation==generation?p->sample_gain:1.f;
 float step=(target-gain)/(float)n;float*l=(float*)Q(Q(b,0x10),0),*r=(float*)Q(Q(b,0x10),8);
 for(unsigned j=0;j<n;j++){gain+=step;l[j]*=gain;r[j]*=gain;}p->sample_gain=target;p->gain_generation=generation;
}
void pc_mix_input(uintptr_t i,uintptr_t b,uintptr_t route,unsigned n){
 pc_tune_audible_sample(i,b,n);
 if(!pc_mix_guard()||!i||Q(i,0)!=host.base+FX_INSTRUMENT||!buffer_ok(b,n)||!route||I(route,8)!=0||I(route,12)!=1||(*(uint8_t *)(b+0x128)&1))return;
 /* Metronome instruments share the Instrument vtable, but their owning
  * program is not a DrumProgram. Never collect them into the FX buses. */
 uintptr_t program=Q(i,0x2310);if(!program||Q(program,0)!=host.base+0x6ec6860||I(program,0x1234)!=0)return;
 float route_gain=F(route,0x10);if(!(route_gain>0&&route_gain<1000000.f))return;
 audio_epoch(n);if(mix.frames!=n)return;MixPad *p=find(i);uint64_t c=p?__atomic_load_n(&p->controls,AQ):pc_mix_default();
 float sends[3],step[3];unsigned generation=p?__atomic_load_n(&p->generation,AQ):0;unsigned active[3];for(unsigned k=0;k<3;k++){
  float target=(float)((c>>(14*k))&MIX_POSITION)/(float)MIX_POSITION;
  sends[k]=p&&p->audio_generation==generation?p->sends[k]:target;step[k]=(target-sends[k])/(float)n;
  active[k]=bus_active(k)&&(custom_type(__atomic_load_n(&mix.types[k],AQ))||audio_effect(k)!=0);
 }
 float *left=(float *)Q(Q(b,0x10),0),*right=(float *)Q(Q(b,0x10),8);
 int exempt=mix.limit_block&&pc_sc_role(i)==1;
 for(unsigned j=0;j<n;j++){
  float dry=0,l=left[j],r=right[j];for(unsigned k=0;k<3;k++){
   sends[k]+=step[k];if(active[k]){if(sends[k]>dry)dry=sends[k];mix.pcm[k][0][j]+=l*route_gain*sends[k];mix.pcm[k][1][j]+=r*route_gain*sends[k];}
  }
  left[j]=l*(1.f-dry);right[j]=r*(1.f-dry);
  if(exempt){mix.exempt[0][j]+=left[j]*route_gain;mix.exempt[1][j]+=right[j]*route_gain;}
 }
 if(p&&__atomic_load_n(&p->instrument,AQ)==i&&generation==__atomic_load_n(&p->generation,AQ)){for(unsigned k=0;k<3;k++)p->sends[k]=(float)((c>>(14*k))&MIX_POSITION)/(float)MIX_POSITION;p->audio_generation=generation;}
 mix.inputs++;
}
void pc_mix_external(float*l,float*r,unsigned n){
 if(!pc_mix_guard()||!n||n>FX_FRAMES)return;audio_epoch(n);if(mix.frames!=n)return;
 for(unsigned k=0;k<3;k++){float gain=pc_input_send(k)/(float)MIX_POSITION;if(!gain||!bus_active(k))continue;for(unsigned j=0;j<n;j++){mix.pcm[k][0][j]+=l[j]*gain;mix.pcm[k][1][j]+=r[j]*gain;}}
}
static void native_process(uintptr_t fx,uintptr_t b,unsigned n){FN(0x27599e0,void(*)(uintptr_t,uintptr_t,unsigned))(fx,b,n);}
typedef struct{unsigned slot,n,generation,active,custom;int type;uintptr_t fx;void*context;float params[6];}FxTask;
static void fx_task_run(void*arg){
 FxTask*t=arg;if(!t->active)return;unsigned k=t->slot;FxBuffer*buf=&mix.buffers[k];
 if(t->custom){
  if(t->type==31)pc_galactic_process(k,mix.pcm[k][0],mix.pcm[k][1],t->n,t->params,t->generation);
  else extra.process(t->context,mix.pcm[k][0],mix.pcm[k][1],t->n,t->params,t->generation);
  buf->cleared=0;
 }
 else {
  // This selected send owns an active DSP, even when the native submix
  // has no playing pads. Publish the audio-side gate on its audio owner.
  __atomic_store_n((unsigned*)(t->fx+0x2f8),1,RL);
  native_process(t->fx,(uintptr_t)buf,t->n);
 }
}

int pc_mix_chain(uintptr_t inserts,uintptr_t b,unsigned n){
 pc_padfx_record_audio(inserts);
 if(!pc_mix_guard()||!buffer_ok(b,n))return 0;uintptr_t owner=__atomic_load_n(&mix.owner,AQ);
 if(!owner)return 0;
 uintptr_t input=__atomic_load_n(&mix.input,AQ);
 if(input&&Q(input,0)==host.base+0x6ec8290&&I(input,0x1234)==10&&Q(input,0x988)==inserts){pc_native_input_process(input,b,n);return 1;}
 uintptr_t first=Q(inserts,0x108),end=Q(inserts,0x110);
 if(end<first||(end-first)%8||end-first>16*8)return 0;

 if(inserts!=__atomic_load_n(&mix.inserts,AQ))return 0;
 if(pc_bounce_ensure_synth(b,n))pc_bounce_synth_route(b,n);
 audio_epoch(n);if(mix.frames!=n){memset(mix.pcm,0,sizeof mix.pcm);memset(mix.exempt,0,sizeof mix.exempt);mix.frames=n;}
 float *left=(float *)Q(Q(b,0x10),0),*right=(float *)Q(Q(b,0x10),8);
 unsigned active=0;
 for(unsigned k=0;k<3;k++)
  if(bus_active(k)&&(custom_type(__atomic_load_n(&mix.types[k],AQ))||audio_effect(k)))active|=1u<<k;
 pc_dj_graph_audio(n,mix.pcm,active);
 FxTask tasks[3];PcFxWork work[3];memset(tasks,0,sizeof tasks);
 for(unsigned k=0;k<3;k++){
  FxBuffer*buf=&mix.buffers[k];memset(buf,0,sizeof*buf);buf->channels=2;buf->capacity=(int32_t)n;buf->data=buf->stack;buf->stack[0]=mix.pcm[k][0];buf->stack[1]=mix.pcm[k][1];buf->cleared=1;
  for(unsigned j=0;j<n;j++)if(mix.pcm[k][0][j]!=0||mix.pcm[k][1][j]!=0){buf->cleared=0;break;}
  FxTask*t=&tasks[k];t->slot=k;t->n=n;t->type=__atomic_load_n(&mix.types[k],AQ);t->fx=t->type>=0&&k<(end-first)/8?Q(first,k*8):0;
  t->custom=custom_type(t->type)&&__atomic_load_n(&extra.ctx[k][t->type-28],AQ)!=0;
  t->active=t->fx||t->custom;
  if(t->custom){t->context=__atomic_load_n(&extra.ctx[k][t->type-28],AQ);t->generation=__atomic_load_n(&extra.generation[k],AQ);for(unsigned j=0;j<6;j++){uint32_t bits=__atomic_load_n(&extra.params[k][j],AQ);memcpy(&t->params[j],&bits,4);}}
  work[k]=(PcFxWork){t->active?fx_task_run:0,t};
 }
 /* Both native and custom send DSPs finish inside this callback. */
 if(!pc_fx_workers_run(work,n))for(unsigned k=0;k<3;k++)fx_task_run(&tasks[k]);
 for(unsigned k=0;k<3;k++){
  FxBuffer*buf=&mix.buffers[k];if(tasks[k].active){mix.returns[k]++;
   if(!(buf->cleared&1)){if(*(uint8_t *)(b+0x128)&1){memset(left,0,n*4);memset(right,0,n*4);*(uint8_t *)(b+0x128)=0;}
    for(unsigned j=0;j<n;j++){float l=mix.pcm[k][0][j],r=mix.pcm[k][1][j];if(l>=-1000000.f&&l<=1000000.f)left[j]+=l;if(r>=-1000000.f&&r<=1000000.f)right[j]+=r;}
   }
  }
  memset(mix.pcm[k][0],0,n*sizeof(float));memset(mix.pcm[k][1],0,n*sizeof(float));
 }
 if(mix.limit_block){
  if(*(uint8_t*)(b+0x128)&1){memset(left,0,n*4);memset(right,0,n*4);*(uint8_t*)(b+0x128)=0;}
  pc_limiter_process(left,right,mix.exempt[0],mix.exempt[1],n,mix.audio_epoch);
 }
 if(mix.limit_block){memset(mix.exempt[0],0,n*sizeof(float));memset(mix.exempt[1],0,n*sizeof(float));}
 mix.frames=0;mix.blocks++;
 for(unsigned k=3;k<(end-first)/8;k++){uintptr_t fx=Q(first,k*8);if(fx)native_process(fx,b,n);}
 /* Bounded diagnostics in the unused gap before the native timeline. */
 __atomic_store_n((uint64_t *)(pc_state_base()+0x1ec0),mix.blocks,RL);__atomic_store_n((uint64_t *)(pc_state_base()+0x1ec8),mix.inputs,RL);
 for(unsigned k=0;k<3;k++)__atomic_store_n((uint64_t *)(pc_state_base()+0x1ed0+8*k),mix.returns[k],RL);
 pc_bounce_fx(b,n);return 1;
}

void pc_mix_dj_fallback(float *left,float *right,unsigned offset,unsigned frames){
 if(!pc_mix_guard()||!frames||frames>FX_FRAMES)return;
 FxBuffer b;memset(&b,0,sizeof b);b.channels=2;b.capacity=frames;b.data=b.stack;
 b.stack[0]=mix.dj_return[0];b.stack[1]=mix.dj_return[1];
 memset(mix.dj_return,0,frames*sizeof(float));memset(mix.dj_return[1],0,frames*sizeof(float));
 uintptr_t inserts=__atomic_load_n(&mix.inserts,AQ);
 if(!pc_mix_chain(inserts,(uintptr_t)&b,frames))return;
 for(unsigned i=0;i<frames;i++){left[offset+i]+=mix.dj_return[0][i];right[offset+i]+=mix.dj_return[1][i];}
}

unsigned pc_mix_volume_position(uintptr_t i){int db=pc_mix_volume(i);if(db< -240)db=-240;if(db>240)db=240;return (unsigned)((db+240)*16383/480);}

/* UI calls under native EngineMode, before worker starts. Recreate native FX
 * with identical controls to discard tails left by prior live playback. */
int pc_mix_bounce_prepare(void){PcFxProject saved;if(!pc_fx_snapshot(&saved))return 0;for(unsigned k=0;k<3;k++){if(custom_type(saved.slots[k].type)){__atomic_add_fetch(&extra.generation[k],1,RL);continue;}if(!pc_fx_select(k,saved.slots[k].type))return 0;uintptr_t fx=ui_effect(k);for(unsigned j=0;j<saved.slots[k].count;j++)set_param(fx,j,saved.slots[k].params[j]);}__atomic_add_fetch(&mix.epoch,1,RL);return 1;}
/* Selected-sound export can omit the shared Submix from its render graph.
 * Drain the already accumulated sends into its dry target exactly once. */
static uint64_t bounce_block;
void pc_mix_bounce_begin(void){bounce_block=mix.blocks;}
int pc_mix_bounce_render(uintptr_t program,uintptr_t instrument,uintptr_t destination,unsigned n){
 if(!pc_mix_guard()||!program||Q(program,0)!=host.base+0x6ec6860)return 0;
 if(destination!=program&&destination!=instrument)return 0;
 if(!destination||!Q(destination,0xba8))return 0;
 uintptr_t target=FN(0x276abc0,uintptr_t(*)(uintptr_t,unsigned))(destination+0x78,0);
 if(!buffer_ok(target,n))return 0;
 uintptr_t inserts=__atomic_load_n(&mix.inserts,AQ);if(!inserts)return 0;
 /* If the native submix already ran, do not process it twice. */
 if(mix.blocks!=bounce_block)return 0;
 if(!mix.frames){
  /* Selected-sound export can bypass the Instrument route callback as well
   * as the shared submix. Feed its actual pad sends into that same renderer. */
  struct{uint64_t unused;uint32_t type,channels;float gain;uint32_t padding;}route={0,0,1,1.f,0};
  if(!pc_valid(program,instrument))return 0;
  pc_mix_input(instrument,target,(uintptr_t)&route,n);
 }
 return pc_mix_chain(inserts,target,n);
}
int pc_mix_bounce_copy(uintptr_t program,uintptr_t source,unsigned n){if(!buffer_ok(source,n)||!program)return 0;
 /* Native writer18bd450 obtains destination+78 even for Instruments.
  * Do not redirect an Instrument export into its parent Program buffer. */
 uintptr_t vt=Q(program,0);
 if(vt!=host.base+FX_INSTRUMENT&&vt!=host.base+0x6ec6860)return 0;
 if(!Q(program,0xba8))return 0;
 uintptr_t target=FN(0x276abc0,uintptr_t(*)(uintptr_t,unsigned))(program+0x78,0);if(!buffer_ok(target,n))return 0;if(target==source)return 1;float**s=(float**)Q(source,0x10),**d=(float**)Q(target,0x10);if(d[0]==s[1]||d[1]==s[0])return 0;memcpy(d[0],s[0],n*4);memcpy(d[1],s[1],n*4);*(uint8_t*)(target+0x128)=*(uint8_t*)(source+0x128);return 1;}

void pc_mix_bounce_reset(void){for(unsigned k=0;k<3;k++)__atomic_add_fetch(&extra.generation[k],1,RL);__atomic_add_fetch(&mix.epoch,1,RL);}
