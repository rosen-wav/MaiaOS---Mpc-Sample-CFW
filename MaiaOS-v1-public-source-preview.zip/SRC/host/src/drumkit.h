#ifndef PC_DRUMKIT_H
#define PC_DRUMKIT_H
#include <stdint.h>
unsigned pc_drumkit_active(void);
int pc_drumkit_open(uintptr_t,unsigned);
void pc_drumkit_close(void);
void pc_drumkit_event(unsigned,unsigned);
void pc_drumkit_lock_edit(void);
int pc_drumkit_pad(unsigned,unsigned);
int pc_drumkit_pressure(uintptr_t,float);
int pc_drumkit_panel_pad(uintptr_t,unsigned,float);
uint64_t pc_drumkit_hw_colour(uintptr_t,uint64_t);
void pc_drumkit_refresh_lights(void);
int pc_drumkit_paint(uintptr_t,uintptr_t);
#endif
