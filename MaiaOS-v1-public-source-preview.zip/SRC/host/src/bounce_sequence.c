/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "bounce.h"
typedef struct {uint8_t bytes[56];} Event;
typedef struct {uintptr_t pad;unsigned color,pad2;uintptr_t parent,left,right;uint64_t count;} Set;
static struct {Set old,next,pairs;uintptr_t list;PcBouncePlan plan;unsigned count,ready;} seqjob;
static void empty(Set*s){memset(s,0,sizeof *s);s->left=s->right=(uintptr_t)s+8;}
void pc_bounce_sequence_clear(void){Set*s[3]={&seqjob.old,&seqjob.next,&seqjob.pairs};for(unsigned n=0;n<3;n++){if(s[n]->parent)FN(n==2?0x157e620:0x157df10,void(*)(uintptr_t))(s[n]->parent);empty(s[n]);}seqjob.ready=seqjob.count=0;seqjob.list=0;memset(&seqjob.plan,0,sizeof seqjob.plan);}
static uintptr_t list(const PcBouncePlan*p){uintptr_t b=Q(pc_state_base(),0x20),c=b?Q(b,0x150):0;return c&&Q(c,0x248)==p->project?Q(c,0xc0):0;}
int pc_bounce_sequence_prepare(const PcBouncePlan*p){
 pc_bounce_sequence_clear();if(!p->mode)return 1;uintptr_t l=list(p);if(!l)return 0;
 unsigned key=I(p->program,0x12a8+4*p->source);if(key>127)return 0;
 uintptr_t node=Q(l,0x78),end=l+0x68;unsigned count=0,steps=0;
 while(node&&node!=end&&steps++<16384){Event*e=(Event*)(node+0x20);int64_t tick=*(int64_t*)e->bytes;
  if((e->bytes[8]&15)==3&&e->bytes[48]==key&&tick>=0&&tick<p->ticks){if(count++>=4096){pc_bounce_sequence_clear();return 0;}FN(0x1574460,uintptr_t(*)(Set*,const Event*))(&seqjob.old,e);}
  node=FN(0xb51738,uintptr_t(*)(uintptr_t))(node);
 }
 if(!count||node&&node!=end){pc_bounce_sequence_clear();return 0;}
 typedef struct {uint8_t data[56];} RetEvent;
 RetEvent root=FN(0x27e54d0,RetEvent(*)(unsigned,int64_t,int64_t,unsigned,unsigned,float))(key,0,p->ticks,100,0,1.f);
 FN(0x27e4400,void(*)(void*,int,int,int))(root.data+0x14,0,0,0);
 FN(0x1574460,uintptr_t(*)(Set*,const Event*))(&seqjob.next,(const Event*)&root);
 seqjob.list=l;seqjob.plan=*p;seqjob.count=count;seqjob.ready=1;return 1;
}
int pc_bounce_sequence_apply(uintptr_t factory){
 if(!seqjob.plan.mode)return 1;if(!seqjob.ready||!pc_bounce_current(&seqjob.plan)||list(&seqjob.plan)!=seqjob.list)return 0;
 uintptr_t end=(uintptr_t)&seqjob.old+8,node=seqjob.old.left;unsigned checked=0;
 while(node&&node!=end&&checked<seqjob.count){uintptr_t n=FN(0x27d0440,uintptr_t(*)(uintptr_t,const Event*))(seqjob.list+0x60,(Event*)(node+0x20));if(!n||n==seqjob.list+0x68)return 0;checked++;node=FN(0xb51738,uintptr_t(*)(uintptr_t))(node);}
 if(checked!=seqjob.count)return 0;
 uintptr_t title=0,name=0;FN(0xf535c0,void(*)(void*,const char*))(&title,"Bounce pad sequence");FN(0xf1c620,void(*)(void*))(&name);
 uint64_t before=Q(seqjob.list,0x88);
 PcNativeReturn result=FN(0x19500e0,PcNativeReturn(*)(uintptr_t,uintptr_t,Set*,Set*,Set*,void*,void*,unsigned,uintptr_t))(factory,seqjob.list,&seqjob.old,&seqjob.next,&seqjob.pairs,&title,&name,0,0);
 if(result.owner)FN(0x123bca0,void(*)(uintptr_t))(result.owner);
 FN(0xf0a290,void(*)(void*))(&name);FN(0xf0a290,void(*)(void*))(&title);
 return result.object&&Q(seqjob.list,0x88)==before-seqjob.count+1;
}
