/* SPDX-License-Identifier: GPL-3.0-only
 * Named user presets. UI/metadata owner only: no live DSP calls or audio I/O.
 * Fixed numeric paths prevent names from becoming filesystem paths.
 */
#include "internal.h"
#include "preset_delete.h"
#define USER_MAX 128u
#define NAME_MAX 24u
static const char root[]="/media/MPCSSH/mpc-user-presets";
static struct {unsigned active,engine,preset,epoch,mode,cursor,count,index,overwrite,target,target_crc,target_preset,delete_choice;uintptr_t program,instrument;char name[25],target_name[25],names[USER_MAX][25];unsigned ids[USER_MAX];uint8_t occupied[USER_MAX],patch[512];const char *message;} user;
static uint32_t crc(const uint8_t*p,unsigned n){uint32_t c=~0u;while(n--){c^=*p++;for(unsigned k=0;k<8;k++)c=c>>1^(0xedb88320u&-(c&1));}return ~c;}
static unsigned get(const uint8_t*p){uint32_t x;memcpy(&x,p,4);return x;}
static void put(uint8_t*p,unsigned x){memcpy(p,&x,4);}
static void path(char*out,unsigned engine,unsigned id,int temp){unsigned n=sizeof root-1;memcpy(out,root,n);out[n++]='/';out[n++]='0'+engine;out[n++]='-';out[n++]='0'+id/100;out[n++]='0'+id/10%10;out[n++]='0'+id%10;memcpy(out+n,temp?".tmp":".pcu",5);}
static int transfer(long fd,uint8_t*p,unsigned n,int write){unsigned done=0;while(done<n){long r=pc_sys(write?64:63,fd,(long)(p+done),n-done,0,0,0);if(r==-4)continue;if(r<=0||r>(long)(n-done))return 0;done+=(unsigned)r;}return 1;}
/* 0 absent, -1 occupied but invalid/unreadable, 1 valid. */
int pc_user_read(unsigned engine,unsigned id,uint8_t*patch,char*name,unsigned*preset){
 if(id>=USER_MAX||engine==6||engine>9)return -1;
 char p[80];path(p,engine,id,0);long fd=pc_sys(56,-100,(long)p,0x88000,0,0,0);if(fd==-2)return 0;if(fd<0)return -1;
 uint8_t b[577];int ok=transfer(fd,b,576,0);long extra=ok?pc_sys(63,fd,(long)(b+576),1,0,0,0):-1;pc_sys(57,fd,0,0,0,0,0);
 if(!ok||extra||memcmp(b,"MPCUSR01",8)||get(b+8)!=engine||get(b+572)!=crc(b,572)||b[40])return -1;
 for(unsigned n=0;n<24;n++)if(b[16+n]&& (b[16+n]<32||b[16+n]>126))return -1;
 unsigned pr=get(b+12);if(engine!=3&&pr>=pc_engine_count(engine))return -1;
 if(patch)memcpy(patch,b+48,512);if(name){memcpy(name,b+16,24);name[24]=0;}if(preset)*preset=pr;return 1;
}
int pc_user_write(unsigned engine,unsigned id,unsigned preset,const char*name,const uint8_t*patch){
 if(id>=USER_MAX||engine==6||engine>9||!name||!patch)return 0;
 unsigned len=0;while(len<25&&name[len])len++;if(!len||len>24)return 0;
 for(unsigned n=0;n<len;n++)if((unsigned char)name[n]<32||(unsigned char)name[n]>126)return 0;
 if(engine!=3&&preset>=pc_engine_count(engine))return 0;
 long mk=pc_sys(34,-100,(long)root,0770,0,0,0);if(mk<0&&mk!=-17)return 0;
 uint8_t b[576]={0};memcpy(b,"MPCUSR01",8);put(b+8,engine);put(b+12,preset);memcpy(b+16,name,len);memcpy(b+48,patch,512);put(b+572,crc(b,572));
 char p[80],tmp[80];path(p,engine,id,0);path(tmp,engine,id,1);
 long fd=pc_sys(56,-100,(long)tmp,0x88000|1|64|512,0660,0,0);if(fd<0)return 0;
 int ok=transfer(fd,b,576,1);if(ok)ok=pc_sys(82,fd,0,0,0,0,0)==0;if(pc_sys(57,fd,0,0,0,0,0)<0)ok=0;
 if(ok)ok=pc_sys(38,-100,(long)tmp,-100,(long)p,0,0)==0;
 if(!ok){pc_sys(35,-100,(long)tmp,0,0,0,0);return 0;}
 fd=pc_sys(56,-100,(long)root,0x8c000,0,0,0);if(fd<0)return 0;ok=pc_sys(82,fd,0,0,0,0,0)==0;pc_sys(57,fd,0,0,0,0,0);return ok;
}
static void scan(void){user.count=user.index=0;for(unsigned id=0;id<USER_MAX;id++){char name[25];int r=pc_user_read(user.engine,id,0,name,0);user.occupied[id]=r!=0;if(r==1){user.ids[user.count]=id;memcpy(user.names[user.count++],name,25);}}}
static unsigned screen_mode(void){uintptr_t b=Q(pc_state_base(),0x20),m=b?Q(b,0x30):0;if(!m)return 0;unsigned id=I(m,0xd8);return id==0x3080?I(m,0x80):id;}
unsigned pc_user_active(void){return __atomic_load_n(&user.active,AQ);}
void pc_user_close(void){__atomic_store_n(&user.active,0,RL);}
int pc_user_open(uintptr_t p,uintptr_t i,unsigned browser){int k=pc_find(i);if(k<0||host.slots[k].program!=p)return 0;Slot*s=&host.slots[k];pc_preview_stop();user.program=p;user.instrument=i;user.epoch=host.project_epoch;user.mode=screen_mode();user.engine=s->engine;user.preset=s->preset;memcpy(user.patch,s->patch,512);user.cursor=user.overwrite=0;user.message=0;memset(user.name,' ',24);user.name[24]=0;char imported[25];const char*name="New preset";if(pc_syx_patch_name(s->patch,imported,sizeof imported))name=imported;else if(pc_mirror_use(s->engine))name=host.mirror.name(s->engine,s->preset);if(!name)name="New preset";for(unsigned n=0;n<24&&name[n];n++)user.name[n]=(name[n]>=32&&name[n]<=126)?name[n]:' ';scan();__atomic_store_n(&user.active,browser?2:3,RL);return 1;}
/* Save-as-new never overwrites, even when the name already exists. */
static void save(void){char name[25]={0};unsigned n=24;while(n&&user.name[n-1]==' ')n--;memcpy(name,user.name,n);if(!n){user.message="Enter a preset name";return;}
 scan();for(unsigned k=0;k<user.count;k++)if(!memcmp(name,user.names[k],25)){user.message="Name exists: rename or B2 overwrite";return;}
 unsigned target=USER_MAX;for(unsigned k=0;k<USER_MAX;k++)if(!user.occupied[k]){target=k;break;}
 if(target==USER_MAX){user.message="User bank full: use B2 overwrite";return;}
 if(!pc_user_write(user.engine,target,user.preset,name,user.patch)){user.message="Save failed: check SD, B1 retry";return;}
 pc_user_close();host.ui.message="New user preset saved";
}
static void overwrite_list(void){scan();user.message=0;if(!user.count){user.message="No user presets: choose NEW PRESET";__atomic_store_n(&user.active,3,RL);user.index=0;return;}__atomic_store_n(&user.active,4,RL);}
static void choose_overwrite(void){if(user.index>=user.count)return;uint8_t patch[512];unsigned preset;char name[25];unsigned target=user.ids[user.index];
 if(pc_user_read(user.engine,target,patch,name,&preset)!=1){user.message="Preset unavailable: choose another";return;}
 user.target=target;user.target_crc=crc(patch,512);user.target_preset=preset;memcpy(user.target_name,name,25);user.message=0;__atomic_store_n(&user.active,5,RL);
}
static void overwrite_save(void){uint8_t patch[512];unsigned preset;char name[25];
 if(pc_user_read(user.engine,user.target,patch,name,&preset)!=1||preset!=user.target_preset||crc(patch,512)!=user.target_crc||memcmp(name,user.target_name,25)){overwrite_list();user.message="Preset changed: select it again";return;}
 if(!pc_user_write(user.engine,user.target,user.preset,user.target_name,user.patch)){user.message="Save failed: check SD, B1 retry";return;}
 pc_user_close();host.ui.message="User preset overwritten";
}
int pc_user_event(unsigned kind,unsigned data,uintptr_t p,uintptr_t i){if(!pc_user_active())return 0;int k=pc_find(i);if(screen_mode()!=user.mode||host.project_epoch!=user.epoch||p!=user.program||i!=user.instrument||k<0||host.slots[k].engine!=user.engine){pc_user_close();return 1;}
 if(kind==36||kind==11){pc_user_close();return 1;}
 if(user.active==6){
  if(kind==14)user.delete_choice=pc_delete_choice(user.delete_choice,(int32_t)data);
  else if(kind==12&&(data==2||data==3)){
   if(data==3&&user.delete_choice==PC_DELETE){
    unsigned index=user.index,preset;
    char name[25],file[80];uint8_t patch[512];
    int same=pc_user_read(user.engine,user.target,patch,name,&preset)==1&&
      preset==user.target_preset&&crc(patch,512)==user.target_crc&&!memcmp(name,user.target_name,25);
    path(file,user.engine,user.target,0);
    if(!same)user.message="Preset changed: select it again";
    else if(pc_sys(35,-100,(long)file,0,0,0,0))user.message="Cannot delete preset";
    else user.message="Preset deleted";
    scan();if(user.count)user.index=index<user.count?index:user.count-1;
   }
   __atomic_store_n(&user.active,2,RL);
  }
  return 1;
 }
 if(user.active==2&&kind==12&&data==PC_PRESET_ERASE&&user.count){
  user.target=user.ids[user.index];
  uint8_t patch[512];
  if(pc_user_read(user.engine,user.target,patch,user.target_name,&user.target_preset)!=1){
   user.message="Preset unavailable";return 1;
  }
  user.target_crc=crc(patch,512);user.delete_choice=PC_KEEP;user.message=0;
  __atomic_store_n(&user.active,6,RL);return 1;
 }
 if(kind==12&&data==2){if(user.active==5){user.message=0;__atomic_store_n(&user.active,4,RL);}else pc_user_close();return 1;}
 if(user.active==3){
  if(kind==14){int64_t n=(int64_t)user.index+(int32_t)data;user.index=n<0?0:n>1?1:(unsigned)n;user.message=0;}
  else if(kind==12){if(data==0||(data==3&&user.index==0)){user.message=0;__atomic_store_n(&user.active,1,RL);}else if(data==1||data==3)overwrite_list();}return 1;
 }
 if(user.active==4){
  if(kind==14){int64_t n=(int64_t)user.index+(int32_t)data;if(n<0)n=0;if(n>=(int64_t)user.count)n=user.count?user.count-1:0;user.index=n;user.message=0;}
  else if(kind==12&&(data==0||data==3))choose_overwrite();
  else if(kind==12&&data==1){user.message=0;__atomic_store_n(&user.active,1,RL);}return 1;
 }
 if(user.active==5){if(kind==12&&(data==0||data==3))overwrite_save();return 1;}
 if(user.active==1){
  if(kind==14){static const char chars[]=" ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.";unsigned at=0;while(at<sizeof chars-1&&chars[at]!=user.name[user.cursor])at++;if(at==sizeof chars-1)at=0;int64_t next=(int64_t)at+(int32_t)data;next%=(int)(sizeof chars-1);if(next<0)next+=sizeof chars-1;user.name[user.cursor]=chars[next];user.overwrite=0;user.message=0;}
  else if(kind==35){int next=(int)user.cursor+(int32_t)data;if(next<0)next=0;if(next>23)next=23;user.cursor=next;user.overwrite=0;user.message=0;}
  else if(kind==12&&(data==0||data==3))save();
  else if(kind==12&&data==1)overwrite_list();
 }else{
  if(kind==14){int64_t n=(int64_t)user.index+(int32_t)data;if(n<0)n=0;if(n>=(int64_t)user.count)n=user.count?user.count-1:0;user.index=n;user.message=0;}
  else if(kind==12&&data==1){user.message=0;__atomic_store_n(&user.active,1,RL);}
  else if(kind==12&&(data==0||data==3)&&user.count){uint8_t patch[512];char name[25];unsigned preset;if(pc_user_read(user.engine,user.ids[user.index],patch,name,&preset)!=1){user.message="Invalid user preset";return 1;}if(!pc_assign(p,i,user.engine,preset,patch)){user.message="Release notes / load busy";return 1;}pc_user_close();host.ui.message="User preset loaded";}
 }
 return 1;
}
static void rect(uintptr_t g,int x,int y,int w,int h,unsigned col){FN(0x102d5e0,void(*)(uintptr_t,unsigned))(g,col);FN(0x102e000,void(*)(uintptr_t,int,int,int,int))(g,x,y,w,h);}
static void glyph(void*g,int x,int y,int w,int h,unsigned col){rect((uintptr_t)g,x,y,w,h,col);}
static void text(uintptr_t g,int x,int y,const char*s,unsigned col){pc_theme_text((void*)g,glyph,x,y,s,52,col);}
int pc_user_paint(uintptr_t g,int w,int h){
 if(!pc_user_active())return 0;EiCanvas e={(void*)g,glyph,w,h};
 if(user.active==6){pc_delete_paint(&e,user.target_name,user.delete_choice);return 1;}
 static const char*engines[]={"PROFET","CLOUD","KR-106","","DEXED","","SAMPLE","CZ-1","CS-1","RS-01"};
 ei_header(&e,user.engine<10?engines[user.engine]:"SYNTH","USER PRESET");
 ei_heading(&e,8,31,user.active==3?"save preset.":user.active==4?"overwrite.":user.active==5?"replace preset?":user.active==1?"new preset.":"user presets.",w-16);
 if(user.active==3){
  const char*options[]={"NEW PRESET","OVERWRITE"};for(unsigned n=0;n<2;n++){int y=(h>=190?88:65)+n*26;if(n==user.index)ei_selection(&e,y,22);ei_text(&e,15,y+5,options[n],w-30,MPC_THEME_TEXT);}
  if(h>=190)ei_text(&e,12,h-64,"ENC choose / press to continue",w-24,MPC_THEME_MUTED);ei_actions(&e,"NEW","OVERWRITE","CANCEL");ei_notice(&e,user.message);return 1;
 }
 if(user.active==5){
  ei_text(&e,12,h>=190?86:65,user.target_name,w-24,MPC_THEME_TEXT);ei_text(&e,12,h>=190?119:87,"Replace with current synth settings?",w-24,MPC_THEME_MUTED);
  ei_text(&e,12,h>=190?141:103,"The preset name will stay the same.",w-24,MPC_THEME_MUTED);ei_actions(&e,"OVERWRITE","","BACK");ei_notice(&e,user.message);return 1;
 }
 if(user.active==1){
  unsigned first=user.cursor<16?0:8;char line[17];memcpy(line,user.name+first,16);line[16]=0;
  int y=h>=190?104:69;unsigned height=h>=190?24:20;
  ei_value(&e,12,y,line,w-24,height,MPC_THEME_TEXT);
  unsigned pen=0;for(unsigned n=first;n<user.cursor;n++){unsigned ch=(unsigned char)user.name[n];if(ch<32||ch>126)ch='?';pen+=ei_display_advance[height>=22?1:0][ch-32];}
  unsigned extent=0;for(unsigned n=0;n<16;n++){unsigned ch=(unsigned char)line[n];if(ch<32||ch>126)ch='?';extent+=ei_display_advance[height>=22?1:0][ch-32];}unsigned scale=extent>(unsigned)(w-24)*64?(unsigned)((unsigned long long)(w-24)*64*65536/extent):65536;int x=12+(int)((unsigned long long)pen*scale/(64*65536));ei_rect(&e,x,y+height+3,(int)((unsigned long long)(height*3/5)*scale/65536),2,MPC_THEME_ACCENT);
  ei_text(&e,12,h-64,"ENC character   -/+ cursor",w-24,MPC_THEME_MUTED);
  ei_actions(&e,"SAVE NEW","OVERWRITE","CANCEL");
 }else{
  unsigned rows=h>100?(h-110)/18:1;if(!rows)rows=1;unsigned first=user.index>=rows?user.index-rows+1:0;
  for(unsigned row=0;row<rows&&first+row<user.count;row++){unsigned k=first+row;int y=65+18*row;if(k==user.index)ei_selection(&e,y,17);ei_text(&e,15,y+2,user.names[k],w-30,MPC_THEME_TEXT);}
  if(!user.count)ei_text(&e,12,65,"No user presets for this engine",w-24,MPC_THEME_MUTED);
  ei_actions(&e,user.active==4?"SELECT":"LOAD","SAVE NEW",user.active==4?"CANCEL":"BACK");
 }
 ei_notice(&e,user.message);return 1;
}
