/* Standard MIDI files and the existing native chord-bank format. */
#include "internal.h"
#include "chord_files.h"
typedef struct {uint32_t tick;uint8_t note,velocity;uint16_t reserved;} Onset;
static Onset notes[32768],scratch[32768];
static unsigned be16(const uint8_t*p){return (unsigned)p[0]<<8|p[1];}
static uint32_t be32(const uint8_t*p){return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];}
static int vlq(const uint8_t**p,const uint8_t*end,uint32_t*out){uint32_t v=0;for(unsigned n=0;n<4&&*p<end;n++){unsigned b=*(*p)++;v=(v<<7)|(b&127);if(!(b&128)){*out=v;return 1;}}return 0;}
static void sort(unsigned count){
 for(unsigned width=1;width<count;width*=2){
  for(unsigned start=0;start<count;start+=width*2){
   unsigned mid=start+width<count?start+width:count,end=mid+width<count?mid+width:count,a=start,b=mid;
   for(unsigned n=start;n<end;n++)scratch[n]=a<mid&&(b==end||notes[a].tick<=notes[b].tick)?notes[a++]:notes[b++];
  }memcpy(notes,scratch,count*sizeof *notes);
 }
}
static int binary(const uint8_t*p,size_t size,ChordBank*out){
 if(size!=sizeof *out)return 0;memcpy(out,p,size);
 if(memcmp(out->magic,"MPCCHD1",8)||out->version!=1||out->reference>127||out->count!=16)return 0;
 out->name[31]=0;
 for(unsigned i=0;i<16;i++){ChordPad*c=&out->pads[i];c->name[31]=0;if(c->count>8)return 0;for(unsigned j=0;j<c->count;j++)if(c->notes[j]>127||c->velocities[j]>127)return 0;}
 return 1;
}
/* MPC .progression files are JSON, distinct from MIDI and MPCCHD1. */
static int json_equal(const char*a,const char*b){while(*a&&*a==*b){a++;b++;}return *a==*b;}
typedef struct {const uint8_t*p,*end;} Json;
static void json_space(Json*j){while(j->p<j->end&&(*j->p==' '||*j->p=='\t'||*j->p=='\r'||*j->p=='\n'))j->p++;}
static int json_take(Json*j,unsigned c){json_space(j);if(j->p==j->end||*j->p!=c)return 0;j->p++;return 1;}
static int json_hex(Json*j,unsigned*v){
 *v=0;for(unsigned n=0;n<4;n++){if(j->p==j->end)return 0;unsigned c=*j->p++,d=c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:c>='A'&&c<='F'?c-'A'+10:16;if(d>15)return 0;*v=(*v<<4)|d;}return 1;
}
static int json_string(Json*j,char*out,unsigned cap){
 if(!json_take(j,'"'))return 0;unsigned n=0,full=0;
 while(j->p<j->end){
  unsigned c=*j->p++;if(c=='"'){if(cap)out[n]=0;return 1;}if(c<32)return 0;
  uint8_t bytes[4];unsigned len=1;bytes[0]=(uint8_t)c;
  if(c=='\\'){
   if(j->p==j->end)return 0;c=*j->p++;
   if(c=='u'){
    unsigned v;if(!json_hex(j,&v))return 0;
    if(v>=0xd800&&v<=0xdbff){if(j->end-j->p<2||j->p[0]!='\\'||j->p[1]!='u')return 0;j->p+=2;unsigned lo;if(!json_hex(j,&lo)||lo<0xdc00||lo>0xdfff)return 0;v=0x10000+((v-0xd800)<<10)+(lo-0xdc00);}
    else if(v>=0xdc00&&v<=0xdfff)return 0;
    if(v<32)v='?';
    if(v<128)bytes[0]=v;
    else if(v<2048){len=2;bytes[0]=0xc0|(v>>6);bytes[1]=0x80|(v&63);}
    else if(v<65536){len=3;bytes[0]=0xe0|(v>>12);bytes[1]=0x80|((v>>6)&63);bytes[2]=0x80|(v&63);}
    else {len=4;bytes[0]=0xf0|(v>>18);bytes[1]=0x80|((v>>12)&63);bytes[2]=0x80|((v>>6)&63);bytes[3]=0x80|(v&63);}
   }else if(c=='"'||c=='\\'||c=='/')bytes[0]=c;
   else if(c=='b'||c=='f'||c=='n'||c=='r'||c=='t')bytes[0]='?';else return 0;
  }
  if(cap&&!full){if(n+len<cap){memcpy(out+n,bytes,len);n+=len;}else full=1;}
 }
 return 0;
}
static int json_number(Json*j,unsigned*integer){
 json_space(j);const uint8_t*start=j->p;int negative=j->p<j->end&&*j->p=='-';if(negative)j->p++;
 if(j->p==j->end||*j->p<'0'||*j->p>'9')return 0;
 unsigned value=0,digits=0;int zero=*j->p=='0';
 while(j->p<j->end&&*j->p>='0'&&*j->p<='9'){if(zero&&digits)return 0;if(value<1000000)value=value*10+*j->p-'0';j->p++;digits++;}
 unsigned integral=1;
 if(j->p<j->end&&*j->p=='.'){integral=0;j->p++;const uint8_t*p=j->p;while(j->p<j->end&&*j->p>='0'&&*j->p<='9')j->p++;if(p==j->p)return 0;}
 if(j->p<j->end&&(*j->p=='e'||*j->p=='E')){integral=0;j->p++;if(j->p<j->end&&(*j->p=='+'||*j->p=='-'))j->p++;const uint8_t*p=j->p;while(j->p<j->end&&*j->p>='0'&&*j->p<='9')j->p++;if(p==j->p)return 0;}
 if(integer){if(negative||!integral||value>127){j->p=start;return 0;}*integer=value;}return 1;
}
static int json_skip(Json*j,unsigned depth){
 if(depth>32)return 0;json_space(j);if(j->p==j->end)return 0;
 unsigned c=*j->p;
 if(c=='"')return json_string(j,0,0);
 if(c=='{'||c=='['){j->p++;unsigned end=c=='{'?'}':']';if(json_take(j,end))return 1;
  do{if(c=='{'&&(!json_string(j,0,0)||!json_take(j,':')))return 0;if(!json_skip(j,depth+1))return 0;if(json_take(j,end))return 1;}while(json_take(j,','));return 0;
 }
 const char*literal=c=='t'?"true":c=='f'?"false":c=='n'?"null":0;
 if(literal){unsigned n=0;while(literal[n])n++;if((size_t)(j->end-j->p)<n||memcmp(j->p,literal,n))return 0;j->p+=n;return 1;}
 return json_number(j,0);
}
static int json_values(Json*j,uint8_t values[8],unsigned*count){
 if(!json_take(j,'['))return 0;*count=0;if(json_take(j,']'))return 1;
 do {unsigned v;if(*count==8||!json_number(j,&v))return 0;values[(*count)++]=(uint8_t)v;if(json_take(j,']'))return 1;}while(json_take(j,','));return 0;
}
static int json_chord(Json*j,ChordPad*pad){
 if(!json_take(j,'{'))return 0;unsigned notes=0,velocities=0,ncount=0,vcount=0;uint8_t v[8];memset(pad,0,sizeof *pad);
 if(json_take(j,'}'))return 0;
 do {char key[32];if(!json_string(j,key,sizeof key)||!json_take(j,':'))return 0;
  if(json_equal(key,"name")){if(!json_string(j,pad->name,sizeof pad->name))return 0;}
  else if(json_equal(key,"notes")){if(notes++||!json_values(j,pad->notes,&ncount))return 0;}
  else if(json_equal(key,"velocities")){if(velocities++||!json_values(j,v,&vcount))return 0;}
  else if(!json_skip(j,0))return 0;
  if(json_take(j,'}')){if(!notes||(velocities&&vcount!=ncount))return 0;pad->count=ncount;for(unsigned i=0;i<ncount;i++)pad->velocities[i]=velocities?v[i]:100;return 1;}
 }while(json_take(j,','));return 0;
}
static int json_bank(Json*j,ChordBank*bank,unsigned level,unsigned*chords){
 if(level>1||!json_take(j,'{')||json_take(j,'}'))return 0;
 do {char key[32];if(!json_string(j,key,sizeof key)||!json_take(j,':'))return 0;
  if(json_equal(key,"progression")){if(level||*chords||!json_bank(j,bank,level+1,chords))return 0;}
  else if(json_equal(key,"name")){if(!json_string(j,bank->name,sizeof bank->name))return 0;}
  else if(json_equal(key,"chords")){
   if(*chords||!json_take(j,'[')||json_take(j,']'))return 0;unsigned count=0;
   do {ChordPad extra,*pad=count<16?&bank->pads[count]:&extra;if(!json_chord(j,pad))return 0;count++;if(json_take(j,']'))break;if(!json_take(j,','))return 0;}while(1);
   *chords=count;
  }else if(!json_skip(j,0))return 0;
  if(json_take(j,'}'))return 1;
 }while(json_take(j,','));return 0;
}
static int progression_json(const uint8_t*data,size_t size,ChordBank*out){
 Json j={data,data+size};if(size>=3&&!memcmp(data,"\xef\xbb\xbf",3))j.p+=3;
 ChordBank bank={0};memcpy(bank.magic,"MPCCHD1",8);bank.version=1;bank.reference=60;bank.count=16;unsigned chords=0;
 if(!json_bank(&j,&bank,0,&chords)||!chords)return 0;json_space(&j);if(j.p!=j.end)return 0;
 unsigned notes=0;for(unsigned n=0;n<16;n++)notes+=bank.pads[n].count;if(!notes)return 0;memcpy(out,&bank,sizeof bank);return 1;
}

int pc_chord_file_parse(const uint8_t*data,size_t size,ChordBank*out){
 if(!data||!out)return 0;
 if(size>=8&&!memcmp(data,"MPCCHD1",8))return binary(data,size,out);
 if(size<14||memcmp(data,"MThd",4))return progression_json(data,size,out);
 unsigned header=be32(data+4),format=be16(data+8),tracks=be16(data+10),division=be16(data+12);
 if(header<6||header>size-8||format>1||!tracks||tracks>128||!division||(division&0x8000))return 0;
 if(!format&&tracks!=1)return 0;
 const uint8_t*p=data+8+header,*end=data+size;unsigned count=0;
 for(unsigned track=0;track<tracks;track++){
  if(end-p<8||memcmp(p,"MTrk",4))return 0;uint32_t length=be32(p+4);p+=8;if(length>(size_t)(end-p))return 0;
  const uint8_t*stop=p+length;uint32_t tick=0;unsigned running=0;
  while(p<stop){
   uint32_t delta;if(!vlq(&p,stop,&delta)||delta>0xffffffffu-tick||p==stop)return 0;tick+=delta;
   unsigned status=*p;if(status&128){p++;if(status<0xf0)running=status;else running=0;}else status=running;
   if(status==0xff){
    if(p==stop)return 0;unsigned type=*p++;uint32_t len;if(!vlq(&p,stop,&len)||len>(size_t)(stop-p))return 0;p+=len;if(type==0x2f){p=stop;break;}continue;
   }
   if(status==0xf0||status==0xf7){uint32_t len;if(!vlq(&p,stop,&len)||len>(size_t)(stop-p))return 0;p+=len;continue;}
   if(status<0x80||status>=0xf0)return 0;
   unsigned kind=status&0xf0,bytes=kind==0xc0||kind==0xd0?1:2;
   if((size_t)(stop-p)<bytes)return 0;for(unsigned i=0;i<bytes;i++)if(p[i]&128)return 0;
   if(kind==0x90&&p[1]&&(status&15)!=9){if(count==32768)return 0;notes[count++]=(Onset){tick,p[0],p[1],0};}
   p+=bytes;
  }
 }
 if(!count)return 0;sort(count);memset(out,0,sizeof *out);memcpy(out->magic,"MPCCHD1",8);out->version=1;out->reference=60;out->count=16;memcpy(out->name,"MIDI progression",17);
 unsigned at=0;
 for(unsigned pad=0;pad<16&&at<count;pad++){
  ChordPad*c=&out->pads[pad];memcpy(c->name,"Chord 00",9);c->name[6]='0'+(pad+1)/10;c->name[7]='0'+(pad+1)%10;
  uint32_t tick=notes[at].tick;uint8_t velocities[128]={0};
  do{if(notes[at].velocity>velocities[notes[at].note])velocities[notes[at].note]=notes[at].velocity;at++;}while(at<count&&notes[at].tick==tick);
  for(unsigned n=0;n<128&&c->count<8;n++)if(velocities[n]){unsigned j=c->count++;c->notes[j]=n;c->velocities[j]=velocities[n];}
 }
 return 1;
}
