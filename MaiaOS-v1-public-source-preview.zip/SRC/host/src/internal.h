/* SPDX-License-Identifier: GPL-3.0-only */
#include "synth_splice.h"
#include "multisamples.h"
static inline int pc_context_engine(unsigned e){return e==PC_MS_ENGINE;}
#include "host.h"
#include "fm6.h"
#include "stock_filter.h"
extern void *memset(void *,int,size_t);
extern void *memcpy(void *,const void *,size_t);
#define Q(p,o) (*(uintptr_t *)((uintptr_t)(p)+(o)))
#define I(p,o) (*(int32_t *)((uintptr_t)(p)+(o)))
#define F(p,o) (*(float *)((uintptr_t)(p)+(o)))
#define FN(off,type) ((type)(host.base+(off)))
#define G PC_LEGACY_STATE_OFFSET
#define AQ __ATOMIC_ACQUIRE
#define RL __ATOMIC_RELEASE
#define RX __ATOMIC_RELAXED
typedef struct {
 int (*prepare)(unsigned);
 unsigned (*version)(void),(*held)(void),(*count)(unsigned);
 const char *(*name)(unsigned,unsigned);
 int (*select)(unsigned,unsigned),(*load)(const uint8_t *),(*save)(uint8_t *),(*set)(unsigned,int32_t);
 void (*on)(unsigned,unsigned),(*off)(unsigned),(*render)(float *,float *,unsigned);
 int (*panel_init)(unsigned,unsigned),(*view)(MpcPanelView *),(*button)(unsigned),(*encoder)(int),(*confirm)(void),(*knob)(unsigned,unsigned);
 int (*saved)(unsigned);
 unsigned (*voices)(void),(*attack_cost)(void);
 uintptr_t legacy_layout;
 int (*panel_load)(unsigned,unsigned,const uint8_t *),(*draw)(uint32_t *,unsigned,unsigned,unsigned);
} Dsp;
typedef struct {uint16_t source;uint8_t channel,note,used;uint16_t filter;unsigned serial,voice_owner;} Held;
typedef struct {uint32_t kind,index;int32_t value;uint32_t reserved;uintptr_t context;uint8_t patch[512];} Command;
#define QUEUE 32
#define NOTE_QUEUE 512u
typedef struct {unsigned sequence,kind,generation,source,channel,pitch,velocity,filter;} NoteEvent;
typedef struct {
 Dsp dsp;uintptr_t instrument,program;PcStockFilter stock_filter;unsigned filter_lock,filter_serial,filter_owner;
 unsigned busy,panic,read,write,pending[4],generation,audio_generation;uint64_t values[128];
 unsigned event_write,event_read,native_muted,pending_on,voice_mask,poly_mode,poly_mode_valid,held_keys,sequence_protected;NoteEvent events[NOTE_QUEUE];
 Command queue[QUEUE];Held held[256];uint16_t refs[128];
 unsigned native_sources[8],release_pending,late_stop,late_off[17][8];
 PcSynthSplice splice;
 float output_gain;unsigned engine,preset,audio_engine;uintptr_t multisample;uintptr_t retired[32];unsigned retire_read,retire_write;uint8_t patch[512];
} Slot;
typedef struct {
 uintptr_t base;PcDebug *debug;Slot slots[PC_SLOTS];Dsp mirror,preview;
 unsigned ready,metadata,project_epoch;
 struct {unsigned catalog,candidate,source,loaded_slot,loaded_valid,scope,owned,replace,save_confirm,save_target;
  uint64_t pads[2];uintptr_t screen,program,lighting,paint_screen,paint_instrument;
  uintptr_t sample_screen;
  unsigned paint_scope,paint_engine;int paint_mode;int screen_mode;const char *message;
  uint32_t pixels[320*160];} ui;
 uintptr_t shared_state;
} Host;
extern Host host;

static inline uintptr_t pc_state_base(void){
 return host.shared_state?host.shared_state:host.base+PC_LEGACY_STATE_OFFSET;
}
void pc_error(unsigned);
int pc_meta(void);void pc_unmeta(void);
int pc_find(uintptr_t);
int pc_valid(uintptr_t,uintptr_t);
int pc_room(Slot *);void pc_push(Slot *,const Command *);
int pc_assign(uintptr_t,uintptr_t,unsigned,unsigned,const uint8_t *);
int pc_remove(uintptr_t);
int pc_ui_physical(uintptr_t,unsigned);int pc_ui_knob(uintptr_t,uint32_t);
int pc_ui_rotation(uintptr_t,int);int pc_ui_capture(int,int);
int pc_ui_event(uint64_t);int pc_ui_paint(uintptr_t,uintptr_t);
int pc_xml_write(uintptr_t,uintptr_t);int pc_xml_read(uintptr_t,uintptr_t);

int pc_light_has(uintptr_t,unsigned,uintptr_t);
int pc_light_playing(uintptr_t,uintptr_t,unsigned);
void pc_light_refresh(void);
void pc_ui_dj_release(void);
void pc_ui_dj_dismiss_fx(void);
int pc_preset_read(unsigned,unsigned,uint8_t *);
int pc_preset_write(unsigned,unsigned,const uint8_t *);
void pc_preset_refresh_hidden(unsigned);
int pc_preset_hidden(unsigned,unsigned);
int pc_preset_delete(unsigned,unsigned);
extern int memcmp(const void *,const void *,size_t);

#include "chord_addresses.h"

unsigned pc_sc_role(uintptr_t);int pc_sc_set(uintptr_t,uintptr_t,unsigned);
void pc_sc_note(uintptr_t,uintptr_t,const uint8_t *);
void pc_sc_process(uintptr_t,uintptr_t,unsigned,unsigned);void pc_sc_forget(uintptr_t,uintptr_t);

void pc_project_info_write(uintptr_t,uintptr_t);void pc_project_info_read(uintptr_t);void pc_project_restore(void);

void pc_project_schedule(void);void pc_project_poll(void);

void pc_preview_schedule(void);void pc_preview_poll(void);void pc_preview_stop(void);void pc_preview_request(unsigned,unsigned);int pc_preview_wav(void);
int pc_load_dsp(Dsp *,const char *,int);long pc_sys(long,long,long,long,long,long,long);

#include "mix.h"
#include "audio_features.h"

void pc_ms_reap(Slot *);void pc_ms_retire(Slot *,uintptr_t);void pc_ms_dispose_locked(Slot *);
void pc_ms_collect(void);
void pc_discard_pad_notes(Slot *);
void pc_ms_unassign_preset(const char *);
void pc_ms_clear_native_pad(uintptr_t);
void pc_ms_clear_queued(unsigned);
int pc_load_dsp(Dsp *,const char *,int);long pc_sys(long,long,long,long,long,long,long);void *pc_read_file(const char *,unsigned *);void pc_free_file(void *);






#include "bounce.h"
int pc_meta_owned(void);
int pc_mix_bounce_prepare(void);int pc_mix_bounce_copy(uintptr_t,uintptr_t,unsigned);

void pc_mix_bounce_reset(void);

int pc_ui_native_fx_guard(void);
void pc_native_sequence_stop(void);
void pc_native_input_process(uintptr_t,uintptr_t,unsigned);
int pc_native_click_load(const char*);void pc_native_click_restore(void);

Dsp*pc_engine_dsp(Slot*,unsigned);Dsp*pc_slot_dsp(Slot*);unsigned pc_engine_count(unsigned);int pc_mirror_use(unsigned);int pc_new_engines_init(void);int pc_preview_backend(unsigned);void pc_new_tempo_poll(void);void pc_new_tempo_audio(Slot*);

unsigned pc_user_active(void);void pc_user_close(void);int pc_user_open(uintptr_t,uintptr_t,unsigned);int pc_user_event(unsigned,unsigned,uintptr_t,uintptr_t);int pc_user_paint(uintptr_t,int,int);
int pc_user_read(unsigned,unsigned,uint8_t*,char*,unsigned*);int pc_user_write(unsigned,unsigned,unsigned,const char*,const uint8_t*);

int pc_editorial_step_paint(uintptr_t,uintptr_t,uintptr_t,unsigned);int pc_editorial_chord_paint(uintptr_t,uintptr_t);

void pc_step_roll_paint_caption(uintptr_t,uintptr_t);
int pc_editorial_step_cached(uintptr_t,uintptr_t);
int pc_editorial_step_reuse(uintptr_t,uintptr_t);
void pc_editorial_step_invalidate(void);

/* SysEx import keeps complete voices in existing project/user patches. */
int pc_backend_load(Dsp*,const uint8_t*);int pc_backend_save(Dsp*,uint8_t*);int pc_backend_panel_load(Dsp*,unsigned,unsigned,const uint8_t*);
int pc_syx_patch_name(const uint8_t*,char*,unsigned);
unsigned pc_syx_active(void);int pc_syx_open(uintptr_t,uintptr_t);void pc_syx_close(void);int pc_syx_event(unsigned,unsigned,uintptr_t,uintptr_t);int pc_syx_paint(uintptr_t,int,int);

int pc_editorial_native_fx(uintptr_t,uintptr_t);

int pc_editorial_native_fx_tile(uintptr_t,uintptr_t);



void pc_audio_close(void);void pc_padfx_ui_frame(uintptr_t);void pc_padfx_touch(unsigned,unsigned);void pc_padfx_record_audio(uintptr_t);void pc_amp_process(unsigned,float*,float*,unsigned,const float*,unsigned);


int pc_editorial_step_populated(uintptr_t,unsigned);

void pc_padfx_record_input(uintptr_t);

void pc_editorial_tempo_font(unsigned);

void pc_input_config_children(uintptr_t,unsigned);

uintptr_t pc_input_config_view(void);
void pc_input_config_background(uintptr_t);

void pc_input_config_refresh(void);

void pc_import_frame(uintptr_t);int pc_import_preview(void);

void pc_diag_flag(unsigned,unsigned);void pc_diag_add(unsigned);void pc_diag_poll(void);

unsigned pc_preview_playing(void);

unsigned pc_native_import_scope(int);
unsigned pc_import_knob_scope(void);int pc_import_knob_event(unsigned);

void pc_diag_value(unsigned,unsigned);

unsigned pc_padfx_visible(void);

int pc_roll_view_paint_locked(uintptr_t,uintptr_t);

void pc_poly_forget(Slot*);void pc_poly_sync(Slot*);int pc_poly_reserve(Slot*);void pc_dsp_attack(Slot*,unsigned,unsigned);void pc_poly_reject(void);unsigned pc_poly_notice(void);
unsigned pc_performance_gate(unsigned,uintptr_t,unsigned);void pc_shutdown_missing_continue(void);

void pc_fx_worker_init(void);
typedef struct{void(*run)(void*);void*arg;}PcFxWork;
int pc_fx_workers_run(const PcFxWork*,unsigned);int pc_fx_worker_tune(PcFxWork,unsigned);
void pc_fx_worker_diagnostics(unsigned*);

int pc_roll_prepare_locked(void);void pc_roll_knob_event(unsigned);void pc_roll_transport_sync(void);void pc_light_refresh_ui(void);

void pc_bounce_note_seen(uintptr_t);void pc_bounce_synth_rendered(uintptr_t);unsigned pc_bounce_synth_gate(uintptr_t,unsigned*,unsigned);int pc_bounce_ensure_synth(uintptr_t,unsigned);void pc_bounce_synth_route(uintptr_t,unsigned);int pc_synth_bounce_render(uintptr_t,uintptr_t,unsigned);void pc_shutdown_watch_init(void);

int pc_bounce_synth_done(void);

void pc_tune_follow_set(unsigned);unsigned pc_tune_follow_mode(void);unsigned pc_tune_follow_result(void);void pc_tune_follow_note(unsigned,unsigned);unsigned pc_tune_follow_render(unsigned);
unsigned pc_tune_sample_key(const char *);
void pc_tune_audible_sample(uintptr_t,uintptr_t,unsigned);
unsigned pc_sample_default_mode(uintptr_t);
void pc_tune_follow_sample(unsigned);
void pc_tune_follow_midi_held(unsigned);

/* Written by the native project commit hook. */
#define PC_NEW_PROJECT_SERIAL 0x1fa0u
#define PC_NEW_PROJECT_MODEL 0x1fa8u
unsigned pc_project_new_serial(void);
int pc_project_new_pending(void);
void pc_mix_new_project(unsigned serial);
int pc_project_new_sync_locked(void);
void pc_project_new_sync_ui(void);

int pc_roll_has_selection(void);
int pc_roll_encoder_click(uintptr_t,unsigned);
void pc_record_arm_reset(uintptr_t,float);
void pc_record_arm_sync(uintptr_t,int64_t);
int64_t pc_record_capture_wait(uintptr_t,int64_t,uint64_t,uint64_t,uint64_t,uint64_t);
int pc_record_finish_entry(uintptr_t,const uintptr_t *);
void pc_record_first_pass(uintptr_t,uintptr_t);
void pc_record_end_block(uintptr_t,uintptr_t,unsigned);
void pc_record_voice_started(uintptr_t);
void pc_record_slice_entry(void);
int pc_record_add_triggers(uintptr_t,uintptr_t,int64_t,uint8_t [128]);
void pc_roll_octave_event(int);

void pc_flex_clock_init(void);
void pc_flex_clock_poll(void);
int pc_flex_clock_external(void);

void pc_cpu_poll(void);
int pc_cpu_overloaded(void);
int pc_cpu_warning(void);

void pc_trigger_block(void);
int pc_trigger_admit(unsigned sample,unsigned offset,unsigned cost);

void pc_quantize_poly(uintptr_t,uintptr_t,uintptr_t,uintptr_t,uintptr_t);

unsigned pc_chord_browser_active(void);
int pc_chord_browser_open(uintptr_t);
void pc_chord_browser_close(void);
void pc_chord_browser_event(unsigned,unsigned);
int pc_chord_browser_paint(uintptr_t,uintptr_t);


void pc_record_controls_defer(uintptr_t,uintptr_t,uint64_t);
void pc_record_controls_poll(void);



int pc_fx_catalog_type(unsigned);unsigned pc_fx_catalog_index(int);

void pc_quantize_cleanup(uintptr_t,uintptr_t);

void pc_mix_native_gain(uintptr_t,uintptr_t,unsigned);

int pc_sd_folder(char*,unsigned,const char*);
void pc_synth_live_input(uintptr_t,unsigned,unsigned,uintptr_t,const uint8_t*);

int64_t pc_sequence_play_tick(void);

void pc_sd_access_visibility(uintptr_t,unsigned);
void pc_sd_access_silence(float**,unsigned,unsigned);

unsigned pc_sd_access_muted(void);
