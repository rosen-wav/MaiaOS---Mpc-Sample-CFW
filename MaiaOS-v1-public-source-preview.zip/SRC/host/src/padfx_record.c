/* Live Pad FX recording withdrawn. Step sequencer replacement is separate. */
#include "internal.h"
unsigned pc_padfx_visible(void){return 0;}
void pc_padfx_ui_frame(uintptr_t screen){(void)screen;}
void pc_padfx_touch(unsigned pad,unsigned release){(void)pad;(void)release;}
void pc_padfx_record_audio(uintptr_t inserts){(void)inserts;}
void pc_padfx_record_input(uintptr_t object){(void)object;}
