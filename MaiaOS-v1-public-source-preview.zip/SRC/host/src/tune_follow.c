/* SPDX-License-Identifier: GPL-3.0-only
 * Note producers only publish bounded pitch-class weights. The existing tune
 * worker owns analysis; no project traversal, allocation or locks in audio.
 * This is local major/minor estimation, not a MIDI chord-note quantizer. */
#include "internal.h"
static unsigned enabled=1,generation=1,result,seen,candidate,stable,midi,quiet,sample_key,midi_held;
#define MIDI_IDLE_FRAMES 52920u
#define SAMPLE_SOURCE 1024u
#define AUDIBLE_WINDOW 8192u
#define AUDIBLE_ORDER_MASK 0x7fffffu
static unsigned audible_clock,audible_serial;
static struct AudibleSample {
 uintptr_t instrument,sample,label;
 unsigned busy,key,epoch;
 uint64_t marker;
} audible[128];
static uint64_t pending[12];static float history[12];
void pc_tune_follow_set(unsigned on){__atomic_store_n(&enabled,!!on,RL);__atomic_fetch_add(&generation,1,__ATOMIC_ACQ_REL);__atomic_store_n(&result,0,RL);__atomic_store_n(&sample_key,0,RL);__atomic_store_n(&midi_held,0,RL);}
unsigned pc_tune_follow_mode(void){return __atomic_load_n(&enabled,AQ);}
unsigned pc_tune_follow_result(void){return __atomic_load_n(&result,AQ);}
void pc_tune_follow_note(unsigned pitch,unsigned velocity){
 if(!pc_tune_follow_mode()||pitch>127||!velocity)return;
 unsigned gen=__atomic_load_n(&generation,AQ),weight=velocity*(pitch<60?2u:1u);uint64_t*p=&pending[pitch%12],old=__atomic_load_n(p,AQ);
 for(unsigned n=0;n<16;n++){unsigned sum=(unsigned)(old>>32)==gen?(unsigned)old:0;if(sum>8192)sum=8192;uint64_t next=(uint64_t)gen<<32|(sum+weight);
  if(__atomic_compare_exchange_n(p,&old,next,0,__ATOMIC_ACQ_REL,AQ))break;}
}
static unsigned lower(unsigned c){return c>='A'&&c<='Z'?c+('a'-'A'):c;}
static int word(unsigned c){
 c=lower(c);return (c>='a'&&c<='z')||(c>='0'&&c<='9');
}
unsigned pc_tune_sample_key(const char *name){
 if(!name)return 0;
 unsigned len=0,start=0;
 while(len<512&&name[len]){if(name[len]=='/'||name[len]=='\\')start=len+1;len++;}
 if(len==512)return 0;
 static const unsigned roots[]={9,11,0,2,4,5,7};
 unsigned found=0;
 for(unsigned i=start;i+3<len;i++){
  if(i>start&&word((unsigned char)name[i-1]))continue;
  unsigned letter=lower((unsigned char)name[i]);
  if(letter<'a'||letter>'g')continue;
  unsigned n=i+1,root=roots[letter-'a'];
  if(name[n]=='#'){root=(root+1)%12;n++;}
  else if(name[n]=='b'||name[n]=='B'){root=(root+11)%12;n++;}
  if(len-n<3||lower(name[n])!='m')continue;
  unsigned minor=lower(name[n+1])=='i'&&lower(name[n+2])=='n';
  if(!minor&&!(lower(name[n+1])=='a'&&lower(name[n+2])=='j'))continue;
  unsigned end=n+3;
  if(end+1<len&&lower(name[end])=='o'&&lower(name[end+1])=='r')end+=2;
  if(end<len&&word((unsigned char)name[end]))continue;
  unsigned key=256u|root|(minor<<4);
  if(found&&found!=key)return 0;
  found=key;
 }
 return found;
}
void pc_tune_follow_midi_held(unsigned held){__atomic_store_n(&midi_held,held,RL);}
void pc_tune_follow_sample(unsigned key){__atomic_store_n(&sample_key,key,RL);}
/* A rendered native pad gives a second source of playback evidence.
 * It does not depend on the optional sample-pool or ALSA relays. */
void pc_tune_audible_sample(uintptr_t instrument,uintptr_t buffer,unsigned frames){
 if(!pc_tune_follow_mode()||!instrument||!buffer||!frames||frames>4096||
    I(buffer,0)<2||I(buffer,4)<(int)frames||(*(const uint8_t*)(buffer+0x128)&1)||
    Q(instrument,0)!=host.base+0x6ec3ca0||(*(const uint8_t*)(instrument+0x78)&1)||
    pc_bounce_busy()||pc_find(instrument)>=0)return;
 uintptr_t program=Q(instrument,0x2310),layers=Q(instrument,0x22e8);
 if(!program||Q(program,0)!=host.base+0x6ec6860||I(program,0x1234)||!layers)return;
 uintptr_t sample=Q(layers,0x4a8);
 if(!sample)return;
 uintptr_t channels=Q(buffer,0x10);
 if(!channels||!Q(channels,0)||!Q(channels,8))return;
 unsigned index=(unsigned)((instrument>>4)^(instrument>>13)^(instrument>>21))&127u;
 struct AudibleSample *slot=&audible[index];
 if(__atomic_exchange_n(&slot->busy,1,AQ))return;
 unsigned epoch=__atomic_load_n(&host.project_epoch,AQ);
 unsigned clock=__atomic_load_n(&audible_clock,AQ);
 uint64_t prior=__atomic_load_n(&slot->marker,AQ);
 uintptr_t label=Q(sample,0xa8);
 if(slot->instrument!=instrument||slot->sample!=sample||slot->label!=label||__atomic_load_n(&slot->epoch,AQ)!=epoch){
  slot->instrument=instrument;slot->sample=sample;slot->label=label;
  slot->key=pc_tune_sample_key((const char*)label);
  __atomic_store_n(&slot->marker,0,RL);
  __atomic_store_n(&slot->epoch,epoch,RL);
  prior=0;
 }
 if(slot->key&&(!prior||(unsigned)(prior>>32)!=clock)){
  const float *l=(const float*)Q(channels,0),*r=(const float*)Q(channels,8);
  for(unsigned n=0;n<frames;n+=8){
   if(l[n]>1.e-7f||l[n]<-1.e-7f||r[n]>1.e-7f||r[n]<-1.e-7f){
    unsigned order=prior&&clock-(unsigned)(prior>>32)<=AUDIBLE_WINDOW?
        ((unsigned)prior>>9):__atomic_add_fetch(&audible_serial,1,RX)&AUDIBLE_ORDER_MASK;
    __atomic_store_n(&slot->marker,(uint64_t)clock<<32|(order<<9)|slot->key,RL);
    if(!prior)pc_diag_add(69);
    break;
   }
  }
 }
 __atomic_store_n(&slot->busy,0,RL);
}
static unsigned audible_key(void){
 unsigned clock=__atomic_load_n(&audible_clock,AQ),epoch=__atomic_load_n(&host.project_epoch,AQ);
 unsigned key=0,newest=0;
 for(unsigned n=0;n<128;n++){
  const struct AudibleSample *slot=&audible[n];
  if(__atomic_load_n(&slot->epoch,AQ)!=epoch)continue;
  uint64_t marker=__atomic_load_n(&slot->marker,AQ);
  if(!marker||clock-(unsigned)(marker>>32)>AUDIBLE_WINDOW)continue;
  unsigned order=(unsigned)marker>>9;
  if(!key||((order-newest)&AUDIBLE_ORDER_MASK)<0x400000u){key=(unsigned)marker&511u;newest=order;}
 }
 return key;
}
static unsigned publish(unsigned current,unsigned gen){
 unsigned shown=current;
 if(!shown){
  unsigned key=__atomic_load_n(&sample_key,AQ);
  if(!key)key=audible_key();
  if(key)shown=key|SAMPLE_SOURCE;
 }
 if(gen==__atomic_load_n(&generation,AQ)&&shown!=pc_tune_follow_result()){
  __atomic_store_n(&result,shown,RL);
  pc_diag_value(70,(shown&SAMPLE_SOURCE)?shown&511u:0);
  FN(0x6d43500,void(*)(uint64_t))((27u<<1)|1u);
 }
 return shown&511u;
}
static unsigned mask(unsigned root,unsigned minor){unsigned m=minor?0x5adu:0xab5u;return ((m<<root)|(m>>(12-root)))&4095u;}
unsigned pc_tune_follow_render(unsigned frames){
 unsigned gen=__atomic_load_n(&generation,AQ);if(seen!=gen){seen=gen;memset(history,0,sizeof history);candidate=stable=midi=quiet=0;}
 if(!pc_tune_follow_mode())return 0;
 __atomic_add_fetch(&audible_clock,frames,RX);
 float fresh[12],total=0;unsigned attacks=0,freshmask=0;
 for(unsigned n=0;n<12;n++){uint64_t w=__atomic_exchange_n(&pending[n],0,__ATOMIC_ACQ_REL);fresh[n]=(unsigned)(w>>32)==gen?(float)(unsigned)w/127.f:0;total+=fresh[n];if(fresh[n]>.1f){attacks++;freshmask|=1u<<n;}}
 if(total>0||__atomic_load_n(&midi_held,AQ))quiet=0;
 else if(quiet<MIDI_IDLE_FRAMES){
  quiet+=frames;
  if(quiet>=MIDI_IDLE_FRAMES){memset(history,0,sizeof history);candidate=stable=midi=0;}
 }
 if(quiet>=MIDI_IDLE_FRAMES)return publish(0,gen);
 unsigned current=midi;
 /* A new chord with several outside notes is stronger evidence of modulation
  * than a lone passing note; shorten old context instead of waiting a bar. */
 float retain=1.f-(float)frames/(44100.f*1.2f);if(retain<0)retain=0;
 if(attacks>=3&&(current&256)){unsigned outside=freshmask&~mask(current&15,(current>>4)&1);if(outside&&(outside&(outside-1)))retain*=.2f;}
 unsigned distinct=0;float mass=0;
 for(unsigned n=0;n<12;n++){history[n]=history[n]*retain+fresh[n];if(history[n]>32)history[n]=32;if(history[n]>.08f)distinct++;mass+=history[n];}
 if(distinct<3||mass<.15f)return publish(current,gen);
 float best=-1e20f,prior=-1e20f;unsigned choice=0;
 for(unsigned minor=0;minor<2;minor++)for(unsigned root=0;root<12;root++){
  unsigned m=mask(root,minor);float score=0;for(unsigned n=0;n<12;n++)score+=history[n]*((m&(1u<<n))?1.f:-3.f);
  score+=history[root]*.35f+history[(root+(minor?3:4))%12]*.25f+history[(root+7)%12]*.18f;
  unsigned key=256u|root|(minor<<4);if(key==current)prior=score;if(score>best){best=score;choice=key;}
 }
 if(!(best>mass*.45f))return publish(current,gen);
 if(choice==current){candidate=stable=0;return publish(current,gen);}
 if((current&256)&&best<prior+mass*.10f){candidate=stable=0;return publish(current,gen);}
 if(choice!=candidate){candidate=choice;stable=0;}stable+=frames;
 if(stable>=3528&&gen==__atomic_load_n(&generation,AQ)){midi=choice;candidate=stable=0;return publish(midi,gen);}
 return publish(current,gen);
}
