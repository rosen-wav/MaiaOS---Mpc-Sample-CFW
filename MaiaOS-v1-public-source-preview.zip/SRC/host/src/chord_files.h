#ifndef PC_CHORD_FILES_H
#define PC_CHORD_FILES_H
#include <stddef.h>
#include <stdint.h>
#include "editorial_chord_layout.h"
int pc_chord_file_parse(const uint8_t*,size_t,ChordBank*);
#endif
