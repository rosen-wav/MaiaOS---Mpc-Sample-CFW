/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "dj_analysis.h"
#include "dj_mixxx.h"
#include "dj_qm.h"

#define ONSET_HZ 100u
#define MAX_SECONDS 1800u
static unsigned u16(const uint8_t *p){return (unsigned)p[0]|(unsigned)p[1]<<8;}
static uint32_t u32(const uint8_t *p){return u16(p)|(uint32_t)u16(p+2)<<16;}
int pc_dj_wav_read(int fd,void *dst,unsigned count,uint64_t offset){
 uint8_t *p=dst;
 while(count){
  long got=pc_sys(67,fd,(long)p,count,(long)offset,0,0);
  if(got==-4)continue;
  if(got<=0)return 0;
  p+=got;count-=got;offset+=got;
 }
 return 1;
}
int pc_dj_wav_header(int fd,uint64_t size,DjWav *w){
 uint8_t header[40];
 if(size<44||!pc_dj_wav_read(fd,header,12,0)||memcmp(header,"RIFF",4)||memcmp(header+8,"WAVE",4))return 0;
 uint64_t end=(uint64_t)u32(header+4)+8;
 if(end>size)return 0;
 unsigned data=0;
 for(uint64_t at=12;at+8<=end;){
  if(!pc_dj_wav_read(fd,header,8,at))return 0;
  unsigned bytes=u32(header+4);
  at+=8;
  if(bytes>end-at)return 0;
  if(!memcmp(header,"fmt ",4)){
   if(bytes<16||!pc_dj_wav_read(fd,header,bytes<40?bytes:40,at))return 0;
   w->format=u16(header);w->channels=u16(header+2);w->rate=u32(header+4);
   w->block=u16(header+12);w->bits=u16(header+14);
   if(w->format==65534&&bytes>=40){
    static const uint8_t guid_end[]={0,0,0,0,16,0,128,0,0,170,0,56,155,113};
    if(u16(header+16)<22||memcmp(header+26,guid_end,sizeof guid_end))return 0;
    w->format=u16(header+24);
   }
  }else if(!memcmp(header,"data",4)&&!w->data){w->data=at;data=bytes;}
  if(w->rate&&w->data)break;
  at+=(uint64_t)bytes+(bytes&1);
 }
 if(!w->data||w->channels<1||w->channels>2||w->rate<8000||w->rate>192000||
    w->block!=w->channels*(w->bits/8)||!w->block||data%w->block)return 0;
 if(w->format==1){
  if(w->bits!=16&&w->bits!=24&&w->bits!=32)return 0;
 }else if(w->format!=3||w->bits!=32)return 0;
 w->frames=data/w->block;
 return w->frames!=0;
}
float pc_dj_pcm(const uint8_t *p,const DjWav *w){
 float value;
 if(w->format==3){
  uint32_t raw=u32(p);memcpy(&value,&raw,4);
  if(!(value>=-4.f&&value<=4.f))return 0;
 }else if(w->bits==16)value=(int16_t)u16(p)*0x1p-15f;
 else if(w->bits==24){
  uint32_t bits=(uint32_t)p[0]<<8|(uint32_t)p[1]<<16|(uint32_t)p[2]<<24;
  value=(int32_t)bits*0x1p-31f;
 }else value=(int32_t)u32(p)*0x1p-31f;
 return value>1?1:value< -1?-1:value;
}
/* libmpg123 is already loaded by the stock MPC application. Resolve the
 * additional scan/seek APIs from that same shared library. */
#ifndef DJ_RESOLVE
#define DJ_RESOLVE(name) FN(0xb51898,void*(*)(void*,const char*))(0,name)
#endif
static int mp3_open(DjReader *reader,const char *path){
 int(*init)(void)=DJ_RESOLVE("mpg123_init");
 void*(*create)(const char*,int*)=DJ_RESOLVE("mpg123_new");
 int(*open)(void*,const char*)=DJ_RESOLVE("mpg123_open");
 int(*format)(void*,long*,int*,int*)=DJ_RESOLVE("mpg123_getformat");
 int(*scan)(void*)=DJ_RESOLVE("mpg123_scan");
 long(*length)(void*)=DJ_RESOLVE("mpg123_length");
 DjMp3 *m=&reader->mp3;
 m->seek=DJ_RESOLVE("mpg123_seek");
 m->read=DJ_RESOLVE("mpg123_read");
 m->destroy=DJ_RESOLVE("mpg123_delete");
 if(!init||!create||!open||!format||!scan||!length||!m->seek||!m->read||!m->destroy||init())return 0;
 m->handle=create(0,0);
 if(!m->handle)return 0;
 long rate=0,frames=0;int channels=0,encoding=0;
 if(!open(m->handle,path)&&!format(m->handle,&rate,&channels,&encoding)&&
    encoding==0xd0&&rate>=8000&&rate<=48000&&(channels==1||channels==2)&&
    !scan(m->handle))frames=length(m->handle);
 if(frames>0&&m->seek(m->handle,0,0)==0){
  reader->format=(DjWav){.frames=frames,.rate=rate,.channels=channels,.bits=16,.format=1,.block=channels*2};
  return 1;
 }
 m->destroy(m->handle);m->handle=0;return 0;
}
static int mp3_path(const char *path){
 const char *extension=path;
 for(const char *p=path;*p;p++)if(*p=='.')extension=p;
 return extension[0]=='.'&&(extension[1]|32)=='m'&&(extension[2]|32)=='p'&&extension[3]=='3'&&!extension[4];
}
int pc_dj_reader_open(DjReader *reader,const char *path){
 reader->fd=-1;
 long fd=pc_sys(56,-100,(long)path,0x80800,0,0,0);
 if(fd<0)return DJ_READ_ERROR;
 long bytes=pc_sys(62,fd,0,2,0,0,0);
 if(bytes>0&&pc_dj_wav_header(fd,(uint64_t)bytes,&reader->format)){reader->fd=fd;return DJ_OK;}
 pc_sys(57,fd,0,0,0,0,0);
 return mp3_path(path)&&mp3_open(reader,path)?DJ_OK:DJ_FORMAT_ERROR;
}
void pc_dj_reader_close(DjReader *reader){
 if(reader->fd>=0)pc_sys(57,reader->fd,0,0,0,0,0);
 if(reader->mp3.handle)reader->mp3.destroy(reader->mp3.handle);
}
int pc_dj_reader_frame(DjReader *reader,uint64_t frame,float *left,float *right){
 const DjWav *w=&reader->format;
 if(frame>=w->frames)return 0;
 if(frame<reader->base||frame-reader->base>=reader->count){
  if(reader->previous_valid&&frame==reader->previous_frame){
   *left=reader->previous_left;*right=reader->previous_right;return 1;
  }
  if(reader->count){
   const uint8_t *last=reader->bytes+(reader->count-1)*w->block;
   reader->previous_left=pc_dj_pcm(last,w);
   reader->previous_right=w->channels==2?pc_dj_pcm(last+w->bits/8,w):reader->previous_left;
   reader->previous_frame=reader->base+reader->count-1;reader->previous_valid=1;
  }
  unsigned count=sizeof reader->bytes/w->block;
  if(count>w->frames-frame)count=w->frames-frame;
  if(reader->mp3.handle){
   DjMp3 *m=&reader->mp3;
   if(frame!=reader->next&&m->seek(m->handle,(long)frame,0)!=(long)frame)return 0;
   size_t got=0;
   int status=m->read(m->handle,reader->bytes,count*w->block,&got);
   if((status!=0&&status!=-12)||!got||got%w->block)return 0;
   count=got/w->block;reader->next=frame+count;
  }else if(!pc_dj_wav_read(reader->fd,reader->bytes,count*w->block,w->data+frame*w->block))return 0;
  reader->base=frame;reader->count=count;
 }
 const uint8_t *p=reader->bytes+(frame-reader->base)*w->block;
 *left=pc_dj_pcm(p,w);
 *right=w->channels==2?pc_dj_pcm(p+w->bits/8,w):*left;
 return 1;
}
static int digit(char c){return c>='0'&&c<='9';}
static int letter(char c){return (c|32)>='a'&&(c|32)<='z';}
static int bpm_word(const char *p,const char *end){
 return end-p>=3&&(p[0]|32)=='b'&&(p[1]|32)=='p'&&(p[2]|32)=='m'&&
        (p+3==end||!letter(p[3]));
}
double pc_dj_filename_bpm(const char *path){
 const char *name=path,*end=path,*extension=0;
 for(;*end;end++){
  if(*end=='/'){name=end+1;extension=0;}
  else if(*end=='.')extension=end;
 }
 if(extension)end=extension;
 double isolated=0,explicit=0;
 for(const char *p=name;p<end;){
  if(!digit(*p)){p++;continue;}
  const char *first=p;
  unsigned whole=0,count=0;
  while(p<end&&digit(*p)){if(count<4)whole=10*whole+*p-'0';count++;p++;}
  double value=whole;
  if(end-p>1&&*p=='.'&&digit(p[1])){
   double place=.1;
   for(p++;p<end&&digit(*p);p++,place*=.1)value+=(*p-'0')*place;
  }
  if(count>3||value<50||value>220)continue;
  const char *before=first,*after=p;
  while(before>name&&(before[-1]==' '||before[-1]=='_'||before[-1]=='-'))before--;
  while(after<end&&(*after==' '||*after=='_'||*after=='-'))after++;
  int prefix=before-name>=3&&bpm_word(before-3,before)&&
      (before-name==3||!letter(before[-4]));
  if(prefix||bpm_word(after,end)){explicit=value;continue;}
  if((first==name||first[-1]==' '||first[-1]=='_')&&(p==end||*p==' '||*p=='_'))isolated=value;
 }
 return explicit?explicit:isolated;
}
static int collect(DjReader *reader,unsigned hop,float *onsets,float *offsets,float *low_onsets,DjAnalysis *result,void *qm,DjProgress *progress){
 const DjWav *w=&reader->format;
 float level=0,baseline=0,bass=0,bass_baseline=0,low_l=0,low_r=0,sub_l=0,sub_r=0;
 float peak_level=0,peak_baseline=0;
 float smooth=880.f/w->rate,sub=155.f/w->rate,previous_peak=0,sharpest=0,previous_sharpest=0;
 unsigned transient=hop/2,previous_transient=hop/2;
 unsigned elapsed=0,onset=0,bin=0;
 uint64_t next=(w->frames+DJ_PEAKS-1)/DJ_PEAKS;
 for(uint64_t frame=0;frame<w->frames;frame++){
   float left,right;
   if(!pc_dj_reader_frame(reader,frame,&left,&right))return 0;
   pc_dj_qm_feed(qm,(left+right)*.5f);
   if(frame%16384==0)pc_dj_progress_report(progress,10+(unsigned)(frame*690/w->frames));
   float peak=left<0?-left:left;
   float right_peak=right<0?-right:right;
   if(right_peak>peak)peak=right_peak;
   if(frame>=next){
    bin=frame*DJ_PEAKS/w->frames;
    next=((bin+1)*w->frames+DJ_PEAKS-1)/DJ_PEAKS;
   }
   unsigned quantized=(unsigned)(peak*255+.5f);
   if(quantized>result->peak[bin])result->peak[bin]=quantized;
   if(onsets){
    if(peak>peak_level)peak_level=peak;
    float attack=peak-previous_peak;
    if(attack>sharpest){sharpest=attack;transient=elapsed;}
    previous_peak=peak;
    low_l+=smooth*(left-low_l);
    low_r+=smooth*(right-low_r);
    /* Broad attacks and low-frequency attacks share the grid. */
    sub_l+=sub*(left-sub_l);sub_r+=sub*(right-sub_r);
    float kick_l=low_l-sub_l,kick_r=low_r-sub_r;
    bass+=(kick_l<0?-kick_l:kick_l)+(kick_r<0?-kick_r:kick_r);
    level+=peak;
    if(++elapsed==hop){
     level/=hop;bass/=(2*hop);
     float rise=level-baseline,low_rise=bass-bass_baseline;
     float peak_rise=peak_level-peak_baseline;
     onsets[onset]=.35f*(rise>0?rise:0)+.30f*(low_rise>0?low_rise:0)+.35f*(peak_rise>0?peak_rise:0);
     low_onsets[onset]=low_rise>0?low_rise:0;
     offsets[onset++]=previous_sharpest*.85f>sharpest?
       (float)previous_transient/hop-1.f:(float)transient/hop;
     previous_sharpest=sharpest;previous_transient=transient;
     baseline+=(level-baseline)*(rise>0?.45f:.20f);
     bass_baseline+=(bass-bass_baseline)*(low_rise>0?.45f:.20f);
     peak_baseline+=(peak_level-peak_baseline)*.35f;
     elapsed=0;level=bass=sharpest=peak_level=0;transient=hop/2;
    }
   }
 }
 return 1;
}
/* Robust 90th-percentile attack level. It suppresses isolated extreme
 * peaks while retaining the recurring loud kick accents. */
static float grid_reference(const float *onsets,const float *low,unsigned size){
 float maximum=0;
 for(unsigned i=0;i<size;i++){
  float value=low?.35f*onsets[i]+1.5f*low[i]:onsets[i];
  if(value>maximum)maximum=value;
 }
 if(maximum<=1e-7f)return 0;
 unsigned histogram[64]={0},count=0;
 for(unsigned i=0;i<size;i++){
  float value=low?.35f*onsets[i]+1.5f*low[i]:onsets[i];
  if(value>maximum*.02f){
   unsigned bin=(unsigned)(63*value/maximum);if(bin>63)bin=63;
   histogram[bin]++;count++;
  }
 }
 unsigned cumulative=0;
 for(unsigned i=0;i<64;i++)if((cumulative+=histogram[i])*10>=count*9)
  return maximum*((float)i+.5f)/63.5f;
 return maximum;
}
static void grid_accent_vote(const float strength[4],unsigned votes[4]){
 unsigned best=0;for(unsigned k=1;k<4;k++)if(strength[k]>strength[best])best=k;
 float second=0;for(unsigned k=0;k<4;k++)if(k!=best&&strength[k]>second)second=strength[k];
 if(strength[best]>1e-6f&&strength[best]>second*1.05f)votes[best]++;
}
/* Fold recurring kick attacks onto the candidate period, independent of
 * QM's broadband phase. One clipped vote per local peak prevents one loud
 * pickup or a sustained bass note from dominating the grid. */
static double kick_phase(const float *low,const float *offsets,unsigned size,double period,double seed){
 enum { BINS=96 };
 double bins[BINS]={0};unsigned hits[BINS]={0};
 float ref=grid_reference(low,0,size);
 if(ref<1e-6f)return seed;
 unsigned total=0;
 for(unsigned i=0;i<size;i++){
  float v=low[i];if(v<ref*.30f||(i&&low[i-1]>=v)||(i+1<size&&low[i+1]>v))continue;
  double cycles=(i+offsets[i])/period;
  int b=(int)((cycles-(int)cycles)*BINS+.5);if(b<0)b+=BINS;if(b>=BINS)b-=BINS;
  bins[b]+=v>ref*1.5f?1.5f:v/ref;hits[b]++;total++;
 }
 if(total<4)return seed;
 unsigned best=0;double best_value=0;
 for(unsigned b=0;b<BINS;b++){
  double score=0;
  for(int j=-6;j<=6;j++)score+=bins[(b+BINS+j)%BINS]*(7-(j<0?-j:j));
  if(score>best_value){best=b;best_value=score;}
 }
 unsigned support=0;double weight=0,offset=0;
 for(int j=-6;j<=6;j++){
  unsigned b=(best+BINS+j)%BINS;support+=hits[b];offset+=j*bins[b];weight+=bins[b];
 }
 if(support<4||support*5<total||weight<3)return seed;
 double phase=(best+offset/weight)*period/BINS;
 if(phase<0)phase+=period;if(phase>=period)phase-=period;
 return phase;
}
static int grid_peak(const float *onsets,const float *low,unsigned size,int centre,int radius){
 int pos=-1;float best=0;
 for(int k=centre-radius;k<=centre+radius;k++)if(k>=0&&(unsigned)k<size){
  float score=.35f*onsets[k]+1.5f*low[k];
  if(score>best){best=score;pos=k;}
 }
 return pos;
}
/* QM/Mixxx estimates tempo, kick evidence refines phase and labels bar one. */
static void beatgrid(const float *onsets,const float *offsets,const float *low,unsigned size,unsigned hop,DjAnalysis *r){
 if(!r->beat_frames||!size)return;
 double period=r->beat_frames/hop,start=r->first_beat/hop;
 float maximum=0;for(unsigned i=0;i<size;i++)if(onsets[i]>maximum)maximum=onsets[i];
 if(maximum<1e-7f){r->beat_frames=0;return;}
 double attack=0;
 for(unsigned i=0;i<size;i++)if(onsets[i]>maximum*.015f&&onsets[i]>1e-6f){
  unsigned at=i;for(unsigned j=i+1;j<size&&j<=i+2;j++)if(onsets[j]>onsets[at])at=j;
  attack=at+offsets[at];if(attack<0)attack=0;r->transient_valid=1;break;
 }
 r->first_transient=attack*hop;
 start=kick_phase(low,offsets,size,period,start);
 double delta=(attack-start)/period;
 double nearest=start+(int)(delta+(delta<0?-.5:.5))*period;
 double error=nearest-attack;if(error<0)error=-error;
 if(error<period*.13){
  double chosen=0,current=0;unsigned hits=0;
  int radius=(int)(period*.12);if(radius<1)radius=1;
  for(unsigned beat=0;beat<32;beat++){
   int ca=(int)(attack+beat*period+.5),cb=(int)(nearest+beat*period+.5);float a=0,b=0;
   for(int j=-radius;j<=radius;j++){
    if(ca+j>=0&&(unsigned)(ca+j)<size&&onsets[ca+j]>a)a=onsets[ca+j];
    if(cb+j>=0&&(unsigned)(cb+j)<size&&onsets[cb+j]>b)b=onsets[cb+j];
   }
   chosen+=a;current+=b;if(a>maximum*.025f)hits++;
  }
  if(hits>=6&&chosen>=current*.85){start=attack;r->first_beat=attack*hop;}
 }

 int first=(int)((attack-start)/period);while(start+first*period<attack-period*.06)first++;
 while(start+first*period<0)first++;
 r->first_beat=(start+first*period)*hop;
 double accent[4]={0};unsigned groups[4]={0},votes[4]={0};float bar[4]={0};
 float limit=grid_reference(onsets,low,size)*1.2f;
 int radius=(int)(period*.14);if(radius<1)radius=1;
 for(int beat=first;start+beat*period<size;beat++){
  unsigned mod=(beat%4+4)%4;
  if(!mod){grid_accent_vote(bar,votes);memset(bar,0,sizeof bar);}
  int centre=(int)(start+beat*period+.5),pos=grid_peak(onsets,low,size,centre,radius);
  float strength=pos>=0?onsets[pos]:0;
  if(pos>=0){float weight=.35f*strength+1.5f*low[pos];if(limit>0&&weight>limit)weight=limit;
   weight*=weight;accent[mod]+=weight;groups[mod]++;bar[mod]=weight;}
 }
 grid_accent_vote(bar,votes);
 unsigned strongest=0,voted=0,total=0;
 for(unsigned i=0;i<4;i++){accent[i]=groups[i]?accent[i]/groups[i]:0;total+=votes[i];if(votes[i]>votes[voted])voted=i;}
 for(unsigned i=1;i<4;i++)if(accent[i]>accent[strongest])strongest=i;
 if(total>=4&&votes[voted]*100>=total*60)strongest=voted;
 double second=0;for(unsigned i=0;i<4;i++)if(i!=strongest&&accent[i]>second)second=accent[i];
 unsigned distinct=groups[strongest]>=4&&(accent[strongest]>1.12*second||(total>=4&&votes[strongest]*100>=total*60));
 float bass_reference=grid_reference(low,0,size);
 // Prefer the opening sound as one when it is a substantial, repeated
 // rhythmic hit. Global accents later in the song must not rotate this bar.
 if(error<period*.13){
  float opening=0,opening_low=0,early_max=0;unsigned followers=0;
  for(unsigned j=0;j<16;j++){
   int centre=(int)(start+(first+j)*period+.5),pos=grid_peak(onsets,low,size,centre,radius);
   float strength=pos>=0?onsets[pos]:0;
   if(pos<0)continue;
   float weight=.35f*strength+1.5f*low[pos];if(weight>early_max)early_max=weight;
   if(!j){opening=weight;opening_low=low[pos];}
   else if(j<4&&strength>maximum*.025f)followers++;
  }
  if(followers>=2&&opening>=early_max*.45f&&
     (bass_reference<1e-7f||opening_low>=bass_reference*.35f)){
   r->downbeat=0;r->first_downbeat=r->first_beat;r->downbeat_valid=1;return;
  }
 }

 for(int beat=first;start+(beat+3)*period<size;beat++){
  if(distinct&&(beat%4+4)%4!=strongest)continue;
  unsigned regular=0;float initial=0,bass=0;
  for(unsigned j=0;j<4;j++){
   int centre=(int)(start+(beat+j)*period+.5),pos=grid_peak(onsets,low,size,centre,radius);
   float strength=pos>=0?onsets[pos]:0;
   if(pos>=0&&strength>maximum*.025f){regular++;if(!j){initial=.35f*strength+1.5f*low[pos];bass=low[pos];}}
  }
  if(regular<3||!initial)continue;
  if(distinct){if(initial*initial<accent[strongest]*.55)continue;}
  else if(bass_reference>1e-7f&&bass<bass_reference*.45f)continue;
  double at=start+beat*period;
  int kick=grid_peak(onsets,low,size,(int)(at+.5),radius);
  if(kick>=0&&low[kick]>=bass_reference*.45f&&bass_reference>1e-7f){
   double correction=kick+offsets[kick]-at;
   if(correction>-period*.10&&correction<period*.10){
    at+=correction;r->first_beat+=correction*hop;
    if(r->first_beat<0)r->first_beat=0;
   }
  }
  r->downbeat=(beat-first)%4;r->first_downbeat=at*hop;r->downbeat_valid=1;break;
 }
}

int pc_dj_analyse_progress(const char *path,const char *name,DjAnalysis *result,DjProgress *progress){
 memset(result,0,sizeof *result);result->downbeat=-1;
 DjReader reader={0};
 int error=pc_dj_reader_open(&reader,path);
 if(error!=DJ_OK)return error;
 const DjWav *wav=&reader.format;
 error=DJ_TOO_LONG;
 if(wav->frames<=(uint64_t)wav->rate*MAX_SECONDS){
  result->tagged_bpm=(float)pc_dj_filename_bpm(name);
  unsigned hop=(wav->rate+ONSET_HZ/2)/ONSET_HZ,count=wav->frames/hop;
  unsigned storage=(count?count:1)*sizeof(float)*3;
  long memory=pc_sys(222,0,storage,3,0x22,-1,0);
  error=DJ_MEMORY_ERROR;
  if(memory>0){
   float *onsets=(float*)memory;
   error=DJ_READ_ERROR;
   float *offsets=onsets+(count?count:1),*low_onsets=offsets+(count?count:1);
   void *qm=pc_dj_qm_create(wav->rate);
   if(qm&&collect(&reader,hop,onsets,offsets,low_onsets,result,qm,progress)){
    result->frames=wav->frames;result->rate=wav->rate;
    double period=0,first=0;
    int detected=pc_dj_qm_finish(qm,result->tagged_bpm,&period,&first,progress);
    if(!detected&&result->tagged_bpm>0){
     period=wav->rate*60.0/result->tagged_bpm;
     double seed=kick_phase(low_onsets,offsets,count,period/hop,-1);
     if(seed<0)seed=kick_phase(onsets,offsets,count,period/hop,-1);
     if(seed>=0){detected=1;first=seed*hop;}
    }
    if(detected){
     result->beat_frames=period;result->first_beat=first;
     beatgrid(onsets,offsets,low_onsets,count,hop,result);
    }
    error=DJ_OK;
   }
   if(qm)pc_dj_qm_destroy(qm);
   pc_sys(215,memory,storage,0,0,0,0);
  }
 }
 pc_dj_reader_close(&reader);
 pc_dj_progress_report(progress,1000);
 return error;
}
int pc_dj_analyse_named(const char *path,const char *name,DjAnalysis *result){return pc_dj_analyse_progress(path,name,result,0);}

int pc_dj_analyse(const char *path,DjAnalysis *result){return pc_dj_analyse_named(path,path,result);}
