#ifndef PC_MULTISAMPLES_H
#define PC_MULTISAMPLES_H
#include <stdint.h>
#define PC_MS_ENGINE 10u
#define PC_MS_VOICES 512u
#define PC_MS_ID 16u
uintptr_t pc_ms_load(const uint8_t*);
void pc_ms_free(uintptr_t);
int pc_ms_on(uintptr_t,unsigned,unsigned,unsigned);
void pc_ms_off(uintptr_t,unsigned);
void pc_ms_stop(uintptr_t);
unsigned pc_ms_voices(uintptr_t);
void pc_ms_render(uintptr_t,float*,float*,unsigned);
int pc_ms_assign(uintptr_t,uintptr_t,const uint8_t*);
unsigned pc_ms_zone(unsigned);
int pc_ms_open(uintptr_t,uintptr_t);
int pc_ms_active(void);
void pc_ms_event(unsigned,unsigned);
void pc_ms_input(uintptr_t,uintptr_t,unsigned,unsigned);
int pc_ms_paint(uintptr_t,uintptr_t);
unsigned pc_ms_envelope(const uint8_t*,unsigned);
void pc_ms_set(uintptr_t,unsigned,unsigned);
int pc_ms_preset_browser(void);
void pc_ms_editor_reset(void);
void pc_ms_editor_event(uintptr_t,unsigned,unsigned);
int pc_ms_editor(uintptr_t,uintptr_t,int,int);
#endif
