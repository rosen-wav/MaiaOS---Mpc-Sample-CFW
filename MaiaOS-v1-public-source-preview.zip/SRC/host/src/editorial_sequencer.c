/* SPDX-License-Identifier: GPL-3.0-only
 * Paint-only views. Native input, timing, note trees and chord state own all
 * behavior. Never write a note, selection, cursor, bank or controller here.
 */
#include "internal.h"
#include "groove.h"
#include "../theme/layout.h"
#include "editorial_chord_layout.h"
#define NATIVE_STEP_VTABLE 0x6e24f38u
#define NATIVE_CH_ENTER 0x7410018u
#define NATIVE_CH_LEAVE 0x7410098u
typedef struct {uintptr_t g;int w,h,top,bottom;} View;
static void draw(void *ptr,int x,int y,int w,int h,unsigned c){
 View*v=ptr;if(y<v->top){h-=v->top-y;y=v->top;}if(y+h>v->bottom)h=v->bottom-y;
 if(x<0){w+=x;x=0;}if(x+w>v->w)w=v->w-x;if(w<=0||h<=0||x>=v->w)return;
 FN(0x102d5e0,void(*)(uintptr_t,unsigned))(v->g,pc_theme_colour(c));FN(0x102e000,void(*)(uintptr_t,int,int,int,int))(v->g,x,y,w,h);
}
static unsigned number(char*out,unsigned at,uint64_t value){char reverse[24];unsigned n=0;do{reverse[n++]='0'+value%10;value/=10;}while(value&&n<24);while(n)out[at++]=reverse[--n];out[at]=0;return at;}
static void pad_name(char out[8],unsigned source){out[0]='A'+source/16;unsigned p=source%16+1;out[1]='0'+p/10;out[2]='0'+p%10;out[3]=0;}
static int bounds(uintptr_t screen,int*w,int*h){typedef struct{uint64_t xy,wh;} Bounds;Bounds b=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);*w=(int)(uint32_t)b.wh;*h=(int)(b.wh>>32);return *w>=200&&*w<=1024&&*h>=130&&*h<=1024;}
/* Same verified native aggregate-return ABI used by the existing piano roll. */
typedef struct {int32_t index,padding;int64_t tick,grid,first,last,length;int32_t max,padding2;} StepInfo;
_Static_assert(sizeof(StepInfo)==56,"native StepInfo ABI");
_Static_assert(sizeof(ChordBank)==1088,"native chord bank ABI");
_Static_assert(offsetof(ChordProjects,live)==596408,"native chord cache ABI");
_Static_assert(offsetof(ChordLive,view)==80,"native chord snapshot ABI");
/* UI-only visual signature. Native widgets may invalidate just a small text
 * field; request ONE complete repaint when the matrix changes, never every
 * paint. This keeps pad/cursor/note changes visible without a repaint loop. */
typedef struct {
 uintptr_t screen,controller,program;
 unsigned epoch,source,rows,cursor;
 int w,h;
 uint64_t first_step,begin,grid,length;
 unsigned pads[6];
 uint16_t notes[6];
 uint8_t chords[6];
} StepVisual;
static StepVisual step_visual;
static unsigned step_retry;
int pc_editorial_step_populated(uintptr_t program,unsigned source){
 int key=I(program,0x12a8+4*source);if(key<0||key>127)return 0;
 int index=I(program,0x14a8+4*key);uintptr_t b=Q(program,0x2808),e=Q(program,0x2810);
 if(!b||e<b||(e-b)%8||e-b>1024||index<0||(unsigned)index>=(e-b)/8)return 0;
 uintptr_t instrument=Q(b,8*index);if(instrument&&pc_find(instrument)>=0)return 1;
 return ((unsigned(*)(uintptr_t,unsigned))Q(Q(program,0),0xd0))(program,source)&1;
}
static int step_paint_locked(uintptr_t screen,uintptr_t graphics,uintptr_t program,unsigned source){
 if(!screen||!graphics||Q(screen,0)!=host.base+NATIVE_STEP_VTABLE)return 0;
 uintptr_t b=Q(pc_state_base(),0x20),manager=b?Q(b,0x30):0,ctrl=b?Q(b,0x150):0;
 if(!manager||pc_audio_config_scope())return 0;
 int id=I(manager,0xd8);if(id==0x3080)id=I(manager,0x80);if(id!=0x20ad)return 0;
 /* Preserve the original piano-roll/browser delegate and its UI side effects. */
 if(I(pc_state_base(),0x860)&&!I(pc_state_base(),0x5000)){
  if(!FN(0x7410018,int(*)(void))()){FN(0x1149d70,void(*)(uintptr_t))(screen);return 1;}
  pc_roll_prepare_locked();FN(0x7403db4,void(*)(uintptr_t,uintptr_t))(screen,graphics);pc_roll_view_paint_locked(screen,graphics);FN(0x7410098,void(*)(void))();return 1;
 }
 FN(0x7403db4,void(*)(uintptr_t,uintptr_t))(screen,graphics);
 if(I(pc_state_base(),0x5000))return 1;
 if(source>=128||!program||!ctrl||!Q(ctrl,0xc0)||!Q(ctrl,0x248)||!Q(ctrl,0x258)||Q(Q(ctrl,0x248),0xb8)!=program)return pc_editorial_step_cached(screen,graphics);
 StepInfo s=FN(0x157f310,StepInfo(*)(uintptr_t,int))(ctrl,I(ctrl,0xe4));
 if(s.index<0||s.grid<1||s.grid>15360||s.length<1||s.index>0x10000000)return pc_editorial_step_cached(screen,graphics);
 uintptr_t project=Q(ctrl,0x248),sequence=Q(project,0x1c8);
 int64_t length=sequence&&Q(sequence,0)==host.base+0x6ecdff0?*(int64_t*)(sequence+0x348):s.length;
 int64_t play_tick=pc_sequence_play_tick();
 if(length>0&&length<0x100000000LL&&play_tick>=0){
  s.index=(play_tick%length)/s.grid;
  s.length=length;
 }
 uint64_t first_step=(unsigned)s.index/16*16,begin=first_step*(uint64_t)s.grid,span=16*(uint64_t)s.grid;
 if(begin>=(uint64_t)s.length){first_step=(((uint64_t)s.length-1)/(uint64_t)s.grid)/16*16;begin=first_step*(uint64_t)s.grid;}
 unsigned cursor=(uint64_t)(unsigned)s.index-first_step>=16?16:(unsigned)((uint64_t)(unsigned)s.index-first_step);
 int w,h;if(!bounds(screen,&w,&h))return 1;
 unsigned occupied[128],total=0,selected=0;for(unsigned pad=0;pad<128;pad++)if(pc_editorial_step_populated(program,pad)){if(pad<=source)selected=total;occupied[total++]=pad;}
 unsigned capacity=h>=190?6:1,first=selected/capacity*capacity,rows=total>first?total-first:0;if(rows>capacity)rows=capacity;
 unsigned pads[6];int keys[6];for(unsigned row=0;row<rows;row++){pads[row]=occupied[first+row];keys[row]=I(program,0x12a8+4*pads[row]);if(keys[row]<0||keys[row]>127)return pc_editorial_step_cached(screen,graphics);}
 uint16_t notes[6]={0};uintptr_t list=Q(ctrl,0xc0),end=list+0x68,node=Q(list,0x78);unsigned count=0;
 for(;node&&node!=end&&count<16384;count++){
  uintptr_t event=node+0x20;int64_t tick=*(int64_t*)event;if(tick>=0&&(uint64_t)tick>=begin+span)break;
  if(*(uint8_t*)(event+8)==3&&tick>=0&&(uint64_t)tick>=begin&&(uint64_t)tick<(uint64_t)s.length){unsigned col=((uint64_t)tick-begin)/(uint64_t)s.grid;unsigned key=*(uint8_t*)(event+0x30);if(col<16)for(unsigned row=0;row<rows;row++)if(key==(unsigned)keys[row])notes[row]|=1u<<col;}
  node=FN(0xb51738,uintptr_t(*)(uintptr_t))(node);
 }
 uint8_t labels[128],chords[6]={0};
 pc_groove_chord_labels(list,length,labels);
 for(unsigned row=0;row<rows;row++)chords[row]=labels[pads[row]];
 if(count==16384)return pc_editorial_step_cached(screen,graphics);
 StepVisual next;
 memset(&next,0,sizeof next);
 next.screen=screen;next.controller=ctrl;next.program=program;
 next.epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 next.source=source;next.rows=rows;next.cursor=cursor;next.w=w;next.h=h;
 next.first_step=first_step;next.begin=begin;next.grid=s.grid;next.length=s.length;
 memcpy(next.pads,pads,rows*sizeof *pads);
 memcpy(next.notes,notes,sizeof notes);memcpy(next.chords,chords,sizeof chords);
 if(memcmp(&step_visual,&next,sizeof next)){
  step_visual=next;
  FN(0x1149d70,void(*)(uintptr_t))(screen);
 }
 step_retry=0;
 return pc_editorial_step_cached(screen,graphics);
}
int pc_editorial_step_cached(uintptr_t screen,uintptr_t graphics){
 if(!screen||!graphics)return 0;
 int w,h;if(!bounds(screen,&w,&h))return 1;
 const StepVisual *vdata=&step_visual;
 unsigned epoch=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ);
 int valid=vdata->screen==screen&&vdata->epoch==epoch&&vdata->w==w&&vdata->h==h;
 if(!step_retry&&!valid){step_retry=1;FN(0x1149d70,void(*)(uintptr_t))(screen);}
 unsigned source=valid?vdata->source:0,rows=valid?vdata->rows:0,cursor=valid?vdata->cursor:0;
 uint64_t first_step=valid?vdata->first_step:0,begin=valid?vdata->begin:0;
 uint64_t grid=valid?vdata->grid:240,length=valid?vdata->length:3840;
 const unsigned *pads=vdata->pads;
 const uint8_t *chords=vdata->chords;
 const uint16_t *notes=vdata->notes;
 unsigned chord_column=0;
 for(unsigned row=0;row<rows;row++)chord_column|=chords[row];
 /* Native B1/B2/B3 captions, knob labels/values and lower status stay visible.
  * Only the central content is replaced. All hit targets remain native. */
 int native_bottom=h>=220?42:48;int gx=chord_column?75:39,gy=h>=220?90:64,gw=w-gx-8,gh=h-native_bottom-gy-21;if(gh<16){pc_step_roll_paint_caption(screen,graphics);return 1;}
 View v={graphics,w,h,h>=220?31:16,h-native_bottom};EiCanvas c={&v,draw,w,h};ei_rect(&c,0,v.top,w,h-native_bottom-v.top,MPC_THEME_BG);
 pc_step_roll_paint_caption(screen,graphics);
 if(h>=220)ei_heading(&c,8,33,"step edit.",w-16);else ei_text(&c,8,18,"STEP EDIT",w-16,MPC_THEME_TEXT);
 char status[72],pad[8];pad_name(pad,source);memcpy(status,"PAD ",4);memcpy(status+4,pad,3);memcpy(status+7," / STEPS ",9);unsigned at=number(status,16,first_step+1);status[at++]='-';at=number(status,at,first_step+16);memcpy(status+at," / ",3);at+=3;
 if(3840%(unsigned)grid==0){unsigned den=3840/(unsigned)grid,third=den/3;int triplet=den%3==0&&third&&!(third&(third-1));memcpy(status+at,"1/",2);at=number(status,at+2,triplet?den*2/3:den);if(triplet){status[at++]='T';status[at]=0;}}else{at=number(status,at,(unsigned)grid);memcpy(status+at," TICKS",7);}
 ei_text(&c,8,h>=220?72:48,status,w-16,MPC_THEME_MUTED);
 for(unsigned row=0;row<rows;row++){
  int y=gy+row*gh/rows,rh=(row+1)*gh/rows-row*gh/rows;unsigned chosen=pads[row]==source;pad_name(pad,pads[row]);
  if(chosen)ei_rect(&c,5,y,w-10,rh,MPC_THEME_SURFACE);
  unsigned label_h=rh<14?10:12;pc_theme_text_face_width(&c,ei_rect,8,y+(rh-(int)label_h)/2,pad,3,chosen?MPC_THEME_TEXT:MPC_THEME_MUTED,0,label_h,27);
  if(chords[row])pc_theme_text_face_width(&c,ei_rect,33,y+(rh-9)/2,"CHORDS",6,MPC_THEME_ACCENT,0,9,39);
  for(unsigned col=0;col<16;col++){
   int x=gx+col*gw/16,cw=(col+1)*gw/16-col*gw/16;uint64_t tick=begin+col*grid;
   if(tick>=length)continue;
   ei_rect(&c,x,y+2,cw-2,rh-4,MPC_THEME_GRID);
   ei_rect(&c,x+1,y+3,cw-4,rh-6,notes[row]&(1u<<col)?MPC_THEME_TEXT:MPC_THEME_BG);
   if(chosen&&col==cursor){if(notes[row]&(1u<<col))ei_rect(&c,x+1,y+3,cw-4,rh-6,MPC_THEME_ACCENT);else ei_rect(&c,x+1,y+rh-4,cw-4,2,MPC_THEME_ACCENT);}
  }
 }
 int x=gx+(int)cursor*gw/16;ei_rect(&c,x,gy-2,1,gh+4,MPC_THEME_ACCENT);
 ei_text(&c,8,h-native_bottom-18,"ENC scroll   -/+ pad   IMPORT groove",w-16,MPC_THEME_MUTED);return 1;
}
int pc_editorial_step_paint(uintptr_t screen,uintptr_t graphics,uintptr_t program,unsigned source){
 /* Same try-lock/recursion contract as the existing native UI painters. No
  * waiting and no model traversal while a project metadata owner is busy. */
 if(!FN(NATIVE_CH_ENTER,int(*)(void))())return pc_editorial_step_cached(screen,graphics);
 int result=step_paint_locked(screen,graphics,program,source);
 FN(NATIVE_CH_LEAVE,void(*)(void))();return result;
}
int pc_editorial_step_reuse(uintptr_t screen,uintptr_t graphics){
 /* A temporary mode may keep the Step Edit child visible. Only redraw its
  * known view and leave native Piano Roll and browser delegates alone. */
 if(step_visual.screen!=screen||
    step_visual.epoch!=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)||
    I(pc_state_base(),0x860)||I(pc_state_base(),0x5000))return 0;
 return pc_editorial_step_cached(screen,graphics);
}
void pc_editorial_step_invalidate(void){step_visual.screen=0;step_retry=0;}
int pc_editorial_chord_paint(uintptr_t screen,uintptr_t graphics){
 int w,h;if(!bounds(screen,&w,&h))return 1;
 /* Original painter already updated this UI-owned snapshot and all native
  * page/import/repaint behavior. Copy under the same native metadata guard. */
 if(!FN(NATIVE_CH_ENTER,int(*)(void))())return 1;
 ChordLive *live=&((ChordProjects*)(pc_state_base()+0x30000))->live;
 ChordBank bank=live->view;unsigned page=live->view_page,fixed=live->view_fixed;int transpose=live->view_transpose;
 FN(NATIVE_CH_LEAVE,void(*)(void))();
 if(bank.version!=1||bank.count!=16||page>=4||fixed>1||transpose< -24||transpose>24)return 1;
 View v={graphics,w,h,0,h};EiCanvas c={&v,draw,w,h};char right[16]="PAGE 1/4";right[5]='1'+page;ei_header(&c,"CHORD MODE",right);if(h>=190)ei_heading(&c,8,29,"chords.",w-16);
 char info[48];const char*policy=fixed?"FIXED / TR ":"INDEP / TR ";unsigned n=0;while(policy[n]){info[n]=policy[n];n++;}if(transpose<0){info[n++]='-';transpose=-transpose;}else info[n++]='+';number(info,n,(unsigned)transpose);ei_text(&c,8,h>=190?64:28,info,w-16,MPC_THEME_MUTED);
 int top=83,space=h-112;if(h<190){top=45;space=h-70;}unsigned held=__atomic_load_n((unsigned*)(pc_state_base()+0x18d0),AQ);
 for(unsigned p=0;p<16;p++){
  int col=p%4,row=3-p/4,x=8+col*(w-16)/4,y=top+row*space/4,cw=(col+1)*(w-16)/4-col*(w-16)/4,ch=(row+1)*space/4-row*space/4;
  ei_rect(&c,x+1,y+1,cw-2,ch-2,(held&(1u<<p))?MPC_THEME_SELECTED:MPC_THEME_SURFACE);
  const char*name=bank.pads[p].count?bank.pads[p].name:"-";char safe[33];memcpy(safe,name,bank.pads[p].count?32:2);safe[32]=0;
  if(ch>=28){ei_text(&c,x+6,y+4,safe,cw-12,MPC_THEME_TEXT);char label[8];number(label,0,p+1);ei_text(&c,x+6,y+ch-15,label,cw-12,MPC_THEME_MUTED);}
  else ei_text(&c,x+4,y+(ch-12)/2,safe,cw-8,MPC_THEME_TEXT);
  if(held&(1u<<p))ei_rect(&c,x+5,y+ch-4,cw-10,2,MPC_THEME_ACCENT);
 }
 ei_rule(&c,h-23);ei_text(&c,8,h-18,"ENC PAGE  K2 IND/FIX  IMPORT",w-16,MPC_THEME_MUTED);return 1;
}
