/* SPDX-License-Identifier: GPL-3.0-only
 * SPSC monitor FIFO into the stock USB gadget's final S32_LE write.
 * The master audio thread publishes. The USB playback thread consumes.
 */
#include "internal.h"
#include "usb_cue.h"
#define CUE_RING 16384u
#define CUE_MAX 4096u
#define CUE_PREFILL 512u

typedef struct {float left,right;} CueFrame;
typedef struct {unsigned read;float phase,signal,last_l,last_r;} CueCursor;
typedef struct {
 uintptr_t pcm;
 unsigned ready,supported;
} PcmIdentity;
static CueFrame ring[CUE_RING];
static unsigned write_index,read_index,enabled,generation,consumer_lock,overflow;
static unsigned consumer_generation,primed;
static CueCursor cursor,snapshots[CUE_MAX+1];
static int32_t converted[CUE_MAX*2];
static const int32_t silence[CUE_MAX*2];
static PcmIdentity identities[8];

static long (*write_original)(uintptr_t,const void*,unsigned long);
static int (*close_original)(uintptr_t);
static int (*pcm_info)(uintptr_t,void*);
static unsigned long (*info_size)(void);
static const char *(*info_id)(const void*);
static int (*params_current)(uintptr_t,void*);
static unsigned long (*params_size)(void);
static int (*params_format)(const void*,int*);
static int (*params_channels)(const void*,unsigned*);
static int (*params_rate)(const void*,unsigned*,int*);

unsigned pc_usb_cue_enabled(void){
 return __atomic_load_n(&enabled,AQ);
}
void pc_usb_cue_enable(unsigned active){
 active=!!active;
 if(__atomic_exchange_n(&enabled,active,RL)!=active)
  __atomic_add_fetch(&generation,1,RL);
}
void pc_usb_cue_publish(const float *left,const float *right,unsigned frames){
 if(!pc_usb_cue_enabled()||frames>CUE_MAX)return;
 unsigned write=__atomic_load_n(&write_index,RX);
 unsigned read=__atomic_load_n(&read_index,AQ);
 if(frames>CUE_RING-(write-read)){__atomic_store_n(&overflow,1,RL);return;}
 for(unsigned i=0;i<frames;i++)
  ring[(write+i)&(CUE_RING-1)]=(CueFrame){left[i],right[i]};
 __atomic_store_n(&write_index,write+frames,RL);
}
static int usb_identity(uintptr_t pcm){
 for(unsigned i=0;i<8;i++)
  if(__atomic_load_n(&identities[i].pcm,AQ)==pcm)
   return __atomic_load_n(&identities[i].ready,AQ)?identities[i].supported:0;
 for(unsigned i=0;i<8;i++){
  uintptr_t empty=0;
  if(!__atomic_compare_exchange_n(&identities[i].pcm,&empty,pcm,0,RL,RX))continue;
  _Alignas(16) unsigned char info[512],params[1024];
  memset(info,0,sizeof info);
  memset(params,0,sizeof params);
  unsigned channels=0,rate=0;
  int format=-1,direction=0,supported=0;
  if(info_size()<=sizeof info&&params_size()<=sizeof params&&!pcm_info(pcm,info)){
   const char *id=info_id(info);
   // This is the actual gadget PCM ID from the device's ALSA report.
   if(id&&!memcmp(id,"UAC2 PCM",9)&&!params_current(pcm,params)&&
      !params_format(params,&format)&&!params_channels(params,&channels)&&
      !params_rate(params,&rate,&direction))
    supported=format==10&&channels==2&&rate==44100; // ALSA S32_LE.
  }
  identities[i].supported=supported;
  __atomic_store_n(&identities[i].ready,1,RL);
  return supported;
 }
 return 0;
}
static int32_t pcm_sample(float value){
 if(!(value>=-1.f&&value<=1.f)){
  if(value>1)return 2147483647;
  if(value< -1)return (-2147483647-1);
  return 0;
 }
 if(value>=1)return 2147483647;
 return (int32_t)((double)value*2147483648.0);
}
long pc_usb_cue_write(uintptr_t pcm,const void *source,unsigned long frames){
 if(!write_original)return -19;
 if(frames>CUE_MAX||(!pc_usb_cue_enabled()&&!pc_sd_access_muted())||!usb_identity(pcm))
  return write_original(pcm,source,frames);
 if(pc_sd_access_muted()||__atomic_exchange_n(&consumer_lock,1,AQ))
  return write_original(pcm,silence,frames);
 unsigned epoch=__atomic_load_n(&generation,AQ);
 unsigned write=__atomic_load_n(&write_index,AQ);
 unsigned reset=consumer_generation!=epoch;
 if(__atomic_exchange_n(&overflow,0,AQ))reset=1;
 if(reset){
  cursor=(CueCursor){.read=write};
  primed=0;
  consumer_generation=epoch;
  __atomic_store_n(&read_index,write,RL);
 }
 unsigned queued=write-cursor.read;
 if(queued>4096){
  cursor.read=write-CUE_PREFILL;
  cursor.phase=0;
  cursor.signal=0;
  primed=0;
  queued=CUE_PREFILL;
 }
 if(!primed&&queued>=CUE_PREFILL)primed=1;
 float speed=1.f+((int)queued-(int)CUE_PREFILL)*(1.f/262144);
 if(speed<.999f)speed=.999f;
 if(speed>1.001f)speed=1.001f;
 CueCursor next=cursor;
 snapshots[0]=next;
 for(unsigned i=0;i<frames;i++){
  float left=0,right=0;
  unsigned available=write-next.read;
  if(primed&&available>=2){
   CueFrame a=ring[next.read&(CUE_RING-1)],b=ring[(next.read+1)&(CUE_RING-1)];
   left=a.left+(b.left-a.left)*next.phase;
   right=a.right+(b.right-a.right)*next.phase;
   next.last_l=left;next.last_r=right;
   next.signal+=1.f/132;if(next.signal>1)next.signal=1;
   next.phase+=speed;
   unsigned consumed=(unsigned)next.phase;
   if(consumed>available-1)consumed=available-1;
   next.read+=consumed;next.phase-=consumed;
   if(next.phase>=1)next.phase=0;
  }else{
   next.signal-=1.f/132;if(next.signal<0)next.signal=0;
   left=next.last_l;right=next.last_r;
  }
  converted[i*2]=pcm_sample(left*next.signal);
  converted[i*2+1]=pcm_sample(right*next.signal);
  snapshots[i+1]=next;
 }
 long result=write_original(pcm,converted,frames);
 if(result>0){
  unsigned committed=(unsigned long)result>frames?frames:(unsigned)result;
  cursor=snapshots[committed];
  __atomic_store_n(&read_index,cursor.read,RL);
 }
 __atomic_store_n(&consumer_lock,0,RL);
 return result;
}
static int usb_close(uintptr_t pcm){
 int result=close_original(pcm);
 if(!result)for(unsigned i=0;i<8;i++){
  if(__atomic_load_n(&identities[i].pcm,AQ)!=pcm)continue;
  __atomic_store_n(&identities[i].ready,0,RL);
  __atomic_store_n(&identities[i].pcm,0,RL);
 }
 return result;
}
void pc_usb_cue_init(unsigned page_size){
 void*(*symbol)(void*,const char*)=FN(0xb51898,void*(*)(void*,const char*));
 pcm_info=symbol(0,"snd_pcm_info");
 info_size=symbol(0,"snd_pcm_info_sizeof");
 info_id=symbol(0,"snd_pcm_info_get_id");
 params_current=symbol(0,"snd_pcm_hw_params_current");
 params_size=symbol(0,"snd_pcm_hw_params_sizeof");
 params_format=symbol(0,"snd_pcm_hw_params_get_format");
 params_channels=symbol(0,"snd_pcm_hw_params_get_channels");
 params_rate=symbol(0,"snd_pcm_hw_params_get_rate");
 void *native_write=symbol(0,"snd_pcm_writei");
 void *native_close=symbol(0,"snd_pcm_close");
 if(!pcm_info||!info_size||!info_id||!params_current||!params_size||
    !params_format||!params_channels||!params_rate||!native_write||!native_close)return;
 uintptr_t slot=host.base+0x716e298u;
 uintptr_t close_slot=host.base+0x716e1e8u;
 if(Q(slot,0)!=(uintptr_t)native_write||Q(close_slot,0)!=(uintptr_t)native_close)return;
 uintptr_t page=slot&~((uintptr_t)page_size-1);
 if(pc_sys(226,page,page_size,3,0,0,0))return;
 write_original=(long(*)(uintptr_t,const void*,unsigned long))native_write;
 close_original=(int(*)(uintptr_t))native_close;
 __atomic_store_n((uintptr_t*)close_slot,(uintptr_t)usb_close,RL);
 __atomic_store_n((uintptr_t*)slot,(uintptr_t)pc_usb_cue_write,RL);
 pc_sys(226,page,page_size,1,0,0,0);
}
