/* SPDX-License-Identifier: GPL-3.0-only
 * The pinned legacy FM library supplies the original preset catalog and
 * editor only. DX7 VMEM is snapshotted in the existing CRC-protected patch
 * for the independent FM6 renderer, keeping old files and IDs readable.
 */
#include "internal.h"
#include "syx.h"
static unsigned get(const uint8_t*p){unsigned x;memcpy(&x,p,4);return x;}
static void put(uint8_t*p,unsigned v){memcpy(p,&v,4);}
static uintptr_t dx_base(Dsp*d){
 static const uint8_t sig[16]={0xc0,0x0a,0x00,0xb4,0xfd,0x7b,0xb0,0xa9,0xc1,0x08,0x00,0xf0,0x02,0x01,0x80,0xd2};
 uintptr_t fn=(uintptr_t)d->load;if(!fn||memcmp((void*)fn,sig,16))return 0;
 uintptr_t base=fn-0x52088;if(memcmp((void*)base,"\177ELF",4))return 0;return base;
}
int pc_syx_embedded(const uint8_t*p){return !memcmp(p,"MPCEXT01",8)&&get(p+8)==4&&!memcmp(p+20,"DX7RAW01",8);}
int pc_backend_load(Dsp*d,const uint8_t*p){
 int custom=pc_syx_embedded(p);uintptr_t base=custom?dx_base(d):0;
 if(custom){uint8_t v[156];pc_dx7_unpack(p+64,v);if(!base||get(p+508)!=pc_syx_crc(p,508)||!pc_dx7_valid(v))return 0;}
 if(!d->load(p))return 0;
 if(custom){uint8_t v[156];pc_dx7_unpack(p+64,v);memcpy((void*)(base+0x254878),v,156);((void(*)(uintptr_t,const uint8_t*))(base+0x588b0))(base+0x254918,v+137);}
 return 1;
}
int pc_backend_save(Dsp*d,uint8_t*p){
 if(!d->save(p))return 0;
 if(!memcmp(p,"MPCEXT01",8)&&get(p+8)==4){
  uintptr_t base=dx_base(d);if(!base)return 0;
  const uint8_t *voice=(const uint8_t*)(base+0x254878);
  if(!pc_dx7_valid(voice))return 0;
  pc_dx7_pack(voice,p+64);memcpy(p+20,"DX7RAW01",8);put(p+508,pc_syx_crc(p,508));
 }
 return 1;
}
int pc_backend_panel_load(Dsp*d,unsigned e,unsigned preset,const uint8_t*p){
 if(pc_syx_embedded(p)){uint8_t v[156];pc_dx7_unpack(p+64,v);if(!dx_base(d)||get(p+508)!=pc_syx_crc(p,508)||!pc_dx7_valid(v))return 0;}
 if(!d->panel_load(e,preset,p))return 0;return !pc_syx_embedded(p)||pc_backend_load(d,p);
}
int pc_syx_make_patch(const PcSyxVoice*v,uint8_t*p){
 if(!v||!p||(v->engine!=4&&v->engine!=7&&v->engine!=9))return 0;memset(p,0,512);
 if(v->engine==4){if(v->size!=128)return 0;memcpy(p,"MPCEXT01",8);put(p+8,4);put(p+16,3);memcpy(p+20,"DX7RAW01",8);float cutoff=20000;memcpy(p+36,&cutoff,4);memcpy(p+64,v->raw,128);}
 else if(v->engine==9){if(v->size!=102)return 0;memcpy(p,"MPCNEW01",8);put(p+8,9);put(p+16,44100);put(p+20,102);memcpy(p+32,v->raw,102);}
 else{if(v->size!=144)return 0;memcpy(p,"MPCNEW01",8);put(p+8,7);put(p+16,44100);put(p+20,146);memcpy(p+32,v->raw,144);p[176]=100;p[177]=64;}
 put(p+508,pc_syx_crc(p,508));return 1;
}
int pc_syx_patch_name(const uint8_t*p,char*out,unsigned cap){
 const uint8_t*name=0;unsigned n=0;
 if(pc_syx_embedded(p)){name=p+64+118;n=10;}
 else if(!memcmp(p,"MPCNEW01",8)&&get(p+8)==7){name=p+32+128;n=16;}
 else if(!memcmp(p,"MPCNEW01",8)&&get(p+8)==9){name=p+32+78;n=23;}
 if(!name||!cap)return 0;if(!pc_syx_embedded(p)){while(n&&*name==' '){name++;n--;}}if(n>=cap)n=cap-1;
 for(unsigned i=0;i<n;i++)out[i]=name[i]>=32&&name[i]<127?name[i]:' ';while(n&&out[n-1]==' ')n--;out[n]=0;return n!=0;
}
