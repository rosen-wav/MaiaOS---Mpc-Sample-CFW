/* SPDX-License-Identifier: GPL-3.0-only. Display metadata only: no DSP access. */
#include "../theme/layout.h"
static int editorial_panel(Canvas*c,MpcPanelView*v,Slot*s){
 EiCanvas e={c,glyph_rect,c->width,c->height};unsigned number=host.ui.source%16+1;char pad[8]={'P','A','D',' ',(char)('A'+host.ui.source/16),(char)('0'+number/10),(char)('0'+number%10),0};
 if(v->browser&&__atomic_load_n(&factory_browser,AQ)!=s->instrument)pc_preset_refresh_hidden(s->engine);
 factory_normalize(s,v);
 __atomic_store_n(&factory_browser,v->browser?s->instrument:0,RL);
 if(factory_confirming(s,v)){pc_delete_paint(&e,v->preset,factory_delete.choice);return 1;}
 ei_header(&e,v->browser?"SYNTH / PRESETS":"SYNTH",pad);
 if(v->browser){
  ei_heading(&e,8,29,"presets.",e.w-16);
  unsigned rows=e.h>100?(e.h-110)/18:1;if(!rows)rows=1;
  int first=(int)v->preset_index;
  for(unsigned row=1;row<rows;row++){
   int previous=preset_step(s->engine,v->preset_count,first,-1);
   if(previous<0)break;
   first=previous;
  }
  if(pc_preset_hidden(s->engine,(unsigned)first))first=preset_step(s->engine,v->preset_count,first,1);
  for(unsigned row=0;row<rows&&first>=0&&(unsigned)first<v->preset_count;row++){
   unsigned n=(unsigned)first;int y=65+row*18;
   if(n==v->preset_index)ei_selection(&e,y,17);
   ei_text(&e,15,y+2,host.mirror.name(s->engine,n),e.w-30,MPC_THEME_TEXT);
   first=preset_step(s->engine,v->preset_count,first,1);
  }
  ei_actions(&e,"PREV","USERS","BACK");ei_notice(&e,v->confirm_replace?"Press encoder again to replace":"ENC load / ERASE+ENC delete");
 }else{
  const char*titles[]={"profet.","cloud.","kr-106.","the synth.","fm6.","tunefish.","sample.","cz-1.","cs-1.","rs-01."};
  ei_heading(&e,8,30,s->engine<10?titles[s->engine]:v->engine,e.w-70);
  char imported[25];const char*preset_name=pc_syx_patch_name(s->patch,imported,sizeof imported)?imported:v->preset;ei_text(&e,8,64,preset_name,e.w-16,MPC_THEME_TEXT);
  if(e.h>=190)ei_text(&e,8,84,v->page,e.w-16,MPC_THEME_MUTED);
  int label_y=e.h>=190?110:80,value_y=label_y+17,bar_y=e.h>=190?e.h-60:e.h-29;
  unsigned value_height=e.h>=190?28:18;
  int sc=sidechain_knob(v),out=output_page(v);
  for(unsigned k=0;k<3;k++){
   MpcPanelSlot *p=&v->slots[k];int x=8+k*e.w/3,width=e.w/3-16;char label[32]={'K',(char)('1'+k),' ',0},value[32];const char*val=p->value;const char*unit=p->unit;unsigned n=0;while(n<23&&p->label[n]){label[3+n]=p->label[n];n++;}label[3+n]=0;
   int range=p->maximum-p->minimum;unsigned position=range>0?(unsigned)(((int64_t)p->current-p->minimum)*16383/range):0;
   if(out&&k==0){memcpy(label,"K1 VOLUME",10);volume_text(value,pc_mix_volume(s->instrument));val=value;unit="";position=pc_mix_volume_position(s->instrument);}
   else if((int)k==sc){memcpy(label,"K1 SIDECHAIN",13);label[1]='1'+k;unsigned role=pc_sc_role(s->instrument);val=role==1?"SEND":role==2?"RECEIVE":"OFF";unit="";position=role*8191;}
   else if(p->index<0)continue;
   if(k)ei_rect(&e,k*e.w/3,label_y-3,1,bar_y-label_y+7,MPC_THEME_GRID);
   ei_text(&e,x,label_y,label,width,MPC_THEME_MUTED);
   ei_value(&e,x,value_y,val,width,value_height,MPC_THEME_TEXT);
   if(unit&&unit[0])ei_text(&e,x,value_y+value_height+3,unit,width,MPC_THEME_MUTED);
   ei_bar(&e,x,bar_y,width,position);
   if(p->takeover)ei_rect(&e,x,bar_y+6,2,2,MPC_THEME_MUTED);
  }
  ei_actions(&e,"PRESET -","PRESET +",s->engine==4||s->engine==7||s->engine==9?"IMPORT":"PRESETS");
 }
 ei_notice(&e,host.ui.message?host.ui.message:pc_synth_filter_page(v)&&pc_synth_fader_default(s->instrument)?"FADER: CUTOFF":"");return 1;
}
