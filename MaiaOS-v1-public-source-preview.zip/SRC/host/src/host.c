/* SPDX-License-Identifier: GPL-3.0-only
 * Audio owns every live DSP. UI and XML workers never call them. Commands
 * cross bounded queues; one independent mirror DSP serves the editor.
 */
#include "internal.h"
#include "synth_filter.h"
#include "sample_playback.h"
Host host;
_Static_assert(offsetof(PcApi,pad_enter)==0xc8,"performance gate API ABI");
void pc_error(unsigned e){__atomic_store_n(&host.debug->error,e,RX);}
static uintptr_t metadata_thread;
int pc_meta(void){if(__atomic_exchange_n(&host.metadata,1,AQ))return 0;__atomic_store_n(&metadata_thread,pc_sys(178,0,0,0,0,0,0),RL);return 1;}
int pc_meta_owned(void){return __atomic_load_n(&metadata_thread,AQ)==(uintptr_t)pc_sys(178,0,0,0,0,0,0);}
void pc_unmeta(void){__atomic_store_n(&metadata_thread,0,RL);__atomic_store_n(&host.metadata,0,RL);}
static void process_events(Slot *s);
static void discard_late_releases(Slot *s);
static void forget(Slot *,Held *);
static unsigned physical_slots[128];
#define NATIVE_SOURCES 256u
static unsigned held_limit(const Slot *s){
 return (pc_context_engine(s->audio_engine)||s->audio_engine==4)?sizeof s->held/sizeof s->held[0]:64;
}
static void count(uint64_t *v){__atomic_fetch_add(v,1,RX);}
static int lock(Slot *s){if(!__atomic_exchange_n(&s->busy,1,AQ))return 1;count(&host.debug->contention);return 0;}
static void unlock(Slot *s){__atomic_store_n(&s->busy,0,RL);}
static void dsp_off(Slot*s,unsigned note){
 if(s->audio_engine==4)pc_fm6_off((unsigned)(s-host.slots),note);
 else pc_slot_dsp(s)->off(note);
}
static void all_off(Slot *s){
 if(s->held_keys)s->splice.transition=1;
 if(pc_context_engine(s->audio_engine))pc_ms_stop(s->multisample);
 else for(unsigned n=0;n<128;n++)if(s->refs[n])dsp_off(s,n);
 memset(s->held,0,sizeof s->held);
 memset(s->refs,0,sizeof s->refs);
 s->held_keys=0;s->filter_lock=0;s->filter_serial=0;s->filter_owner=0;
 for(unsigned n=0;n<8;n++)__atomic_store_n(&s->native_sources[n],0,RL);
 pc_poly_sync(s);
}
static void held_debug(Slot *s){unsigned k=(unsigned)(s-host.slots),keys=s->held_keys;unsigned voices=pc_context_engine(s->audio_engine)?pc_ms_voices(s->multisample):s->audio_engine==4?keys:pc_slot_dsp(s)->held();__atomic_store_n(&host.debug->held[k],keys<voices?keys:voices,RL);}
int pc_find(uintptr_t instrument){if(!host.ready||!instrument)return -1;for(unsigned k=0;k<PC_SLOTS;k++)if(__atomic_load_n(&host.slots[k].instrument,AQ)==instrument)return (int)k;return -1;}
int pc_valid(uintptr_t program,uintptr_t instrument){
 if(!program||!instrument||Q(program,0)!=host.base+0x6ec6860||I(program,0x1234)!=0||Q(instrument,0)!=host.base+0x6ec3ca0||Q(instrument,0x2310)!=program)return 0;
 uintptr_t r=Q(instrument,0x638);return r&&F(r,0x50)==44100;
}
int pc_room(Slot *s){return __atomic_load_n(&s->write,RX)-__atomic_load_n(&s->read,AQ)<QUEUE;}
void pc_push(Slot *s,const Command *c){unsigned w=__atomic_load_n(&s->write,RX);s->queue[w%QUEUE]=*c;__atomic_store_n(&s->write,w+1,RL);}
/* Metadata ownership serializes UI and project-reader producers. Audio is the
 * sole queue consumer and never waits for metadata or accesses its mirror. */
static void drain(Slot *s){
 if(__atomic_exchange_n(&s->panic,0,AQ)){all_off(s);count(&host.debug->panics);}
 unsigned r=__atomic_load_n(&s->read,RX),w=__atomic_load_n(&s->write,AQ);
 for(unsigned n=0;r!=w&&n<QUEUE;n++,r++){
  Command *c=&s->queue[r%QUEUE];
  if(c->kind==1){all_off(s);s->splice.transition=1;discard_late_releases(s);if(s->multisample){pc_ms_retire(s,s->multisample);s->multisample=0;}s->audio_engine=c->index;s->poly_mode_valid=0;s->sequence_protected=0;memset(&s->stock_filter,0,sizeof s->stock_filter);if(pc_context_engine(c->index))s->multisample=c->context;else if(c->index==4){if(!pc_fm6_load((unsigned)(s-host.slots),c->patch,0))pc_error(41);}else if(!pc_backend_load(pc_slot_dsp(s),c->patch))pc_error(41);s->audio_generation=c->reserved;}
  else if(c->kind==2){if(pc_context_engine(s->audio_engine)){pc_ms_set(s->multisample,c->index,(uint32_t)c->value);}else {if(!pc_slot_dsp(s)->set(c->index,c->value))pc_error(42);if(s->audio_engine<3)s->poly_mode_valid=0;}}
  else if(c->kind==3)all_off(s);
  else if(c->kind==4&&s->audio_engine==4&&s->audio_generation==c->reserved){if(!pc_fm6_load((unsigned)(s-host.slots),c->patch,1))pc_error(42);}
 }
 __atomic_store_n(&s->read,r,RL);
 /* Independent latest-value mailboxes cannot fill while audio is idle. */
 for(unsigned group=0;group<4;group++){
  unsigned pending=__atomic_exchange_n(&s->pending[group],0,AQ);
  for(unsigned bit=0;bit<32;bit++)if(pending&(1u<<bit)){
   unsigned index=group*32+bit;
   uint64_t update=__atomic_load_n(&s->values[index],AQ);
   if((unsigned)(update>>32)==s->audio_generation){if(pc_context_engine(s->audio_engine)){pc_ms_set(s->multisample,index,(uint32_t)update);}else {if(!pc_slot_dsp(s)->set(index,(int32_t)update))pc_error(42);if(s->audio_engine<3)s->poly_mode_valid=0;}}
   else if((int32_t)((unsigned)(update>>32)-s->audio_generation)>0)__atomic_fetch_or(&s->pending[group],1u<<bit,RL);
  }
 }
 if(__atomic_load_n(&s->event_read,RX)!=__atomic_load_n(&s->event_write,AQ))pc_poly_sync(s);process_events(s);held_debug(s);
}
int pc_assign(uintptr_t p,uintptr_t instrument,unsigned engine,unsigned preset,const uint8_t *patch){
 if(engine==PC_MS_ENGINE)return pc_ms_assign(p,instrument,patch);
 if((engine==3||engine==5||engine==6||engine>9)||!pc_valid(p,instrument)||preset>=pc_engine_count(engine)){pc_error(10);return 0;}
 int k=pc_find(instrument);
 if(k<0)for(unsigned n=0;n<PC_SLOTS;n++)if(!__atomic_load_n(&host.slots[n].instrument,AQ)){k=(int)n;break;}
 if(k<0){pc_error(40);return 0;}Slot *s=&host.slots[k];
 unsigned free=!__atomic_load_n(&s->instrument,AQ);
 if(free){
  if(__atomic_exchange_n(&s->busy,1,AQ)){pc_error(43);return 0;}
  pc_ms_dispose_locked(s);
  memset(&s->splice,0,sizeof s->splice);
  __atomic_store_n(&s->read,__atomic_load_n(&s->write,AQ),RL);
  __atomic_store_n(&s->panic,1,RL);s->output_gain=pc_mix_gain(instrument);__atomic_store_n(&host.debug->held[k],0,RL);unlock(s);
 }
 pc_ms_reap(s);
 if(!pc_room(s)||__atomic_load_n(&s->retire_write,AQ)-__atomic_load_n(&s->retire_read,AQ)+__atomic_load_n(&s->write,AQ)-__atomic_load_n(&s->read,AQ)>=31||(!free&&(__atomic_load_n(&s->pending_on,AQ)||__atomic_load_n(&host.debug->held[k],AQ)))){pc_error(43);return 0;}
 if(!pc_mirror_use(engine)){pc_error(44);return 0;}
 if(patch){if(!pc_backend_panel_load(&host.mirror,engine,preset,patch)){pc_error(44);return 0;}}
 else if(!host.mirror.panel_init(engine,preset)){pc_error(44);return 0;}
 if(engine!=4&&!pc_engine_dsp(s,engine)->prepare(engine)){pc_error(45);return 0;}
 for(unsigned g=0;g<4;g++)__atomic_store_n(&s->pending[g],0,RL);
 Command c={.kind=1,.index=engine,.reserved=__atomic_load_n(&s->generation,RX)+1};if(!pc_backend_save(&host.mirror,c.patch))return 0;
 pc_push(s,&c);__atomic_store_n(&s->generation,c.reserved,RL);s->engine=engine;s->preset=preset;memcpy(s->patch,c.patch,512);
 __atomic_store_n(&s->program,p,RL);__atomic_store_n(&s->instrument,instrument,RL);
 if(free)pc_synth_fader_reset(instrument);
 host.ui.loaded_slot=(unsigned)k;__atomic_store_n(&host.ui.loaded_valid,1,RL);pc_mix_route_program(p);pc_error(0);
 unsigned total=0;for(unsigned n=0;n<PC_SLOTS;n++)total+=!!__atomic_load_n(&host.slots[n].instrument,AQ);
 __atomic_store_n(&host.debug->assigned,total,RX);pc_light_refresh();return 1;
}
int pc_ms_assign(uintptr_t program,uintptr_t instrument,const uint8_t *patch){
 if(!pc_valid(program,instrument)||!patch||!patch[24]||patch[55])return 0;
 int k=pc_find(instrument);
 if(k<0)for(unsigned n=0;n<PC_SLOTS;n++)
  if(!__atomic_load_n(&host.slots[n].instrument,AQ)){k=(int)n;break;}
 if(k<0)return 0;
 uintptr_t ctx=pc_ms_load(patch);
 if(!ctx)return 0;
 Slot*s=&host.slots[k];
 if(!lock(s)){pc_ms_free(ctx);return 0;}
 int occupied=__atomic_load_n(&s->instrument,AQ)!=0;
 if(occupied&&(__atomic_load_n(&s->pending_on,AQ)||s->held_keys)){
  unlock(s);pc_ms_free(ctx);return 0;
 }
 pc_ms_reap(s);
 if(occupied&&(!pc_room(s)||__atomic_load_n(&s->retire_write,AQ)-__atomic_load_n(&s->retire_read,AQ)+
    __atomic_load_n(&s->write,AQ)-__atomic_load_n(&s->read,AQ)>=31)){
  unlock(s);pc_ms_free(ctx);return 0;
 }
 if(!occupied){
  pc_ms_dispose_locked(s);memset(&s->splice,0,sizeof s->splice);
  s->output_gain=pc_mix_gain(instrument);__atomic_store_n(&s->panic,1,RL);
 }
 for(unsigned n=0;n<4;n++)__atomic_store_n(&s->pending[n],0,RL);
 Command c={.kind=1,.index=PC_MS_ENGINE,.reserved=__atomic_load_n(&s->generation,RX)+1,.context=ctx};
 memcpy(c.patch,patch,sizeof c.patch);pc_push(s,&c);
 s->engine=PC_MS_ENGINE;s->preset=0;memcpy(s->patch,patch,sizeof s->patch);
 __atomic_store_n(&s->generation,c.reserved,RL);
 __atomic_store_n(&s->program,program,RL);__atomic_store_n(&s->instrument,instrument,RL);
 unlock(s);
 if(!occupied){pc_synth_fader_reset(instrument);__atomic_fetch_add(&host.debug->assigned,1,RL);}
 __atomic_store_n(&host.ui.loaded_valid,0,RL);
 pc_mix_route_program(program);pc_light_refresh();return 1;
}
static int detach_multisample(Slot *s,int clear_pad){
 unsigned k=(unsigned)(s-host.slots);
 uintptr_t instrument=__atomic_load_n(&s->instrument,AQ),expected=instrument;
 if(!instrument||s->engine!=PC_MS_ENGINE||
    !__atomic_compare_exchange_n(&s->instrument,&expected,0,0,__ATOMIC_ACQ_REL,AQ))return 0;
 __atomic_add_fetch(&s->generation,1,RL);
 __atomic_store_n(&s->program,0,RL);
 __atomic_store_n(&s->panic,1,RL);
 pc_poly_forget(s);
 for(unsigned n=0;n<128;n++)__atomic_fetch_and(&physical_slots[n],~(1u<<k),RL);
 __atomic_store_n(&host.debug->held[k],0,RL);
 __atomic_fetch_sub(&host.debug->assigned,1,RX);
 __atomic_store_n(&host.ui.loaded_valid,0,RL);
 if(clear_pad){pc_sc_forget(instrument,0);pc_mix_forget(instrument,0);}
 return 1;
}
void pc_ms_unassign_preset(const char *id){
 int changed=0;
 for(unsigned k=0;k<PC_SLOTS;k++){
  Slot *s=&host.slots[k];
  if(__atomic_load_n(&s->instrument,AQ)&&s->engine==PC_MS_ENGINE&&
     !memcmp(s->patch,"MPCMUL01",8)&&!memcmp(s->patch+8,id,PC_MS_ID))
   changed|=detach_multisample(s,0);
 }
 if(changed){pc_ms_collect();pc_light_refresh();}
}
void pc_ms_clear_queued(unsigned data){
 unsigned k=data&255;
 if(k>=PC_SLOTS)return;
 Slot *s=&host.slots[k];
 if((__atomic_load_n(&s->generation,AQ)&0xffffff)==data>>8&&detach_multisample(s,1)){
  pc_ms_collect();pc_light_refresh();
 }
}
void pc_ms_clear_native_pad(uintptr_t instrument){
 int k=pc_find(instrument);
 if(k<0||host.slots[k].engine!=PC_MS_ENGINE)return;
 unsigned generation=__atomic_load_n(&host.slots[k].generation,AQ);
 unsigned data=(generation<<8)|(unsigned)k;
 int owned=pc_meta_owned();
 if(owned||pc_meta()){
  pc_ms_clear_queued(data);
  if(!owned)pc_unmeta();
 }else FN(0x6d43500,void(*)(uint64_t))(((uint64_t)data<<32)|(63u<<1)|1u);
}
int pc_remove(uintptr_t instrument){
 int k=pc_find(instrument);if(k<0)return 1;Slot *s=&host.slots[k];
 if(s->engine==PC_MS_ENGINE){detach_multisample(s,0);pc_ms_collect();pc_light_refresh();return 1;}
 if(!pc_room(s)||__atomic_load_n(&s->pending_on,AQ)||__atomic_load_n(&host.debug->held[k],AQ)){pc_error(43);return 0;}
 Command c={.kind=3};pc_push(s,&c);__atomic_store_n(&s->panic,1,RL);
 __atomic_store_n(&s->instrument,0,RL);pc_poly_forget(s);__atomic_store_n(&s->program,0,RL);
 __atomic_store_n(&host.ui.loaded_valid,0,RL);__atomic_fetch_sub(&host.debug->assigned,1,RX);pc_error(0);pc_light_refresh();return 1;
}
static void forget(Slot *s,Held *h){
 if(!h->used)return;
 unsigned note=h->note,source=h->source;
 h->used=0;
 if(h->serial==s->filter_owner){
  const Held*latest=0;
  for(unsigned n=0;n<held_limit(s);n++){
   const Held*other=&s->held[n];
   if(other->used&&(!latest||(int)(other->serial-latest->serial)>0))latest=other;
  }
  if(latest){s->filter_owner=latest->serial;s->filter_lock=latest->filter;}
 }
 if(source<NATIVE_SOURCES){
  unsigned still_owned=0;
  for(unsigned n=0;n<held_limit(s);n++)if(s->held[n].used&&s->held[n].source==source){still_owned=1;break;}
  if(!still_owned)__atomic_fetch_and(&s->native_sources[source/32],~(1u<<(source%32)),RL);
 }
 if(pc_context_engine(s->audio_engine))pc_ms_off(s->multisample,h->voice_owner);
 if(s->refs[note]&&!--s->refs[note]){
  s->held_keys--;
  if(s->audio_engine!=PC_MS_ENGINE&&s->audio_engine!=4)s->splice.transition=1;
  if(!pc_context_engine(s->audio_engine))dsp_off(s,note);
  pc_poly_sync(s);
 }
}
static void release_event(Slot *s,unsigned kind,unsigned source,unsigned channel){
 for(unsigned n=0;n<held_limit(s);n++){
  Held *h=&s->held[n];
  if(!h->used)continue;
  if(kind==3){
   if(h->source<(pc_context_engine(s->audio_engine)?NATIVE_SOURCES:128u)&&(channel>=16||h->channel==channel))forget(s,h);
  }else if(h->source==source&&(kind==4||h->channel==channel))forget(s,h);
 }
}
static void discard_late_releases(Slot *s){
 if(!__atomic_exchange_n(&s->release_pending,0,__ATOMIC_ACQ_REL))return;
 __atomic_store_n(&s->late_stop,0,RL);
 for(unsigned ch=0;ch<17;ch++)for(unsigned group=0;group<8;group++)
  __atomic_store_n(&s->late_off[ch][group],0,RL);
}
void pc_discard_pad_notes(Slot *s){
 /* Leave an in-flight producer's unpublished reservation intact. Its
  * generation cannot match the assignment subsequently published here. */
 unsigned pos=__atomic_load_n(&s->event_read,RX);
 for(unsigned n=0;n<NOTE_QUEUE;n++){
  NoteEvent *e=&s->events[pos&(NOTE_QUEUE-1)];
  if(__atomic_load_n(&e->sequence,AQ)!=pos+1)break;
  if(e->kind==1)__atomic_fetch_sub(&s->pending_on,1,RL);
  __atomic_store_n(&e->sequence,pos+NOTE_QUEUE,RL);
  __atomic_store_n(&s->event_read,++pos,RL);
 }
 discard_late_releases(s);
 if(s->held_keys)all_off(s);
 else{
  memset(s->held,0,sizeof s->held);memset(s->refs,0,sizeof s->refs);
  for(unsigned n=0;n<8;n++)__atomic_store_n(&s->native_sources[n],0,RL);
 }
 s->filter_lock=s->filter_serial=s->filter_owner=s->native_muted=0;
 s->sequence_protected=s->poly_mode_valid=0;
 memset(&s->stock_filter,0,sizeof s->stock_filter);
}
static void late_release(Slot *s,unsigned kind,unsigned source,unsigned channel){
 if(kind==3)__atomic_fetch_or(&s->late_stop,channel<16?1u<<channel:0xffffu,RL);
 else {
  unsigned key=kind==4?source&127u:source&255u;
  __atomic_fetch_or(&s->late_off[kind==4?16:channel][key/32],1u<<(key%32),RL);
 }
 __atomic_store_n(&s->release_pending,1,RL);
}
/* Keep space for key-ups and keep an ownership-specific fallback. */
static int event_push_generation(Slot *s,unsigned generation,unsigned kind,unsigned source,unsigned channel,unsigned pitch,unsigned velocity,unsigned filter){
 if(generation!=__atomic_load_n(&s->generation,AQ))return 0;
 if(kind==1)__atomic_fetch_add(&s->pending_on,1,RL);
 unsigned pos=__atomic_load_n(&s->event_write,RX);
 for(unsigned attempt=0;attempt<32;attempt++){
  if(kind==1&&(__atomic_load_n(&s->release_pending,AQ)||
              pos-__atomic_load_n(&s->event_read,AQ)>=NOTE_QUEUE-128))break;
  NoteEvent *e=&s->events[pos&(NOTE_QUEUE-1)];
  unsigned sequence=__atomic_load_n(&e->sequence,AQ);int diff=(int)(sequence-pos);
  if(diff==0){
   if(!__atomic_compare_exchange_n(&s->event_write,&pos,pos+1,0,RX,RX))continue;
   e->kind=kind;e->generation=generation;
   e->source=source;e->channel=channel;e->pitch=pitch;e->velocity=velocity;e->filter=filter;
   __atomic_store_n(&e->sequence,pos+1,RL);return 1;
  }
  if(diff<0)break;
  pos=__atomic_load_n(&s->event_write,RX);
 }
 if(kind==1)__atomic_fetch_sub(&s->pending_on,1,RL);
 else if(generation==__atomic_load_n(&s->generation,AQ))late_release(s,kind,source,channel);
 pc_error(79);count(&host.debug->contention);return 0;
}
static int event_push(Slot *s,unsigned kind,unsigned source,unsigned channel,unsigned pitch,unsigned velocity,unsigned filter){
 return event_push_generation(s,__atomic_load_n(&s->generation,AQ),kind,source,channel,pitch,velocity,filter);
}
static void attack(Slot *s,const NoteEvent *e){
 uintptr_t instrument=__atomic_load_n(&s->instrument,AQ);
 if(!instrument||(__atomic_load_n((uint8_t*)(instrument+0x78),AQ)&1))return;
 Held *empty=0;
 for(unsigned n=0;n<held_limit(s);n++){
  Held *h=&s->held[n];
  if(!h->used){if(!empty)empty=h;continue;}
  if(h->source==e->source&&h->channel==e->channel&&h->note==e->pitch){
   if(e->filter){h->filter=e->filter;h->serial=++s->filter_serial;s->filter_owner=h->serial;s->filter_lock=h->filter;}
   return;
  }
 }
 if(!empty){pc_poly_reject();return;}
 /* Synths share a pitch gate. Multisamples need one independently
  * releasable voice per owner, including pitches shared by chords. */
 unsigned sounding=s->refs[e->pitch],multisample=pc_context_engine(s->audio_engine);
 if((multisample||!sounding)&&(pc_cpu_overloaded()||!pc_poly_reserve(s)))return;
 unsigned serial=++s->filter_serial;
 if(multisample&&!pc_ms_on(s->multisample,e->pitch,e->velocity,serial)){pc_poly_reject();return;}
 if(s->audio_engine==4&&!sounding&&!pc_fm6_on((unsigned)(s-host.slots),e->pitch,e->velocity)){pc_poly_reject();return;}
 if(e->source<128)s->sequence_protected=1;
 *empty=(Held){.source=e->source,.channel=e->channel,.note=e->pitch,.used=1,
               .filter=e->filter,.serial=serial,.voice_owner=serial};
 s->filter_owner=empty->serial;s->filter_lock=empty->filter;
 if(!s->refs[e->pitch]++)s->held_keys++;
 if(e->source<NATIVE_SOURCES)__atomic_fetch_or(&s->native_sources[e->source/32],1u<<(e->source%32),RL);
 if(!multisample){
  if(sounding)return;
  if(s->audio_engine!=4){s->splice.transition=1;pc_dsp_attack(s,e->pitch,e->velocity);}
 }
 pc_poly_sync(s);count(&host.debug->notes);
}
static void process_events(Slot *s){
 unsigned pos=__atomic_load_n(&s->event_read,RX);
 for(unsigned j=0;j<NOTE_QUEUE;j++){
  NoteEvent *e=&s->events[pos&(NOTE_QUEUE-1)];
  if(__atomic_load_n(&e->sequence,AQ)!=pos+1)break;
  if(e->generation==s->audio_generation){
   if(e->kind==1)attack(s,e);
   else {release_event(s,e->kind,e->source,e->channel);count(&host.debug->offs);}
  }
  if(e->kind==1){held_debug(s);__atomic_fetch_sub(&s->pending_on,1,RL);}
  __atomic_store_n(&e->sequence,pos+NOTE_QUEUE,RL);
  __atomic_store_n(&s->event_read,++pos,RL);
 }
 if(pos!=__atomic_load_n(&s->event_write,AQ)||!__atomic_load_n(&s->release_pending,AQ))return;
 __atomic_store_n(&s->release_pending,0,RL);
 unsigned stops=__atomic_exchange_n(&s->late_stop,0,__ATOMIC_ACQ_REL);
 for(unsigned ch=0;ch<17;ch++){
  if(ch<16&&(stops&(1u<<ch)))release_event(s,3,0,ch);
  for(unsigned group=0;group<(ch==16?4u:8u);group++){
   unsigned mask=__atomic_exchange_n(&s->late_off[ch][group],0,__ATOMIC_ACQ_REL);
   while(mask){
    unsigned key=group*32+(unsigned)__builtin_ctz(mask);mask&=mask-1;
    release_event(s,ch==16?4:2,ch==16?key+NATIVE_SOURCES:key,ch);
   }
  }
 }
}
/* Scope only the outer physical pad callback. Tune's internal on/off
 * arguments are different identities and must not be paired. A physical up
 * also queues a release directly: a consumed native on need not populate the
 * native router's off bookkeeping. Audio remains the sole owner of refs. */
static __thread unsigned pad_owner,pad_dispatch;
static __thread uintptr_t live_forwarded;
int pc_physical_pad_dispatch(void){return pad_dispatch!=0;}
/* Producers record only which slots may own this physical key. A release
 * targets those slots once, rather than filling dormant engines' queues. The
 * audio thread never clears this map: pending attacks must retain ownership. */
static void release_physical(unsigned source){
 if(source>=128)return;
 unsigned mask=__atomic_exchange_n(&physical_slots[source],0,__ATOMIC_ACQ_REL);
 for(unsigned k=0;k<PC_SLOTS;k++)if(mask&(1u<<k)){
  Slot *s=&host.slots[k];if(__atomic_load_n(&s->instrument,AQ))event_push(s,4,source+NATIVE_SOURCES,0,0,0,0);
 }
}
static unsigned pad_enter(unsigned source,uintptr_t unused,unsigned releasing){
 if(source>=0xfffffffbu&&source<=0xfffffffdu)return pc_performance_gate(source,unused,releasing);
 pc_padfx_touch(source,releasing);(void)unused;unsigned previous=pad_owner|(pad_dispatch<<16);pad_owner=0;pad_dispatch=source<128;
 if(source>=128)return previous;
 if(releasing)release_physical(source);
 pad_owner=source+NATIVE_SOURCES; /* Physical ownership is independent of Step / 16 Levels. */
 return previous;
}
static void pad_leave(unsigned previous){pad_owner=previous&65535u;pad_dispatch=previous>>16;}
static int note(uintptr_t p,uintptr_t t,uintptr_t c,uintptr_t i,const uint8_t *d,unsigned f){
 (void)c;(void)f;int k=pc_find(i);if(k<0||__atomic_load_n(&host.slots[k].program,AQ)!=p){pc_sc_note(p,i,d);return 0;}
 if(live_forwarded==i)return 1;
 Slot *s=&host.slots[k];if(!d)return 1;
 unsigned generation=__atomic_load_n(&s->generation,AQ);
 if(__atomic_load_n(&s->instrument,AQ)!=i)return 1;
 pc_bounce_note_seen(i);float velocity;memcpy(&velocity,d+8,4);
 unsigned source=d[0],channel=d[4]&15,mask=(unsigned)d[12]|(unsigned)d[13]<<8;int pitch=60+(mask&1?(int)d[14]-120:0);
 if(!(velocity>0&&velocity<=1)||pitch<0||pitch>127){pc_error(20);return 1;}
 unsigned v=(unsigned)(velocity*127+.5f);if(!v)v=1;
 if(__atomic_load_n((uint8_t*)(i+0x78),AQ)&1)return 1;
 if(!pad_dispatch&&!pc_bounce_busy())pc_tune_follow_note((unsigned)pitch,v);
 if(!pc_trigger_admit(0,(unsigned)t,1)){pc_poly_reject();return 1;}
 pc_sc_note(p,i,d);if(pad_owner)__atomic_fetch_or(&physical_slots[pad_owner-NATIVE_SOURCES],1u<<k,RL);event_push_generation(s,generation,1,pad_owner?pad_owner:source,channel,(unsigned)pitch,v,pc_stock_filter_note(p,d));
 FN(0x286c860,void (*)(uintptr_t,uintptr_t,unsigned))(p,i,0);return 1;
}
/* Live events are queued by the native UI. Resolve their instrument again
 * at the AUDIO entry; the physical callback's TLS scope has already ended.
 * Forward native bookkeeping once while suppressing a duplicate synth hook. */
void pc_synth_live_input(uintptr_t iface,unsigned offset,unsigned track,uintptr_t context,const uint8_t*d){
 uintptr_t program=iface>=0xdf0?iface-0xdf0:0,instrument=0;
 if(d&&program&&Q(program,0)==host.base+0x6ec6860&&I(program,0x1234)==0){
  unsigned source=d[0];int index=source;
  if(source<128)index=I(program,0x14a8+4*source);
  uintptr_t begin=Q(program,0x2808),end=Q(program,0x2810);
  if(source!=128&&begin&&end>=begin&&(end-begin)%8==0&&end-begin<=256*8&&index>=0&&(uintptr_t)index<(end-begin)/8){
   uintptr_t i=Q(begin,8*(unsigned)index);
   int k=pc_find(i);if(k>=0&&__atomic_load_n(&host.slots[k].program,AQ)==program)instrument=i;
  }
 }
 uintptr_t previous=live_forwarded;
 if(instrument){live_forwarded=0;note(program,offset,context,instrument,d,1);live_forwarded=instrument;}
 FN(0x286fcf0,void(*)(uintptr_t,unsigned,unsigned,uintptr_t,const uint8_t*))(iface,offset,track,context,d);
 live_forwarded=previous;
}
static void off(uintptr_t iface,uintptr_t t,unsigned tr,unsigned ch,unsigned source){
 (void)t;(void)tr;if(iface<0xdf0||source>=256)return;
 if(pad_owner)return;
 for(unsigned k=0;k<PC_SLOTS;k++){
  Slot *s=&host.slots[k];
  if(__atomic_load_n(&s->program,AQ)!=iface-0xdf0)continue;
  if(source>=128||__atomic_load_n(&s->pending_on,AQ)||
     (__atomic_load_n(&s->native_sources[source/32],AQ)&(1u<<(source%32))))
   event_push(s,2,source,ch&15,0,0,0);
 }
}
static int active(uintptr_t i){return pc_find(i)>=0;}
static void render(uintptr_t i,uintptr_t b,unsigned frames,unsigned phase){
 (void)phase;int k=pc_find(i);if(k<0)return;
 if(!b||I(b,0)<2||I(b,0)>32||!frames||frames>4096||I(b,4)<(int)frames){pc_error(30);return;}
 uintptr_t channels=Q(b,0x10);if(!channels||!Q(channels,0)||!Q(channels,8)||Q(channels,0)==Q(channels,8)){pc_error(31);return;}
 Slot *s=&host.slots[k];if(!lock(s)){
  memset((void *)Q(channels,0),0,frames*4);memset((void *)Q(channels,8),0,frames*4);return;
 }if(__atomic_load_n(&s->instrument,AQ)!=i){unlock(s);return;}
 drain(s);unsigned source=0,trigger=pc_bounce_synth_gate(i,&source,s->held_keys);
 if(trigger==1)event_push(s,1,source,0,60,100,0);else if(trigger==2)event_push(s,2,source,0,0,0,0);
 if(trigger)drain(s);unsigned muted=__atomic_load_n((uint8_t*)(i+0x78),AQ)&1;if(muted&&!s->native_muted)all_off(s);s->native_muted=muted;
 pc_new_tempo_audio(s);if(pc_context_engine(s->audio_engine))pc_ms_render(s->multisample,(float *)Q(channels,0),(float *)Q(channels,8),frames);else if(s->audio_engine==4)pc_fm6_render((unsigned)k,(float*)Q(channels,0),(float*)Q(channels,8),frames);else pc_slot_dsp(s)->render((float *)Q(channels,0),(float *)Q(channels,8),frames);
 pc_poly_sync(s);
 /* Engine base gain, followed by independent pad Volume with a block ramp.
  * FM6 keeps the existing FM pad gain; other engines keep their base levels. */
 float base=pc_context_engine(s->audio_engine)?1.f:s->audio_engine==4?1.f:s->audio_engine>=5?1.7782794100f:s->audio_engine==2?5.0118723363f:2.2387211386f;
 float target=muted?0.f:pc_mix_gain(i),current=s->output_gain,step=(target-current)/(float)frames;
 int invalid=0;float *left=(float *)Q(channels,0),*right=(float *)Q(channels,8);
 pc_stock_filter_render(&s->stock_filter,i,s->filter_lock,left,right,frames);
 pc_synth_splice(&s->splice,left,right,frames);
 for(unsigned n=0;n<frames;n++){
  current+=step;float gain=base*current,limit=s->audio_engine>=4?1000000.f:16.f;
  if(!(left[n]>=-3.402823466e38f&&left[n]<=3.402823466e38f)){left[n]=0;invalid=1;}else{if(left[n]>limit)left[n]=limit;else if(left[n]<-limit)left[n]=-limit;left[n]*=gain;}
  if(!(right[n]>=-3.402823466e38f&&right[n]<=3.402823466e38f)){right[n]=0;invalid=1;}else{if(right[n]>limit)right[n]=limit;else if(right[n]<-limit)right[n]=-limit;right[n]*=gain;}
 }s->output_gain=target;
 if(invalid){pc_error(32);}*(uint8_t *)(b+0x128)=0;__atomic_fetch_add(&host.debug->frames,frames,RX);held_debug(s);pc_bounce_synth_rendered(i);unlock(s);
}
int pc_synth_bounce_render(uintptr_t i,uintptr_t b,unsigned n){
 int k=pc_find(i);if(k<0)return 0;render(i,b,n,0);return pc_bounce_synth_done();
}
static void stop(uintptr_t iface,uintptr_t t,unsigned tr,unsigned ch){
 (void)t;(void)tr;if(iface<0xdf0)return;
 /* A sample/channel stop emitted by a physical pad is its key-up, not a
  * transport stop. Never fan it out to the other held keys or MIDI voices. */
 if(pad_owner)return;
 for(unsigned k=0;k<PC_SLOTS;k++){
  Slot *s=&host.slots[k];
  if(__atomic_load_n(&s->program,AQ)!=iface-0xdf0)continue;
  unsigned active=__atomic_load_n(&s->pending_on,AQ);
  for(unsigned group=0;group<8;group++)active|=__atomic_load_n(&s->native_sources[group],AQ);
  if(active)event_push(s,3,0,ch,0,0,0);
 }
}
static void destroy(uintptr_t p){
 __atomic_fetch_add(&host.project_epoch,1,RL);
 pc_sc_forget(0,p);pc_mix_forget(0,p);
 for(unsigned k=0;k<PC_SLOTS;k++){Slot *s=&host.slots[k];if(__atomic_load_n(&s->program,AQ)!=p)continue;
  __atomic_store_n(&s->instrument,0,RL);pc_poly_forget(s);__atomic_store_n(&s->program,0,RL);__atomic_store_n(&s->panic,1,RL);
 }
 __atomic_store_n(&host.ui.loaded_valid,0,RL);
 unsigned total=0;for(unsigned k=0;k<PC_SLOTS;k++)total+=!!__atomic_load_n(&host.slots[k].instrument,AQ);__atomic_store_n(&host.debug->assigned,total,RX);
}
static void destroy_instrument(uintptr_t instrument){
 pc_sc_forget(instrument,0);pc_mix_forget(instrument,0);
 int k=pc_find(instrument);if(k<0)return;Slot *s=&host.slots[k];
 uintptr_t expected=instrument;
 if(__atomic_compare_exchange_n(&s->instrument,&expected,0,0,__ATOMIC_ACQ_REL,AQ)){
  pc_poly_forget(s);
  __atomic_store_n(&s->program,0,RL);__atomic_store_n(&s->panic,1,RL);__atomic_fetch_sub(&host.debug->assigned,1,RX);
  __atomic_store_n(&host.ui.loaded_valid,0,RL);
 }
}
int pc_load_dsp(Dsp *d,const char *path,int panel){
 void *h=FN(0xb518a8,void *(*)(const char *,int))(path,2);if(!h)return 0;
 void *(*sym)(void *,const char *)=FN(0xb51898,void *(*)(void *,const char *));
#define LOAD(field,name) d->field=sym(h,name);if(!d->field)return 0
 d->attack_cost=sym(h,"mpc_synth_attack_cost");
 LOAD(voices,"mpc_synth_voices");LOAD(prepare,"mpc_synth_prepare");LOAD(version,"mpc_synth_api_version");LOAD(held,"mpc_synth_held");LOAD(count,"mpc_synth_preset_count");LOAD(name,"mpc_synth_preset_name");
 LOAD(select,"mpc_synth_select");LOAD(load,"mpc_synth_load");LOAD(save,"mpc_synth_save");LOAD(set,"mpc_synth_set");
 LOAD(on,"mpc_synth_note_on");
 /* Layout-specific allocator support is available only for the shipped DSP. */
 static const uint8_t legacy_id[20]={0x2a,0xca,0xfd,0x03,0x1e,0x29,0xa2,0x73,0x24,0x93,0x83,0x6f,0x19,0xd2,0x1e,0x78,0x10,0x2f,0x1c,0xe6};
 uintptr_t legacy=(uintptr_t)d->on-0x4dd70;
 uintptr_t module[4];
 int(*address_info)(const void*,uintptr_t*)=sym(0,"dladdr");
 if(address_info&&((uintptr_t)d->on&4095)==0xd70&&(uintptr_t)d->held==legacy+0x4de28&&
    address_info((const void*)d->on,module)&&module[1]==legacy&&
    !memcmp((void*)(legacy+0x210),legacy_id,sizeof legacy_id))d->legacy_layout=legacy;
 LOAD(off,"mpc_synth_note_off");LOAD(render,"mpc_synth_render");
 if(panel){LOAD(panel_init,"mpc_panel_init");LOAD(view,"mpc_panel_view");LOAD(button,"mpc_panel_button");LOAD(encoder,"mpc_panel_encoder");LOAD(confirm,"mpc_panel_confirm");LOAD(knob,"mpc_panel_knob");LOAD(panel_load,"mpc_panel_load");LOAD(draw,"mpc_panel_draw");LOAD(saved,"mpc_panel_saved");}
#undef LOAD
 return d->version()==1&&(d->select(0,0)||d->select(7,0));
}
/* A native archive can run synchronously inside a metadata owner, or on
 * a worker. Borrow an existing owner without releasing it on return.
 * Nested archive callbacks must not overwrite the outer static snapshots. */
static __thread unsigned archive_active;

static int archive_enter(int *acquired){
 if(archive_active)return 0;
 archive_active=1;
 *acquired=!pc_meta_owned();
 if(*acquired){
  const long pause[2]={0,1000000};
  while(!pc_meta())pc_sys(101,(long)pause,0,0,0,0,0);
 }
 return 1;
}

static void archive_leave(int acquired){
 if(acquired)pc_unmeta();
 archive_active=0;
}

static void info_write(uintptr_t archive,uintptr_t info){
 int acquired;
 if(!host.ready||!info||!archive_enter(&acquired))return;
 if(pc_project_new_sync_locked()){
  pc_project_info_write(archive,info);
  pc_mix_info_write(info);
  pc_audio_info_write(info);
 }
 archive_leave(acquired);
}

static void info_read(uintptr_t info){
 int acquired;
 if(!host.ready||!info||!archive_enter(&acquired))return;
 pc_mix_info_read(info);
 pc_project_info_read(info);
 pc_audio_info_read(info);
 archive_leave(acquired);
}
static const PcApi api={PC_MAGIC,6,note,off,active,render,stop,destroy,pc_ui_physical,pc_ui_knob,pc_ui_rotation,pc_ui_capture,pc_ui_event,pc_ui_paint,pc_xml_write,pc_xml_read,destroy_instrument,pc_light_has,pc_light_playing,pc_sc_process,info_write,info_read,pc_mix_input,pc_mix_chain,pc_ui_native_fx_guard,pad_enter,pad_leave,pc_audio_input,pc_audio_tick,pc_audio_click,0x303730415544494fULL,sizeof(PcApi),pc_bounce_export,pc_bounce_enter,pc_bounce_block,pc_bounce_collect,pc_bounce_status,pc_bounce_lcd};
static const PcApi *init_host(uintptr_t base,uintptr_t state,PcDebug *debug){
 if(!base||!state||!debug)return 0;
 if(host.ready)return host.base==base&&pc_state_base()==state?&api:0;
 host.base=base;
 host.shared_state=state;
 host.debug=debug;
 memset(debug,0,sizeof *debug);debug->magic=PC_MAGIC;
 char path[]="/run/mpc-pc-integrated-v040/libpc-dsp-00.aarch64.so";
 for(unsigned k=0;k<PC_SLOTS;k++){
  for(unsigned n=0;n<NOTE_QUEUE;n++)host.slots[k].events[n].sequence=n;
  path[38]=(char)('0'+k/10);path[39]=(char)('0'+k%10);
  if(!pc_load_dsp(&host.slots[k].dsp,path,0)){pc_error(100+k);return 0;}
 }
 if(!pc_load_dsp(&host.mirror,"/run/mpc-pc-integrated-v040/libpc-editor.aarch64.so",1)){pc_error(120);return 0;}
 if(!pc_new_engines_init()){pc_error(121);return 0;}
 pc_fx_worker_init();pc_shutdown_watch_init();pc_flex_clock_init();pc_stock_filter_init();pc_sample_playback_init();host.ready=1;debug->state=1;
 const char marker[]="/run/mpc-pc-integrated-v040/editorial-r1.ready",message[]="mpc-editorial-r1-ready\n";
 long fd=pc_sys(56,-100,(long)marker,0x80000|0x40|0x200|1,0600,0,0);
 if(fd>=0){pc_sys(64,fd,(long)message,sizeof message-1,0,0,0);pc_sys(57,fd,0,0,0,0,0);}
host.ui.message="Select a pad, then an engine";return &api;
}
__attribute__((visibility("default"))) const PcApi *pc_init(uintptr_t base,PcDebug *debug){
 if(base>UINTPTR_MAX-PC_LEGACY_STATE_OFFSET)return 0;
 return init_host(base,base+PC_LEGACY_STATE_OFFSET,debug);
}
__attribute__((visibility("default"))) const PcApi *pc_init_with_state(uintptr_t base,void *state,size_t size){
 uintptr_t address=(uintptr_t)state;
 if(!address||address%16||size<PC_SHARED_STATE_SIZE||
    address>UINTPTR_MAX-PC_SHARED_STATE_SIZE)return 0;
 return init_host(base,address,(PcDebug*)(address+PC_SHARED_DEBUG_OFFSET));
}

void pc_bounce_detach(uintptr_t i){int k=pc_find(i);if(k<0)return;Slot*s=&host.slots[k];__atomic_store_n(&s->instrument,0,RL);pc_poly_forget(s);__atomic_store_n(&s->program,0,RL);__atomic_add_fetch(&s->generation,1,RL);__atomic_store_n(&s->panic,1,RL);__atomic_store_n(&host.debug->held[k],0,RL);__atomic_fetch_sub(&host.debug->assigned,1,RX);host.ui.loaded_valid=0;}
void pc_bounce_voices_reset(void){for(unsigned n=0;n<PC_SLOTS;n++){__atomic_store_n(&host.slots[n].panic,1,RL);__atomic_store_n(&host.debug->held[n],0,RL);}}
