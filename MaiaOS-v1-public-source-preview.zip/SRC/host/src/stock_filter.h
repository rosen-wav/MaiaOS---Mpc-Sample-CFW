#ifndef PC_STOCK_FILTER_H
#define PC_STOCK_FILTER_H
#include <stdint.h>
typedef struct {
 _Alignas(32) uint8_t native[0xc0];
 _Alignas(32) uint8_t previous[0xc0];
 unsigned mode,previous_mode,fade_left;
} PcStockFilter;
enum { PC_STOCK_FILTER_TYPES=29, PC_STOCK_FILTER_VOCAL1=26 };
void pc_stock_filter_init(void);
int pc_stock_filter_process(PcStockFilter*,unsigned,float,float,float*,float*,unsigned);
unsigned pc_stock_filter_note(uintptr_t,const uint8_t*);
int pc_stock_filter_render(PcStockFilter*,uintptr_t,unsigned,float*,float*,unsigned);
#endif
