/* SPDX-License-Identifier: GPL-3.0-only */
#pragma once
#include <stdint.h>
#define PC_SYX_MAX 128
/* engine 4 = Yamaha DX7 VMEM record; engine 7 = native Casio 144-byte tone. */
typedef struct{unsigned engine,size;char name[25];uint8_t raw[144];} PcSyxVoice;
int pc_syx_parse(const uint8_t*,unsigned,unsigned,PcSyxVoice*,unsigned);
void pc_dx7_unpack(const uint8_t*,uint8_t*);void pc_dx7_pack(const uint8_t*,uint8_t*);
unsigned pc_syx_crc(const uint8_t*,unsigned);
int pc_dx7_valid(const uint8_t*);

int pc_syx_make_patch(const PcSyxVoice*,uint8_t*);
