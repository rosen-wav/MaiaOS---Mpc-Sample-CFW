#ifndef PC_AIRWINDOWS_H
#define PC_AIRWINDOWS_H
#ifdef __cplusplus
extern "C" {
#endif
void pc_galactic_prepare(unsigned);
void pc_galactic_process(unsigned,float*,float*,unsigned,const float*,unsigned);
unsigned pc_dj_space_active(void);
void pc_dj_space_process(float*,float*,unsigned,unsigned,unsigned);
#ifdef __cplusplus
}
#endif
#endif
