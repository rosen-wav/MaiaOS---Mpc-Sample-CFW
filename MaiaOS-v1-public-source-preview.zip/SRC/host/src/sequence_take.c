/* SPDX-License-Identifier: GPL-3.0-only */
#include "internal.h"
#include "bounce.h"
#include "sample_playback.h"

enum { PAD_COUNT = 128 };
enum { TAIL_EMPTY, TAIL_WRITING, TAIL_READY, TAIL_READING };
typedef struct {
    int64_t tick;
    uint8_t body[48];
} TakeEvent;

typedef struct {
    int64_t start, end, loop_start, loop_end;
    uint64_t settings[3];
} TakeSlice;

_Static_assert(sizeof(TakeEvent) == 56 && sizeof(TakeSlice) == 56, "native take ABI");

typedef struct {
    uintptr_t instrument, sample;
    unsigned index, key, frames, rate;
    unsigned tried_muted;
} TakePad;
typedef struct {
    uintptr_t recorder, project, track, program, sequence, clip;
    int64_t ticks;
    unsigned epoch;
    uint64_t sends;
} SequenceTake;

/* Both call sites are on the native PadAudioRecorder UI path. The audio
 * worker still owns recording and the sample command still owns the WAV. */
static SequenceTake armed;
static struct {
    SequenceTake take;
    TakePad pads[PAD_COUNT];
    double last;
    unsigned count, state;
} tail;

/* The native sampler can consume its event later in the same audio block. */
static __thread struct {
    uintptr_t instrument, sample;
    int64_t frames;
    unsigned index;
    int sliced, launched;
} first_voice[PAD_COUNT];
static __thread unsigned first_count, reading_tail;

static void set_mute(uintptr_t instrument, unsigned muted)
{
    FN(0x13904f0,void(*)(uintptr_t,unsigned))(instrument+0x28,muted);
}

static unsigned muted(uintptr_t instrument)
{
    return __atomic_load_n((const uint8_t *)(instrument+0x78),AQ)&1;
}

static unsigned project_epoch(void)
{
    return __atomic_load_n((unsigned *)(pc_state_base()+0x1ef4), AQ);
}

static int take_current(const SequenceTake *t)
{
    return t->project && t->clip && t->epoch == project_epoch() &&
           t->project == Q(pc_state_base(),0x1d08) &&
           Q(t->project,0x140) == t->track && Q(t->track,0xbb8) == t->program &&
           Q(t->project,0xb8) == t->program && Q(t->project,0x1c8) == t->sequence &&
           Q(t->project,0x3d0) == t->clip &&
           *(int64_t *)(t->sequence+0x348) == t->ticks;
}

void pc_record_arm_reset(uintptr_t recorder, float seconds)
{
    armed.project = 0;
    FN(0x20826c0,void(*)(uintptr_t,float))(recorder,seconds);
}

void pc_record_arm_sync(uintptr_t recorder, int64_t until_wrap)
{
    /* The only hooked caller already checked fixed length and running
     * transport. Its native scheduler starts the take on the next downbeat. */
    uintptr_t project = Q(pc_state_base(),0x1d08);
    if (host.ready && project && Q(project,0) == host.base+0x6ecc648) {
        uintptr_t track = Q(project,0x140), program = Q(project,0xb8);
        uintptr_t seq = Q(project,0x1c8), clip = Q(project,0x3d0);
        if (track && Q(track,0) == host.base+0x6ecf118 && program &&
            Q(track,0xbb8) == program && Q(program,0) == host.base+0x6ec6860 &&
            !I(program,0x1234) && seq && Q(seq,0) == host.base+0x6ecdff0) {
            int64_t ticks = *(int64_t *)(seq+0x348);
            if (ticks > 0 && ticks <= 128LL*122880) {
                uint64_t sends = 0;
                for (unsigned k = 0; k < 3; k++)
                    sends |= (uint64_t)pc_input_send(k) << (14*k);
                armed = (SequenceTake){recorder,project,track,program,seq,clip,ticks,project_epoch(),sends};
                pc_diag_add(58);
            }
        }
    }
    FN(0x206b350,void(*)(uintptr_t,int64_t))(recorder,until_wrap);
}

int64_t pc_record_capture_wait(uintptr_t clock, int64_t ticks,
                               uint64_t tempo, uint64_t has_tempo,
                               uint64_t rate, uint64_t has_rate)
{
    int64_t frames = FN(0x2159ab0,int64_t(*)(uintptr_t,int64_t,uint64_t,uint64_t,uint64_t,uint64_t))
        (clock,ticks,tempo,has_tempo,rate,has_rate);
    /* This converter's call site belongs to the fixed-length, running
     * SEQ scheduler. Delay the capture window by one 256-frame audio
     * block so its first frame matches the delayed input downbeat.
     * The recorder's independent duration still covers the full loop. */
    enum { INPUT_LATENCY_FRAMES = 256 };
    /* Stock starts in the current block for both zero and a one-frame
     * wait. Normalize an already-due start to that first frame. */
    if (frames < 1) frames = 1;
    return frames <= INT32_MAX - INPUT_LATENCY_FRAMES ?
        frames + INPUT_LATENCY_FRAMES : frames;
}

static int claim_tail(unsigned desired, unsigned state)
{
    return __atomic_compare_exchange_n(&tail.state,&desired,state,0,AQ,RX);
}

static uintptr_t sample_of(uintptr_t instrument)
{
    uintptr_t layers = instrument ? Q(instrument,0x22e8) : 0;
    return layers ? Q(layers,0x4a8) : 0;
}

static uintptr_t instrument_at(uintptr_t program, unsigned index)
{
    if (index >= PAD_COUNT) return 0;
    uintptr_t instrument = FN(0x286bbe0,uintptr_t(*)(uintptr_t,unsigned))(program,index);
    return instrument && Q(instrument,0) == host.base+0x6ec3ca0 &&
           Q(instrument,0x2310) == program ? instrument : 0;
}

static unsigned pad_key(uintptr_t program, unsigned index)
{
    for (unsigned key = 0; key < PAD_COUNT; key++)
        if (I(program,0x14a8+4*key) == (int)index) return key;
    return PAD_COUNT;
}

int pc_record_finish(uintptr_t manager, const uintptr_t *command, uintptr_t pad_recorder)
{
    int(*native)(uintptr_t,const uintptr_t *) = FN(0x19d0a00,int(*)(uintptr_t,const uintptr_t *));
    SequenceTake take = armed;
    armed.project = 0;
    uintptr_t cmd = command ? command[0] : 0;
    if (!take.project || take.epoch != project_epoch() || take.project != Q(pc_state_base(),0x1d08) ||
        !pad_recorder || Q(pad_recorder,0x88) != take.recorder || Q(pad_recorder,0x90) != manager ||
        !cmd || Q(cmd,0) != host.base+0x6e07ed8 || Q(cmd,0x60) != take.program)
        return native(manager,command);

    uintptr_t begin = Q(cmd,0x68), end = Q(cmd,0x70);
    if (!begin || end <= begin || (end-begin)%4 || end-begin > PAD_COUNT*4)
        return native(manager,command);
    unsigned count = (end-begin)/4;
    unsigned indexes[PAD_COUNT], previous_mutes[PAD_COUNT];
    uintptr_t instruments[PAD_COUNT], previous_samples[PAD_COUNT];
    for (unsigned n = 0; n < count; n++) {
        indexes[n] = (unsigned)I(begin,4*n);
        uintptr_t instrument = instrument_at(take.program,indexes[n]);
        instruments[n] = instrument;
        previous_samples[n] = sample_of(instrument);
        previous_mutes[n] = instrument ? muted(instrument) : 0;
    }
    for (unsigned n = 0; n < count; n++)
        if (instruments[n] && !muted(instruments[n])) set_mute(instruments[n],1);

    int result = native(manager,command);
    if (take.epoch != project_epoch() || take.project != Q(pc_state_base(),0x1d08)) return result;
    uint8_t keys[PAD_COUNT] = {0};
    TakePad pads[PAD_COUNT];
    unsigned assigned = 0, pad_count = 0;
    int acquired = !pc_meta_owned() && pc_meta();
    int can_route = acquired || pc_meta_owned(), routed = can_route;
    for (unsigned n = 0; n < count; n++) {
        uintptr_t instrument = instrument_at(take.program,indexes[n]);
        if (!instrument) continue;
        uintptr_t sample = sample_of(instrument);
        if (result || !sample || sample == previous_samples[n]) {
            if (muted(instrument) != previous_mutes[n]) set_mute(instrument,previous_mutes[n]);
            continue;
        }
        if (!muted(instrument)) set_mute(instrument,1);
        FN(0x2806c90,void(*)(uintptr_t,unsigned))(instrument,pc_sample_default_mode(sample));
        assigned++;
        if (can_route) {
            int ok=pc_mix_set_controls(take.program,instrument,((uint64_t)661<<42)|take.sends);
            routed &= ok;
            if(!ok)pc_record_controls_defer(take.program,instrument,((uint64_t)661<<42)|take.sends);
        }else pc_record_controls_defer(take.program,instrument,((uint64_t)661<<42)|take.sends);
        unsigned key = pad_key(take.program,indexes[n]);
        if (key >= PAD_COUNT || keys[key]) continue;
        keys[key] = 1;
        pads[pad_count++] = (TakePad){instrument,sample,indexes[n],key,
            FN(0x2941f80,unsigned(*)(uintptr_t))(sample),
            FN(0x2941f90,unsigned(*)(uintptr_t))(sample),0};
    }

    if (assigned) {
        uintptr_t factory = Q(pad_recorder,0x98);
        int added = 0;
        if (!take.clip && Q(take.project,0x140) == take.track && Q(take.project,0x1c8) == take.sequence)
            take.clip = Q(take.project,0x3d0);
        if (pad_count && take_current(&take) && factory &&
            Q(factory,0x28) == take.project && Q(factory,0x60) == manager &&
            FN(0x7410018,int(*)(void))()) {
            if (take_current(&take))
                added = pc_record_add_triggers(factory,take.clip+0x688,take.ticks,keys);
            FN(0x7410098,void(*)(void))();
        }
        if (added && (claim_tail(TAIL_EMPTY,TAIL_WRITING) || claim_tail(TAIL_READY,TAIL_WRITING))) {
            tail.take = take;
            memcpy(tail.pads,pads,pad_count*sizeof *pads);
            tail.count = pad_count;
            tail.last = -1;
            __atomic_store_n(&tail.state,TAIL_READY,RL);
        }
        if (can_route) pc_mix_route_program(take.program);
        pc_light_refresh();
        pc_diag_add(added && routed ? 59 : 60);
    }
    if (acquired) pc_unmeta();
    return result;
}

/* Live audio PositionInfo already accounts for the transport's loop. Chase
 * just the unfinished part of the first pass when the recording is published
 * after tick zero. Keep the real tick-zero note for the following passes. */
static uint64_t transport_tick;
int64_t pc_sequence_play_tick(void){
 uint64_t value=__atomic_load_n(&transport_tick,AQ);
 if(!(uint32_t)value||(unsigned)(value>>32)!=__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ))return -1;
 return (uint32_t)value-1;
}
static void publish_transport_tick(uintptr_t engine,uintptr_t position){
 uint64_t value=0;
 if(*(const uint8_t*)(position+0x3c)&1){
  uintptr_t transport=Q(engine,0x790),shared=transport?Q(transport,0x258):0,map=shared?Q(shared,0x110):0;
  if(map){
   int64_t sample=*(const int64_t*)(position+0x10);
   int64_t tick=FN(0x2159b60,int64_t(*)(uintptr_t,int64_t,uint64_t,uint64_t,uint64_t,uint64_t))(map,sample,0,0,0,0);
   if(tick>=0&&tick<0xffffffffLL)
    value=(uint64_t)__atomic_load_n((unsigned*)(pc_state_base()+0x1ef4),AQ)<<32|(uint32_t)(tick+1);
  }
 }
 __atomic_store_n(&transport_tick,value,RL);
}
void pc_record_first_pass(uintptr_t engine, uintptr_t position)
{
    FN(0x2114c00,void(*)(uintptr_t,uintptr_t))(engine,position);
    publish_transport_tick(engine,position);
    if (reading_tail || !claim_tail(TAIL_READY,TAIL_READING)) return;

    double elapsed = *(const double *)(position+0x18);
    if (!(*(const uint8_t *)(position+0x3c)&1) || !take_current(&tail.take) ||
        !(elapsed >= 0) || (tail.last >= 0 && (elapsed < tail.last || elapsed-tail.last > .05))) {
        __atomic_store_n(&tail.state,TAIL_EMPTY,RL);
        return;
    }
    tail.last = elapsed;
    reading_tail = 1;

    for (unsigned n = 0; n < tail.count; n++) {
        TakePad *pad = &tail.pads[n];
        if (!pad->sample || instrument_at(tail.take.program,pad->index) != pad->instrument ||
            sample_of(pad->instrument) != pad->sample ||
            pad->rate < 8000 || pad->rate > 192000 || elapsed*pad->rate >= pad->frames) {
            pad->sample = 0;
            continue;
        }
        if (pad->tried_muted && muted(pad->instrument)) continue;
        int64_t frames = (int64_t)(elapsed*pad->rate);
        int64_t remaining = tail.take.ticks - frames*tail.take.ticks/pad->frames;
        if (!remaining) continue;
        first_voice[first_count].instrument = pad->instrument;
        first_voice[first_count].sample = pad->sample;
        first_voice[first_count].frames = frames;
        first_voice[first_count].index = n;
        first_voice[first_count].sliced = 0;
        first_voice[first_count++].launched = 0;
        /* A native tick-zero note can already fire if publication landed
         * in this exact block. Observe that voice before chasing the tail. */
        if (!frames) continue;
        TakeEvent note = FN(0x27e54d0,TakeEvent(*)(unsigned,int64_t,int64_t,unsigned,unsigned,float))
            (pad->key,0,remaining,100,0,1.f);
        FN(0x211a230,void(*)(uintptr_t,int64_t,int64_t,uintptr_t,const TakeEvent *))
            (engine,0,0,tail.take.track,&note);
        if (muted(pad->instrument)) pad->tried_muted = 1;
        else pad->sample = 0;
    }
    /* Keep the packet owned until the stock sampler has consumed its input. */
}

void pc_record_end_block(uintptr_t renderer, uintptr_t output, unsigned frames)
{
    FN(0x2226fb0,void(*)(uintptr_t,uintptr_t,unsigned))(renderer,output,frames);
    if (!reading_tail) return;
    reading_tail = 0;
    for (unsigned n = 0; n < first_count; n++)
        if (first_voice[n].launched) tail.pads[first_voice[n].index].sample = 0;
    first_count = 0;
    for (unsigned n = 0; n < tail.count; n++)
        if (tail.pads[n].sample) {
            __atomic_store_n(&tail.state,TAIL_READY,RL);
            return;
        }
    __atomic_store_n(&tail.state,TAIL_EMPTY,RL);
}

void pc_record_voice_started(uintptr_t instrument)
{
    for (unsigned n = 0; n < first_count; n++)
        if (first_voice[n].instrument == instrument && first_voice[n].sliced) first_voice[n].launched = 1;
}

TakeSlice pc_record_slice(uintptr_t slice, uintptr_t sample, uintptr_t instrument)
{
    TakeSlice copy = FN(0x2949a80,TakeSlice(*)(uintptr_t))(slice);
    if (!first_count || pc_physical_pad_dispatch()) return copy;
    for (unsigned n = 0; n < first_count; n++) {
        if (first_voice[n].instrument != instrument || first_voice[n].sample != sample) continue;
        int64_t start = copy.start + first_voice[n].frames;
        if (start >= copy.start && start < copy.end) {
            first_voice[n].sliced = 1;
            copy.start = start;
            if (copy.loop_start < start) copy.loop_start = start;
        }
        break;
    }
    return copy;
}

#if defined(__aarch64__)
/* x19 is PadAudioRecorder::this at this exact call site. */
__asm__(".text\n.hidden pc_record_finish_entry\n.global pc_record_finish_entry\n"
        "pc_record_finish_entry:\nbti c\nmov x2, x19\nb pc_record_finish\n");
__asm__(".text\n.hidden pc_record_slice_entry\n.global pc_record_slice_entry\n"
        "pc_record_slice_entry:\nbti c\nmov x1, x25\nldr x2, [x26, #0x8f8]\nb pc_record_slice\n");
#endif

/* Preserve recording gain/sends even if the metadata owner was busy when
 * native finalized the take. Only the UI retry publishes mix state. */
static struct {uintptr_t instrument,program;unsigned epoch;uint64_t controls;} pending_controls[128];
void pc_record_controls_defer(uintptr_t program,uintptr_t instrument,uint64_t controls){
 for(unsigned n=0;n<128;n++){
  uintptr_t expected=0;
  if(!__atomic_compare_exchange_n(&pending_controls[n].instrument,&expected,1,0,__ATOMIC_ACQ_REL,AQ))continue;
  pending_controls[n].program=program;pending_controls[n].epoch=project_epoch();pending_controls[n].controls=controls;
  __atomic_store_n(&pending_controls[n].instrument,instrument,RL);return;
 }
 pc_diag_add(60);
}
void pc_record_controls_poll(void){
 if(!pc_meta())return;
 for(unsigned n=0;n<128;n++){
  uintptr_t i=__atomic_load_n(&pending_controls[n].instrument,AQ);if(i<=1)continue;
  if(pending_controls[n].epoch!=project_epoch()||!pc_valid(pending_controls[n].program,i)){
   __atomic_store_n(&pending_controls[n].instrument,0,RL);continue;
  }
  if(pc_mix_set_controls(pending_controls[n].program,i,pending_controls[n].controls)){
   pc_mix_route_program(pending_controls[n].program);__atomic_store_n(&pending_controls[n].instrument,0,RL);
  }
 }pc_unmeta();
}
