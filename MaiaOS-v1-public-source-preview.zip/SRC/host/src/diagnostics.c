/* UI writes a bounded numeric snapshot. Audio only publishes atomics. */
#include "internal.h"
enum { DIAG_FIELDS=77 };
static unsigned values[DIAG_FIELDS],last[DIAG_FIELDS],written,publishing;static long last_second=-1;
void pc_diag_flag(unsigned field,unsigned bits){if(field<DIAG_FIELDS)__atomic_fetch_or(&values[field],bits,RL);}
void pc_diag_add(unsigned field){if(field<DIAG_FIELDS)__atomic_fetch_add(&values[field],1,RX);}
void pc_diag_value(unsigned field,unsigned value){if(field<DIAG_FIELDS)__atomic_store_n(&values[field],value,RL);}
void pc_diag_poll(void){
 /* Linux/AArch64 syscall and open flag values. */
 enum { OPENAT=56, FACCESSAT=48, RENAMEAT2=276, TEMP_FLAGS=0x88241 };
 const char path[]="/run/mpc-pc-integrated-v040/r24-diagnostics.txt";
 const char staged[]="/run/mpc-pc-integrated-v040/r24-diagnostics.txt.tmp";
 long ts[2];if(pc_sys(113,1,(long)ts,0,0,0,0)||__atomic_exchange_n(&publishing,1,AQ))return;
 if(ts[0]==last_second)goto done;
 last_second=ts[0];
 unsigned w[6];pc_fx_worker_diagnostics(w);for(unsigned j=0;j<6;j++)pc_diag_value(29+j,w[j]);
 unsigned v[DIAG_FIELDS];for(unsigned j=0;j<DIAG_FIELDS;j++)v[j]=__atomic_load_n(&values[j],AQ);
 if(written&&!memcmp(v,last,sizeof v)&&!pc_sys(FACCESSAT,-100,(long)path,0,0,0,0))goto done;
 char b[4096];unsigned at=0;const char*keys[]={"padfx_mask=","bounce_mask=","physical_calls=","events_submitted=","bounce_polls=","bounce_engine_busy=","bounce_status=","padfx_ui_mask=","commit_begin_status=","commit_add_status=","commit_assign_status=","commit_sample_match=","commit_routing_ok=","padfx_owner_vtable=","padfx_descriptor_type=","ui_mode=","padfx_prior_mode=","padfx_leave_mode=","padfx_last_button=","roll_zoom_bars=","roll_bar_ticks=","roll_begin_tick=","roll_span_ticks=","roll_view_paints=","synth_limit_rejected=","synth_onset_voices=","padfx_limit_rejected=","sample_limit_rejected=","shutdown_missing_mask=","fx_core1_ready=","fx_core2_ready=","fx_core1_jobs=","fx_core2_jobs=","fx_sync_over_budget=","fx_worker_failed_mask=","fx_button_presses=","fx_button_releases=","fx_toggle_events=","fx_legacy_open_events=","fx_open_calls=","fx_back_calls=","fx_popup_paints=","fx_dismiss_button=","fx_overlay_active=","fx_last_raw_button=","fx_native_open_requests=","fx_mode_at_open=","new_project_serial=","new_project_applied=","synth_release_reused=","sample_voice_hook=","tempo_declick_hook=","tempo_seams_smoothed=","sample_live_recycled=","roll_clipboard_hook=","tempo_spike_blocks=","sample_poly_default=","sequence_take_hook=","sequence_take_armed=","sequence_take_synced=","sequence_take_incomplete=","quantize_poly_hook=","cpu_overloaded=","sample_onset_voices=","drumkit_raw_property_hooks=","drumkit_lock_edit=","drumkit_locked_mask=","drumkit_raw_pad_events=","drumkit_panel_pad_events=","autotune_rendered_sample_keys=","autotune_filename_result=","dj_live_engine_hook=","dj_live_engine_blocks=","dj_device_clock=","dj_play_requests=","dj_worker_error=","dj_buffer_underruns="};
 for(unsigned j=0;j<DIAG_FIELDS;j++){const char*s=keys[j];while(*s)b[at++]=*s++;for(int k=7;k>=0;k--)b[at++]="0123456789abcdef"[(v[j]>>(4*k))&15];b[at++]='\n';}
 /* AArch64 openat is 56. Publish by rename so the boot worker can
  * never observe a truncated snapshot while the UI updates it. */
 long fd=pc_sys(OPENAT,-100,(long)staged,TEMP_FLAGS,0600,0,0);if(fd<0)goto done;
 long n=pc_sys(64,fd,(long)b,at,0,0,0);
 long closed=pc_sys(57,fd,0,0,0,0,0);
 if(n==at&&!closed&&!pc_sys(RENAMEAT2,-100,(long)staged,-100,(long)path,0,0)){
  memcpy(last,v,sizeof v);written=1;
 }else pc_sys(35,-100,(long)staged,0,0,0,0);
done:
 __atomic_store_n(&publishing,0,RL);
}
