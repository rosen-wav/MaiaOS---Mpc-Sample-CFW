/* SPDX-License-Identifier: GPL-3.0-only
 * FM6 synthesis from More Chords v63 / Melodee.
 * Copyright (C) 2026 Leo Kuroshita, Hügelton Instruments.
 * Modifications Copyright (C) 2026 Kerem Kilic (Ellic Studio).
 * MaiaOS adapter: per-pad audio ownership and independent release lanes.
 * Upstream operator DSP, lookup tables and original sources are bundled.
 */
#include "fm6.h"
#include "syx.h"
#include <stddef.h>
extern void *memset(void*,int,size_t);
extern void *memcpy(void*,const void*,size_t);
extern int memcmp(const void*,const void*,size_t);
#define CTL 32
#define CR_CPU1 0
#define NTRK 0
static inline int32_t clamp(int32_t x,int32_t a,int32_t b){return x<a?a:x>b?b:x;}
#include "../vendor/more-chords-fm6/felucca_tables.h"
#include "../vendor/more-chords-fm6/fm6_core.c"
typedef struct {uint32_t ph,dly;int32_t val,depth;uint8_t rnd;} fm6_lfo_t;
typedef struct {fm6_voice_t dsp;unsigned active,gate,age,tail;} Fm6Lane;
typedef struct{
 uint8_t patch[156];unsigned count,active,gates,sub,loaded;
 fm6_lfo_t lfo;
 unsigned pok;uint32_t amd,pt[4];
 float x1,y1;
 Fm6Lane lane[PC_FM6_VOICES];
} Fm6Pad;
static Fm6Pad pads[PC_FM6_PREVIEW+1];

static void fm6_lfo_step(fm6_lfo_t *l, const uint8_t *ed)   /* one block of the LFO: Lfo::getsample, getdelay */
{
    uint32_t inc = FM6_LFO_INC[ed[FP_LFS]], ph = l->ph + inc, a = 99u - (uint32_t)ed[FP_LFD], d1, d2, d;
    int32_t x;
    l->ph = ph;
    switch (ed[FP_LFW]) {
    case 0:                                              /* triangle */
        x = (int32_t)((ph >> 7) ^ (uint32_t)-(int32_t)(ph >> 31)) & ((1 << 24) - 1);
        break;
    case 1:                                              /* saw down */
        x = (int32_t)((~ph ^ (1u << 31)) >> 8);
        break;
    case 2:                                              /* saw up */
        x = (int32_t)((ph ^ (1u << 31)) >> 8);
        break;
    case 3:                                              /* square */
        x = (int32_t)(((~ph) >> 7) & (1u << 24));
        break;
    case 4:                                              /* sine */
        x = (1 << 23) + (fm6_sin((int32_t)(ph >> 8)) >> 1);
        break;
    default:                                             /* sample & hold */
        if (ph < inc)
            l->rnd = (uint8_t)(l->rnd * 179u + 17u);
        x = ((l->rnd ^ 0x80) + 1) << 16;
        break;
    }
    l->val = x;
    if (a == 99u) {                                      /* DELAY 0 */
        d1 = d2 = 0xFFFFFFFFu;
    } else {
        a = (16u + (a & 15u)) << (1u + (a >> 4));
        d1 = FM6_LFO_UNIT * a;
        d2 = FM6_LFO_UNIT * (a & 0xFF80u ? a & 0xFF80u : 0x80u);
    }
    if(l->depth==(1<<24))return;
    d = l->dly + (l->dly < (1u << 31) ? d1 : d2);
    if (d < l->dly) {                                    /* past the top */
        l->depth = 1 << 24;
        return;
    }
    l->dly = d;
    l->depth = d < (1u << 31) ? 0 : (int32_t)((d >> 7) & ((1u << 24) - 1u));
}

static void fm6_keyed(fm6_voice_t *s, const uint8_t *ed, uint32_t note)
{
    uint32_t k;
    for (k = 0; k < 6u; k++) {
        const uint8_t *op = &ed[k * FP_OP];
        s->ol[k] = (int16_t)fm6_outlevel(op, note, s->vel);
        s->rs[k] = (int8_t)fm6_rscale(op, note);
        s->base[k] = fm6_logfreq(op, note);
    }
}

static void voice_control(Fm6Pad *P, Fm6Lane *v, fm6_voice_t *s)
{
    uint32_t alg, k, dead=1;
    const uint8_t *ed=P->patch;
    int32_t lv[6],lfo=P->lfo.val,dly=P->lfo.depth,pm,sens,amd;
    uint32_t pmd = ((uint32_t)ed[FP_LPMD] * 165u) >> 6;
    alg = (uint32_t)ed[FP_ALG] & 31u;
    if (!v->gate && s->down) {                           /* key up: every envelope to its fourth segment */
        s->down = 0;
        for (k = 0; k < 6u; k++)
            fm6_eg_go(&s->eg[k], &ed[k * FP_OP], s->ol[k], s->rs[k], 3);
        fm6_peg_go(&s->pe, 3);
    }
    /* pitch: the LFO (PMD x PMS, after the delay, or a controller's), the pitch envelope, bend */
    sens = FM6_PMS[ed[FP_LPMS]] * (lfo - (1 << 23));
    int32_t pitch_lfo=(int32_t)(((int64_t)(pmd*(uint32_t)dly)*sens)>>39);
    pm=fm6_peg_step(&s->pe,s->down)+pitch_lfo;
    lfo=(1<<24)-lfo;
    amd=(int32_t)(((int64_t)((((uint32_t)ed[FP_LAMD]*165u)>>6)*(uint32_t)dly>>8)*lfo)>>24);
    for (k = 0; k < 6u; k++) {
        const uint8_t *op = &ed[k * FP_OP];
        int32_t rs=s->rs[k],level;
        s->fq[k]=fm6_freq(s->base[k]+(op[FP_MODE]?0:pm));
        level = fm6_eg_step(&s->eg[k], op, s->ol[k], rs, s->down);
        if (FM6_AMS[op[FP_AMS]]) {                       /* AMS: the modulation takes a part of the level */
            uint32_t a = (uint32_t)op[FP_AMS], pt;
            if (P->amd != (uint32_t)amd) {            /* one modulation a block for the part: 3 shares */
                P->amd = (uint32_t)amd;
                P->pok = 0;
            }
            if (!((P->pok >> a) & 1u)) {
                uint32_t sa = (uint32_t)(((uint64_t)(uint32_t)amd * FM6_AMS[a]) >> 24);
                P->pt[a] = sa ? fm6_ams_pt(sa) : 198789u;   /* exp(12.2) */
                P->pok |= (uint8_t)(1u << a);
            }
            pt = P->pt[a];
            level -= (int32_t)(((uint64_t)(uint32_t)level * ((uint64_t)pt << 4)) >> 28);
        }
        lv[k] = level;
    }
    for (k = 0; k < 6u; k++) {                           /* the output operators all gone for good? */
        const fm6_eg_t *e = &s->eg[k];               /* (and the feedback one: its memory outlives the note) */
        if ((fm6_carrier(alg, 6u - k) || ((FM6_ALG[alg][k] & 0xc0u) == 0xc0u && ed[FP_FB])) &&
            (s->down || ed[k * FP_OP + FP_L1 + 3] > 0 || e->level >= FM6_SILENT || e->ix < 3u ||
             (e->ix == 3u && e->rising)))
            dead = 0;
    }
    s->quiet = dead ? (uint8_t)(s->quiet + (s->quiet < 2u)) : 0;
    unsigned fb=ed[FP_FB];
    fm6_plan(s,lv,alg,FM6_MARK1,fb?8u-fb:16u);
}

int pc_fm6_load(unsigned owner,const uint8_t *patch,int edit){
 if(owner>PC_FM6_PREVIEW||!patch||memcmp(patch,"MPCEXT01",8)||
    patch[8]!=4||patch[9]||patch[10]||patch[11]||memcmp(patch+20,"DX7RAW01",8))return 0;
 uint32_t crc;memcpy(&crc,patch+508,4);if(crc!=pc_syx_crc(patch,508))return 0;
 uint8_t voice[156];pc_dx7_unpack(patch+64,voice);if(!pc_dx7_valid(voice))return 0;
 for(unsigned k=0;k<6;k++)for(unsigned j=0;j<4;j++)if(voice[k*21+j]>99)voice[k*21+j]=99;
 Fm6Pad*p=&pads[owner];
 if(!edit){memset(p,0,sizeof *p);p->lfo.val=1<<23;p->loaded=1;}
 if(edit&&!memcmp(p->patch,voice,sizeof voice))return 1;
 memcpy(p->patch,voice,sizeof voice);
 if(edit)for(unsigned k=0;k<p->count;k++){
  Fm6Lane*v=&p->lane[k];fm6_voice_t*s=&v->dsp;
  if(!v->active)continue;
  fm6_keyed(s,p->patch,(unsigned)clamp(s->note+p->patch[FP_TRNSP]-24,0,127));
  for(unsigned j=0;j<6;j++){
   // Preserve the current level and stage; held voices follow the edit.
   unsigned stage=s->eg[j].ix;
   if(stage<4)fm6_eg_go(&s->eg[j],p->patch+j*FP_OP,s->ol[j],s->rs[j],s->down&&stage==3?2:stage);
  }
  for(unsigned j=0;j<4;j++){s->pe.pr[j]=voice[FP_PR1+j];s->pe.pv[j]=voice[FP_PL1+j];}
  if(s->pe.pix<4)fm6_peg_go(&s->pe,s->down&&s->pe.pix==3?2:s->pe.pix);
 }
 return 1;
}
int pc_fm6_on(unsigned owner,unsigned note,unsigned velocity){
 if(owner>PC_FM6_PREVIEW||note>127||!velocity||velocity>127)return 0;
 Fm6Pad*p=&pads[owner];if(!p->loaded)return 0;unsigned i=0;
 for(;i<p->count;i++)if(!p->lane[i].active)break;
 if(i==PC_FM6_VOICES)return 0; // No release or sequenced voice gets stolen.
 if(i==p->count)p->count++;
 Fm6Lane*v=&p->lane[i];memset(v,0,sizeof *v);
 fm6_voice_t*s=&v->dsp;
 if(!p->gates++){
  if(p->patch[FP_LKS])p->lfo.ph=(1u<<31)-1u;
  p->lfo.dly=0;p->lfo.depth=0;
 }
 p->active++;v->active=v->gate=1;s->down=1;s->note=note;s->vel=velocity;
 fm6_keyed(s,p->patch,(unsigned)clamp(note+p->patch[FP_TRNSP]-24,0,127));
 for(unsigned j=0;j<6;j++)fm6_eg_go(&s->eg[j],p->patch+j*FP_OP,s->ol[j],s->rs[j],0);
 fm6_peg_set(&s->pe,p->patch);
 return 1;
}
void pc_fm6_off(unsigned owner,unsigned note){
 if(owner>PC_FM6_PREVIEW)return;
 Fm6Pad*p=&pads[owner];
 for(unsigned i=0;i<p->count;i++){
  Fm6Lane*v=&p->lane[i];
  if(v->active&&v->gate&&v->dsp.note==note){v->gate=0;p->gates--;}
 }
}
unsigned pc_fm6_voices(unsigned owner){return owner<=PC_FM6_PREVIEW?pads[owner].active:0;}
void pc_fm6_render(unsigned owner,float*l,float*r,unsigned frames){
 if(owner>PC_FM6_PREVIEW){memset(l,0,frames*4);memset(r,0,frames*4);return;}
 Fm6Pad*p=&pads[owner];fm6_scr_t scratch;
 // Maintain 64-sample control timing even across partial host blocks.
 unsigned at=0;
 while(at<frames){
  unsigned n=32-(p->sub&31u);if(n>frames-at)n=frames-at;
  if(!p->sub&&p->count)fm6_lfo_step(&p->lfo,p->patch);
  for(unsigned j=0;j<n;j++)l[at+j]=0;
  for(unsigned i=0;i<p->count;i++){
   Fm6Lane*v=&p->lane[i];fm6_voice_t*s=&v->dsp;
   if(!v->active)continue;
   if(!p->sub||!v->age||(!v->gate&&s->down))voice_control(p,v,s);
   fm6_run(s,n,&scratch);
   if(s->quiet>=2&&!v->tail)v->tail=132;
   for(unsigned j=0;j<n;j++){
    float fade=v->age<132?(float)++v->age/132:1;
    if(v->tail)fade*=v->tail--*(1.f/132);
    l[at+j]+=(float)clamp(scratch.sum[j],-(1<<28),(1<<28)-1)*(0x1p-26f*fade);
    if(s->quiet>=2&&!v->tail){v->active=0;p->active--;break;}
   }
  }
  while(p->count&&!p->lane[p->count-1].active)p->count--;
  for(unsigned j=0;j<n;j++){
   float x=l[at+j],y=x-p->x1+.997142858f*p->y1;
   p->x1=x;p->y1=(y>-1e-20f&&y<1e-20f)?0:y;
   l[at+j]=r[at+j]=p->y1;
  }
  p->sub=(p->sub+n)&63u;at+=n;
 }
}
