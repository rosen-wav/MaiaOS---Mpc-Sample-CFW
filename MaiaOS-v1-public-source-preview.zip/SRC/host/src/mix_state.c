/* SPDX-License-Identifier: GPL-3.0-only
 * Separate, checked section preserves older engine/chord state verbatim.
 * Persist track IDs and instrument indices, never process addresses or paths.
 */
#include "internal.h"
#define MIX_NOTE_LIMIT 1048576u
static const char start_tag[]="\n[MPC-PC-MIX:1]\n",end_tag[]="\n[/MPC-PC-MIX]\n",xml_tag[]="MpcPcMixV1";
typedef struct {char track[128];uint16_t instrument,reserved;uint32_t pad;uint64_t controls;} MixRecord;
_Static_assert(sizeof(MixRecord)==144,"mix record ABI");
typedef struct {uint32_t version,count,crc,fx_size;PcFxProject fx;MixRecord records[MIX_PADS];} MixSnapshot;
#define MIX_HEADER offsetof(MixSnapshot,records)
static MixSnapshot snapshot,pending;
static char encoded[MIX_NOTE_LIMIT];
static unsigned pending_valid,attempts,read_epoch,read_serial;
static uintptr_t read_project,read_first;
static size_t len(const char *s,size_t max){size_t n=0;if(s)while(n<max&&s[n])n++;return n;}
static size_t locate(const char *s,size_t n,const char *p,size_t k){for(size_t j=0;j+k<=n;j++)if(!memcmp(s+j,p,k))return j;return n;}
static uint32_t checksum(const void *data,size_t n){const uint8_t *b=data;uint32_t c=~0u;while(n--){c^=*b++;for(unsigned j=0;j<8;j++)c=(c>>1)^((0u-(c&1))&0xedb88320u);}return ~c;}
static int hex(char c){return c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:-1;}
static uintptr_t project(void){uintptr_t holder=Q(pc_state_base(),0x1e70),p=holder?Q(holder,0):Q(pc_state_base(),0x1e40);if(!p||Q(p,0)!=host.base+0x6ecc648)p=Q(pc_state_base(),0x1d08);return p&&Q(p,0)==host.base+0x6ecc648?p:0;}
static int tracks(uintptr_t p,uintptr_t *b,unsigned *n){
 if(!p||!Q(p,0x1288))return 0;uintptr_t list=FN(0x2925db0,uintptr_t(*)(uintptr_t))(Q(p,0x1288));if(!list)return 0;
 uintptr_t begin=Q(list,8),end=Q(list,16);if(!begin||end<begin||(end-begin)%8||end-begin>1024*8)return 0;*b=begin;*n=(unsigned)((end-begin)/8);return 1;
}
static int controls_valid(uint64_t c){return !(c>>52)&&((c>>42)&1023)<=841;}
void pc_mix_info_write(uintptr_t info){
 if(!host.ready||!info)return;
 if(pending_valid){return;}
 memset(&snapshot,0,sizeof snapshot);snapshot.version=1;snapshot.fx_size=sizeof(PcFxProject);
 if(!pc_fx_snapshot(&snapshot.fx)){pc_error(75);return;}
 uintptr_t list;unsigned count;if(!tracks(project(),&list,&count)){pc_error(75);return;}
 uintptr_t seen[MIX_PADS];unsigned total=0;
 for(unsigned t=0;t<count;t++){
  uintptr_t track=Q(list,t*8);if(!track||Q(track,0)!=host.base+0x6ecf118)continue;uintptr_t p=Q(track,0xbb8);
  if(!p||Q(p,0)!=host.base+0x6ec6860||I(p,0x1234))continue;
  const char *id=(const char *)Q(track,0x820);size_t length=len(id,128);if(!length||length>=128)continue;
  uintptr_t b=Q(p,0x2808),e=Q(p,0x2810);if(!b||e<b||(e-b)%8||e-b>128*8)continue;
  for(unsigned j=0;j<(e-b)/8;j++){
   uintptr_t i=Q(b,j*8);if(!pc_mix_nondefault(i))continue;unsigned duplicate=0;for(unsigned k=0;k<total;k++)duplicate|=seen[k]==i;if(duplicate)continue;
   if(total==MIX_PADS){pc_error(76);return;}
   MixRecord *r=&snapshot.records[total];seen[total++]=i;memcpy(r->track,id,length);r->instrument=(uint16_t)j;r->controls=pc_mix_controls(i);
  }
 }
 snapshot.count=total;size_t size=MIX_HEADER+total*sizeof(MixRecord);snapshot.crc=checksum(&snapshot.fx,size-16);
 const char *old=(const char *)Q(info,0x60);size_t n=len(old,MIX_NOTE_LIMIT),left=locate(old,n,start_tag,sizeof start_tag-1),right=n;
 if(n==MIX_NOTE_LIMIT){pc_error(75);return;}
 if(left<n){size_t off=left+sizeof start_tag-1;right=locate(old+off,n-off,end_tag,sizeof end_tag-1);if(right==n-off){pc_error(75);return;}right+=off+sizeof end_tag-1;}
 size_t tail=n-right,bytes=sizeof start_tag-1+size*2+sizeof end_tag-1;if(left+tail+bytes>=sizeof encoded){pc_error(75);return;}
 if(left)memcpy(encoded,old,left);size_t out=left;memcpy(encoded+out,start_tag,sizeof start_tag-1);out+=sizeof start_tag-1;
 static const char digits[]="0123456789abcdef";const uint8_t *data=(const uint8_t *)&snapshot;
 for(size_t j=0;j<size;j++){encoded[out++]=digits[data[j]>>4];encoded[out++]=digits[data[j]&15];}
 memcpy(encoded+out,end_tag,sizeof end_tag-1);out+=sizeof end_tag-1;if(tail){memcpy(encoded+out,old+right,tail);out+=tail;}encoded[out]=0;
 FN(0xf0a290,void(*)(uintptr_t))(info+0x60);FN(0xf535c0,void(*)(uintptr_t,const char *))(info+0x60,encoded);pc_error(0);
}
void pc_mix_new_project(unsigned serial){
 if(read_serial!=serial)pending_valid=0;
 pc_mix_reset();
}
void pc_mix_info_read(uintptr_t info){
 if(!host.ready||!info)return;pc_mix_reset();pending_valid=2;attempts=0;read_serial=pc_project_new_serial();read_project=project();read_epoch=__atomic_load_n(&host.project_epoch,AQ);
 uintptr_t list;unsigned count;read_first=tracks(read_project,&list,&count)&&count?Q(list,0):0;
 const char *old=(const char *)Q(info,0x60);size_t n=len(old,MIX_NOTE_LIMIT),at=locate(old,n,start_tag,sizeof start_tag-1);
 if(n==MIX_NOTE_LIMIT||at==n){return;}at+=sizeof start_tag-1;
 size_t end=locate(old+at,n-at,end_tag,sizeof end_tag-1),bytes=end/2;
 if(end==n-at||end%2||bytes<MIX_HEADER||bytes>sizeof pending){pending_valid=0;pc_error(77);return;}
 memset(&pending,0,sizeof pending);uint8_t *data=(uint8_t *)&pending;
 for(size_t j=0;j<bytes;j++){int a=hex(old[at+2*j]),b=hex(old[at+2*j+1]);if(a<0||b<0){pending_valid=0;pc_error(77);return;}data[j]=(uint8_t)((a<<4)|b);}
 if(pending.version!=1||pending.fx_size!=sizeof(PcFxProject)||pending.count>MIX_PADS||bytes!=MIX_HEADER+pending.count*sizeof(MixRecord)||checksum(&pending.fx,bytes-16)!=pending.crc){pending_valid=0;pc_error(77);return;}
 if(pending.fx.version!=1){pending_valid=0;pc_error(77);return;}
 for(unsigned k=0;k<3;k++){PcFxState *s=&pending.fx.slots[k];if(s->type< -1||s->type>=32||s->count>MIX_MAX_PARAMS||(s->type<0&&s->count)||(s->type>=28&&s->count!=6)){pending_valid=0;pc_error(77);return;}for(unsigned j=0;j<s->count;j++)if(!(s->params[j]>=0&&s->params[j]<=1)){pending_valid=0;pc_error(77);return;}}
 for(unsigned j=0;j<pending.count;j++){MixRecord *r=&pending.records[j];if(!r->track[0]||len(r->track,128)>=128||r->instrument>=128||r->reserved||r->pad||!controls_valid(r->controls)){pending_valid=0;pc_error(77);return;}}
 pending_valid=1;
}
void pc_mix_restore_poll(void){
 if(!host.ready||!pc_meta())return;
 if(!pending_valid){if(pc_mix_ensure())pc_mix_route_project();pc_unmeta();return;}
 uintptr_t list,p=project();unsigned count;
 if(!tracks(p,&list,&count)||!count||(p==read_project&&Q(list,0)==read_first&&__atomic_load_n(&host.project_epoch,AQ)==read_epoch)){pc_unmeta();return;}
 if(pending_valid==2){if(pc_mix_ensure())pending_valid=0;pc_unmeta();return;}
 uintptr_t instruments[MIX_PADS],programs[MIX_PADS];unsigned missing=0;
 for(unsigned k=0;k<pending.count;k++){
  MixRecord *r=&pending.records[k];uintptr_t instrument=0,program=0;
  for(unsigned t=0;t<count;t++){
   uintptr_t track=Q(list,t*8);if(!track||Q(track,0)!=host.base+0x6ecf118)continue;
   const char *id=(const char *)Q(track,0x820);size_t n=len(id,128);if(!n||n>=128||n!=len(r->track,128)||memcmp(id,r->track,n))continue;
   program=Q(track,0xbb8);if(!program||Q(program,0)!=host.base+0x6ec6860||I(program,0x1234)){program=0;continue;}
   uintptr_t b=Q(program,0x2808),e=Q(program,0x2810);if(b&&e>=b&&(e-b)%8==0&&e-b<=128*8&&r->instrument<(e-b)/8)instrument=Q(b,r->instrument*8);break;
  }
  instruments[k]=instrument;programs[k]=program;if(!instrument||!pc_valid(program,instrument))missing++;
 }
 if(missing){if(++attempts>=128){pending_valid=0;pc_error(78);}pc_unmeta();return;}
 if(!pc_fx_restore(&pending.fx)||!pc_mix_ensure()){pc_error(79);pc_unmeta();return;}
 for(unsigned k=0;k<pending.count;k++)if(!pc_mix_set_controls(programs[k],instruments[k],pending.records[k].controls))missing++;
 pending_valid=0;pc_error(missing?78:0);pc_unmeta();
}
int pc_mix_xml_write(uintptr_t i,uintptr_t xml){
 uint64_t controls=pc_mix_controls(i);if(controls==pc_mix_default())return 1;if(!xml)return 0;
 uint8_t bytes[16]={1};memcpy(bytes+4,&controls,8);uint32_t crc=checksum(bytes,12);memcpy(bytes+12,&crc,4);
 char text[33];static const char hexes[]="0123456789abcdef";for(unsigned k=0;k<16;k++){text[2*k]=hexes[bytes[k]>>4];text[2*k+1]=hexes[bytes[k]&15];}text[32]=0;
 uintptr_t name=0,value=0;FN(0xf535c0,void(*)(uintptr_t *,const char *))(&name,xml_tag);FN(0xf535c0,void(*)(uintptr_t *,const char *))(&value,text);
 uintptr_t node=FN(0x1da04a0,uintptr_t(*)(uintptr_t,uintptr_t *,uintptr_t *))(xml,&name,&value);FN(0xf0a290,void(*)(uintptr_t *))(&value);FN(0xf0a290,void(*)(uintptr_t *))(&name);return node!=0;
}
int pc_mix_xml_read(uintptr_t i,uintptr_t xml){
 if(!xml)return 0;const char *name=(const char *)Q(xml,0x18);if(!name||len(name,32)!=sizeof xml_tag-1||memcmp(name,xml_tag,sizeof xml_tag-1))return 0;
 uintptr_t value=FN(0x1da12b0,uintptr_t(*)(uintptr_t))(xml);const char *text=value?(const char *)Q(value,0):0;
 if(!text||len(text,33)!=32){pc_error(77);return 1;}uint8_t bytes[16];for(unsigned k=0;k<16;k++){int a=hex(text[2*k]),b=hex(text[2*k+1]);if(a<0||b<0){pc_error(77);return 1;}bytes[k]=(uint8_t)(a*16+b);}
 uint64_t controls;uint32_t crc;memcpy(&controls,bytes+4,8);memcpy(&crc,bytes+12,4);
 if(bytes[0]!=1||bytes[1]||bytes[2]||bytes[3]||crc!=checksum(bytes,12)||!controls_valid(controls)){pc_error(77);return 1;}
 if(!pc_meta()){pc_error(50);return 1;}if(!pc_mix_set_controls(Q(i,0x2310),i,controls))pc_error(78);pc_unmeta();return 1;
}

int pc_mix_needs_poll(void){return pending_valid||!pc_mix_ready();}

void pc_mix_route_project(void){
 uintptr_t list;unsigned count;if(!tracks(project(),&list,&count))return;
 for(unsigned n=0;n<count;n++){uintptr_t track=Q(list,n*8);if(track&&Q(track,0)==host.base+0x6ecf118)pc_mix_route_program(Q(track,0xbb8));}
}
