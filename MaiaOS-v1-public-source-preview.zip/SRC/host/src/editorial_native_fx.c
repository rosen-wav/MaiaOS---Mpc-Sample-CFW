/* SPDX-License-Identifier: GPL-3.0-only
 * Visual integration for the actual AC50 Pad FX / Flex Beat screens.
 * IMPORTANT: native ui::PadGrid and every native child painter are retained.
 * Names, pressure, latch, queued state, pattern paths and playhead continue to
 * come from stock widgets and stock signals. No reference thumbnail is used.
 * Only bounds / local colours change, through native Component setters.
 */
#include "internal.h"
#include "../theme/layout.h"
#define PAD_SCREEN 0x6e1f400u
#define FLEX_SCREEN 0x6e1d3f0u
#define GRID_VT 0x6e18010u
#define TILE_VT 0x6e18180u
static int set_bounds(uintptr_t c,int x,int y,int w,int h){
 if(I(c,0x20)==x&&I(c,0x24)==y&&I(c,0x28)==w&&I(c,0x2c)==h)return 0;
 uint64_t xy=(uint64_t)(uint32_t)x|((uint64_t)(uint32_t)y<<32),wh=(uint64_t)(unsigned)w|((uint64_t)(unsigned)h<<32);
 FN(0x1160fc0,void(*)(uintptr_t,uint64_t,uint64_t))(c,xy,wh);return 1;
}
static void rect(void*g,int x,int y,int w,int h,unsigned c){FN(0x102d5e0,void(*)(uintptr_t,unsigned))((uintptr_t)g,c);FN(0x102e000,void(*)(uintptr_t,int,int,int,int))((uintptr_t)g,x,y,w,h);}
int pc_editorial_native_fx(uintptr_t screen,uintptr_t graphics){
 uintptr_t vt=screen?Q(screen,0):0;int flex=vt==host.base+FLEX_SCREEN;
 if(vt!=host.base+PAD_SCREEN&&!flex)return 0;
 /* If any expected widget is absent, keep the original complete screen. */
 uintptr_t grid=screen+(flex?0x4f0:0x340),list=Q(grid,0xc8),end=Q(grid,0xd0);
 typedef struct{uint64_t xy,wh;} Bounds;Bounds b=FN(0x10f8ec0,Bounds(*)(uintptr_t))(screen);int w=(int)(uint32_t)b.wh,h=(int)(b.wh>>32);
 if(w!=320||h!=240||Q(grid,0)!=host.base+GRID_VT||!list||end<list||end-list!=16*8)goto fallback;
 for(unsigned k=0;k<16;k++){uintptr_t tile=Q(list,k*8);if(!tile||Q(tile,0)!=host.base+TILE_VT)goto fallback;}
 if(flex&&Q(screen+0x128,0)!=host.base+0x6d849e8)goto fallback;
 int locked=flex&&pc_flex_clock_external();
 if(flex&&Q(screen+0x920,0)==host.base+0x706e5d0){
  uintptr_t mix=screen+0x920;
  unsigned visible=(*(uint8_t*)(mix+0xa8)>>1)&1;
  if(visible==(unsigned)locked)FN(0x1172670,void(*)(uintptr_t,unsigned))(mix,!locked);
 }
 unsigned foreground=flex?MPC_THEME_TEXT:MPC_THEME_SELECTED;
 if((unsigned)I(grid,0xbc)!=MPC_THEME_SURFACE||(unsigned)I(grid,0xc0)!=foreground){
  unsigned surface=MPC_THEME_SURFACE,accent=foreground;
  FN(0x15babd0,void(*)(uintptr_t,const unsigned*,const unsigned*))(grid,&surface,&accent);
 }
 int changed=0,cell_changed=0;
 if(I(grid,0xb0)!=75||I(grid,0xb4)!=28){FN(0x15babb0,void(*)(uintptr_t,int,int))(grid,75,28);changed=cell_changed=1;}
 changed|=set_bounds(grid,0,70,320,128);
 if(cell_changed)FN(0x15b9e10,void(*)(uintptr_t))(grid);
 if(flex){
  /* Keep the native Label visible: its original signal must still invalidate
   * its real display area whenever the selected pattern name changes. */
  uintptr_t label=screen+0x128;
  if(set_bounds(label,8,51,200,17)){
   uint64_t font=0;FN(0x1082810,void(*)(void*,float,int))(&font,12.f,0);
   FN(0x114c0c0,void(*)(uintptr_t,const void*))(label,&font);
   FN(0x1070d60,void(*)(void*))(&font);changed=1;
  }
  changed|=set_bounds(screen+0x2d0,213,0,107,22); /* B3 Quantize, original widget */
 }else changed|=set_bounds(screen+0x120,0,0,106,22); /* B1 Latch, original widget */
 if(changed)FN(0x1149d70,void(*)(uintptr_t))(screen);
 EiCanvas e={(void*)graphics,rect,w,h};ei_rect(&e,0,0,w,h,MPC_THEME_BG);ei_rule(&e,22);
 pc_theme_title(&e,ei_rect,8,28,flex?"flex beat.":"pad fx.",w-16,MPC_THEME_TEXT);
 if(!flex)ei_text(&e,8,55,"PAD PRESSURE / LIVE",w-16,MPC_THEME_MUTED);
 /* Knob widgets retain their original 198..236 positions and model values. */
 ei_rule(&e,198);
 if(locked){
  ei_text(&e,8,204,"EXTERNAL MIDI CLOCK",197,MPC_THEME_MUTED);
  ei_text(&e,219,204,"MIX 0%",94,MPC_THEME_ACCENT);
 }
 return 1;
fallback:
 FN(flex?0x1610bc0:0x163eb00,void(*)(uintptr_t,uintptr_t))(screen,graphics);return 1;
}

/* Native child invalidation remains authoritative, so pressure redraws even
 * when JUCE invalidates only one pad rather than the full parent screen. */
int pc_editorial_native_fx_tile(uintptr_t tile,uintptr_t graphics){
 if(!tile||Q(tile,0)!=host.base+TILE_VT)return 0;
 uintptr_t grid=Q(tile,0x18),screen=grid?Q(grid,0x18):0;
 if(!grid||Q(grid,0)!=host.base+GRID_VT||!screen||Q(screen,0)!=host.base+PAD_SCREEN)return 0;
 uintptr_t impl=Q(tile,0x160);if(!impl)return 0;double value=*(double*)(impl+0x80);
 int w=I(tile,0x28),h=I(tile,0x2c);if(w<20||w>320||h<18||h>80||!(value>=0&&value<=1))return 0;
 rect((void*)graphics,5,h-5,w-10,2,MPC_THEME_GRID);
 int width=(int)((w-10)*value+.5);if(width)rect((void*)graphics,5,h-5,width,2,MPC_THEME_ACCENT);return 1;
}
