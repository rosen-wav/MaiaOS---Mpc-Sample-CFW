/* SPDX-License-Identifier: GPL-3.0-only
 * DX7 bit packing and CZ transport match the included Melodee sources by
 * Kerem Kilic (Ellic Studio), fm6_store.c, eng_fm6.c and cz_store.c.
 * File parser only: never accesses a DSP, filesystem or native object.
 */
#include "syx.h"
extern void*memcpy(void*,const void*,__SIZE_TYPE__);extern void*memset(void*,int,__SIZE_TYPE__);
#include "../dsp/new/melodee/cz_patch.h"
unsigned pc_syx_crc(const uint8_t*p,unsigned n){unsigned c=~0u;while(n--){c^=*p++;for(unsigned k=0;k<8;k++)c=c>>1^(0xedb88320u&-(c&1));}return ~c;}
void pc_dx7_unpack(const uint8_t*b,uint8_t*v){
 for(unsigned k=0;k<6;k++){const uint8_t*o=b+17*k;uint8_t*d=v+21*k;memcpy(d,o,11);d[11]=o[11]&3;d[12]=o[11]>>2&3;d[13]=o[12]&7;d[20]=o[12]>>3&15;d[14]=o[13]&3;d[15]=o[13]>>2&7;d[16]=o[14];d[17]=o[15]&1;d[18]=o[15]>>1&31;d[19]=o[16];}
 memcpy(v+126,b+102,9);v[135]=b[111]&7;v[136]=b[111]>>3&1;memcpy(v+137,b+112,4);v[141]=b[116]&1;v[142]=b[116]>>1&7;v[143]=b[116]>>4&7;v[144]=b[117];memcpy(v+145,b+118,10);v[155]=63;
}
void pc_dx7_pack(const uint8_t*v,uint8_t*b){
 for(unsigned k=0;k<6;k++){const uint8_t*o=v+21*k;uint8_t*d=b+17*k;memcpy(d,o,11);d[11]=o[11]|o[12]<<2;d[12]=o[13]|o[20]<<3;d[13]=o[14]|o[15]<<2;d[14]=o[16];d[15]=o[17]|o[18]<<1;d[16]=o[19];}
 memcpy(b+102,v+126,9);b[111]=v[135]|v[136]<<3;memcpy(b+112,v+137,4);b[116]=v[141]|v[142]<<1|v[143]<<4;b[117]=v[144];memcpy(b+118,v+145,10);
}
int pc_dx7_valid(const uint8_t*v){
 static const uint8_t lim[21]={127,127,127,127,99,99,99,99,99,99,99,3,3,7,3,7,99,1,31,99,14};
 for(unsigned k=0;k<126;k++)if(v[k]>lim[k%21])return 0;
 for(unsigned k=126;k<134;k++)if(v[k]>99)return 0;
 if(v[134]>31||v[135]>7||v[136]>1||v[141]>1||v[142]>5||v[143]>7||v[144]>48)return 0;
 for(unsigned k=137;k<141;k++)if(v[k]>99)return 0;
 for(unsigned k=145;k<155;k++)if(v[k]>127)return 0;return 1;
}
static void name(char*out,const uint8_t*in,unsigned n){unsigned i=0;for(;i<n&&i<24;i++)out[i]=in[i]>=32&&in[i]<127?in[i]:' ';while(i&&out[i-1]==' ')i--;out[i]=0;if(!i)memcpy(out,"Imported tone",14);}
static int frame(const uint8_t*b,unsigned n,unsigned e,PcSyxVoice*out,unsigned cap){
 if(n<7||b[0]!=240||b[n-1]!=247||!cap)return -1;
 for(unsigned k=1;k+1<n;k++)if(b[k]>127)return -1;
 if(e==4){
  if(b[1]!=0x43||b[2]>15)return -2;
  unsigned count=0,bytes=0;
  if(n==163&&b[3]==0&&b[4]==1&&b[5]==0x1b){count=1;bytes=155;}
  else if(n==4104&&b[3]==9&&b[4]==0x20&&b[5]==0){count=32;bytes=4096;}else return -2;
  if(count>cap)return -3;unsigned sum=b[n-2];for(unsigned k=0;k<bytes;k++)sum+=b[6+k];if(sum&127)return -4;
  for(unsigned k=0;k<count;k++){
   uint8_t v[156];if(count==1)memcpy(v,b+6,155);else pc_dx7_unpack(b+6+128*k,v);
   if(!pc_dx7_valid(v))return -5;
   out[k].engine=e;out[k].size=128;if(count==1)pc_dx7_pack(v,out[k].raw);else memcpy(out[k].raw,b+6+128*k,128);name(out[k].name,v+145,10);
  }return (int)count;
 }
 if(e==7){
  if(b[1]!=0x44||b[2]||b[3]||(b[4]&0xf0)!=0x70)return -2;
  unsigned offset=6,bytes=0;
  if(b[5]==0x30&&(n==263||n==295))bytes=n-7;
  else if((b[5]==0x20&&n==264)||(b[5]==0x21&&n==296)){offset=7;bytes=n-8;if(b[6]>0x7f)return -2;}else return -2;
  uint8_t raw[144];memset(raw,0,144);memset(raw+128,' ',16);
  for(unsigned j=0;j<bytes;j++)if(b[offset+j]>15)return -5;
  for(unsigned j=0;j<bytes/2;j++)raw[j]=b[offset+2*j]|b[offset+2*j+1]<<4;
  if(bytes==256){static const uint8_t kw[]={0,31,44,57,70,83,96,111,146,255};for(unsigned l=0;l<2;l++){unsigned o=l*57;if((raw[18+o]&15)>9)return -5;raw[16+o]&=15;raw[19+o]=kw[raw[18+o]&15];for(unsigned j=20;j<=54;j+=17)raw[j+o]|=240;}}
  if(!cz_patch_valid(raw))return -5;out->engine=e;out->size=144;memcpy(out->raw,raw,144);name(out->name,raw+128,16);return 1;
 }
 return -2;
}
int pc_syx_parse(const uint8_t*data,unsigned bytes,unsigned engine,PcSyxVoice*out,unsigned capacity){
 if(engine==9){extern int pc_rs_import(const uint8_t*,unsigned,uint8_t*,char*,unsigned*);if(!out||!capacity)return -3;unsigned warnings=0;memset(out,0,sizeof*out);if(!pc_rs_import(data,bytes,out->raw,out->name,&warnings))return -2;out->engine=9;out->size=102;out->raw[143]=warnings;return 1;}
 if(!data||!out||!capacity||capacity>PC_SYX_MAX||!bytes||bytes>1048576)return -1;
 uint8_t buffer[4104];unsigned used=0,count=0;int on=0;
 for(unsigned i=0;i<bytes;i++){
  unsigned b=data[i];if(b>=248)continue;
  if(!on){if(b!=240)return -1;on=1;used=0;}else if(b>=128&&b!=247)return -1;
  if(used==sizeof buffer)return -1;buffer[used++]=b;
  if(b==247){int n=frame(buffer,used,engine,out+count,capacity-count);if(n<0)return n;count+=(unsigned)n;on=0;}
 }
 return on||!count?-1:(int)count;
}
