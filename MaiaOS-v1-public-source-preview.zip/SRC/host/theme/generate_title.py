from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import os
r=Path(__file__).resolve().parent;f=ImageFont.truetype(str(r/'fonts/SpaceGrotesk.ttf'),18);rows=[];adv=[]
for code in range(32,127):
 im=Image.new('L',(24,20));ImageDraw.Draw(im).text((0,16),chr(code),font=f,fill=255,anchor='ls');glyph=[]
 for y in range(20):
  glyph.append([sum(((im.getpixel((x,y))*15+127)//255)<<(4*(x%16)) for x in range(start,end)) for start,end in [(0,16),(16,24)]])
 rows.append(glyph);adv.append(round(f.getlength(chr(code))*64))
s='/* Space Grotesk 18px, pre-rasterized 4-bit coverage. See fonts/SpaceGrotesk-OFL.txt */\nstatic const unsigned long long ei_title[95][20][2]={\n'
for glyph in rows:s+='{'+','.join('{0x%xull,0x%xull}'%tuple(row) for row in glyph)+'},\n'
s+='};\nstatic const unsigned short ei_title_advance[95]={'+','.join(map(str,adv))+'};\n';p=r/'title_aa.h';p.write_text(s);os.utime(p,(3000000050,3000000050))
