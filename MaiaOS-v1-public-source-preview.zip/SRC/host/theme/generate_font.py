"""Generate the fixed 8x12 MPC Minimal Mono bitmap; requires Pillow.
Use the supplied DejaVu license when distributing the generated header.
"""
import argparse
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
p=argparse.ArgumentParser();p.add_argument('--font',type=Path,default=Path('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'));p.add_argument('--output',type=Path,default=Path(__file__).with_name('font.h'));a=p.parse_args()
f=ImageFont.truetype(str(a.font),11);rows=[]
for code in range(32,127):
 im=Image.new('L',(8,12));d=ImageDraw.Draw(im);d.text((0,9),chr(code),font=f,fill=255,anchor='ls',stroke_width=0)
 rows.append([sum((1<<x) for x in range(8) if im.getpixel((x,y))>=112) for y in range(12)])
assert all(0<=v<256 for r in rows for v in r)
assert all(any(r) for r in rows[1:]), 'Printable glyph clipped'
s='/* MPC Minimal Mono 8x12, derived from DejaVu Sans Mono.\n * Copyright Bitstream, Inc.; DejaVu changes public domain.\n * See FONT-LICENSE.txt. Cell advance 8; line height 12. */\n#ifndef MPC_MINIMAL_FONT_H\n#define MPC_MINIMAL_FONT_H\nstatic const unsigned char pc_minimal_font[95][12]={\n'
s+='\n'.join('{'+','.join(map(str,r))+'},' for r in rows)+'\n};\n#endif\n';a.output.write_text(s)
