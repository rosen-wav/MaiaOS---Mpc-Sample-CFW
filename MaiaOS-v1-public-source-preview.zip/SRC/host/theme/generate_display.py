"""Hinted, native-size glyphs: never enlarge the old 12px bitmap. OFL fonts."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import os
r=Path(__file__).resolve().parent;faces=[];advances=[]
for name,size,bold in [('IBMPlexMono-Regular.ttf',20,False),('IBMPlexMono-Regular.ttf',24,False),('IBMPlexMono-Regular.ttf',28,False),('SpaceGrotesk.ttf',28,True)]:
 f=ImageFont.truetype(str(r/'fonts'/name),size)
 if bold:f.set_variation_by_axes([600])
 glyphs=[];advance=[]
 for code in range(32,127):
  im=Image.new('L',(32,36));ImageDraw.Draw(im).text((0,size),chr(code),font=f,fill=255,anchor='ls')
  glyphs.append([[sum(((im.getpixel((x,y))*15+127)//255)<<(4*(x%16)) for x in range(start,start+16)) for start in (0,16)] for y in range(36)])
  advance.append(round(f.getlength(chr(code))*64))
 faces.append(glyphs);advances.append(advance)
s='/* IBM Plex Mono 20/24/28px; Space Grotesk 600 28px. OFL fonts/. */\nstatic const unsigned long long ei_display[4][95][36][2]={\n'
for face in faces:
 s+='{\n'
 for glyph in face:s+='{'+','.join('{0x%xull,0x%xull}'%tuple(row) for row in glyph)+'},\n'
 s+='},\n'
s+='};\nstatic const unsigned short ei_display_advance[4][95]={'+','.join('{'+','.join(map(str,a))+'}' for a in advances)+'};\n'
p=r/'display_aa.h';p.write_text(s);os.utime(p,(3000310500,3000310500))
