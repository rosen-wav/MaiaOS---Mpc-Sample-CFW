/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef PC_MULTISAMPLE_TEXT_H
#define PC_MULTISAMPLE_TEXT_H
#include "layout.h"

typedef struct {
 unsigned offset;
 unsigned char advance,x,y,w,h;
} MsGlyph;
typedef struct {unsigned height;MsGlyph glyphs[95];} MsFont;
#include "multisample_font_aa.h"

enum {MS_PLEX_24=7,MS_PLEX_28,MS_SPACE_28};
static void ms_font_draw(EiCanvas*c,int x,int y,const char*text,int width,const MsFont *font,unsigned colour){
 if(!text||width<=0||x>=c->w)return;
 if(width>c->w-x)width=c->w-x;
 if(width>1024)return;
 const MsGlyph *glyph[96];
 unsigned length=0,pen=0,extent=0;
 for(;length<96&&text[length];length++){
  unsigned ch=(unsigned char)text[length];if(ch<32||ch>126)ch='?';
  const MsGlyph *g=&font->glyphs[ch-32];
  glyph[length]=g;
  if(g->w&&pen+g->x+g->w>extent)extent=pen+g->x+g->w;
  pen+=g->advance;
 }
 if(!extent)return;
 unsigned ink=extent>(unsigned)width?(unsigned)width:extent;
 colour=pc_theme_text_colour(colour);
 /* Box-filter the coverage horizontally when a field is narrow. Native rows
  * stay at their original height and thin strokes retain partial coverage. */
 for(unsigned row=0;row<font->height;row++){
  unsigned coverage[1024];
  memset(coverage,0,ink*sizeof *coverage);
  pen=0;
  for(unsigned k=0;k<length;k++){
   const MsGlyph *g=glyph[k];
   if(row>=g->y&&row<g->y+g->h){
    const unsigned char *pixels=ms_font_pixels+g->offset+(row-g->y)*g->w;
    for(unsigned col=0;col<g->w;col++){
     if(!pixels[col])continue;
     unsigned left=(pen+g->x+col)*ink,limit=left+ink;
     while(left<limit){
      unsigned pos=left/extent,end=(pos+1)*extent;
      if(end>limit)end=limit;
      coverage[pos]+=pixels[col]*(end-left);
      left=end;
     }
    }
   }
   pen+=g->advance;
  }
  for(unsigned col=0;col<ink;){
   unsigned alpha=(coverage[col]+extent/2)/extent;
   if(alpha>255)alpha=255;
   if(!alpha){col++;continue;}
   unsigned first=col++;
   while(col<ink&&(coverage[col]+extent/2)/extent==alpha)col++;
   ei_rect(c,x+first,y+row,col-first,1,(colour&0xffffffu)|((alpha*(colour>>24)/255)<<24));
  }
 }
}
#endif
