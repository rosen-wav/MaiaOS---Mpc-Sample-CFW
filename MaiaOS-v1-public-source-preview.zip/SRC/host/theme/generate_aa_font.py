"""Offline hinted Roboto atlas: proportional labels, fixed numeric advance.
The renderer preserves field anchors, original field width and line height.
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
r=Path(__file__).resolve().parent;atlases=[];advances=[];ink=[]
for weight in ['Regular','Medium']:
 font=ImageFont.truetype(str(r/'fonts'/('Roboto-'+weight+'.ttf')),12);rows=[];advance=[];widths=[]
 for code in range(32,127):
  ch=chr(code);box=font.getbbox(ch,anchor='ls');im=Image.new('L',(12,12));ImageDraw.Draw(im).text((-min(0,box[0]),10),ch,font=font,fill=255,anchor='ls')
  values=[sum(min(15,(im.getpixel((x,y))*15+127)//255)<<(4*x) for x in range(12)) for y in range(12)]
  if code!=32 and not any(values):
   if code==95:values[11]=0x00000ffffff0
   else:raise ValueError('Glyph clipped: '+ch)
  widths.append(max((x+1 for row in values for x in range(12) if (row>>(4*x))&15),default=0));rows.append(values);advance.append(8*64 if ch.isdigit() else round(font.getlength(ch)*64))
 atlases.append(rows);advances.append(advance);ink.append(widths)
s='/* Roboto Regular/Medium. Copyright 2011 Google Inc.; Apache-2.0.\n * Height 12, maximum ink 12. Advances in 1/64 px; numeric advance 8. */\n#ifndef PC_FONT_AA_H\n#define PC_FONT_AA_H\nstatic const unsigned long long pc_font_aa[2][95][12]={\n'
for rows in atlases:s+='{\n'+'\n'.join('{'+','.join('0x%012xull'%v for v in row)+'},' for row in rows)+'\n},\n'
s+='};\nstatic const unsigned char pc_font_ink_width[2][95]={\n'+',\n'.join('{'+','.join(map(str,row))+'}' for row in ink)+'\n};\nstatic const unsigned short pc_font_advance[2][95]={\n'+',\n'.join('{'+','.join(map(str,row))+'}' for row in advances)+'\n};\n#endif\n';(r/'font_aa.h').write_text(s)
