/* SPDX-License-Identifier: GPL-3.0-only
 * Editorial Instrument static ink renderer. Anchors and available field width come from the
 * existing screen code; only glyph shapes/spacing change inside those bounds.
 */
#ifndef PC_THEME_TEXT_H
#define PC_THEME_TEXT_H
#include "minimal.h"
#include "font_aa.h"
#include "title_aa.h"
typedef void (*PcThemeRect)(void *,int,int,int,int,unsigned);
static inline int pc_theme_button_start(const char *s,unsigned n){return n&&s[n-1]==' '&&s[n]=='B'&&s[n+1]>='1'&&s[n+1]<='3'&&s[n+2]==' ';}
static inline void pc_theme_text_face_width(void *canvas,PcThemeRect draw,int x,int y,const char *s,unsigned limit,unsigned color,unsigned weight,unsigned height,unsigned available){
 if(!s||!limit)return;unsigned pen=0,extent=0,length=0;
 for(;length<limit&&s[length];length++){
  unsigned ch=(unsigned char)s[length];if(ch<32||ch>126)ch='?';if(pc_theme_button_start(s,length))pen=length*8*64;
  if(ch!=' '){unsigned end=pen+pc_font_ink_width[weight][ch-32]*64;if(end>extent)extent=end;}pen+=pc_font_advance[weight][ch-32];
 }
 unsigned width=available*64*12/height,scale=extent>width?(unsigned)((unsigned long long)width*65536/extent):65536;pen=0;
 color=pc_theme_text_colour(color);
 for(unsigned n=0;n<length;n++){
  unsigned ch=(unsigned char)s[n];if(ch<32||ch>126)ch='?';if(pc_theme_button_start(s,n))pen=n*8*64;
  for(unsigned row=0;row<12;row++){
   unsigned long long data=pc_font_aa[weight][ch-32][row];
   for(unsigned col=0;col<12;){unsigned coverage=(unsigned)(data>>(4*col))&15;if(!coverage){col++;continue;}unsigned start=col;
    while(col<12&&((unsigned)(data>>(4*col))&15)==coverage)col++;
    int left=(int)((unsigned long long)(pen+start*64)*scale/(64*65536)),right=(int)((unsigned long long)(pen+col*64)*scale/(64*65536));
    left=left*(int)height/12;right=right*(int)height/12;int top=row*height/12,bottom=(row+1)*height/12;
    if(right>left&&bottom>top)draw(canvas,x+left,y+top,right-left,bottom-top,(color&0xffffffu)|(((color>>24)*coverage/15)<<24));
   }
  }
  pen+=pc_font_advance[weight][ch-32];
 }
}
static inline void pc_theme_text_face(void*c,PcThemeRect d,int x,int y,const char*s,unsigned limit,unsigned color,unsigned weight,unsigned height){pc_theme_text_face_width(c,d,x,y,s,limit,color,weight,height,limit*8);}
static inline void pc_theme_text_fit(void*c,PcThemeRect d,int x,int y,const char*s,unsigned width,unsigned color){if(width)pc_theme_text_face_width(c,d,x,y,s,96,color,0,12,width);}
static inline void pc_theme_text(void*c,PcThemeRect d,int x,int y,const char*s,unsigned limit,unsigned color){pc_theme_text_face(c,d,x,y,s,limit,color,0,12);}
static inline void pc_theme_title(void*c,PcThemeRect d,int x,int y,const char*s,unsigned width,unsigned color){
 if(!s||!width)return;unsigned extent=0,n=0;for(;n<70&&s[n];n++){unsigned ch=(unsigned char)s[n];if(ch<32||ch>126)ch='?';extent+=ei_title_advance[ch-32];}
 unsigned scale=extent>width*64?(unsigned)((unsigned long long)width*64*65536/extent):65536,pen=0;color=pc_theme_text_colour(color);
 for(unsigned k=0;k<n;k++){unsigned ch=(unsigned char)s[k];if(ch<32||ch>126)ch='?';
  for(unsigned row=0;row<20;row++)for(unsigned col=0;col<24;){unsigned cov=ei_title[ch-32][row][col/16]>>(4*(col%16))&15;if(!cov){col++;continue;}unsigned first=col++;
   while(col<24&&((ei_title[ch-32][row][col/16]>>(4*(col%16)))&15)==cov)col++;
   int left=(unsigned long long)(pen+first*64)*scale/(64*65536),right=(unsigned long long)(pen+col*64)*scale/(64*65536);
   if(right>left)d(c,x+left,y+row,right-left,1,(color&0xffffffu)|(((color>>24)*cov/15)<<24));}
  pen+=ei_title_advance[ch-32];}
}
#endif
