/* SPDX-License-Identifier: GPL-3.0-only
 * Editorial Instrument: one shared opaque/alpha-preserving ARGB palette.
 * This function changes colour only. It has no access to geometry, events,
 * audio, allocations, state or native objects. Safe for freestanding builds.
 */
#ifndef MPC_MINIMAL_THEME_H
#define MPC_MINIMAL_THEME_H
#define MPC_THEME_BG       0xff141917u
#define MPC_THEME_SURFACE  0xff1e2421u
#define MPC_THEME_SELECTED 0xff36312bu
#define MPC_THEME_LINE     0xff6b716au
#define MPC_THEME_GRID     0xff363b38u
#define MPC_THEME_TEXT     0xffe9e7dfu
#define MPC_THEME_MUTED    0xffb8bcb4u
#define MPC_THEME_DIM      0xff9b9f98u
#define MPC_THEME_ACCENT   0xffd66142u
#define MPC_THEME_WARNING  0xffffa88du
#define MPC_THEME_DANGER   0xffd66142u
static inline unsigned pc_theme_colour(unsigned argb){
 unsigned alpha=argb&0xff000000u,c=argb&0xffffffu,out=c;
 if(!alpha)return argb;
 /* Theme outputs are fixed points, so a shared renderer can map colours
  * already mapped by a DSP panel without altering contrast a second time. */
 switch(c){
 case 0x65cfa8:out=MPC_THEME_ACCENT;break;
 case 0x181818:case 0x18232d:out=MPC_THEME_SURFACE;break;
 case 0xb8b8b8:case 0x909090:out=MPC_THEME_MUTED;break;
 case 0x606870:out=MPC_THEME_DIM;break;
 case 0x0c0e0e:out=MPC_THEME_BG;break;
 case 0x141717:out=MPC_THEME_SURFACE;break;
 case 0x24342e:out=MPC_THEME_SELECTED;break;
 case 0x303736:out=MPC_THEME_LINE;break;
 case 0x232928:out=MPC_THEME_GRID;break;
 case 0xf0f3f1:out=MPC_THEME_TEXT;break;
 case 0xa4aca8:out=MPC_THEME_MUTED;break;
 case 0x646e69:out=MPC_THEME_DIM;break;
 case 0x9cebd0:out=0xffd66142u;break;
 case 0xe8c17d:out=MPC_THEME_WARNING;break;
 case 0xff625b:out=0xffd66142u;break;
 case 0xc9cfcc:out=MPC_THEME_MUTED;break;
 case 0x141917:case 0x1e2421:case 0x36312b:case 0x6b716a:case 0x363b38:
 case 0xe9e7df:case 0xb8bcb4:case 0x9b9f98:case 0xd66142:case 0xffa88d:return argb;
 case 0x10151c:case 0x10151b:case 0x0d131b:out=MPC_THEME_BG;break;
 case 0x1b2530:case 0x1c2631:case 0x1a2531:case 0x18222d:out=MPC_THEME_SURFACE;break;
 case 0x293f50:case 0x30414e:case 0x233145:case 0x26394b:case 0x293a4c:out=MPC_THEME_SELECTED;break;
 case 0x293442:case 0x293444:case 0x35404e:out=MPC_THEME_GRID;break;
 case 0x4b596b:out=MPC_THEME_LINE;break;
 case 0xffffff:case 0xf0f2f4:out=MPC_THEME_TEXT;break;
 case 0xadb7c4:case 0x9aa8b5:case 0xaebccb:case 0xc6d1db:out=MPC_THEME_MUTED;break;
 case 0x8798a8:case 0x9aaab9:out=MPC_THEME_DIM;break;
 case 0x65e5c0:case 0x61dfc1:case 0xffc56c:case 0xafa5ff:
 case 0xe8b46b:case 0xa6d98a:case 0x77d8dc:out=MPC_THEME_ACCENT;break;
 case 0xffcf66:out=MPC_THEME_WARNING;break;
 default:return argb;
 }
 return alpha|(out&0xffffffu);
}
/* Text-role mapping is separate from fill-role mapping. On dark mod surfaces,
 * ink must never inherit a background/line colour or orange selection fill.
 * Alpha coverage is applied by the glyph rasterizer AFTER this decision. */
static inline unsigned pc_theme_text_colour(unsigned argb){
 if(!(argb>>24))return argb;unsigned c=pc_theme_colour(argb)&0xffffffu;
 switch(c){case 0x141917:case 0x1e2421:case 0x36312b:case 0x363b38:case 0x6b716a:case 0xd66142:case 0x000000:return MPC_THEME_TEXT;}
 unsigned r=c>>16,g=c>>8&255,b=c&255;
 if(((54*r+183*g+19*b)>>8)<140)return MPC_THEME_MUTED;
 return 0xff000000u|c;
}
static inline unsigned pc_theme_font_weight(unsigned colour){
 unsigned c=pc_theme_colour(colour)&0xffffffu;
 return c==(MPC_THEME_TEXT&0xffffffu)||c==(MPC_THEME_ACCENT&0xffffffu)||c==(MPC_THEME_WARNING&0xffffffu)||c==(MPC_THEME_DANGER&0xffffffu);
}
/* Native paint calls have no semantic palette labels. Keep neutral values
 * neutral, replace accent families, and use the orange family for focus/record/error markers. */
static inline unsigned pc_native_theme_colour(unsigned argb){
 switch(argb&0xffffffu){
 case 0x141917:case 0x1e2421:case 0x36312b:case 0x6b716a:case 0x363b38:
 case 0xe9e7df:case 0xb8bcb4:case 0x9b9f98:case 0xd66142:case 0xffa88d:return argb;
 }
 unsigned known=pc_theme_colour(argb);if(known!=argb)return known;
 unsigned a=argb&0xff000000u,c=argb&0xffffffu;if(!a)return argb;
 unsigned r=c>>16,g=c>>8&255,b=c&255,hi=r>g?r:g;if(b>hi)hi=b;
 unsigned lo=r<g?r:g;if(b<lo)lo=b;unsigned out=c;
 if(hi-lo<20){unsigned y=(54*r+183*g+19*b)>>8;
  if(y<10)out=MPC_THEME_BG;else if(y<31)out=MPC_THEME_SURFACE;
  else if(y<65)out=MPC_THEME_GRID;else if(y<150)out=MPC_THEME_DIM;
  else if(y<225)out=MPC_THEME_MUTED;else out=MPC_THEME_TEXT;
 }else if(r>170&&r>g*3/2&&g<130&&b<140)out=MPC_THEME_DANGER;
 else if(r>190&&g>145&&b<140)out=MPC_THEME_WARNING;
 else if(hi<72)out=hi<30?MPC_THEME_BG:MPC_THEME_SURFACE;
 else out=MPC_THEME_ACCENT;
 return a|(out&0xffffffu);
}
/* Convert prepainted r1 synth panels, including their antialias pixels.
 * DSP code and sample processing remain byte-identical. */
static inline unsigned pc_theme_legacy_panel(unsigned argb){
 unsigned a=argb&0xff000000u,c=argb&0xffffffu,r=c>>16,g=c>>8&255,b=c&255;
 if(r>g+24&&r>b+24)return argb; /* orange curves/focus */
 unsigned y=(54*r+183*g+19*b)>>8;
 unsigned p=y<=24?255:y>=231?0:(231-y)*255/207;
 unsigned br=20,bg=25,bb=23,fr=233,fg=231,fb=223;
 return a|((br+(fr-br)*p/255)<<16)|((bg+(fg-bg)*p/255)<<8)|(bb+(fb-bb)*p/255);
}
#endif
