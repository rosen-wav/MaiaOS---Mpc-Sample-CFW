/* SPDX-License-Identifier: GPL-3.0-only
 * Editorial Instrument layout primitives; visual-only and allocation-free.
 * Every renderer uses semantic ink/surface roles instead of guessing from RGB.
 */
#ifndef EI_LAYOUT_H
#define EI_LAYOUT_H
#include "text.h"
#include "display_aa.h"
typedef struct {void *context;PcThemeRect draw;int w,h;} EiCanvas;
static inline void ei_rect(void*v,int x,int y,int w,int h,unsigned colour){EiCanvas*c=v;if(w<=0||h<=0)return;if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}if(x>=c->w||y>=c->h||w<=0||h<=0)return;if(w>c->w-x)w=c->w-x;if(h>c->h-y)h=c->h-y;c->draw(c->context,x,y,w,h,colour);}
static inline void ei_text(EiCanvas*c,int x,int y,const char*s,int width,unsigned colour){if(width>0)pc_theme_text_face_width(c,ei_rect,x,y,s,96,colour,0,12,width);}
static inline void ei_display_text(EiCanvas*c,int x,int y,const char*s,int width,unsigned face,unsigned colour){
 if(!s||width<=0)return;unsigned extent=0,n=0;for(;n<48&&s[n];n++){unsigned ch=(unsigned char)s[n];if(ch<32||ch>126)ch='?';extent+=ei_display_advance[face][ch-32];}
 unsigned scale=extent>(unsigned)width*64?(unsigned)((unsigned long long)width*64*65536/extent):65536,pen=0;colour=pc_theme_text_colour(colour);
 for(unsigned k=0;k<n;k++){unsigned ch=(unsigned char)s[k];if(ch<32||ch>126)ch='?';
  for(unsigned row=0;row<36;row++)for(unsigned col=0;col<32;){unsigned cov=ei_display[face][ch-32][row][col/16]>>(4*(col%16))&15;if(!cov){col++;continue;}unsigned first=col++;while(col<32&&((ei_display[face][ch-32][row][col/16]>>(4*(col%16)))&15)==cov)col++;
   int l=(unsigned long long)(pen+first*64)*scale/(64*65536),r=(unsigned long long)(pen+col*64)*scale/(64*65536);if(r>l)ei_rect(c,x+l,y+row,r-l,1,(colour&0xffffffu)|(((colour>>24)*cov/15)<<24));}
  pen+=ei_display_advance[face][ch-32];}
}
static inline void ei_value(EiCanvas*c,int x,int y,const char*s,int width,unsigned height,unsigned colour){ei_display_text(c,x,y,s,width,height>=26?2:height>=22?1:0,colour);}
static inline void ei_heading(EiCanvas*c,int x,int y,const char*s,int width){ei_display_text(c,x,y,s,width,3,MPC_THEME_TEXT);}
static inline void ei_rule(EiCanvas*c,int y){ei_rect(c,8,y,c->w-16,1,MPC_THEME_GRID);}
static inline void ei_header(EiCanvas*c,const char*left,const char*right){ei_rect(c,0,0,c->w,c->h,MPC_THEME_BG);int rw=right&&right[0]?80:0;ei_text(c,8,5,left,c->w-16-rw,MPC_THEME_MUTED);if(rw)ei_text(c,c->w-rw-8,5,right,rw,MPC_THEME_MUTED);ei_rule(c,22);}
/* Footer geometry and ink are identical for native/mod commands. */
static inline void ei_actions_at(EiCanvas*c,int y,const char*a,const char*b,const char*d){
 ei_rect(c,0,y,c->w,c->h-y<25?c->h-y:25,MPC_THEME_BG);ei_rule(c,y);
 const char*labels[3]={a,b,d};for(unsigned k=0;k<3;k++){int x=k*c->w/3;char key[3]={'B',(char)('1'+k),0};if(k)ei_rect(c,x,y+6,1,12,MPC_THEME_GRID);ei_text(c,x+7,y+7,key,17,MPC_THEME_TEXT);ei_text(c,x+28,y+7,labels[k],c->w/3-34,MPC_THEME_TEXT);}
}
static inline void ei_actions(EiCanvas*c,const char*a,const char*b,const char*d){ei_actions_at(c,c->h-25,a,b,d);}
static inline void ei_notice(EiCanvas*c,const char*s){if(!s||!s[0])return;ei_rect(c,8,c->h-45,c->w-16,17,MPC_THEME_SURFACE);ei_text(c,12,c->h-43,s,c->w-24,MPC_THEME_WARNING);}
static inline void ei_bar(EiCanvas*c,int x,int y,int width,unsigned position){if(position>16383)position=16383;ei_rect(c,x,y,width,3,MPC_THEME_GRID);ei_rect(c,x,y,(int)((unsigned)width*position/16383),3,MPC_THEME_ACCENT);}
static inline void ei_selection(EiCanvas*c,int y,int height){ei_rect(c,8,y,c->w-16,height,MPC_THEME_SELECTED);ei_rect(c,8,y,2,height,MPC_THEME_ACCENT);}
#endif
