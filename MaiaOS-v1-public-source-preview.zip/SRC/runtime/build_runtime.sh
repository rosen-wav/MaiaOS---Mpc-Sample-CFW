#!/bin/sh
# Build the recovered r109 runtime components for MPC Sample ARM64.
set -eu
if [ "$#" -ne 1 ]; then
    printf '%s\n' 'Usage: build_runtime.sh NEW_OUTPUT_DIRECTORY' >&2
    exit 2
fi

src=$(CDPATH= cd -- "$(dirname -- "$0")/SRC" && pwd)
zig=${MPC_ZIG:-zig}
gnu_cpp=${MPC_GNU_CPP:-/usr/include/c++/14}
gnu_config=${MPC_GNU_CONFIG:-/usr/include/x86_64-linux-gnu/c++/14}
zig_lib=$("$zig" env | python3 -c 'import json,sys; from pathlib import Path; print(Path(json.load(sys.stdin)["lib_dir"]).resolve())')
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
trap 'exit 1' HUP INT TERM

"$zig" clang -cc1 -triple aarch64-unknown-linux-gnu -emit-obj -ffreestanding \
    -fno-builtin -O2 "$src/affinity/pin_fx_routing.c" -o "$tmp/pin.o"
"$zig" clang -cc1as -triple aarch64-unknown-linux-gnu -filetype obj \
    "$src/affinity/start.S" -o "$tmp/start.o"
"$zig" ld.lld -static -z noexecstack --no-undefined -e _start \
    -o "$tmp/maia-pin-fx-cpu1" "$tmp/start.o" "$tmp/pin.o"

"$zig" clang -cc1 -triple aarch64-unknown-linux-gnu -emit-obj -std=c++17 \
    -fcxx-exceptions -fexceptions -fgnuc-version=4.2.1 -fno-builtin \
    -mno-outline-atomics -pic-level 2 -fvisibility=hidden -O3 \
    -internal-isystem "$zig_lib/include" -isystem "$gnu_cpp" -isystem "$gnu_config" \
    -isystem "$zig_lib/libc/include/aarch64-linux-gnu" \
    -isystem "$zig_lib/libc/include/generic-glibc" \
    -isystem "$zig_lib/libc/include/aarch64-linux-any" \
    -isystem "$zig_lib/libc/include/any-linux-any" \
    "$src/autotune/src/mpc_autotune.cpp" -o "$tmp/autotune.o"
"$zig" ld.lld -shared -Bsymbolic -o "$tmp/libmpc-autotune.aarch64.so" "$tmp/autotune.o"

fx=$src/fx
"$zig" cc -target aarch64-linux-gnu.2.31 -mcpu=cortex_a55 -std=gnu11 -O2 \
    -fPIC -fvisibility=hidden -shared -Wl,-Bsymbolic \
    -I"$fx/war-bells" -I"$fx/war-bells/dsp" \
    "$fx/src/extra_fx.c" "$fx/war-bells/dsp/war_bells.c" \
    "$fx/war-bells/dsp/effects.c" "$fx/war-bells/dsp/params.c" -lm \
    -o "$tmp/libpc-fx.aarch64.so"

mkdir "$1"
cp "$tmp/maia-pin-fx-cpu1" "$tmp/libmpc-autotune.aarch64.so" "$tmp/libpc-fx.aarch64.so" "$1/"
