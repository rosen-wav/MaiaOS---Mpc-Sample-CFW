/* Freestanding ARM64 utility: pin known Maia FX threads: FX1/2 CPU1, FX3/autotune CPU3.
 * No libc, DSP, allocation or signals. Called after host readiness at boot. */
_Static_assert(sizeof(unsigned long)==8,"ARM64 ABI");
static long call(long n,long a,long b,long c,long d,long e,long f){register long x8 __asm__("x8")=n;register long x0 __asm__("x0")=a;register long x1 __asm__("x1")=b;register long x2 __asm__("x2")=c;register long x3 __asm__("x3")=d;register long x4 __asm__("x4")=e;register long x5 __asm__("x5")=f;__asm__ volatile("svc #0":"+r"(x0):"r"(x8),"r"(x1),"r"(x2),"r"(x3),"r"(x4),"r"(x5):"memory","cc");return x0;}
static unsigned length(const char*s){unsigned n=0;while(s[n])n++;return n;}
static int equal(const char*a,const char*b,unsigned n){for(unsigned i=0;i<n;i++)if(a[i]!=b[i])return 0;return 1;}
static unsigned parse(const char*s){unsigned v=0;if(!*s)return 0;for(;*s;s++){if(*s<'0'||*s>'9'||v>214748364u)return 0;v=v*10+(unsigned)(*s-'0');if(v>2147483647u)return 0;}return v;}
static unsigned append(char*out,unsigned n,const char*s){while(*s)out[n++]=*s++;return n;}
static unsigned decimal(char*out,unsigned n,unsigned v){char b[12];unsigned k=0;do{b[k++]=(char)('0'+v%10);v/=10;}while(v);while(k)out[n++]=b[--k];return n;}
static int owner(unsigned pid,unsigned tid,unsigned role){
 char path[96],buf[4096];unsigned n=0;n=append(path,n,"/proc/");n=decimal(path,n,pid);n=append(path,n,"/task/");n=decimal(path,n,tid);n=append(path,n,"/status");path[n]=0;
 long fd=call(56,-100,(long)path,0x80000,0,0,0);if(fd<0)return 0;
 long count=call(63,fd,(long)buf,sizeof(buf)-1,0,0,0);call(57,fd,0,0,0,0,0);if(count<=0)return 0;buf[count]=0;
 unsigned group=0,named=0;
 for(unsigned at=0;at<(unsigned)count;){
  unsigned end=at;while(end<(unsigned)count&&buf[end]!='\n')end++;
  if(end-at>5&&equal(buf+at,"Tgid:",5)){unsigned p=at+5;while(p<end&&(buf[p]==' '||buf[p]=='\t'))p++;unsigned v=0;for(;p<end;p++){if(buf[p]<'0'||buf[p]>'9'){v=0;break;}v=v*10+(unsigned)(buf[p]-'0');}group=v;}
  if(end-at>5&&equal(buf+at,"Name:",5)){unsigned p=at+5;while(p<end&&(buf[p]==' '||buf[p]=='\t'))p++;const char*name=role==1?"Maia FX12 C1":"Maia FX3 AT C2";unsigned size=length(name);named=end-p==size&&equal(buf+p,name,size);}
  at=end+1;
 }
 return group==pid&&named;
}
static int error(const char*s,int code){call(64,2,(long)s,length(s),0,0,0);return code;}
int program_main(unsigned long*stack){
 if(stack[0]!=4)return error("Usage: maia-pin-fx-cpu1 PID FX12_TID FX3_TID\n",2);
 char**argv=(char**)(stack+1);unsigned pid=parse(argv[1]),first=parse(argv[2]),second=parse(argv[3]);
 if(pid<2||first<2||second<2||first==second||first==pid||second==pid)return error("Invalid process/thread IDs\n",3);
 if(!owner(pid,first,1)||!owner(pid,second,2))return error("FX thread identity/Tgid mismatch\n",4);
 unsigned tids[2]={first,second};
 for(unsigned k=0;k<2;k++){
  unsigned core=k?3:1;unsigned long mask=1ul<<core;
  if(!owner(pid,tids[k],k+1))return error("FX thread changed before pinning\n",5);
  if(call(122,tids[k],sizeof mask,(long)&mask,0,0,0))return error("sched_setaffinity target CPU failed\n",6);
  unsigned long got=0;if(call(123,tids[k],sizeof got,(long)&got,0,0,0)<0||got!=mask||!owner(pid,tids[k],k+1))return error("Target CPU affinity/identity verification failed\n",7);
  char msg[96];unsigned n=append(msg,0,"Maia FX thread ");n=decimal(msg,n,tids[k]);n=append(msg,n," verified on CPU");n=decimal(msg,n,core);n=append(msg,n," Linux\n");call(64,1,(long)msg,n,0,0,0);
 }
 return 0;
}
