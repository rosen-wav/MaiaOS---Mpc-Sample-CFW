/* SPDX-License-Identifier: AGPL-3.0-or-later
 * War Bells adapter. Legacy kind 0 (Paul Stretch) is no longer available.
 */
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <string.h>
#define API __attribute__((visibility("default")))
extern void *wb_mpc_create(void);
extern void wb_mpc_destroy(void*),wb_mpc_process(void*,float*,float*,int),wb_mpc_set(void*,const float*),wb_mpc_reset(void*);
typedef struct{void*war;unsigned generation;float params[6];} Extra;
API void *mpc_fx_create(unsigned kind){if(kind!=1)return NULL;Extra*x=calloc(1,sizeof *x);if(!x)return NULL;x->war=wb_mpc_create();if(!x->war){free(x);return NULL;}return x;}
API void mpc_fx_destroy(void*v){if(v){Extra*x=v;wb_mpc_destroy(x->war);free(x);}}
API void mpc_fx_process(void*v,float*l,float*r,unsigned n,const float*params,unsigned generation){if(!v||!l||!r||!params||n>4096)return;Extra*x=v;float p[6];for(unsigned j=0;j<6;j++)p[j]=isfinite(params[j])?fminf(1,fmaxf(0,params[j])):0;
 if(x->generation!=generation){wb_mpc_reset(x->war);x->generation=generation;wb_mpc_set(x->war,p);}else if(memcmp(x->params,p,sizeof p))wb_mpc_set(x->war,p);memcpy(x->params,p,sizeof p);wb_mpc_process(x->war,l,r,(int)n);
 for(unsigned i=0;i<n;i++){l[i]=isfinite(l[i])?fminf(4,fmaxf(-4,l[i])):0;r[i]=isfinite(r[i])?fminf(4,fmaxf(-4,r[i])):0;}}

void mpc_fx_touch_memory(void*memory,size_t size){volatile unsigned char*p=memory;for(size_t i=0;i<size;i+=4096){unsigned char value=p[i];p[i]=value;}}
