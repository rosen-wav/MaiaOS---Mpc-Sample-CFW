from pathlib import Path
import argparse,subprocess,os
p=argparse.ArgumentParser();p.add_argument('--cross-root',type=Path,required=True);a=p.parse_args();r=Path(__file__).resolve().parent;root=a.cross_root.resolve();env=dict(os.environ,LD_LIBRARY_PATH=str(root/'usr/lib/x86_64-linux-gnu'));src=[r/'src/extra_fx.c']+[r/'war-bells/dsp'/n for n in ['war_bells.c','effects.c','params.c']]
subprocess.run([str(root/'usr/bin/aarch64-linux-gnu-gcc-9'),'--sysroot='+str(root),'-mcpu=cortex-a55','-std=gnu11','-O2','-fPIC','-fvisibility=hidden','-shared','-Wl,-Bsymbolic','-I'+str(r/'war-bells'),'-I'+str(r/'war-bells/dsp')]+list(map(str,src))+['-lm','-o',str(r.parent/'bin/libpc-fx.aarch64.so')],env=env,check=True)

os.utime(r/'../bin/libpc-fx.aarch64.so',(2272147200,2272147200))
