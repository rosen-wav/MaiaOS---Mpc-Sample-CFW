# MPC extra send effects — source and attribution

The complete source used for libpc-fx.aarch64.so is here. Build with
`python3 fx/build.py --cross-root /path/to/focal-toolchain`.
The shared module is AGPL-3.0-or-later; the full license is in
licenses/War-Bells-AGPL-3.txt. SDK header notices are in
licenses/War-Bells-THIRD_PARTY.md and the original headers.

War Bells: copyright 2026 Chris Farrell. Imported from the user-supplied
war-bells-main archive. Original DSP, effects tables, utility code and copyright
headers retained. MPC changes in war_bells.c: planar float audio entry instead
of int16 conversion, direct six-macro adapter, eco mode forced, looper signal
path bypassed, UI-only instance creation, audio-owned bounded reset, internal
file/preset and MIDI operations not exposed. The host supplies no Move APIs.
Capture is five seconds and multitap delay four seconds at 44100 Hz.

Paul Stretch Live: original MPC implementation in src/extra_fx.c, inspired by
the random-phase spectral stretching algorithm demonstrated in the user-supplied
PaulXStretch source. NO PaulXStretch/PaulStretch/JUCE/FFTW source is copied,
compiled or linked into this effect. It is not the full PaulXStretch plugin
and does not load that plugin's projects or files. FFT/ring/overlap-add code
was written for this MPC port. Fixed FFT 512, hop 128, immediate filtered live return followed by a crossfade into the spectral output (new onset after silence also starts live), stereo rolling capture
131072 frames (~2.97 seconds), magnitude blur, random-phase resynthesis,
spectral pitch shift, tone and width. Initialization builds all trigonometric
lookup tables; render allocates no memory and does no file I/O or waiting.

Both effects are always-wet returns. Individual pad sends provide dry/effect
balance. Three independent instances can be active, one per shared slot.
Unused effects do not process audio. Previously selected contexts stay cached
until application exit to avoid freeing anything still visible to audio;
their state resets on slot reselection or project restoration. Captured audio
is temporary, not serialized; the six control values are serialized.
