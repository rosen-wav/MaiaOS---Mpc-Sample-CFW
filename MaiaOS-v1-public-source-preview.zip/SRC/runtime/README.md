# MaiaOS r109 — runtime build sources

This source addendum covers AutoTune, the War Bells send module and the
CPU-affinity helper used at launch. It includes their build recipe, tests
and applicable notices. It contains no executables or stock firmware.

Build on Linux with Python 3, Zig 0.14.1 and GNU C++ 14 headers:

```sh
MPC_ZIG=/absolute/path/to/zig sh build_runtime.sh ./runtime-test
```

Use `MPC_GNU_CPP` and `MPC_GNU_CONFIG` if the GNU C++ headers are in a
different location. The FX module targets glibc 2.31. AutoTune uses the
existing host's GNU C++ ABI, as the r109 module does.

The ARM64 builds export the same AutoTune and War Bells entry points as
r109. The Linux smoke test checks AutoTune bypass, harmony ABI and finite
stereo processing for both modules. The ARM64 affinity test runs with
mocked syscalls and verifies that the helper pins the correct threads to
CPU1 and CPU3 and rejects threads from a different process.

The ARM64 rebuilds have different hashes from the private binaries.
Integration and audio tests on the MPC are still required before these
builds can be used as release replacements. The current SD preparer
continues to require the original r109 hashes.

The native reconstruction, WT Lite and the two remaining DSP modules
still need release verification. This is a source addendum, not a
stock-only installer.
