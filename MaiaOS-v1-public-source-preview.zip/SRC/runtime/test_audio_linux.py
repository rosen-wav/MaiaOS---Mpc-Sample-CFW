import ctypes as c
import math,sys
fp=c.POINTER(c.c_float)
def bind(lib,name,result,params):
 f=getattr(lib,name);f.restype=result;f.argtypes=params;return f
at=c.CDLL(sys.argv[1])
make=bind(at,'mpc_autotune_create',c.c_void_p,[c.c_double])
free=bind(at,'mpc_autotune_destroy',None,[c.c_void_p])
enable=bind(at,'mpc_autotune_enable',None,[c.c_void_p,c.c_uint])
harmony=bind(at,'mpc_autotune_set_harmony',None,[c.c_void_p,c.c_uint])
process=bind(at,'mpc_autotune_process',None,[c.c_void_p,fp,fp,c.c_uint])
assert bind(at,'mpc_autotune_harmony_version',c.c_uint,[])()==1
handle=make(44100)
assert handle
length=256
buffer=c.c_float*length
l=buffer(*([.25]*length));r=buffer(*([.125]*length))
process(handle,l,r,length)
assert l[0]==.25 and r[0]==.125
harmony(handle,0x100);enable(handle,1)
for b in range(128):
 for i in range(length): l[i]=r[i]=.2*math.sin(2*math.pi*229*(length*b+i)/44100)
 process(handle,l,r,length)
 assert all(math.isfinite(x) for x in (*l,*r))
assert max(abs(x) for x in l)>0.01
free(handle)
fx=c.CDLL(sys.argv[2])
make=bind(fx,'mpc_fx_create',c.c_void_p,[c.c_uint])
free=bind(fx,'mpc_fx_destroy',None,[c.c_void_p])
process=bind(fx,'mpc_fx_process',None,[c.c_void_p,fp,fp,c.c_uint,fp,c.c_uint])
assert not make(0)
handle=make(1)
assert handle
params=(c.c_float*6)(.3,.2,.4,.5,.6,.3)
processed=False
for b in range(96):
 for i in range(length): l[i]=.2*math.sin(.12*(length*b+i));r[i]=.17*math.sin(.18*(length*b+i))
 dry=tuple(l)
 process(handle,l,r,length,params,1)
 processed|=any(abs(x-y)>1e-4 for x,y in zip(l,dry))
 assert all(math.isfinite(x) and abs(x)<=4 for x in (*l,*r))
assert processed
free(handle)
print('AutoTune harmony ABI and War Bells stereo processing passed')
