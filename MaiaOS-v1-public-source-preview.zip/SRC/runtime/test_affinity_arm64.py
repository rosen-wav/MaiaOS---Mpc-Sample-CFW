from struct import pack,unpack
from pathlib import Path
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_MODE_ARM,UC_HOOK_INTR
from unicorn.arm64_const import *
import sys

def test(path, valid):
 u=Uc(UC_ARCH_ARM64,UC_MODE_ARM)
 u.mem_map(0x200000,0x30000);u.mem_map(0x800000,0x20000)
 with Path(path).open('rb') as f:
  elf=ELFFile(f)
  for segment in elf.iter_segments():
   if segment['p_type']=='PT_LOAD':u.mem_write(segment['p_vaddr'],segment.data())
  start=elf['e_entry']
 top=0x810000
 args=(b'pin',b'100',b'101',b'102')
 for index,arg in enumerate(args):u.mem_write(top+64+32*index,arg+b'\0')
 u.mem_write(top,pack('<6Q',4,*(top+64+32*i for i in range(4)),0))
 u.reg_write(UC_ARM64_REG_SP,top)
 affinities={}
 handles={}
 def read_str(address):
  data=bytearray()
  while (v:=u.mem_read(address+len(data),1)[0]):data.append(v)
  return bytes(data)
 def hook(uc,number,data):
  n=uc.reg_read(UC_ARM64_REG_X8)
  a,b,c=(uc.reg_read(reg) for reg in (UC_ARM64_REG_X0,UC_ARM64_REG_X1,UC_ARM64_REG_X2))
  if n==56:
   route=read_str(b)
   assert route in (b'/proc/100/task/101/status',b'/proc/100/task/102/status')
   fd=3+len(handles);handles[fd]=route;result=fd
  elif n==63:
   role=handles[a].endswith(b'101/status')
   name=b'Maia FX12 C1' if role else b'Maia FX3 AT C2'
   proc=b'Name:\t'+name+b'\nTgid:\t'+(b'100' if valid else b'900')+b'\n'
   uc.mem_write(b,proc);result=len(proc)
  elif n==57:result=0
  elif n==122:
   assert b==8
   affinities[a]=unpack('<Q',uc.mem_read(c,8))[0];result=0
  elif n==123:
   uc.mem_write(c,pack('<Q',affinities[a]));result=8
  elif n==64:result=c
  elif n==93:
   assert a==(0 if valid else 4);uc.emu_stop();return
  else:raise AssertionError(n)
  uc.reg_write(UC_ARM64_REG_X0,result)
 u.hook_add(UC_HOOK_INTR,hook)
 u.emu_start(start,0,count=100000)
 assert affinities==({101:2,102:8} if valid else {})
test(sys.argv[1],True)
test(sys.argv[1],False)
print('ARM64 affinity: CPU1 / CPU3 applied to verified threads; wrong process rejected')
