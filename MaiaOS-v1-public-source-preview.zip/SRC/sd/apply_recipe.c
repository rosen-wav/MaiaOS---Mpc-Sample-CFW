/* MaiaOS local reconstruction. Input records are one tag and a little-endian
 * 32-bit length, followed by a source offset for C or local bytes for W. */
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int read_exact(void *data, size_t size, FILE *stream)
{
    return fread(data, 1, size, stream) == size;
}

static int read_u32(FILE *stream, uint32_t *value)
{
    unsigned char b[4];
    if (!read_exact(b, sizeof b, stream))
        return 0;
    *value = (uint32_t)b[0] | (uint32_t)b[1] << 8 |
             (uint32_t)b[2] << 16 | (uint32_t)b[3] << 24;
    return 1;
}

static long read_size(const char *text)
{
    char *end;
    errno = 0;
    long size = strtol(text, &end, 10);
    return !errno && end != text && !*end && size > 0 && size <= 128L * 1024 * 1024
        ? size : -1;
}

static int rebuild(FILE *stock, uint32_t stock_size, uint32_t left)
{
    static unsigned char buffer[65536];
    unsigned char header[8];
    if (!read_exact(header, sizeof header, stdin) || memcmp(header, "MAIASD1\0", 8))
        return 0;
    while (left) {
        int tag = getchar();
        uint32_t length;
        if ((tag != 'C' && tag != 'W' && tag != 'Z') ||
            !read_u32(stdin, &length) || !length || length > left)
            return 0;
        if (tag == 'C') {
            uint32_t offset;
            if (!read_u32(stdin, &offset) || offset > stock_size ||
                length > stock_size - offset || fseek(stock, (long)offset, SEEK_SET))
                return 0;
        }
        if (tag == 'Z')
            memset(buffer, 0, sizeof buffer);
        left -= length;
        while (length) {
            size_t chunk = length < sizeof buffer ? length : sizeof buffer;
            if (tag != 'Z' && !read_exact(buffer, chunk, tag == 'C' ? stock : stdin))
                return 0;
            if (fwrite(buffer, 1, chunk, stdout) != chunk)
                return 0;
            length -= (uint32_t)chunk;
        }
    }
    return getchar() == EOF && !ferror(stdin) && !fflush(stdout);
}

int main(int argc, char **argv)
{
    if (argc != 4)
        return 1;
    long stock_size = read_size(argv[2]);
    long target_size = read_size(argv[3]);
    if (stock_size < 0 || target_size < 0)
        return 1;
    FILE *stock = fopen(argv[1], "rb");
    if (!stock)
        return 1;
    int ok = !fseek(stock, 0, SEEK_END) && ftell(stock) == stock_size &&
             rebuild(stock, (uint32_t)stock_size, (uint32_t)target_size);
    fclose(stock);
    return !ok;
}
