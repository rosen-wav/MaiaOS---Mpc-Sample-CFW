/* MaiaOS delta tool, freestanding Linux AArch64. */
typedef unsigned long Size;

static long syscall3(long number, long a, long b, long c)
{
    register long x8 __asm__("x8") = number;
    register long x0 __asm__("x0") = a;
    register long x1 __asm__("x1") = b;
    register long x2 __asm__("x2") = c;
    __asm__ volatile("svc #0" : "+r"(x0) : "r"(x8), "r"(x1), "r"(x2) : "memory");
    return x0;
}

static Size parse_size(const char *s)
{
    Size size = 0;
    for (; *s; ++s) {
        if (*s < '0' || *s > '9')
            return 0;
        size = size * 10 + (*s - '0');
        if (size > 128ul * 1024 * 1024)
            return 0;
    }
    return size;
}

static int transfer(long call, long fd, unsigned char *buf, Size n)
{
    while (n) {
        long count = syscall3(call, fd, (long)buf, n);
        if (count == -4)
            continue;
        if (count <= 0)
            return 0;
        buf += count;
        n -= count;
    }
    return 1;
}

int apply_delta(long *stack)
{
    if (stack[0] != 4)
        return 1;
    const char **argv = (const char **)(stack + 1);
    Size stock_size = parse_size(argv[2]), left = parse_size(argv[3]);
    if (!stock_size || !left)
        return 1;
    long fd = syscall3(56, -100, (long)argv[1], 0);
    if (fd < 0 || syscall3(62, fd, 0, 2) != (long)stock_size ||
        syscall3(62, fd, 0, 0) != 0)
        return 1;

    static unsigned char stock[65536], mask[65536];
    Size available = stock_size;
    while (left) {
        Size n = left < sizeof stock ? left : sizeof stock;
        if (n > available)
            n = available;
        if (!transfer(63, fd, stock, n) || !transfer(63, 0, mask, n))
            return 1;
        for (Size i = 0; i < n; ++i)
            mask[i] ^= stock[i];
        if (!transfer(64, 1, mask, n))
            return 1;
        left -= n;
        available -= n;
        if (!available && left) {
            if (syscall3(62, fd, 0, 0) != 0)
                return 1;
            available = stock_size;
        }
    }
    return syscall3(63, 0, (long)mask, 1) != 0;
}

__asm__(".global _start\n_start:\nmov x0, sp\nbl apply_delta\nmov x8, #93\nsvc #0\n");
