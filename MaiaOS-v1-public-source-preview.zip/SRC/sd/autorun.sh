#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$here" = /media/MPCSSH/autorun ] || exit 0
[ ! -e "$here/stock-only" ] && [ ! -e "$here/maia.failed" ] || exit 0
[ "$(awk '{print int($1)}' /proc/uptime)" -le 180 ] || exit 0
# The stock UI must finish autorun before its application can be stopped.
systemd-run --no-block --unit=maia-public-sdboot \
    --property=After=ac50.service --property=RuntimeMaxSec=170s \
    /bin/sh "$here/maia-start.sh" "$here"
