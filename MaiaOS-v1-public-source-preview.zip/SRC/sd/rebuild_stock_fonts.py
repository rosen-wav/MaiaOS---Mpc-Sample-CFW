#!/usr/bin/env python3
"""Build the r109 native reference with fonts supplied by local stock."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import tempfile
import tarfile

STOCK_SHA = "b6584cba76e416e432ad202509099d34373dc2c3d6a8fb625f5678bf0193b508"
NATIVE_SHA = "fd05d449acce78919915b564042bfe61a954645616703c9b9733b1c27f5bff16"
RESULT_SHA = "431e5992652e98fc58cc322ab2eb7d10e23c976562fa5273d31f19dc2649eb14"
STOCK_SIZE = 119243440
NATIVE_SIZE = 119467760
NATIVE_NAME = "runtime/MPC-Sample-pc-integrated-v0.4.0"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_exact(path, size):
    with path.open("rb") as file:
        data = file.read(size + 1)
    if len(data) != size:
        raise ValueError(f"Dimensione inattesa: {path}")
    return data

def read_reference(path):
    if path.name.endswith((".tar.gz", ".tgz")):
        with tarfile.open(path, mode="r:gz") as archive:
            member = archive.getmember(NATIVE_NAME)
            if not member.isfile() or member.size != NATIVE_SIZE:
                raise ValueError("Riferimento nativo mancante o non valido")
            with archive.extractfile(member) as stream:
                return stream.read(NATIVE_SIZE + 1)
    return read_exact(path, NATIVE_SIZE)

def rebuild(stock, native, spans):
    if len(stock) != STOCK_SIZE or sha(stock) != STOCK_SHA:
        raise ValueError("Eseguibile stock 1.3.0.12 non riconosciuto")
    if len(native) != NATIVE_SIZE or sha(native) != NATIVE_SHA:
        raise ValueError("Riferimento nativo r109 non riconosciuto")
    result = bytearray(native)
    for offset, size in spans:
        if offset < 0 or size <= 0 or offset + size > len(stock):
            raise ValueError("Intervallo font fuori dal file")
        result[offset:offset+size] = stock[offset:offset+size]
    if sha(result) != RESULT_SHA:
        raise ValueError("Checksum dell'app ricostruita inatteso")
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stock", type=Path, required=True)
    parser.add_argument("--reference", type=Path, required=True,
                        help="Eseguibile r109 o archivio di riferimento privato")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        spans = json.loads(Path(__file__).with_name("font-ranges.json").read_text())
        data = rebuild(read_exact(args.stock, STOCK_SIZE), read_reference(args.reference), spans)
        with tempfile.NamedTemporaryFile(dir=args.output.parent) as temp:
            temp.write(data)
            temp.flush()
            os.link(temp.name, args.output)
    except (OSError, KeyError, ValueError, tarfile.TarError) as error:
        parser.exit(1, f"Ricostruzione interrotta: {error}\n")
    print(f"{RESULT_SHA}  {args.output}")

if __name__ == "__main__":
    main()
