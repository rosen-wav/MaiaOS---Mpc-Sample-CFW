/* Maia boot r44. SDK call matches the native application's ARM64 call site:
 * image record {0,0,fd,0}, count=1, timeout=-1, flags=0x80000001, mode=1.
 * Standalone pre-start helper is killed by a kernel timer after two seconds.
 * Failure never stops ac50; no framebuffer/DRM access, no extra audio thread.
 */
#include <stddef.h>
#include <stdint.h>
extern void *dlsym(void*,const char*);
extern void *dlopen(const char*,int);
extern char *getenv(const char*);
static long sys(long n,long a,long b,long c,long d,long e,long f){register long x8 __asm__("x8")=n;register long x0 __asm__("x0")=a;register long x1 __asm__("x1")=b;register long x2 __asm__("x2")=c;register long x3 __asm__("x3")=d;register long x4 __asm__("x4")=e;register long x5 __asm__("x5")=f;__asm__ volatile("svc #0":"+r"(x0):"r"(x8),"r"(x1),"r"(x2),"r"(x3),"r"(x4),"r"(x5):"memory","cc");return x0;}
static long started;static unsigned used;
static void status(const char*s){unsigned n=0;while(s[n])n++;long fd=sys(56,-100,(long)"/run/maia-boot-logo-r44.status",0x80441,0600,0,0);if(fd>=0){sys(64,fd,(long)s,n,0,0,0);sys(57,fd,0,0,0,0,0);}}
static void result_status(const char*prefix,int value){char out[96],rev[16];unsigned n=0,k=0;while(prefix[n]&&n<70){out[n]=prefix[n];n++;}long v=value;if(v<0){out[n++]='-';v=-v;}do{rev[k++]='0'+v%10;v/=10;}while(v&&k<16);while(k)out[n++]=rev[--k];out[n++]='\n';out[n]=0;status(out);}
static int equal(const unsigned char*a,const unsigned char*b,unsigned n){for(unsigned i=0;i<n;i++)if(a[i]!=b[i])return 0;return 1;}
/* Identify the two stock screens from their size and fingerprint.
 * The images are supplied at runtime by the local firmware. */
static int stock_system_screen(const unsigned char *data,unsigned size){
 uint64_t expected;
 switch(size){
 case 2508: expected=UINT64_C(0x7df0396d2ed6d80c); break; /* update */
 case 2763: expected=UINT64_C(0xc490ada191c15f4a); break; /* shutdown */
 default: return 0;
 }
 uint64_t fingerprint=UINT64_C(14695981039346656037);
 for(unsigned i=0;i<size;i++)fingerprint=(fingerprint^data[i])*UINT64_C(1099511628211);
 return fingerprint==expected;
}
static int helper(void){const char*s=getenv("MAIA_BOOT_HELPER");return s&&s[0]=='1'&&!s[1];}
static const char*image_path(void){const char*s=getenv("MAIA_BOOT_IMAGE");return s&&s[0]=='/'?s:0;}
typedef int(*Show)(void*,const void*,unsigned,int,int,int);
static int png_fd(const char*path){
 if(!path)return -1;long fd=sys(56,-100,(long)path,0x80000,0,0,0);if(fd<0)return (int)fd;
 unsigned char p[24];static const unsigned char magic[8]={137,80,78,71,13,10,26,10};
 long n=sys(67,fd,(long)p,24,0,0,0);
 if(n!=24||!equal(p,magic,8)){sys(57,fd,0,0,0,0,0);return -1;}return (int)fd;
}
static int arm_watchdog(void){
 struct{uint64_t value;int signo,notify;unsigned char pad[48];}event={0,9,0,{0}};
 int id=-1;long r=sys(107,1,(long)&event,(long)&id,0,0,0);if(r<0)return -1;
 long time[4]={0,0,2,0};r=sys(110,id,0,(long)time,0,0,0);
 if(r<0){sys(111,id,0,0,0,0,0);return -1;}return id;
}
static void explicit_splash(void){
 int timer=arm_watchdog();if(timer<0){status("helper skipped: kernel watchdog unavailable\n");return;}
 status("helper r44; native flags=0x80000001; watchdog=2s\n");
 void*lib=dlopen("libaz0x-splashctl.so.0",2);
 if(!lib){status("SDK library unavailable\n");goto done;}
 int(*create)(void**)=dlsym(lib,"az0x_splash_client_new");void(*destroy)(void*)=dlsym(lib,"az0x_splash_client_free");Show show=(Show)dlsym(lib,"az0x_splash_show_image");
 if(!create||!destroy||!show){status("SDK symbols unavailable\n");goto done;}
 int fd=png_fd(image_path());if(fd<0){status("logo PNG unavailable\n");goto done;}
 void*client=0;int rc=create(&client);result_status("client result=",rc);
 if(rc>=0&&client){struct{uint32_t width,height;int fd;uint32_t reserved;}record={0,0,fd,0};
  rc=show(client,&record,1,-1,(int)0x80000001u,1);result_status("show result=",rc);
  status(rc<0?"MaiaOS logo rejected; firmware continues\n":"MaiaOS logo submitted\n");
 }
 if(client)destroy(client);sys(57,fd,0,0,0,0,0);
done:sys(111,timer,0,0,0,0,0);
}
__attribute__((constructor))static void init(void){long t[2];if(!sys(113,1,(long)t,0,0,0,0))started=t[0];if(helper())explicit_splash();}
__attribute__((visibility("default")))int az0x_splash_show_image(void*client,const void*images,unsigned count,int a,int b,int c){
 static Show real;Show f=__atomic_load_n(&real,__ATOMIC_ACQUIRE);
 if(!f){f=(Show)dlsym((void*)-1L,"az0x_splash_show_image");if(!f){status("binding unavailable\n");return -38;}__atomic_store_n(&real,f,__ATOMIC_RELEASE);}
 long t[2];int eligible=!helper()&&started&&!sys(113,1,(long)t,0,0,0,0)&&t[0]-started<180&&!__atomic_load_n(&used,__ATOMIC_ACQUIRE)&&count==1&&images;
 if(!eligible)return f(client,images,count,a,b,c);
 unsigned char record[16];for(unsigned i=0;i<16;i++)record[i]=((const unsigned char*)images)[i];int oldfd;__builtin_memcpy(&oldfd,record+8,4);
 unsigned char prefix[4096];long n=sys(67,oldfd,(long)prefix,sizeof prefix,0,0,0);
 static const unsigned char png[8]={137,80,78,71,13,10,26,10};
 if(n<24||!equal(prefix,png,8)||stock_system_screen(prefix,(unsigned)n))return f(client,images,count,a,b,c);
 int fd=png_fd(image_path());if(fd<0){status("logo unavailable; original image preserved\n");return f(client,images,count,a,b,c);}
 __builtin_memcpy(record+8,&fd,4);unsigned expected=0;
 if(!__atomic_compare_exchange_n(&used,&expected,1,0,__ATOMIC_ACQ_REL,__ATOMIC_ACQUIRE)){sys(57,fd,0,0,0,0,0);return f(client,images,count,a,b,c);}
 int rc=f(client,record,count,a,b,c);sys(57,fd,0,0,0,0,0);result_status("intercept result=",rc);
 if(rc<0)return f(client,images,count,a,b,c);return rc;
}
