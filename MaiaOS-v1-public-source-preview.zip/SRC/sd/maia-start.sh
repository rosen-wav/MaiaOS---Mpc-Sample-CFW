#!/bin/sh
# All executable staging and service overrides are volatile.
set -eu
umask 077
HERE=$1
STOCK='/usr/bin/MPC Sample'
WORK=/run/mpc-pc-integrated-v040
APP="$WORK/MPC-Sample-pc-integrated-v0.4.0"
DROP=/run/systemd/system/ac50.service.d/90-maia-public.conf
BASE=/data/mpc-internal-mod
FLAG=$BASE/maia-fx-worker.enabled
INTERNAL_LOCK=/run/mpc-ui-editorial-r1-sdboot.lock
OWN_LOCK=0
TEST_WITH_INTERNAL=0
OWN_WORK=0
OWN_DROP=0
OWN_FLAG=0
TOUCHED=0
BOUND=0
DONE=0

log() { printf '[MaiaOS] %s\n' "$*"; }
fail() { log "$*" >&2; exit 1; }
sha() { sha256sum "$1" | awk '{print $1}'; }
pid() { systemctl show ac50.service -p MainPID --value; }
stopping() {
    [ "$(systemctl is-system-running 2>/dev/null || true)" = stopping ] ||
        systemctl list-jobs --no-legend --no-pager 2>/dev/null |
            grep -Eq '(shutdown|poweroff|reboot|halt)\.target[[:space:]]+start'
}
finalize() {
    result=$?
    trap - EXIT HUP INT TERM
    if [ "$OWN_FLAG" = 1 ]; then rm -f "$FLAG"; rmdir "$BASE" 2>/dev/null || true; fi
    if [ "$DONE" = 1 ]; then exit 0; fi
    stopping && exit "$result"
    if [ "$TOUCHED" = 1 ]; then
        if [ "$BOUND" = 1 ]; then
            if [ "$STOCK" -ef "$APP" ]; then
                systemctl stop ac50.service || true
                umount "$STOCK" || { log 'Power off and boot without SD'; exit 1; }
            else
                log 'Unexpected mount. Power off and boot without SD'
                exit 1
            fi
        fi
        if [ "$OWN_DROP" = 1 ]; then
            rm -f "$DROP"
            systemctl daemon-reload || true
        fi
        systemctl start ac50.service || log 'Stock restart failed. Boot without SD'
    fi
    if [ "$OWN_WORK" = 1 ]; then rm -rf "$WORK"; fi
    if [ "$OWN_LOCK" = 1 ]; then rmdir "$INTERNAL_LOCK" 2>/dev/null || true; fi
    log 'MaiaOS activation stopped'
    printf '%s\n' 'Activation failed. See maia-boot.log' > "$HERE/maia.failed" 2>/dev/null || true
    exit "$result"
}
[ "$HERE" = /media/MPCSSH/autorun ] || exit 1
[ ! -e "$HERE/stock-only" ] && [ ! -e "$HERE/maia.failed" ] || exit 0
mkdir /run/maia-public-once 2>/dev/null || exit 0
if [ ! -L "$HERE/maia-boot.log" ]; then exec >>"$HERE/maia-boot.log" 2>&1; fi
trap finalize EXIT
trap 'exit 130' HUP INT TERM
[ "$(uname -m)" = aarch64 ] && [ "$(id -u)" = 0 ] || fail 'MPC Sample ARM64 required'
for tool in findmnt systemctl sha256sum gzip awk mount umount stat; do
    command -v "$tool" >/dev/null || fail "Missing tool: $tool"
done
[ ! -e "$WORK" ] && [ ! -L "$WORK" ] || fail 'Another MaiaOS runtime is present'
[ ! -L "$BASE" ] && [ ! -L "$BASE/active" ] || fail 'Unexpected internal release selector'
if [ -e "$BASE/active" ]; then
    [ -f "$HERE/test-with-internal" ] && [ ! -L "$HERE/test-with-internal" ] ||
        fail 'Internal MaiaOS installed. Enable the SD-only test to continue'
    [ -f "$BASE/active" ] &&
        [ "$(cat "$BASE/active")" = "$BASE/maia-r39-caec95afcd29-r1" ] ||
        fail 'Unrecognized internal MaiaOS release'
    TEST_WITH_INTERNAL=1
fi
mkdir "$INTERNAL_LOCK" 2>/dev/null || fail 'Another MaiaOS boot is in progress'
OWN_LOCK=1
[ ! -e /run/systemd/system/ac50.service.d/90-maia-logo.conf ] &&
    [ ! -L /run/systemd/system/ac50.service.d/90-maia-logo.conf ] ||
    fail 'Internal MaiaOS service override is active'
[ ! -e "$DROP" ] && [ ! -L "$DROP" ] || fail 'Existing MaiaOS service override'
if findmnt -rn -M "$STOCK" >/dev/null 2>&1; then fail 'Application already overridden'; fi
(cd "$HERE" && sha256sum -c SHA256SUMS) || fail 'Damaged SD package'
read -r stock_sha stock_size app_sha app_size < "$HERE/release.txt"
[ "$(sha "$STOCK")" = "$stock_sha" ] && [ "$(stat -c %s "$STOCK")" = "$stock_size" ] ||
    fail 'Unsupported Akai application. Requires MPC Sample stock 1.3.0.12'
original=$(pid)
[ "${original:-0}" -gt 1 ] && [ "$STOCK" -ef "/proc/$original/exe" ] || fail 'Stock process not ready'
[ "$(df -Pk /run | awk 'END {print $4}')" -ge 235000 ] || fail 'Insufficient RAM filesystem space'
[ "$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)" -ge 390000 ] || fail 'Insufficient available RAM'

mkdir "$WORK"
OWN_WORK=1
cp "$HERE/apply-delta" "$WORK/"
chmod 500 "$WORK/apply-delta"
gzip -dc "$HERE/app.delta.gz" | "$WORK/apply-delta" "$STOCK" "$stock_size" "$app_size" > "$APP" ||
    fail 'Delta failed'
[ "$(sha "$APP")" = "$app_sha" ] || fail 'Rebuilt application checksum mismatch'
chmod 555 "$APP"
for name in libpc-host libpc-fx libmpc-wt-lite libmpc-autotune libmaia-boot; do
    cp "$HERE/runtime/$name.aarch64.so" "$WORK/"
done
for stem in dsp new; do
    cp "$HERE/runtime/libpc-$stem.aarch64.so" "$WORK/libpc-${stem}-00.aarch64.so"
    index=1
    while [ "$index" -lt 16 ]; do
        # Distinct inodes give each dlopen its own synth instance.
        cp "$WORK/libpc-${stem}-00.aarch64.so" "$WORK/$(printf 'libpc-%s-%02d.aarch64.so' "$stem" "$index")"
        index=$((index+1))
    done
done
for suffix in editor preview; do
    cp "$WORK/libpc-dsp-00.aarch64.so" "$WORK/libpc-$suffix.aarch64.so"
    cp "$WORK/libpc-new-00.aarch64.so" "$WORK/libpc-new-$suffix.aarch64.so"
done
cp "$HERE/runtime/maia-320x240.png" "$HERE/runtime/maia-pin-fx-cpu1" "$WORK/"
chmod 500 "$WORK/maia-pin-fx-cpu1"
LD=/usr/lib/ld-linux-aarch64.so.1
for name in libpc-host libpc-fx libmpc-wt-lite libmpc-autotune libpc-new-00 libpc-dsp-00; do
    "$LD" --list "$WORK/$name.aarch64.so" > "$WORK/dependencies.log" 2>&1 ||
        fail "Runtime dependencies unavailable: $name"
    if grep -q 'not found' "$WORK/dependencies.log"; then fail "Missing dependency: $name"; fi
done
[ "$(pid)" = "$original" ] && [ "$STOCK" -ef "/proc/$original/exe" ] || fail 'Stock process changed'
[ ! -e "$HERE/stock-only" ] && [ ! -e "$HERE/maia.failed" ] || fail 'Activation cancelled'
stopping && exit 1
# The existing host reads this flag only during initialization. Remove it after startup.
[ ! -L "$BASE" ] && [ ! -L "$FLAG" ] || fail 'Unexpected FX configuration link'
if [ -e "$FLAG" ]; then
    [ "$TEST_WITH_INTERNAL" = 1 ] && [ -f "$FLAG" ] ||
        fail 'Existing internal FX configuration'
    log 'Using existing FX worker flag without changing it'
else
    mkdir -p "$BASE"
    (set -C; : > "$FLAG")
    OWN_FLAG=1
fi
if [ "$TEST_WITH_INTERNAL" = 1 ]; then
    log 'SD-only test enabled. Internal release selector preserved'
fi
TOUCHED=1
systemctl stop ac50.service || fail 'Stock stop failed'
mount --bind "$APP" "$STOCK" || fail 'Could not start temporary application mount'
BOUND=1
[ "$STOCK" -ef "$APP" ] || fail 'Unexpected application mount'
mkdir -p "$(dirname "$DROP")"
OWN_DROP=1
cat > "$DROP" <<'UNIT'
[Service]
Environment="LD_PRELOAD=libdl.so.2:/run/mpc-pc-integrated-v040/libmaia-boot.aarch64.so"
Environment="MAIA_BOOT_IMAGE=/run/mpc-pc-integrated-v040/maia-320x240.png"
ExecStartPre=-/bin/sh -c 'MAIA_BOOT_HELPER=1 exec /bin/true'
TimeoutStopSec=15s
UNIT
systemctl daemon-reload || fail 'Cannot reload transient service settings'
systemctl start ac50.service || fail 'Mod start failed'
active=$(pid)
[ "${active:-0}" -gt 1 ] || fail 'Mod process missing'
seconds=0
while [ "$seconds" -lt 35 ]; do
    [ "$(pid)" = "$active" ] || fail 'Mod restarted during launch'
    if [ "$APP" -ef "/proc/$active/exe" ] &&
       grep -Fq " $WORK/libpc-host.aarch64.so" "/proc/$active/maps" 2>/dev/null &&
       grep -qx 'mpc-editorial-r1-ready' "$WORK/editorial-r1.ready" 2>/dev/null &&
       grep -qx 'fx_core1_ready=00000001' "$WORK/r24-diagnostics.txt" 2>/dev/null &&
       grep -qx 'fx_core2_ready=00000001' "$WORK/r24-diagnostics.txt" 2>/dev/null; then break; fi
    sleep 1
    seconds=$((seconds+1))
done
[ "$seconds" -lt 35 ] || fail 'MaiaOS host initialization timed out'
fx12=
fx3=
for task in "/proc/$active/task/"*; do
    [ -r "$task/comm" ] || continue
    case "$(cat "$task/comm" 2>/dev/null)" in
        'Maia FX12 C1') fx12=${task##*/};;
        'Maia FX3 AT C2') fx3=${task##*/};;
    esac
done
[ -n "$fx12" ] && [ -n "$fx3" ] &&
    "$WORK/maia-pin-fx-cpu1" "$active" "$fx12" "$fx3" || fail 'MaiaOS audio thread affinity failed' 
seconds=0
while [ "$seconds" -lt 30 ]; do
    stopping && exit 1
    [ "$(pid)" = "$active" ] && systemctl is-active --quiet ac50.service || fail 'MaiaOS stopped during startup'
    sleep 1
    seconds=$((seconds+1))
done
DONE=1
log 'MaiaOS r109 boot verified'
