#!/bin/sh
set -eu
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
zig=${MPC_ZIG:-zig}
output=${1:-libmaia-boot.aarch64.so}
include=$("$zig" env | python3 -c 'import json, sys; from pathlib import Path; print(Path(json.load(sys.stdin)["lib_dir"]) / "include")')
obj=$(mktemp)
trap 'rm -f "$obj"' EXIT
"$zig" clang -cc1 -triple aarch64-unknown-linux-gnu -emit-obj -ffreestanding \
  -fno-builtin -mno-outline-atomics -pic-level 2 -fvisibility=hidden -O2 \
  -internal-isystem "$include" \
  "$src/maia_boot.c" -o "$obj"
"$zig" ld.lld -shared -Bsymbolic -o "$output" "$obj"
