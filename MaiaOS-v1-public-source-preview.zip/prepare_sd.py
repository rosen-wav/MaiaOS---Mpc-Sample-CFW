#!/usr/bin/env python3
"""Prepare a MaiaOS microSD folder using the locally held r109 runtime."""
import argparse
import gzip
import hashlib
import io
import mmap
from pathlib import Path
import shutil
import sys
import tempfile
from zipfile import BadZipFile, ZipFile

ROOT = Path(__file__).resolve().parent
SOURCES = ROOT / "SRC" / "sd"
PREFIX = "autorun/"
STOCK_SHA = "b6584cba76e416e432ad202509099d34373dc2c3d6a8fb625f5678bf0193b508"
STOCK_SIZE = 119243440
APP_SHA = "fd05d449acce78919915b564042bfe61a954645616703c9b9733b1c27f5bff16"
APP_SIZE = 119467760

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read_member(bundle, name, expected):
    path = PREFIX + name
    entries = [item for item in bundle.infolist() if item.filename == path]
    if len(entries) != 1 or entries[0].is_dir() or entries[0].file_size > 16 * 1024 * 1024:
        raise ValueError(f"Voce mancante, duplicata o non valida: {path}")
    data = bundle.read(entries[0])
    if sha(data) != expected:
        raise ValueError(f"Checksum inatteso: {path}")
    return data

def verify_reconstruction(stock_path, delta):
    with stock_path.open("rb") as stream:
        if stream.seek(0, 2) != STOCK_SIZE:
            raise ValueError("Dimensione dell'eseguibile stock 1.3.0.12 inattesa")
        with mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ) as stock:
            if sha(stock) != STOCK_SHA:
                raise ValueError("SHA-256 dell'eseguibile stock 1.3.0.12 inatteso")
            result = hashlib.sha256()
            with gzip.GzipFile(fileobj=io.BytesIO(delta), mode="rb") as mask:
                position = 0
                while position < APP_SIZE:
                    offset = position % STOCK_SIZE
                    count = min(65536, APP_SIZE - position, STOCK_SIZE - offset)
                    segment = mask.read(count)
                    if len(segment) != count:
                        raise ValueError("Delta locale incompleto")
                    before = int.from_bytes(stock[offset:offset+count], "little")
                    change = int.from_bytes(segment, "little")
                    result.update((before ^ change).to_bytes(count, "little"))
                    position += count
                if mask.read(1) or result.hexdigest() != APP_SHA:
                    raise ValueError("L'app ricostruita non corrisponde alla r109")

def prepare(bundle_path, output, stock, allow_internal):
    if output.exists() or output.is_symlink():
        raise ValueError(f"La destinazione esiste già: {output}")
    inputs = {}
    for line in (SOURCES / "runtime-r109.sha256").read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        inputs[name] = expected
    with ZipFile(bundle_path) as bundle:
        runtime = {name: read_member(bundle, name, expected) for name, expected in inputs.items()}
    if stock is not None:
        verify_reconstruction(stock, runtime["app.delta.gz"])

    files = {name: (SOURCES / name).read_bytes() for name in ("autorun.sh", "autorun.json", "maia-start.sh")}
    files.update(runtime)
    files["release.txt"] = f"{STOCK_SHA} {STOCK_SIZE} {APP_SHA} {APP_SIZE}\n".encode()
    controls = {"autorun.sh", "autorun.json", "autorun.check"}
    manifest = sorted(set(files) - controls)
    files["SHA256SUMS"] = "".join(f"{sha(files[name])}  {name}\n" for name in manifest).encode()
    if allow_internal:
        files["test-with-internal"] = b""

    # Prepare everything off the target SD, so incomplete outputs never boot.
    with tempfile.TemporaryDirectory(prefix=".maia-sd-", dir=output.parent) as temp:
        stage = Path(temp) / "autorun"
        stage.mkdir()
        for name, data in files.items():
            path = stage / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        output.mkdir()
        try:
            stage.rename(output / "autorun")
        except OSError:
            shutil.rmtree(output)
            raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime-locale", type=Path, required=True,
                        help="ZIP privato MaiaOS-r109-SD-completa-privata.zip")
    parser.add_argument("--output", type=Path, required=True,
                        help="Nuova cartella locale in cui preparare autorun")
    parser.add_argument("--stock", type=Path,
                        help="Eseguibile stock locale, facoltativo per la verifica prima del boot")
    parser.add_argument("--test-con-mod-interna", action="store_true",
                        help="Abilita il test sulla MPC con installazione interna r109")
    args = parser.parse_args()
    try:
        prepare(args.runtime_locale.expanduser(), args.output.expanduser(),
                args.stock.expanduser() if args.stock else None, args.test_con_mod_interna)
    except (OSError, ValueError, BadZipFile, EOFError) as error:
        print(f"Preparazione interrotta: {error}", file=sys.stderr)
        return 1
    print(f"Pronto: {args.output.expanduser() / 'autorun'}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
