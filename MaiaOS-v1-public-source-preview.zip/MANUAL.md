# MaiaOS r109 user manual

This manual describes the r109 controls on Akai MPC Sample. See the [installation guide](INSTALL.md) for the currently available SD test procedure. B1–B3 are the three screen buttons, and K1–K3 are the three knobs.

## DJ Mode

Open the Fader menu with **Shift + Pad 9**, then press **B2** for DJ Mode. Entering stops the sequencer. To leave, press **Sample**, select **Yes** using the encoder, then press it to confirm. Leaving stops both decks.

Press **Sample Import** inside DJ Mode to open Song Import. **B1** goes up a folder, **B2** loads Deck 1 and **B3** loads Deck 2. **K3** switches storage. The browser opens on the microSD by default. Load WAV or MP3. A BPM token separated by a space or underscore, such as `Beat 170.wav` or `Song_90.mp3`, sets the tempo while the deck still analyzes beat placement. Otherwise, tempo and beat placement are analyzed together. Watch the progress under the waveform.

The first loaded song becomes sync master. Deck 1 is green and Deck 2 is purple. The waveforms show an eight-bar window with red bar numbers outlined in black. Turn the encoder to move the selected deck along the beat grid. Press it to switch deck selection and USB cue.

| Control | Deck 1 | Deck 2 |
| --- | --- | --- |
| Play or pause | Note Repeat | Play |
| Cue | Erase | Stop |
| BPM down / up | Pads 1 / 2 | Pads 3 / 4 |
| Sync | Pad 5 | Pad 7 |
| Master indicator | Pad 6 | Pad 8 |
| Nudge back / forward | Pads 9 / 10 | Pads 11 / 12 |
| Toggle two-bar / four-bar loop | Pads 13 / 14 | Pads 15 / 16 |

Hold a BPM pad to repeat the adjustment. Nudge temporarily shifts timing. Sync aligns the deck to the master grid and picks the closest tempo among the master BPM and its half or double. Sync on a stopped deck sets tempo without starting playback. Press Play to start from the selected position in sync. Switching loop length replaces the active loop and highlights its region.

| Page | Knobs and buttons |
| --- | --- |
| Volume | K1 and K3 set deck volumes. K2 controls the DJ filter. B2 switches the filter to the other deck and restores the old deck to dry. The filter is dry from 45% through 55%. |
| EQ | B1 toggles between EQ and Volume. K1 and K3 control low EQ for the two decks. K2 remains the DJ filter and B2 switches its target. |
| Sends | B3 opens or leaves Sends. B2 selects the target deck. K1–K3 control sends to the three knob effects. |
| Cue | Hold Shift on Volume. K1 blends cue and master, starting at 100% cue. K3 sets USB cue gain. |

Knobs use pickup. Turn a knob to its current setting before it changes the parameter. Press **Knob FX** to open or close the DJ effect editor. Hold **Shift** there for the second parameter page. In DJ Mode the fader blends Galactic3 reverb with a gradual high-pass. Bring it to zero to pick up the setting.

The selected deck can be heard through USB cue even with its deck volume at zero. The analog stereo output carries the master. For cue monitoring, connect the MPC to a computer over USB and monitor its stereo input with headphones attached to the computer. The USB gadget route was tested on Mac and requires a USB host.

## Step Edit, grooves and chords

In Step Edit, select a pad and press **Sample Import** for Groove Import. Turn the encoder to select a category or pattern and press it to open or load. B1 returns to the category list. Loading closes the browser and replaces the selected pad’s pattern. The imported groove repeats or truncates to match the current sequence length. Kick, Snare, Hat and Perc are trigger patterns. Loading a Kick groove also assigns the pad as a sidechain send.

Bass follows the lowest note of a chord track and Lead follows the highest. Arp Chords distributes chord notes in the selected order and rhythm. The chord source is a track containing a chord of at least three notes.

Press **Shift + Sample Import** in Step Edit to save the selected pad’s percussion pattern. Choose Kick, Snare, Hat or Perc, name the groove and save. Saved grooves can be loaded onto other pads and adapt to the target sequence length. In Step Edit, **B3 Erase** clears the selected step on the highlighted pad.

In Chord Mode, open chord bank import to browse `progressions/` at the root of the microSD. Select a bank or **Random** to fill available chord slots. Existing chords are retained.

In Piano Roll, hold **Shift** and turn the encoder to select a range. Press **+** or **−** to move the whole selection up or down an octave. After copying, open another pad’s Piano Roll and press the encoder to paste there.

## Drumkit

Select **DRUMKIT** from the engine list. It uses the selected page if all 16 pads are free, or finds the first empty page. It reports when no empty page is available. Use these folders on the microSD:

```text
MPC-Sample/Samples/
  Kick/
  Snare/
  Claps/
  Hats/
  Cymbals/
  Perc/
```

**B3** randomizes two kicks, three snares, two claps, four hats, two cymbals and three percussion sounds. **B2** toggles lock editing. While editing locks, press a pad to lock or unlock it. Locked pads have a yellow background and black text. Turn lock editing off to play the pads. Locked sounds stay fixed when you randomize. **K1** adjusts kick gain, **K2** adjusts snare and clap gain and **K3** adjusts the remaining groups. Kicks become sidechain sends. **B1** exits and keeps the samples on the pads.

## Multisamples

Select **MULTISAMPLES** from the engine list. Connect the MPC MIDI output to the DAW instrument and route the DAW audio back to the MPC. Set the recording input in **Input Config**. Press **B2 Capture**, review the reminder and press the encoder to start.

| Knob | Capture setting |
| --- | --- |
| K1 | Held note duration, 2–10 seconds |
| K2 | MIDI output channel, 1–16 |
| K3 | Velocity layers, 1–4 |

Capture sends MIDI through `f_midi` and records C2, G2, C3, G3, C4, G4, C5, G5 and C6. The engine waits for the recorded tail before sending the next note. A single layer captures at velocity 127. With more layers, playback selects a layer from the incoming velocity and uses the velocity to scale playback level.

Name the finished preset with the encoder. **B2** is backspace. Open preset import with **B3** and press the encoder or the load button to load the selected preset. In the preset browser, hold **Erase** and press the encoder, then choose **Delete** or **Keep**. Deleting a multisample preset also removes its assignments from pads. In 16 Levels Tune, Chord Mode and Piano Roll, the engine pitches the nearest mapped recording across the playable range. Use the engine pages to adjust the amp envelope, stock filter, volume, sidechain and sends.

## Samples, input and effects

Samples start in Poly by default. Samples longer than 30 seconds default to Mono. Sample Edit shows the pad’s sidechain state. Muting a pad that sends sidechain prevents it from ducking receiving tracks.

Use **Shift + Sample** for Input Config. **B2** opens AutoTune. New projects start in Auto-MIDI with a 120 ms tune speed. With no MIDI reference, AutoTune can follow a key token such as `Cmin`, `F#maj` or `Dbmin` in the filename of a playing sample. With no recognized key or MIDI reference it shows **Wait MIDI**.

In Input Config, **B3** opens Sends. Hold **Shift** for the input filter page. It starts at **Vocal1** and provides type, cutoff and resonance. Synths also expose the stock filter before the Volume and Sidechain page. The synth fader assignment defaults to filter cutoff.

Open **Mastering** with **B2** from Compressor. Use the encoder to navigate its parameters and **B1** to return. Compressor displays input level and gain reduction.
