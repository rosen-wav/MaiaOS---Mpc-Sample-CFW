#!/usr/bin/env python3
"""Prepare a local MaiaOS SD using stock and a verified local runtime."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
from zipfile import BadZipFile, ZipFile

from prepare_sd import APP_SHA, APP_SIZE, SOURCES, STOCK_SHA, STOCK_SIZE, read_member

STOCK_FONTS_SHA = "431e5992652e98fc58cc322ab2eb7d10e23c976562fa5273d31f19dc2649eb14"
BLOCK_SIZE = 64
ZERO = bytes(BLOCK_SIZE)
LEGACY_ONLY = {"apply-delta", "app.delta.gz", "runtime/libmpc-wt-lite.aarch64.so"}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_verified(path, size, expected):
    with path.open("rb") as stream:
        data = stream.read(size + 1)
    if len(data) != size or digest(data) != expected:
        raise ValueError(f"File non riconosciuto: {path}")
    return data

def rebuild_from_local_delta(stock, path):
    """Use the legacy delta only as a local reference, never as an SD payload."""
    app = bytearray()
    with gzip.open(path, "rb") as mask:
        while len(app) < APP_SIZE:
            offset = len(app) % len(stock)
            count = min(65536, APP_SIZE - len(app), len(stock) - offset)
            change = mask.read(count)
            if len(change) != count:
                raise ValueError("Delta locale incompleto")
            before = int.from_bytes(stock[offset:offset+count], "little")
            app.extend((before ^ int.from_bytes(change, "little")).to_bytes(count, "little"))
        if mask.read(1) or digest(app) != APP_SHA:
            raise ValueError("L'app ricostruita non corrisponde alla r109")
    for offset, size in json.loads((SOURCES / "font-ranges.json").read_text()):
        if offset < 0 or size <= 0 or offset + size > len(stock):
            raise ValueError("Intervallo font fuori dal file")
        app[offset:offset+size] = stock[offset:offset+size]
    if digest(app) != STOCK_FONTS_SHA:
        raise ValueError("Checksum dell'app con font stock inatteso")
    return app

def recipe_ranges(stock, app):
    for offset in range(0, len(app), BLOCK_SIZE):
        piece = app[offset:offset+BLOCK_SIZE]
        original = stock[offset:offset+len(piece)]
        if piece == original:
            yield b"C", offset, offset + len(piece)
            continue
        if piece == ZERO[:len(piece)]:
            yield b"Z", offset, offset + len(piece)
            continue
        if not original:
            yield b"W", offset, offset + len(piece)
            continue

        # A mixed block must not carry unchanged firmware as literal bytes.
        start, previous = 0, None
        for index, value in enumerate(piece):
            if index < len(original) and value == original[index]:
                tag = b"C"
            else:
                tag = b"Z" if value == 0 else b"W"
            if tag != previous:
                if previous is not None:
                    yield previous, offset + start, offset + index
                start, previous = index, tag
        yield previous, offset + start, offset + len(piece)


def make_recipe(stock, app, destination):
    with destination.open("wb") as file, gzip.GzipFile(filename="", mode="wb", fileobj=file, mtime=0) as stream:
        stream.write(b"MAIASD1\0")

        def emit(tag, start, end):
            stream.write(struct.pack("<cI", tag, end-start))
            if tag == b"C":
                stream.write(struct.pack("<I", start))
            elif tag == b"W":
                stream.write(app[start:end])

        start, previous = 0, None
        for tag, position, _ in recipe_ranges(stock, app):
            if tag != previous:
                if previous is not None:
                    emit(previous, start, position)
                start, previous = position, tag
        if previous is not None:
            emit(previous, start, len(app))

def prepare(args):
    out = args.output.expanduser()
    if out.exists() or out.is_symlink():
        raise ValueError(f"La destinazione esiste già: {out}")
    stock = read_verified(args.stock.expanduser(), STOCK_SIZE, STOCK_SHA)
    if args.local_delta is None:
        app = read_verified(args.native.expanduser(), APP_SIZE, STOCK_FONTS_SHA)
    else:
        app = rebuild_from_local_delta(stock, args.local_delta.expanduser())
    inputs = {}
    for line in (SOURCES / "runtime-r109.sha256").read_text().splitlines():
        expected, name = line.split(maxsplit=1)
        if name not in LEGACY_ONLY:
            inputs[name] = expected
    with ZipFile(args.runtime_locale.expanduser()) as bundle:
        runtime = {name: read_member(bundle, name, expected) for name, expected in inputs.items()}

    with tempfile.TemporaryDirectory(prefix=".maia-stock-", dir=out.parent) as directory:
        stage = Path(directory) / "sd"
        autorun = stage / "autorun"
        autorun.mkdir(parents=True)
        for name, data in runtime.items():
            target = autorun / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
        for name in ("autorun.sh", "autorun.json"):
            shutil.copyfile(SOURCES / name, autorun / name)
        worker = (SOURCES / "maia-start.sh").read_text()
        for previous, replacement in (("app.delta.gz", "app.recipe.gz"), ("apply-delta", "apply-recipe")):
            if previous not in worker:
                raise ValueError("Launcher di origine inatteso")
            worker = worker.replace(previous, replacement)
        if worker.count(" libmpc-wt-lite") != 2:
            raise ValueError("Elenco dei moduli r109 inatteso")
        worker = worker.replace(" libmpc-wt-lite", "")
        (autorun / "maia-start.sh").write_text(worker)
        (autorun / "release.txt").write_text(f"{STOCK_SHA} {STOCK_SIZE} {STOCK_FONTS_SHA} {APP_SIZE}\n")
        make_recipe(stock, app, autorun / "app.recipe.gz")
        subprocess.run([args.zig, "cc", "-target", "aarch64-linux-musl", "-static", "-O2",
                        str(SOURCES / "apply_recipe.c"), "-o", str(autorun / "apply-recipe")], check=True)
        if args.test_con_mod_interna:
            (autorun / "test-with-internal").touch()
        controls = {"autorun.sh", "autorun.json", "autorun.check", "test-with-internal"}
        files = sorted(p for p in autorun.rglob("*") if p.is_file() and p.name not in controls)
        (autorun / "SHA256SUMS").write_text("".join(
            f"{digest(p.read_bytes())}  {p.relative_to(autorun).as_posix()}\n" for p in files))
        out.mkdir()
        try:
            autorun.rename(out / "autorun")
        except OSError:
            out.rmdir()
            raise

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stock", type=Path, required=True)
    reference = parser.add_mutually_exclusive_group(required=True)
    reference.add_argument("--native", type=Path,
                        help="Riferimento locale r109 rigenerato con i font stock")
    reference.add_argument("--local-delta", type=Path,
                           help="Delta privato r109, usato solo per ricostruire il riferimento locale")
    parser.add_argument("--runtime-locale", type=Path, required=True,
                        help="ZIP privato della candidata r109 verificata")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--zig", default="zig")
    parser.add_argument("--test-con-mod-interna", action="store_true")
    args = parser.parse_args()
    try:
        prepare(args)
    except (OSError, EOFError, ValueError, BadZipFile, subprocess.CalledProcessError) as error:
        parser.exit(1, f"Preparazione interrotta: {error}\n")
    print(f"Pronto per il test: {args.output.expanduser() / 'autorun'}")

if __name__ == "__main__":
    main()
