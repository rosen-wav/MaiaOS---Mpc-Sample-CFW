#!/usr/bin/env python3
"""Rebuild the exact legacy v064 reference from trusted local inputs."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


STOCK_SHA = "b6584cba76e416e432ad202509099d34373dc2c3d6a8fb625f5678bf0193b508"
V051_SHA = "203cedabc7de24ec0ca2a5aff6d6931a071d1afc8b51155610a0b5fad2a7efdb"
V064_SHA = "f05128d7b437704a11609a6f725d20068835dc82e35cc04c90a6a464a0cbef99"
MANIFESTS = (
    "base054/base053/base051/patches.json",
    "base054/base053/base052/bridge.json",
    "base054/base053/native/patches.json",
    "base054/native/patches.json",
    "native/patches.json",
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load_builder(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot load builder: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rebuild_v051(stock, manifest):
    if digest(stock) != STOCK_SHA:
        raise ValueError("Unexpected stock input for the v051 stage")
    result = bytearray(stock)
    end = 0
    patches = sorted(manifest["patches"], key=lambda patch: patch["offset"])
    for patch in patches:
        offset = patch["offset"]
        replacement = bytes.fromhex(patch["after"])
        if not replacement or offset < end or offset + len(replacement) > len(stock):
            raise ValueError(f"Invalid or overlapping v051 patch: {patch['name']}")
        end = offset + len(replacement)
        result[offset:end] = replacement
    if digest(result) != V051_SHA:
        raise ValueError("Unexpected output from the v051 stage")
    return bytes(result)


def inventory(stock, legacy):
    report = {}
    for name in MANIFESTS:
        manifest = read_json(legacy / name)
        patches = manifest["patches"]
        preimages = [
            (patch, bytes.fromhex(patch["before"]))
            for patch in patches if "before" in patch
        ]
        after = [bytes.fromhex(patch["after"]) for patch in patches]
        report[name] = {
            "preimage_bytes": sum(len(fragment) for _, fragment in preimages),
            "replacement_bytes": sum(map(len, after)),
            "appended_bytes": len(bytes.fromhex(manifest.get("module", {}).get("bytes", ""))),
            "whole_preimages_matching_stock_at_patch_offset": sum(
                bool(fragment) and stock.startswith(fragment, patch["offset"])
                for patch, fragment in preimages
            ),
            "whole_replacements_matching_stock_at_any_offset": sum(
                len(fragment) >= 16 and any(fragment) and fragment in stock for fragment in after
            ),
        }
    return report


def rebuild(stock, legacy, offsets):
    v054 = load_builder("maia_legacy_v054", legacy / "base054/prepare_from_mac.py")
    v064 = load_builder("maia_legacy_v064", legacy / "prepare_from_mac.py")
    chord = rebuild_v051(stock, read_json(legacy / MANIFESTS[0]))
    v052 = v054.base_ui.patch(chord, offsets[:3])
    v053 = v054.parent053.apply(v052, offsets[:3], offsets[3])
    base = v054.apply(v053, offsets[:6])
    return v064.apply(base, offsets, read_json(legacy / "native/patches.json"))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stock", type=Path, required=True)
    parser.add_argument("--legacy", type=Path, required=True,
                        help="Trusted, extracted MPC UI v0.6.4 source folder")
    parser.add_argument("--button-map", type=Path, required=True)
    parser.add_argument("--output", type=Path,
                        help="Optional new private reference executable")
    args = parser.parse_args()
    try:
        if args.output and (args.output.exists() or args.output.is_symlink()):
            raise ValueError(f"Output already exists: {args.output}")
        stock = args.stock.read_bytes()
        if len(stock) != 119243440 or digest(stock) != STOCK_SHA:
            raise ValueError("Expected the verified stock executable for firmware 1.3.0.12")
        mapping = read_json(args.button_map)
        offsets = mapping["offsets"]
        if (mapping.get("version") != 64 or mapping.get("result_sha256") != V064_SHA
                or not isinstance(offsets, list) or len(offsets) != 7
                or any(type(n) is not int or not 0 <= n <= 65535 for n in offsets)):
            raise ValueError("Expected the verified historical v064 button map")
        result = rebuild(stock, args.legacy.resolve(), offsets)
        if digest(result) != V064_SHA:
            raise ValueError("Rebuilt executable differs from the historical v064 reference")
        report = inventory(stock, args.legacy)
        if args.output:
            with args.output.open("xb") as stream:
                stream.write(result)
        print(json.dumps({"reference_sha256": V064_SHA, "manifest_inventory": report}, indent=2))
    except (OSError, ValueError, KeyError, ImportError) as error:
        print(f"v064 verification failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
