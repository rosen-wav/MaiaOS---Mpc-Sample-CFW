# Legacy v064 development reference

Use this verifier to reproduce the historical intermediate required by the
native MaiaOS build. Run it with Python 3 and trusted local copies of the
verified stock executable, the extracted MPC UI v0.6.4 development package,
and its historical button-map.json.

```sh
python3 SRC/sd/dev/rebuild_v064_reference.py \
  --stock /path/to/MPC-Sample-original \
  --legacy /path/to/mpc-ui-v064 \
  --button-map /path/to/button-map.json
```

The command verifies both hashes and prints counts without emitting firmware
bytes. Add `--output /path/to/new/private-reference` to save the verified
intermediate locally. The utility calls the historical build functions
without running their deployment entry points.

The v051 stage validates the entire stock input and the entire generated
output by SHA-256. It can rebuild from the historical replacement records
with the `before` fields removed. The inventory still reports these fields
when available. Later stages still use the original preimage checks.

The inventory counts preimages, replacements and the appended module.
Whole-fragment matches identify a subset of stock bytes; an absence of a
match cannot establish provenance for shorter or relocated instructions.
Keep the historical manifests, compiled native modules and generated
executables private. A release build still needs to reconstruct the
reviewed changes without these historical inputs.
