/* Reserve r109 address ranges without replacing an existing mapping.
 * A diagnostic may release all reservations after recording the result. */
#define _GNU_SOURCE
#include <errno.h>
#include <stdint.h>
#include <stddef.h>
#include <sys/mman.h>
#include <unistd.h>

#ifndef MAP_FIXED_NOREPLACE
#define MAP_FIXED_NOREPLACE 0x100000
#endif

enum { MAIA_RANGE_COUNT = 3 };

static const struct {
    uintptr_t offset;
    size_t length;
} ranges[MAIA_RANGE_COUNT] = {
    {0x6d3b000, 0x9000},   /* extension of stock executable mapping */
    {0x72a5000, 0xf0000},  /* r109 shared state */
    {0x7400000, 0x36000},  /* r109 executable hooks */
};

struct maia_layout {
    void *mapping[MAIA_RANGE_COUNT];
    int error[MAIA_RANGE_COUNT];
};

static void maia_layout_release(struct maia_layout *layout)
{
    for (unsigned i = 0; i < MAIA_RANGE_COUNT; ++i) {
        if (layout->mapping[i] != NULL) {
            munmap(layout->mapping[i], ranges[i].length);
            layout->mapping[i] = NULL;
        }
    }
}

static int maia_layout_reserve(uintptr_t base, struct maia_layout *layout)
{
    long page = sysconf(_SC_PAGESIZE);
    int complete = 1;
    for (unsigned i = 0; i < MAIA_RANGE_COUNT; ++i) {
        layout->mapping[i] = NULL;
        layout->error[i] = 0;
        if (page != 4096 || !base || base % (uintptr_t)page ||
            base > UINTPTR_MAX - ranges[i].offset - ranges[i].length) {
            layout->error[i] = EINVAL;
            complete = 0;
            continue;
        }
        void *address = (void *)(base + ranges[i].offset);
        void *result = mmap(address, ranges[i].length, PROT_NONE,
                            MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
        if (result == MAP_FAILED) {
            layout->error[i] = errno;
            complete = 0;
        } else if (result != address) {
            /* Old kernels may ignore NOREPLACE and choose a different hint. */
            munmap(result, ranges[i].length);
            layout->error[i] = EEXIST;
            complete = 0;
        } else {
            layout->mapping[i] = result;
        }
    }
    if (!complete)
        maia_layout_release(layout);
    return complete;
}
