#!/usr/bin/env python3
"""Audit r109 stock/preload layout. Emit addresses and counts only."""
import argparse
import hashlib
import json
from pathlib import Path
from elftools.elf.elffile import ELFFile

STOCK_SHA = 'b6584cba76e416e432ad202509099d34373dc2c3d6a8fb625f5678bf0193b508'
R109_STOCK_FONTS_SHA = '431e5992652e98fc58cc322ab2eb7d10e23c976562fa5273d31f19dc2649eb14'
RELATIVE = 1027
PAGE = 4096

def roundup(n):
    return (n + PAGE - 1) & -PAGE

def identity(path, expected):
    with path.open('rb') as stream:
        digest = hashlib.sha256()
        for chunk in iter(lambda: stream.read(65536), b''):
            digest.update(chunk)
        if digest.hexdigest() != expected:
            raise ValueError(f'Unexpected native executable: {path}')

def ranges(original, modified):
    if len(original) != len(modified):
        raise ValueError('Segment sizes differ')
    start = None
    for index, (before, after) in enumerate(zip(original, modified)):
        if before != after and start is None:
            start = index
        elif before == after and start is not None:
            yield start, index
            start = None
    if start is not None:
        yield start, len(original)

def changes(before, after):
    if before.num_relocations() != after.num_relocations():
        raise ValueError('Unexpected relocation count')
    for a, b in zip(before.iter_relocations(), after.iter_relocations()):
        same_target = (a['r_offset'], a['r_info']) == (b['r_offset'], b['r_info'])
        if not same_target:
            raise ValueError('Unexpected relocation target change')
        if a['r_addend'] != b['r_addend']:
            if b['r_info_type'] != RELATIVE:
                raise ValueError('Only relative native relocations are supported')
            yield a['r_offset'], a['r_addend'], b['r_addend']

def inspect(stock, native):
    original = [s for s in stock.iter_segments() if s['p_type'] == 'PT_LOAD']
    modified = [s for s in native.iter_segments() if s['p_type'] == 'PT_LOAD']
    if len(original) != 2 or len(modified) != 3:
        raise ValueError('Unexpected ELF segment layout')
    old_code, old_data = original
    new_code, new_data, extension = modified
    plans = []
    for old, new, label in ((old_code, new_code, 'existing RX extension'),
                            (old_data, new_data, 'r109 shared state extension')):
        if old['p_vaddr'] != new['p_vaddr'] or old['p_flags'] != new['p_flags']:
            raise ValueError('Existing segment layout changed unexpectedly')
        current_end = old['p_vaddr'] + old['p_memsz']
        needed_end = new['p_vaddr'] + new['p_memsz']
        plans.append({'purpose':label, 'from':hex(current_end), 'to':hex(needed_end),
                      'new_pages_from':hex(roundup(current_end)), 'new_pages_to':hex(roundup(needed_end))})
    plans.append({'purpose':'r109 executable hooks', 'from':hex(extension['p_vaddr']),
                  'to':hex(extension['p_vaddr'] + extension['p_memsz']),
                  'new_pages_from':hex(extension['p_vaddr']),
                  'new_pages_to':hex(roundup(extension['p_vaddr'] + extension['p_memsz']))})
    relocs = list(changes(stock.get_section_by_name('.rela.dyn'), native.get_section_by_name('.rela.dyn')))
    section_summary = {}
    for name in ('.text','.rodata','.data','.got','.got.plt','.init_array'):
        first, second = stock.get_section_by_name(name), native.get_section_by_name(name)
        if first is None or second is None:
            raise ValueError(f'Missing section: {name}')
        spans = list(ranges(first.data(), second.data()))
        section_summary[name] = {'changed_bytes':sum(end-start for start,end in spans),
                                 'changed_ranges':len(spans)}
    init = next(tag['d_ptr'] for tag in native.get_section_by_name('.dynamic').iter_tags()
                if tag['d_tag'] == 'DT_INIT')
    return {'mapped_extensions':plans, 'section_summary':section_summary,
            'relative_relocations':[{'slot':hex(slot), 'stock_target':hex(before), 'r109_target':hex(after)}
                                    for slot,before,after in relocs],
            'r109_initializer':hex(init)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stock', type=Path, required=True)
    parser.add_argument('--r109', type=Path, required=True)
    args = parser.parse_args()
    identity(args.stock, STOCK_SHA)
    identity(args.r109, R109_STOCK_FONTS_SHA)
    with args.stock.open('rb') as a, args.r109.open('rb') as b:
        print(json.dumps(inspect(ELFFile(a), ELFFile(b)), indent=2))

if __name__ == '__main__':
    main()
