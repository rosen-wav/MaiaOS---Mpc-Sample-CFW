# Stock startup diagnostic

From this directory, use Zig 0.14.1 to build the ARM64 probe for the
MPC Sample stock firmware 1.3.0.12.

```sh
MPC_ZIG=/path/to/zig sh build.sh maia-stock-probe.aarch64.so
cc -std=c11 -O2 -Wall -Wextra -Werror test_layout.c -o /tmp/maia-test-layout
/tmp/maia-test-layout
```

The probe records whether audio and control surface traffic passes through
ALSA. It checks whether the legacy address ranges can be reserved without
replacing existing mappings and releases every reservation afterwards.
It contains no firmware executable, binary delta, or production hooks.

The included layout.json is a report from a comparison with the legacy
r109 native reference. To regenerate it locally, install pyelftools and run
audit_native_layout.py with the verified stock and r109 references.
Keep both reference executables private.
