#!/bin/sh
set -eu
src=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
zig=${MPC_ZIG:-zig}
"$zig" cc -target aarch64-linux-gnu.2.31 -std=c11 -O2 -Wall -Wextra -Werror \
  -shared -fPIC -fvisibility=hidden "$src/probe.c" -ldl -pthread -o "$1"
