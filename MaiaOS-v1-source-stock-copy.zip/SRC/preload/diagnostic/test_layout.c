#include "layout_reservation.c"
#include <assert.h>
#include <stdio.h>
int main(void)
{
    struct maia_layout layout;
    void *temp = mmap(NULL, 0x7500000, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    assert(temp != MAP_FAILED);
    uintptr_t base = (uintptr_t)temp;
    assert(!munmap(temp, 0x7500000));
    assert(maia_layout_reserve(base, &layout));
    for (unsigned i = 0; i < MAIA_RANGE_COUNT; ++i)
        assert(layout.mapping[i] == (void *)(base + ranges[i].offset));
    maia_layout_release(&layout);

    char *occupied = mmap((void *)(base + ranges[1].offset), 4096, PROT_READ | PROT_WRITE,
                          MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
    assert(occupied == (void *)(base + ranges[1].offset));
    *occupied = 42;
    assert(!maia_layout_reserve(base, &layout));
    assert(layout.error[1] == EEXIST && *occupied == 42);
    assert(!layout.mapping[0] && !layout.mapping[1] && !layout.mapping[2]);
    assert(!munmap(occupied, 4096));
    assert(maia_layout_reserve(base, &layout));
    maia_layout_release(&layout);
    puts("Three ranges reserved; occupied mapping preserved and partial reservations released");
}
