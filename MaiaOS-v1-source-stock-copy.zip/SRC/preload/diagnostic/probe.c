#define _GNU_SOURCE
#include <dlfcn.h>
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "layout_reservation.c"

typedef long (*pcm_write_fn)(void *, const void *, unsigned long);
typedef long (*midi_read_fn)(void *, void *, size_t);
typedef long (*midi_tread_fn)(void *, struct timespec *, void *, size_t);
typedef const char *(*midi_name_fn)(void *);

#ifndef MAIA_EVENTS_PATH
#define MAIA_EVENTS_PATH "/run/maia-stock-probe.events"
#endif

#ifndef MAIA_STOCK_PATH
#define MAIA_STOCK_PATH "/usr/bin/MPC Sample"
#endif

static int is_stock_process;
static pcm_write_fn pcm_write;
static midi_read_fn midi_read;
static midi_tread_fn midi_tread;
static midi_name_fn midi_name;
static atomic_uint audio_frames, surface_bytes, midi_bytes;
static _Atomic(uintptr_t) surface_handle;
static int surface_card = -1;
static uintptr_t stock_base;

static int capture_main_base(struct dl_phdr_info *image, size_t size, void *context)
{
    (void)size;
    (void)context;
    if (image->dlpi_name && image->dlpi_name[0])
        return 0;
    stock_base = (uintptr_t)image->dlpi_addr;
    return 1;
}

static void log_line(int fd, const char *key, unsigned value)
{
    char line[96];
    int size = snprintf(line, sizeof line, "%s=%u\n", key, value);
    if (size > 0 && (size_t)size < sizeof line)
        (void)write(fd, line, (size_t)size);
}

static void *report(void *unused)
{
    (void)unused;
    int fd = open(MAIA_EVENTS_PATH, O_WRONLY | O_APPEND | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0)
        return NULL;
    struct maia_layout layout;
    int free_ranges = maia_layout_reserve(stock_base, &layout);
    maia_layout_release(&layout);
    log_line(fd, "layout_free", free_ranges);
    log_line(fd, "layout_rx_extension_errno", layout.error[0]);
    log_line(fd, "layout_shared_state_errno", layout.error[1]);
    log_line(fd, "layout_hook_code_errno", layout.error[2]);
    log_line(fd, "preload_ready", !!pcm_write && !!midi_name && (!!midi_read || !!midi_tread));
    log_line(fd, "surface_card_found", surface_card >= 0);
    unsigned sent_audio = 0, sent_surface = 0, sent_midi = 0;
    for (unsigned i = 0; i < 750; ++i) {
        if (!sent_audio && (sent_audio = atomic_load_explicit(&audio_frames, memory_order_relaxed)))
            log_line(fd, "audio_frames", sent_audio);
        if (!sent_midi && (sent_midi = atomic_load_explicit(&midi_bytes, memory_order_relaxed)))
            log_line(fd, "raw_midi_bytes", sent_midi);
        if (!sent_surface && (sent_surface = atomic_load_explicit(&surface_bytes, memory_order_relaxed)))
            log_line(fd, "surface_bytes", sent_surface);
        if (sent_audio && sent_surface)
            break;
        const struct timespec delay = {0, 100000000};
        nanosleep(&delay, NULL);
    }
    close(fd);
    return NULL;
}

__attribute__((constructor)) static void initialize(void)
{
    struct stat current, stock;
    if (stat("/proc/self/exe", &current) || stat(MAIA_STOCK_PATH, &stock) ||
        current.st_dev != stock.st_dev || current.st_ino != stock.st_ino)
        return;
    is_stock_process = 1;
    dl_iterate_phdr(capture_main_base, NULL);
    pcm_write = (pcm_write_fn)dlsym(RTLD_NEXT, "snd_pcm_writei");
    midi_read = (midi_read_fn)dlsym(RTLD_NEXT, "snd_rawmidi_read");
    midi_tread = (midi_tread_fn)dlsym(RTLD_NEXT, "snd_rawmidi_tread");
    midi_name = (midi_name_fn)dlsym(RTLD_NEXT, "snd_rawmidi_name");
    FILE *cards = fopen("/proc/asound/cards", "r");
    if (cards) {
        char line[256];
        while (fgets(line, sizeof line, cards)) {
            int card;
            char name[48];
            if (sscanf(line, " %d [%47[^] ]", &card, name) == 2 && !strcmp(name, "Surface")) {
                surface_card = card;
                break;
            }
        }
        fclose(cards);
    }
    pthread_t worker;
    if (!pthread_create(&worker, NULL, report, NULL))
        pthread_detach(worker);
}

static void remember_first(atomic_uint *sample, long n)
{
    unsigned empty = 0;
    if (n > 0)
        atomic_compare_exchange_strong_explicit(sample, &empty, (unsigned)n,
                                                memory_order_relaxed, memory_order_relaxed);
}

static void midi_observe(void *handle, long count)
{
    if (count <= 0)
        return;
    remember_first(&midi_bytes, count);
    if (atomic_load_explicit(&surface_bytes, memory_order_relaxed) || !midi_name)
        return;
    uintptr_t known = atomic_load_explicit(&surface_handle, memory_order_relaxed);
    if (known && known != (uintptr_t)handle)
        return;
    if (!known) {
        const char *name = midi_name(handle);
        if (!name)
            return;
        int card = -1;
        if (!strstr(name, "Surface") &&
            !(surface_card >= 0 &&
              (sscanf(name, "hw:%d", &card) == 1 || sscanf(name, "hw:CARD=%d", &card) == 1) &&
              card == surface_card))
            return;
        atomic_store_explicit(&surface_handle, (uintptr_t)handle, memory_order_relaxed);
    }
    remember_first(&surface_bytes, count);
}

__attribute__((visibility("default"))) long snd_pcm_writei(void *pcm, const void *data, unsigned long frames)
{
    pcm_write_fn next = pcm_write;
    if (!next)
        next = (pcm_write_fn)dlsym(RTLD_NEXT, "snd_pcm_writei");
    if (!next)
        return -38;
    long result = next(pcm, data, frames);
    if (is_stock_process)
        remember_first(&audio_frames, result);
    return result;
}

__attribute__((visibility("default"))) long snd_rawmidi_read(void *handle, void *buffer, size_t size)
{
    midi_read_fn next = midi_read;
    if (!next)
        next = (midi_read_fn)dlsym(RTLD_NEXT, "snd_rawmidi_read");
    if (!next)
        return -38;
    long result = next(handle, buffer, size);
    if (is_stock_process)
        midi_observe(handle, result);
    return result;
}

__attribute__((visibility("default"))) long snd_rawmidi_tread(void *handle, struct timespec *time,
                                                             void *buffer, size_t size)
{
    midi_tread_fn next = midi_tread;
    if (!next)
        next = (midi_tread_fn)dlsym(RTLD_NEXT, "snd_rawmidi_tread");
    if (!next)
        return -38;
    long result = next(handle, time, buffer, size);
    if (is_stock_process)
        midi_observe(handle, result);
    return result;
}
