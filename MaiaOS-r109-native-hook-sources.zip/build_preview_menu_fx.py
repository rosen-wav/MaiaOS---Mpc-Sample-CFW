#!/usr/bin/env python3
"""Generate the r109 preview, menu and FX instructions from verified inputs."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import struct

from elftools.elf.elffile import ELFFile

STOCK_SHA = "b6584cba76e416e432ad202509099d34373dc2c3d6a8fb625f5678bf0193b508"
PREVIEW_SITES = (0x1605B78, 0x1605D0C, 0x1606158, 0x16062EC, 0x1606588, 0x160671C)
MENU_SITE = 0x16237A4
FX_SITE = 0x28A1618


def branch_link(site, target):
    displacement = target - site
    if displacement % 4 or not -(1 << 27) <= displacement < (1 << 27):
        raise ValueError("FX gate is out of range")
    return 0x94000000 | ((displacement // 4) & 0x3FFFFFF)


def generate(stock, loader):
    if sha256(stock).hexdigest() != STOCK_SHA:
        raise ValueError("Expected the verified stock executable for firmware 1.3.0.12")
    with loader.open("rb") as stream:
        elf = ELFFile(stream)
        if elf["e_machine"] != "EM_AARCH64":
            raise ValueError("Expected an ARM64 loader")
        symbols = elf.get_section_by_name(".symtab")
        gates = symbols.get_symbol_by_name("pc_gate_fx_chain") if symbols else None
        if not gates or len(gates) != 1 or gates[0]["st_shndx"] == "SHN_UNDEF":
            raise ValueError("Expected one defined pc_gate_fx_chain symbol")
        target = gates[0]["st_value"]
    changes = [(site, 0x52800001) for site in PREVIEW_SITES]  # MOV W1, #0
    changes += [(MENU_SITE, 0xD503201F), (FX_SITE, branch_link(FX_SITE, target))]
    return [{"offset": site, "data": struct.pack("<I", word).hex()} for site, word in changes]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stock", type=Path, required=True)
    parser.add_argument("--loader", type=Path, required=True, help="Linked ARM64 loader ELF")
    args = parser.parse_args()
    try:
        changes = generate(args.stock.read_bytes(), args.loader)
    except (OSError, ValueError) as error:
        parser.exit(1, f"{error}\n")
    print(json.dumps(changes, indent=2))


if __name__ == "__main__":
    main()
