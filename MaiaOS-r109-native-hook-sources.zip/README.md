# MaiaOS r109 native source work

This source bundle reconstructs the 28 instruction sites where the historical
integrator left the original instruction untouched while r109 changed it.
The generated project/note, bounce and performance code blocks and all 28
entry instructions were verified against the historical r109 reference.

The scripts take a local stock 1.3.0.12 executable with a pinned SHA-256.
They require Zig 0.14.1 for ARM64 assembly and pyelftools for reading linked
symbols. The performance builder also uses the historical
performance-gates.S source from the Editorial r38.1 development archive.
The preview/menu/FX builder takes the linked loader ELF.

Run each script with --help for its inputs. These are development inputs
to the native build. They do not assemble a full application or an SD card.
Do not distribute the generated intermediates as standalone binaries.
