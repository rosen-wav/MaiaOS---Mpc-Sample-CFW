#!/usr/bin/env python3
"""Compile the r109 bounce gates with the original instructions read locally."""
import argparse
from hashlib import sha256
from pathlib import Path
import struct
import subprocess

STOCK_SHA = "b6584cba76e416e432ad202509099d34373dc2c3d6a8fb625f5678bf0193b508"
SITES = {"export": 0x18C54D0, "enter": 0x18B97C0, "block": 0x18B984C, "collect": 0x18B98C0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stock", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--zig", default="zig")
    args = parser.parse_args()
    stock = args.stock.read_bytes()
    if sha256(stock).hexdigest() != STOCK_SHA:
        parser.error("Expected stock firmware 1.3.0.12")
    args.output.mkdir()
    source = Path(__file__).with_name("bounce-gates.S").read_text()
    replays = "".join(
        f".equ replay_{name}, {struct.unpack_from('<I', stock, site)[0]:#x}\n"
        for name, site in SITES.items()
    )
    assembly = args.output / "bounce.S"
    assembly.write_text(replays + source)
    layout = args.output / "bounce.ld"
    layout.write_text(
        "ENTRY(bounce_export_gate)\n"
        "SECTIONS { . = 0x7434200; .text : { *(.text .text.*) } "
        "/DISCARD/ : { *(.comment .note* .eh_frame .eh_frame_hdr) } }\n"
        + "".join(f"native_{name}_resume = {site + 4:#x};\n" for name, site in SITES.items())
    )
    obj = args.output / "bounce.o"
    elf = args.output / "bounce.elf"
    subprocess.run([args.zig, "cc", "-target", "aarch64-linux-none", "-c", str(assembly),
                    "-o", str(obj)], check=True)
    subprocess.run([args.zig, "ld.lld", "-T", str(layout), str(obj), "-o", str(elf)],
                   check=True)


if __name__ == "__main__":
    main()
