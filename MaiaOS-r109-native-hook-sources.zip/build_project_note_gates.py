#!/usr/bin/env python3
"""Build the four r109 project and note hooks from local stock and assembly."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import struct
import subprocess

from elftools.elf.elffile import ELFFile

STOCK_SHA = "b6584cba76e416e432ad202509099d34373dc2c3d6a8fb625f5678bf0193b508"
SITES = {
    "project_notify": 0x150641C,
    "note_first": 0x1A3FFB4,
    "note_second": 0x1A40134,
    "note_third": 0x1A402D4,
}
ADDRESS = 0x742A180


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stock", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--zig", default="zig")
    args = parser.parse_args()
    stock = args.stock.read_bytes()
    if sha256(stock).hexdigest() != STOCK_SHA:
        parser.error("Expected stock firmware 1.3.0.12")
    args.output.mkdir()
    source = Path(__file__).with_name("project-note-gates.S").read_text()
    symbols = "".join(
        f".equ replay_{name}, {struct.unpack_from('<I', stock, site)[0]:#x}\n"
        for name, site in SITES.items()
    )
    assembly = args.output / "project-note.S"
    assembly.write_text(symbols + source)
    layout = args.output / "project-note.ld"
    layout.write_text(
        f"ENTRY(maia_project_notify)\nSECTIONS {{ . = {ADDRESS:#x}; .text : {{ *(.text) }} }}\n"
        "project_state_page = 0x72a6000;\nlegacy_state_page = 0x72a4000;\n"
        + "".join(f"resume_{name} = {site + 4:#x};\n" for name, site in SITES.items())
    )
    obj = args.output / "project-note.o"
    elf = args.output / "project-note.elf"
    subprocess.run([args.zig, "cc", "-target", "aarch64-linux-none", "-c", str(assembly),
                    "-o", str(obj)], check=True)
    subprocess.run([args.zig, "ld.lld", "-T", str(layout), str(obj), "-o", str(elf)],
                   check=True)
    patches = []
    with elf.open("rb") as stream:
        table = ELFFile(stream).get_section_by_name(".symtab")
        for name, site in SITES.items():
            target = table.get_symbol_by_name(f"maia_{name}")[0]["st_value"]
            delta = target - site
            if delta % 4 or not -(1 << 27) <= delta < (1 << 27):
                raise ValueError(f"Branch to {name} out of range")
            branch = struct.pack("<I", 0x14000000 | ((delta // 4) & 0x3FFFFFF))
            patches.append({"offset": site, "data": branch.hex()})
    (args.output / "project-note-sites.json").write_text(json.dumps(patches, indent=2) + "\n")


if __name__ == "__main__":
    main()
